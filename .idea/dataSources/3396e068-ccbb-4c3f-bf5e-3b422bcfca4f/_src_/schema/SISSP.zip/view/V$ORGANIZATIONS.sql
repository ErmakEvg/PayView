CREATE VIEW V$ORGANIZATIONS AS SELECT   CODE,
            RID,
            VALUE,
            PARENT_CODE,
            ORG_TYPE,
            BANK,
            CORRESPONDENT_ACCT,
            FLAG,
            START_DATE,
            CLOSE_DATE,
            ENTRY_DATE,
            ENTERED_BY,
            END_DATE,
            STAGE
     FROM   ORGANIZATIONS
/
