CREATE VIEW INV_SPS_LIST2 AS SELECT a.pid,
          a.pik,
          A.SURNAME,
          A.NAME,
          A.PATNAME,
          A.BIRTH_DATE,
          A.SEX,
          A.DEATH_DATE,
          A.DEATH_REASON,
          A.DEATH_CERTIFICATE,
          cit.VALUE AS city,
          str.VALUE as street,
          a.house,
          a.house_x,
          a.appt,
          a.ADVICE_TYPE
     FROM (SELECT a.pid,
                  a.pik,
                  A.SURNAME,
                  A.NAME,
                  A.PATNAME,
                  A.BIRTH_DATE,
                  A.SEX,
                  A.DEATH_DATE,
                  A.DEATH_REASON,
                  A.DEATH_CERTIFICATE,
                  b.site,
                  b.street,
                  b.house,
                  b.house_x,
                  b.appt,
                  C.ADVICE_TYPE
             FROM SISSP.PERSON a,
                  SISSP.ADDRESS b,
                  SISSP.MRAK_OPINION_ADVICE c
            WHERE     A.PID = B.PID
                  AND a.rid IN (SELECT a.rid
                                  FROM sissp.person a,
                                       (  SELECT pid, MAX (A.ENTRY_DATE) AS b
                                            FROM sissp.person a
                                        GROUP BY a.pid) b
                                 WHERE a.pid = B.PID AND A.ENTRY_DATE = b.b)
                  AND (    b.address_type IN (2)
                       AND NOT EXISTS
                                  (SELECT k.pid
                                     FROM sissp.person k
                                    WHERE     k.pid = a.pid
                                          AND b.address_type IN (1, 3)))
                  AND (b.record_end <= SYSDATE OR b.record_end IS NULL)
                  AND b.rid IN (SELECT a.rid
                                  FROM sissp.address a,
                                       (  SELECT pid, MAX (A.ENTRY_DATE) AS b
                                            FROM sissp.address a
                                        GROUP BY a.pid) b
                                 WHERE a.pid = B.PID AND A.ENTRY_DATE = b.b)
                  AND C.PID = a.pid
                  AND C.ADVICE_TYPE IN (11, 12, 13, 14)
           UNION
           (SELECT a.pid,
                   a.pik,
                   A.SURNAME,
                   A.NAME,
                   A.PATNAME,
                   A.BIRTH_DATE,
                   A.SEX,
                   A.DEATH_DATE,
                   A.DEATH_REASON,
                   A.DEATH_CERTIFICATE,
                   b.site,
                   b.street,
                   b.house,
                   b.house_x,
                   b.appt,
                   C.ADVICE_TYPE
              FROM SISSP.PERSON a,
                   SISSP.ADDRESS b,
                   SISSP.MRAK_OPINION_ADVICE c
             WHERE     A.PID = B.PID
                   AND a.rid IN (SELECT a.rid
                                   FROM sissp.person a,
                                        (  SELECT pid, MAX (A.ENTRY_DATE) AS b
                                             FROM sissp.person a
                                         GROUP BY a.pid) b
                                  WHERE a.pid = B.PID AND A.ENTRY_DATE = b.b)
                   AND (b.address_type IN (1.3))
                   AND (b.record_end <= SYSDATE OR b.record_end IS NULL)
                   AND b.rid IN (SELECT a.rid
                                   FROM sissp.address a,
                                        (  SELECT pid, MAX (A.ENTRY_DATE) AS b
                                             FROM sissp.address a
                                         GROUP BY a.pid) b
                                  WHERE a.pid = B.PID AND A.ENTRY_DATE = b.b)
                   AND C.PID = a.pid
                   AND C.ADVICE_TYPE IN (11, 12, 13, 14))) a left join SISSP.STATE_DIVISION cit on a.SITE=cit.code
                   left join SISSP.STATE_DIVISION str on a.street=str.code
/
