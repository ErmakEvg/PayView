CREATE VIEW INV_SPISOK_INV AS SELECT   PERS1.PID,
            PERS1.Lik,
            PERS1.surname,
            PERS1.name,
            PERS1.patname,
            PERS1.birth_date,
            PERS1.sex,
            PERS1.DEATH_DATE,
            REASON1.VALUE AS DEATH_REASON,
            PERS1.death_certificate
     FROM         (SELECT   DISTINCT PID FROM SISSP.INV_GROUPS) mrak
               INNER JOIN
                  (SELECT   DISTINCT PERS2.PID,
                                     PERS2.Lik,
                                     PERS2.surname,
                                     PERS2.name,
                                     PERS2.patname,
                                     PERS2.birth_date,
                                     PERS2.sex,
                                     PERS2.DEATH_DATE,
                                     PERS2.death_certificate,
                                     PERS2.DEATH_REASON
                     FROM   person PERS2
                    WHERE   PERS2.STAGE IS NULL) PERS1
               ON mrak.pid = PERS1.pid
            LEFT JOIN
               (SELECT   DISTINCT REASON2.code, REASON2.VALUE
                  FROM   REF_DEATH_REASON REASON2) REASON1
            ON PERS1.DEATH_REASON = REASON1.code
    WHERE   (SELECT   COUNT (C.CID)
               FROM   (   (SELECT   CID, PID
                             FROM   SISSP.CASE_PERSON
                            WHERE   STAGE IS NULL
                                    AND role IN (51, 53, 62, 65, 75)) CP
                       INNER JOIN
                          (SELECT   CID
                             FROM   SISSP.CASE
                            WHERE   STAGE IS NULL AND pr_arch = 0) C
                       ON C.CID = CP.CID)
              WHERE   CP.PID = PERS1.PID) > 0
/
