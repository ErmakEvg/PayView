CREATE VIEW INV_PENSION AS SELECT   persons.PID,
              MONTH_AMOUNT,
              STATUS.VALUE AS ALLOC_STATUS,
              period_START,
              prichina.VALUE AS reason,
              status_reason,
              step_start
       FROM                  (  SELECT   PID FROM SISSP.INV_SPISOK_INV) persons
                          LEFT JOIN
                             (SELECT   DISTINCT PID, ALLOCATION_RID
                                FROM   SISSP.ALLOCATION_PERSON
                               WHERE       STAGE IS NULL
                                       AND role IN (51, 53)
                                       AND close_date IS NULL) alloc_pers
                          ON persons.PID = alloc_pers.PID
                       LEFT JOIN
                          (  SELECT   RID,
                                      cid,
                                      ALLOC_STATUS,
                                      status_reason,
                                      step_start
                               FROM   SISSP.ALLOCATION
                              WHERE   STAGE IS NULL AND close_date IS NULL
                                      AND (ALLOC_CODE BETWEEN 20 AND 385
                                           OR ALLOC_CODE IN (1222, 1223, 1215))
                           ORDER BY   rid) alloc
                       ON alloc.RID = ALLOC_PERS.ALLOCATION_RID
                    LEFT JOIN
                       (  SELECT   SUM (MONTH_AMOUNT) AS MONTH_AMOUNT,
                                   MIN (PERIOD_START) AS PERIOD_START,
                                   MIN (ALLOCATION_RID) AS ALLOCATION_RID
                            FROM   SISSP.CALC_AMOUNT
                           WHERE   STAGE IS NULL AND history_flag IS NULL
                                   AND (ALLOC_CODE BETWEEN 20 AND 385
                                        OR ALLOC_CODE IN (1222, 1223, 1215))
                                   AND PERIOD_START >=
                                         ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -2)
                        GROUP BY   RESULT_PAYMENT_RID) calc
                    ON ALLOC.RID = CALC.ALLOCATION_RID
                 LEFT JOIN
                    (  SELECT   CODE, VALUE FROM SISSP.REF_ALLOC_STATUS) status
                 ON status.code = alloc.ALLOC_STATUS
              LEFT JOIN
                 (  SELECT   code, VALUE FROM alloc_status_change_reason)
                 prichina
              ON prichina.code = alloc.status_reason
   ORDER BY   pid, period_start
/
