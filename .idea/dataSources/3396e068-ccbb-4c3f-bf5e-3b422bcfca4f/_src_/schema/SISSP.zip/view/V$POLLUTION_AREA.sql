CREATE VIEW V$POLLUTION_AREA AS SELECT "CODE",
          "RID",
          "STATE_CODE",
          "PARENT_CODE",
          "LEVEL_CODE",
          "POLLUTION_AREA",
          "PARENT_NAME",
          "STAGE",
          "VALUE",
          "START_DATE",
          "END_DATE",
          "ENTRY_DATE",
          "ENTERED_BY",
          "CLOSE_DATE"
     FROM (SELECT sd.code,
                  s.rid,
                  s.state_code,
                  sd.parent_code,
                  sd.level_code,
                  s.pollution_area,
                  (SELECT VALUE
                     FROM state_division
                    WHERE code = sd.parent_code)
                     parent_name,
                  sd.stage,
                  sd.VALUE VALUE,
                  s.START_DATE,
                  s.END_DATE,
                  s.ENTRY_DATE,
                  s.ENTERED_BY,
                  s.CLOSE_DATE
             FROM state_division sd, ST_DIVISION_POLLUTION_AREA s
            WHERE sd.code = s.state_code(+)) TBL
    WHERE TBL.LEVEL_CODE BETWEEN 2 AND 5 OR TBL.LEVEL_CODE BETWEEN 11 AND 21
/
