CREATE VIEW INV_TSSR AS SELECT PERSONS.PID,
          tssr.VALUE AS CODE_TSSR,
          models.model,
          PARAM.TSSR_START,
          PARAM.TSSR_END,
          PARAM.AMOUNT_UNITS
     FROM (SELECT PID FROM SISSP.INV_SPISOK_INV) PERSONS
          LEFT JOIN (SELECT PID, ALLOCATION_RID
                       FROM SISSP.ALLOCATION_PERSON
                      WHERE STAGE IS NULL) ALLOC_PERS
             ON PERSONS.PID = ALLOC_PERS.PID
          INNER JOIN (SELECT RID,
                             ALLOC_STATUS,
                             CID,
                             ALLOC_CODE,
                             STEP_START
                        FROM SISSP.ALLOCATION
                       WHERE STAGE IS NULL AND ALLOC_CODE = 1080) ALLOC
             ON ALLOC.RID = ALLOC_PERS.ALLOCATION_RID
          LEFT JOIN (SELECT *
                       FROM SISSP.QUEUE_TSSR
                      WHERE STAGE IS NULL) Q
             ON Q.ALLOCATION_RID = ALLOC.RID
          LEFT JOIN SISSP.PARAM_ADDR_HELP PARAM ON PARAM.CID = ALLOC.CID
          LEFT JOIN SISSP.W$MRAK_DESIRED_TSSR mrak
             ON MRAK.RID = PARAM.RID_TSSR
          LEFT JOIN (SELECT CODE, model FROM SISSP.TSSR_MODELS) models
             ON models.CODE = mrak.Code_model
          LEFT JOIN (SELECT CODE, VALUE FROM SISSP.REF_TSSR) tssr
             ON tssr.code = q.CODE_TSSR
/
