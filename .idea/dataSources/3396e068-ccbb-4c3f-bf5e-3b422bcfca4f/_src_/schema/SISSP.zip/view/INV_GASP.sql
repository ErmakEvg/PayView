CREATE VIEW INV_GASP AS SELECT   PERSONS.PID,
              APPL.CID,
              APPL.APPLICATION_DATE,
              req.VALUE AS REQUEST_REASON,
              DECIS.DATE_DECISIONS,
              DECIS.PR_FINAL,
              status.VALUE AS ALLOC_STATUS,
              ALLCODE.VALUE AS ALLOC_CODE,
              ALLOC.STEP_START,
              ESTIMATION.ESTIMATION_DATE,
              PARAM.COUNT_MONTHS,
              PARAM.SUMMA,
              DECIS.TEXT
       FROM                              (SELECT   PID
                                            FROM   SISSP.INV_SPISOK_INV)
                                         PERSONS
                                      LEFT JOIN
                                         (SELECT   PID, ALLOCATION_RID
                                            FROM   SISSP.ALLOCATION_PERSON
                                           WHERE   STAGE IS NULL) ALLOC_PERS
                                      ON PERSONS.PID = ALLOC_PERS.PID
                                   INNER JOIN
                                      (  SELECT   RID,
                                                  ALLOC_STATUS,
                                                  CID,
                                                  ALLOC_CODE,
                                                  STEP_START
                                           FROM   SISSP.ALLOCATION
                                          WHERE   STAGE IS NULL
                                                  AND ALLOC_CODE BETWEEN 751
                                                                     AND  754
                                                  AND step_start >=
                                                        ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -2)
                                       ORDER BY   cid, step_start) ALLOC
                                   ON ALLOC.RID = ALLOC_PERS.ALLOCATION_RID
                                LEFT JOIN
                                   (SELECT   *
                                      FROM   SISSP.APPLICATION
                                     WHERE   STAGE IS NULL) APPL
                                ON APPL.CID = ALLOC.CID
                             LEFT JOIN
                                (SELECT   *
                                   FROM   SISSP.ALLOC_DATE_ESTIMATION
                                  WHERE   STAGE IS NULL) ESTIMATION
                             ON ESTIMATION.CID = ALLOC.CID
                          LEFT JOIN
                             SISSP.DECISIONS DECIS
                          ON DECIS.CID = ALLOC.CID
                       LEFT JOIN
                          SISSP.PARAM_ADDR_HELP PARAM
                       ON PARAM.CID = ALLOC.CID
                    LEFT JOIN
                       (  SELECT   CODE, VALUE FROM SISSP.ALLOCATIONS) ALLCODE
                    ON ALLCODE.CODE = ALLOC.ALLOC_CODE
                 LEFT JOIN
                    (  SELECT   CODE, VALUE FROM SISSP.REF_ALLOC_STATUS) status
                 ON status.code = alloc.ALLOC_STATUS
              LEFT JOIN
                 (  SELECT   CODE, VALUE FROM SISSP.ReQUESTS) req
              ON req.code = APPL.REQUEST_REASON
   ORDER BY   pid, step_start
/
