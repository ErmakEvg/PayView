CREATE VIEW INV_TSSR_INV AS SELECT tssr.pid,
          tssr.code_tssr,
          tssr.code_mod,
          tssr.decision_date,
          tssr1.surrender_date,
          tssr.status
     FROM (SELECT C.CID
             FROM CASE C
            WHERE C.STAGE IS NULL AND C.CASE_STATUS = 1 AND c.country IS NULL) C,
          (SELECT DISTINCT (PERS.PID),
                           pers.pik,
                           pers.surname,
                           pers.name,
                           pers.patname,
                           pers.birth_date,
                           pers.sex,
                           PERS.DEATH_DATE,
                           pers.death_certificate
             FROM person PERS
            WHERE pers.stage IS NULL) PERS,
          (SELECT cp.cid, cp.pid
             FROM case_person cp
            WHERE cp.stage IS NULL) cp,
          (SELECT tssr.rid,
                  tssr.pid,
                  tssr.code_tssr,
                  tssr.code_mod,
                  tssr.decision_date,
                  tssr.status
             FROM queue_tssr tssr
            WHERE tssr.status = 9) tssr,
          (SELECT tssr1.rid_queue_tssr, tssr1.surrender_date
             FROM tssr_move tssr1
            WHERE tssr1.stage IS NULL) tssr1,
          (SELECT mrak1.pid, MRAK1.RID
             FROM mrak_opinion mrak1
            WHERE mrak1.STAGE IS NULL AND mrak1.record_end IS NULL) mrak1,
          (SELECT DISTINCT inv.pid, inv.advice_type, inv.mrak_rid
             FROM mrak_opinion_advice inv
            WHERE inv.advice_type IN (11, 12, 13) AND stage IS NULL) inv
    WHERE     cp.cid = C.CID
          AND cp.pid = pers.pid
          AND cp.pid = inv.pid
          AND cp.pid = mrak1.pid
          AND inv.mrak_rid = mrak1.rid
          AND pers.pid = tssr.pid
          AND tssr.rid = TSSR1.RID_QUEUE_TSSR
/
