CREATE VIEW INV_TCSON AS SELECT ALLOC.cid,
          PERSons.PID,
          orgs.VALUE AS RESOURCE_ID,
          us.DATE_START,
          us.DATE_MADE,
          us.DATE_REFUSE,
          ust.VALUE AS SERVICE_TYPE
     FROM (SELECT PID FROM SISSP.INV_SPISOK_INV) PERSONS
          LEFT JOIN (SELECT PID, ALLOCATION_RID
                       FROM SISSP.ALLOCATION_PERSON
                      WHERE STAGE IS NULL) ALLOC_PERS
             ON PERSONS.PID = ALLOC_PERS.PID
          INNER JOIN (SELECT RID,
                             ALLOC_STATUS,
                             CID,
                             ALLOC_CODE,
                             STEP_START
                        FROM SISSP.ALLOCATION
                       WHERE STAGE IS NULL) ALLOC
             ON ALLOC.RID = ALLOC_PERS.ALLOCATION_RID
          INNER JOIN (SELECT *
                        FROM USLUGI_TCSON usl
                       WHERE usl.FL_REFUSE = 0) us
             ON us.CID = alloc.cid
          LEFT JOIN (SELECT uslt.code, uslt.VALUE
                       FROM TYPE_USLUG_TCSON uslt
                      WHERE uslt.stage IS NULL) ust
             ON us.code = ust.code
          LEFT JOIN (SELECT *
                       FROM queue Qu
                      WHERE Qu.STAGE IS NULL) Q
             ON Q.ALLOCATION_RID = alloc.rid
          LEFT JOIN (SELECT CODE, VALUE FROM SISSP.ORGANIZATIONS) orgs
             ON orgs.code = Q.ReSOURCE_ID
/
