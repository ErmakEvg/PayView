CREATE VIEW INV_DI_INV AS SELECT PERSONS.PID,
          Q.REGISTER_DATE,
          req.VALUE AS REQUEST_REASON,
          orgs.VALUE AS RESOURCE_ID,
          Q.residing_start,
          Q.residing_end,
          st.VALUE AS PENSION_HOUSE_SERVICE,
          Q.STATUS,
          Q.DECISION_DATE
     FROM (SELECT PID FROM SISSP.INV_SPISOK_INV) PERSONS
          LEFT JOIN (SELECT PID, ALLOCATION_RID
                       FROM SISSP.ALLOCATION_PERSON
                      WHERE STAGE IS NULL) ALLOC_PERS
             ON PERSONS.PID = ALLOC_PERS.PID
          INNER JOIN (SELECT RID,
                             ALLOC_STATUS,
                             CID,
                             ALLOC_CODE,
                             STEP_START
                        FROM SISSP.ALLOCATION
                       WHERE STAGE IS NULL) ALLOC
             ON ALLOC.RID = ALLOC_PERS.ALLOCATION_RID
          INNER JOIN
          (SELECT *
             FROM queue Qu
                  LEFT JOIN SISSP.ALLOCATIONS A ON Qu.QUEUE_TYPE = A.CODE
            WHERE     Qu.STAGE IS NULL
                  AND A.STAGE IS NULL
                  AND A.PARENT_CODE = 1070
                  AND (QU.STATUS = 5 OR QU.STATUS = 1)) Q
             ON Q.ALLOCATION_RID = alloc.rid
          LEFT JOIN (SELECT CODE, VALUE FROM SISSP.ORGANIZATIONS) orgs
             ON orgs.code = Q.ReSOURCE_ID
          LEFT JOIN (SELECT *
                       FROM SISSP.APPLICATION
                      WHERE STAGE IS NULL) APPL
             ON APPL.CID = ALLOC.CID
          LEFT JOIN (SELECT CODE, VALUE FROM SISSP.ReQUESTS) req
             ON req.code = APPL.REQUEST_REASON
          LEFT JOIN (SELECT st.Code, st.VALUE
                       FROM REF_PENSION_HOUSE_SERVICE st
                      WHERE st.stage IS NULL) st
             ON st.code = Q.PENSION_HOUSE_SERVICE
/
