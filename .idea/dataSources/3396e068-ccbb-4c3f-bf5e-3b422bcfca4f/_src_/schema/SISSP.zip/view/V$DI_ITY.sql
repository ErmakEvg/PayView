CREATE VIEW V$DI_ITY AS SELECT   "CODE",
              "RID",
              "PARENT_CODE",
              "ORG_TYPE",
              "STAGE",
              "FLAG",
              "CORRESPONDENT_ACCT",
              "TAX_ID",
              "VALUE",
              "START_DATE",
              "END_DATE",
              "ENTRY_DATE",
              "ENTERED_BY",
              "CLOSE_DATE",
              "SHORTNAME"
       FROM   ORGANIZATIONS
      WHERE   ORG_TYPE IN (10, 15)
   ORDER BY   VALUE
/
