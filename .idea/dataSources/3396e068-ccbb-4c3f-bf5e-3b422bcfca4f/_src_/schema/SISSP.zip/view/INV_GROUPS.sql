CREATE VIEW INV_GROUPS AS SELECT   p.PID,
            m.ADVICE_TYPE,
            m.LOSS_HEALTH,
            disreason.VALUE AS DIS_REASON,
            DISREASON_1.VALUE AS DIS_END_REASON,
            m.RECORD_START,
            m.RECORD_END,
            m.DIS_TERM
     FROM            (SELECT   MRAK_RID,
                               RECORD_START,
                               RECORD_END,
                               PID,
                               ADVICE_TYPE,
                               OPINION_TYPE,
                               STAGE,
                               DIS_END_REASON,
                               LOSS_HEALTH,
                               DIS_PERCENT,
                               DIS_REASON,
                               DIS_TERM
                        FROM   SISSP.MRAK_OPINION_ADVICE moa
                       WHERE   STAGE IS NULL
                               AND ADVICE_TYPE BETWEEN 11 AND 14) m
                  INNER JOIN
                     (SELECT   *
                        FROM   SISSP.PERSON
                       WHERE   stage IS NULL) p
                  ON p.pid = m.pid
               LEFT JOIN
                  SISSP.REF_DISABILITY_REASON disreason
               ON m.DIS_REASON = disreason.code
            LEFT JOIN
               SISSP.REF_DISABILITY_CANCEL disreason_1
            ON m.dis_end_reason = disreason_1.code

/
