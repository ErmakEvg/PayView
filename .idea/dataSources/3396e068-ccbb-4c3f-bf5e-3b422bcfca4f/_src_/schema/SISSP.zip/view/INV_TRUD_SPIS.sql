CREATE VIEW INV_TRUD_SPIS AS SELECT A.pid,
          B.VALUE AS activity,
          C.VALUE AS LABOR,
          A.PERIOD_START,
          A.PERIOD_END
     FROM (SELECT PID FROM SISSP.INV_SPISOK_INV) D
          INNER JOIN (SELECT *
                        FROM SISSP.ACTIVITY
                       WHERE STAGE IS NULL) A
             ON d.pid = a.pid
          LEFT JOIN SISSP.REF_ACTIVITY B ON A.ACTIVITY = B.CODE
          LEFT JOIN SISSP.LABOR_TYPE C ON C.CODE = A.LABOR
/
