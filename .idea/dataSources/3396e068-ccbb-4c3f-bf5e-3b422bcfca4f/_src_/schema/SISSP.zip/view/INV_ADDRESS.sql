CREATE VIEW INV_ADDRESS AS SELECT                                                /*+ NO_CPU_COSTING */
         DISTINCT spisok.PID,
                  obltype.VALUE AS OBLTYPE,
                  OBL1.VALUE AS OBLAST,
                  distype.VALUE AS DISTYPE,
                  DISTR1.VALUE AS DISTRICT,
                  CITTYPE.CATSHORTNAME AS CITTYPE,
                  CIT.VALUE AS CITY,
                  STRTYPE.CATSHORTNAME AS STRTYPE,
                  str.VALUE AS STREET,
                  addr.HOUSE,
                  addr.HOUSE_X,
                  addr.APPT
     FROM                              (SELECT   PID
                                          FROM   SISSP.INV_SPISOK_INV) spisok
                                    LEFT JOIN
                                       (SELECT   PID,
                                                 ADDRESS_TYPE,
                                                 SITE,
                                                 STREET,
                                                 HOUSE,
                                                 HOUSE_X,
                                                 APPT
                                          FROM   SISSP.ADDRESS ad
                                         WHERE   STAGE IS NULL
                                                 AND (ad.Pid, RID) IN
                                                          (  SELECT   ad1.Pid,
                                                                      MAX (RID)
                                                               FROM   SISSP.ADDRESS ad1
                                                              WHERE   STAGE IS NULL
                                                           GROUP BY   pid))
                                       addr
                                    ON addr.pid = spisok.pid
                                 LEFT JOIN
                                    SISSP.STATE_DIVISION str
                                 ON addr.street = str.code
                              LEFT JOIN
                                 SISSP.REF_ST_DIVISION_LEVELS strtype
                              ON str.Level_CODE = strtype.code
                           LEFT JOIN
                              SISSP.STATE_DIVISION CIT
                           ON addr.SITE = CIT.code
                        LEFT JOIN
                           SISSP.REF_ST_DIVISION_LEVELS cittype
                        ON CIT.Level_CODE = cittype.code
                     LEFT JOIN
                        (SELECT   *
                           FROM   SISSP.STATE_DIVISION DISTR2
                          WHERE   DISTR2.LEVEL_CODE IN (2, 3, 4)) DISTR1
                     ON CIT.PARENT_CODE = DISTR1.code
                  LEFT JOIN
                     SISSP.REF_ST_DIVISION_LEVELS distype
                  ON DISTR1.Level_CODE = distype.code
               LEFT JOIN
                  (SELECT   *
                     FROM   SISSP.STATE_DIVISION OBL2
                    WHERE   OBL2.LEVEL_CODE IN (2, 3)) OBL1
               ON DISTR1.PARENT_CODE = OBL1.code
            LEFT JOIN
               SISSP.REF_ST_DIVISION_LEVELS obltype
            ON OBL1.Level_CODE = obltype.code
/
