CREATE VIEW INV_ADDR_HELP_INV AS SELECT c.cid,
          PERS.PID,
          app.APPLICATION_DATE,
          rq.VALUE AS REQUEST_REASON,
          ASS.AMOUNT,
          allt.VALUE AS PrimaryAssigningType,
          alloc.ALLOCATION_START,
          alloc.ALLOCATION_END,
          '' AS REFUSE_REASON,
          ass.ASSISTANCE_DATE AS DecisionDate,
          'Назначена' AS Decision
     FROM (SELECT C.CID
             FROM CASE C
            WHERE C.STAGE IS NULL AND C.CASE_STATUS = 1 AND c.country IS NULL) C,
          (SELECT DISTINCT (PERS.PID),
                           pers.pik,
                           pers.surname,
                           pers.name,
                           pers.patname,
                           pers.birth_date,
                           pers.sex,
                           PERS.DEATH_DATE,
                           pers.death_certificate
             FROM person PERS
            WHERE pers.stage IS NULL) PERS,
          (SELECT cp.cid, cp.pid
             FROM case_person cp
            WHERE cp.stage IS NULL) cp,
          (SELECT mrak1.pid, MRAK1.RID
             FROM mrak_opinion mrak1
            WHERE mrak1.STAGE IS NULL AND mrak1.record_end IS NULL) mrak1,
          (SELECT DISTINCT inv.pid, inv.advice_type, inv.mrak_rid
             FROM mrak_opinion_advice inv
            WHERE inv.advice_type IN (11, 12, 13, 14) AND stage IS NULL) inv,
          (SELECT app.cid, app.APPLICATION_DATE, app.REQUEST_REASON
             FROM APPLICATION app
            WHERE APP.STAGE IS NULL) app,
          (SELECT rq.code, rq.VALUE, rq.parent_code
             FROM REQUESTS rq
            WHERE rq.stage IS NULL) rq,
          (SELECT ASS.ALLOCATION_RID,
                  ASS.AMOUNT,
                  ass.REFUSE_REASON,
                  ass.ASSISTANCE_DATE
             FROM assistance ass
            WHERE ASS.STAGE IS NULL AND ass.ASSISTANCE_DATE IS NOT NULL) ass,
          (SELECT alloc.RID,
                  alloc.CID,
                  ALLOC.ALLOC_CODE,
                  alloc.ALLOCATION_START,
                  alloc.ALLOCATION_END
             FROM ALLOCATION alloc
            WHERE alloc.STAGE IS NULL) alloc,
          (SELECT allt.code, allt.VALUE
             FROM ALLOCATIONS allt
            WHERE allt.stage IS NULL) allt
    WHERE     cp.cid = C.CID
          AND cp.pid = pers.pid
          AND cp.pid = inv.pid
          AND cp.pid = mrak1.pid
          AND inv.mrak_rid = mrak1.rid
          AND cp.cid = app.cid
          AND rq.code = app.REQUEST_REASON
          AND (rq.code = 14 OR rq.parent_code = 14)
          AND alloc.cid = cp.cid
          AND alloc.RID = ASS.ALLOCATION_RID
          AND alloc.ALLOC_CODE = allt.code
   UNION
   SELECT c.cid,
          PERS.PID,
          app.APPLICATION_DATE,
          rq.VALUE AS REQUEST_REASON,
          ASS.AMOUNT,
          allt.VALUE AS PrimaryAssigningType,
          NULL AS ALLOCATION_START,
          NULL AS ALLOCATION_END,
          ascr.VALUE AS REFUSE_REASON,
          ass.REFUSE_DATE AS DecisionDate,
          'Отказано' AS Decision
     FROM (SELECT C.CID
             FROM CASE C
            WHERE C.STAGE IS NULL AND C.CASE_STATUS = 1 AND c.country IS NULL) C,
          (SELECT DISTINCT (PERS.PID),
                           pers.pik,
                           pers.surname,
                           pers.name,
                           pers.patname,
                           pers.birth_date,
                           pers.sex,
                           PERS.DEATH_DATE,
                           pers.death_certificate
             FROM person PERS
            WHERE pers.stage IS NULL) PERS,
          (SELECT cp.cid, cp.pid
             FROM case_person cp
            WHERE cp.stage IS NULL) cp,
          (SELECT mrak1.pid, MRAK1.RID
             FROM mrak_opinion mrak1
            WHERE mrak1.STAGE IS NULL AND mrak1.record_end IS NULL) mrak1,
          (SELECT DISTINCT inv.pid, inv.advice_type, inv.mrak_rid
             FROM mrak_opinion_advice inv
            WHERE inv.advice_type IN (11, 12, 13, 14) AND stage IS NULL) inv,
          (SELECT app.cid, app.APPLICATION_DATE, app.REQUEST_REASON
             FROM APPLICATION app
            WHERE APP.STAGE IS NULL) app,
          (SELECT rq.code, rq.VALUE, rq.parent_code
             FROM REQUESTS rq
            WHERE rq.stage IS NULL) rq,
          (SELECT ass.ALLOCATION_RID,
                  ass.AMOUNT,
                  ass.REFUSE_REASON,
                  ass.REFUSE_DATE
             FROM assistance ass
            WHERE ASS.STAGE IS NULL AND ass.REFUSE_DATE IS NOT NULL) ass LEFT JOIN(SELECT ascr.code,
                                                                                          ascr.VALUE
                                                                                     FROM ALLOC_STATUS_CHANGE_REASON ascr
                                                                                    WHERE ascr.stage
                                                                                             IS NULL) ascr ON ass.REFUSE_REASON =
                                                                                                                 ascr.code,
          (SELECT alloc.RID,
                  alloc.CID,
                  ALLOC.ALLOC_CODE,
                  alloc.ALLOCATION_START,
                  alloc.ALLOCATION_END
             FROM ALLOCATION alloc
            WHERE alloc.STAGE IS NULL) alloc,
          (SELECT allt.code, allt.VALUE
             FROM ALLOCATIONS allt
            WHERE allt.stage IS NULL) allt
    WHERE     cp.cid = C.CID
          AND cp.pid = pers.pid
          AND cp.pid = inv.pid
          AND cp.pid = mrak1.pid
          AND inv.mrak_rid = mrak1.rid
          AND cp.cid = app.cid
          AND rq.code = app.REQUEST_REASON
          AND (rq.code = 14 OR rq.parent_code = 14)
          AND alloc.cid = cp.cid
          AND alloc.RID = ass.ALLOCATION_RID
          AND alloc.ALLOC_CODE = allt.code
/
