CREATE VIEW INV_SOCWORKER AS SELECT soc.pid,
          soc.swid,
          soc.bind_start,
          soc.bind_end,
          swk.surname,
          swk.name,
          swk.patname,
          soc.count_visitings
     FROM (SELECT PID FROM SISSP.INV_SPISOK_INV) PERSONS
          INNER JOIN (SELECT *
                        FROM sworker_bind socw
                       WHERE socw.stage IS NULL) soc
             ON persons.pid = soc.pid
          LEFT JOIN (SELECT sw.swid,
                            sw.surname,
                            sw.name,
                            sw.patname
                       FROM social_worker sw
                      WHERE sw.stage IS NULL) swk
             ON soc.swid = swk.swid
/
