CREATE VIEW V$POSTS AS SELECT   "CODE",
            "RID",
            "PARENT_CODE",
            "ORG_TYPE",
            "STAGE",
            "FLAG",
            "CORRESPONDENT_ACCT",
            "TAX_ID",
            CASE
               WHEN org_type IN (33, 8)
               THEN
                     VALUE
                  || ' '
                  || (SELECT   VALUE
                        FROM   organizations
                       WHERE   code = o.parent_code)
               ELSE
                  VALUE
            END
               VALUE,
            "START_DATE",
            "END_DATE",
            "ENTRY_DATE",
            "ENTERED_BY",
            "CLOSE_DATE",
            "SHORTNAME"
     FROM   Organizations o
    WHERE   org_type IN (33, 8)
/
