CREATE VIEW INV_HOME_LIST AS (SELECT A.PID,
           b.VALUE AS living_place,
           C.VALUE AS property_type,
           D.VALUE AS owner,
           A.ROOMS_COUNT,
           A.TOTAL_AREA,
           A.EFFECT_AREA,
           A.PERSONAL_EFFECT_AREA,
           A.NOTES
      FROM SISSP.RESIDENCE_STATUS a,
           SISSP.PROPERTY b,
           SISSP.REF_PROPERTY_OWNERSHIP C,
           SISSP.REF_RELATION D
     WHERE     (A.RECORD_END > SYSDATE OR A.RECORD_END IS NULL)
           AND A.PROPERTY_TYPe = B.CODE
           AND C.CODE = A.OWNERSHIP_TYPE
           AND A.OWNER = D.CODE)
   UNION
   (SELECT A.PID,
           b.VALUE AS living_place,
           C.VALUE AS property_type,
           NULL,
           A.ROOMS_COUNT,
           A.TOTAL_AREA,
           A.EFFECT_AREA,
           A.PERSONAL_EFFECT_AREA,
           A.NOTES
      FROM SISSP.RESIDENCE_STATUS a,
           SISSP.PROPERTY b,
           SISSP.REF_PROPERTY_OWNERSHIP C
     WHERE     (A.RECORD_END > SYSDATE OR A.RECORD_END IS NULL)
           AND A.PROPERTY_TYPe = B.CODE
           AND C.CODE = A.OWNERSHIP_TYPE
           AND a.owner IS NULL)
/
