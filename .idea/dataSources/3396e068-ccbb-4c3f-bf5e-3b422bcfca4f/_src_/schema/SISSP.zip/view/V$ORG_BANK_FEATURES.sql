CREATE VIEW V$ORG_BANK_FEATURES AS SELECT   "CODE",
            "RID",
            "MFO",
            "ITS_NUMBER",
            "STAGE",
            "ACCOUNT_AMOUNT",
            "ACCOUNT_SERVICE",
            "BANK_RATE",
            "START_DATE",
            "END_DATE",
            "CLOSE_DATE",
            "ENTRY_DATE",
            "ENTERED_BY",
            (SELECT   parent_code
               FROM   organizations
              WHERE   code = fur.code)
               parent_code
     FROM   org_bank_features fur
/
