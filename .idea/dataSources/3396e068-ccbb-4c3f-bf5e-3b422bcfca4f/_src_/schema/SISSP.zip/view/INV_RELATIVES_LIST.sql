CREATE VIEW INV_RELATIVES_LIST AS SELECT A.PID,
          A.SURNAME,
          A.NAME,
          A.PATNAME,
          B.VALUE AS Relation,
          A.BIRTH_DATE,
          A.RESIDENCE_RELATION,
          A.OCCUPATION,
          C.VALUE AS Disability,
          A.SOCIAL_STATUS,
          D.VALUE AS with_parents,
          A.OWN_FAMILY,
          A.PHONE
     FROM SISSP.INV_SPS_LIST2 X
          LEFT JOIN SISSP.FAMILY_MEMBER A ON x.pid = a.pid
          LEFT JOIN SISSP.REF_RELATION B ON A.RELATION = B.CODE
          LEFT JOIN SISSP.MRAK_opinions C ON A.DISABILITY = C.CODe
          LEFT JOIN SISSP.REF_CONFIRMATION D ON A.WITH_PARENTS = D.CODE
    WHERE a.pid IS NOT NULL
/
