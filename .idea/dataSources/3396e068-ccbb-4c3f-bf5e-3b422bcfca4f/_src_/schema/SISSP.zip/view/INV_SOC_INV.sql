CREATE VIEW INV_SOC_INV AS SELECT soc.pid,
          soc.swid,
          soc.bind_start,
          soc.bind_end,
          sw.surname,
          sw.name,
          sw.patname,
          soc.count_visitings
     FROM (SELECT C.CID
             FROM CASE C
            WHERE C.STAGE IS NULL AND C.CASE_STATUS = 1 AND c.country IS NULL) C,
          (SELECT DISTINCT (PERS.PID),
                           pers.pik,
                           pers.surname,
                           pers.name,
                           pers.patname,
                           pers.birth_date,
                           pers.sex,
                           PERS.DEATH_DATE,
                           pers.death_certificate
             FROM person PERS
            WHERE pers.stage IS NULL) PERS,
          (SELECT cp.cid, cp.pid
             FROM case_person cp
            WHERE cp.stage IS NULL AND cp.role = 51) cp,
          (SELECT soc.pid,
                  soc.swid,
                  soc.bind_start,
                  soc.bind_end,
                  soc.count_visitings
             FROM sworker_bind soc
            WHERE soc.stage IS NULL) soc,
          (SELECT mrak1.pid, MRAK1.RID
             FROM mrak_opinion mrak1
            WHERE mrak1.STAGE IS NULL AND mrak1.record_end IS NULL) mrak1,
          (SELECT DISTINCT inv.pid, inv.advice_type, inv.mrak_rid
             FROM mrak_opinion_advice inv
            WHERE inv.advice_type IN (11, 12, 13, 14) AND stage IS NULL) inv,
          (SELECT sw.swid,
                  sw.surname,
                  sw.name,
                  sw.patname
             FROM social_worker sw
            WHERE sw.stage IS NULL) sw
    WHERE     cp.cid = C.CID
          AND cp.pid = pers.pid
          AND cp.pid = inv.pid
          AND cp.pid = soc.pid
          AND cp.pid = mrak1.pid
          AND inv.mrak_rid = mrak1.rid
          AND soc.swid = sw.swid
/
