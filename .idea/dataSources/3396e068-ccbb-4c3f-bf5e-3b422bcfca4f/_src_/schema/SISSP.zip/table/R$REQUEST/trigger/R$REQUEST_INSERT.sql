CREATE TRIGGER R$REQUEST_INSERT
BEFORE INSERT
  ON R$REQUEST
FOR EACH ROW
  DECLARE
tmpVar NUMBER;
/******************************************************************************
изменение статуса записи при вставке
******************************************************************************/
BEGIN

   :NEW.STATUS := 1;  -- Оформлена

   EXCEPTION  WHEN OTHERS THEN NULL;

END ;
/
