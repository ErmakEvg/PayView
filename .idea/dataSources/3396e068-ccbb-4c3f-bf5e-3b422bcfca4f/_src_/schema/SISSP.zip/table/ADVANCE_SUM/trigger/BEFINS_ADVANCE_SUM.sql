CREATE TRIGGER BEFINS_ADVANCE_SUM
BEFORE INSERT
  ON ADVANCE_SUM
FOR EACH ROW
  BEGIN

   if :new.RID is null then
     :new.RID:=sissp_sys.create_rid('ADVANCE_SUM');
   end if;


   EXCEPTION
     WHEN OTHERS THEN
       null;
END BeforeInsert_ADVANCE_SUM;
/
