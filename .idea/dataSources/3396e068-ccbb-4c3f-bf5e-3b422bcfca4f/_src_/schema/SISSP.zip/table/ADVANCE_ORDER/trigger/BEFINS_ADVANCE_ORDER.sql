CREATE TRIGGER BEFINS_ADVANCE_ORDER
BEFORE INSERT
  ON ADVANCE_ORDER
FOR EACH ROW
  BEGIN

   if :new.RID is null then
     :new.RID:=sissp_sys.create_rid('ADVANCE_ORDER');
   end if;


   EXCEPTION
     WHEN OTHERS THEN
       null;
END BeforeInsert_ADVANCE_ORDER;
/
