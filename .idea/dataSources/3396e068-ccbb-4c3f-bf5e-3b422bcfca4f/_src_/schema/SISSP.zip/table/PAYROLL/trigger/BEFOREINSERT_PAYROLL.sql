CREATE TRIGGER BEFOREINSERT_PAYROLL
BEFORE INSERT
  ON PAYROLL
FOR EACH ROW
  BEGIN

   if :new.RID is null then
     :new.RID:=sissp_sys.create_rid('PAYROLL');
   end if;


   EXCEPTION
     WHEN OTHERS THEN
           null;
END BeforeInsert_PAYROLL;
/
