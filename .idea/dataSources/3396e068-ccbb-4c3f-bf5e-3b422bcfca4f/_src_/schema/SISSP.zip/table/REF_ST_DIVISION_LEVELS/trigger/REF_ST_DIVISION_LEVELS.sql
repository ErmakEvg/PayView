CREATE TRIGGER REF_ST_DIVISION_LEVELS
AFTER INSERT OR UPDATE OR DELETE
  ON REF_ST_DIVISION_LEVELS
FOR EACH ROW
  DECLARE
   OPERATION#       NUMBER (1);
   TABLE_NAME#      VARCHAR2 (30);
   RID_VALUE#       NUMBER (13);
   CATEGORY_CODE#   NUMBER (3);
BEGIN
   IF INSERTING THEN
      OPERATION# := 1;
      RID_VALUE# := :NEW.RID;
   ELSIF UPDATING THEN
      OPERATION# := 2;
      RID_VALUE# := :NEW.RID;
   ELSE
      OPERATION# := 3;
      RID_VALUE# := :OLD.RID;
   END IF;

   TABLE_NAME# := 'REF_ST_DIVISION_LEVELS';
   CATEGORY_CODE# := 9;    -- изменения в справочнике/классификаторе
   IF OPERATION# = 2 OR OPERATION# = 3
   THEN
      IF SISSP_AUDIT.T_ProvAudit (RID_VALUE#, TABLE_NAME#, OPERATION#) = 0
      THEN
         SISSP_AUDIT.T_Audit (TABLE_NAME#,
                              RID_VALUE#,
                              OPERATION#,
                              CATEGORY_CODE#,
                              null);
      END IF;
   ELSE
      SISSP_AUDIT.T_Audit (TABLE_NAME#,
                           RID_VALUE#,
                           OPERATION#,
                           CATEGORY_CODE#,
                           null);
   END IF;
END;
/
