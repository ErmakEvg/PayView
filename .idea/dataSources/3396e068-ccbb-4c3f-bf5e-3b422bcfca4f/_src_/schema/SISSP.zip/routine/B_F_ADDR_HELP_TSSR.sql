CREATE FUNCTION       B_F_ADDR_HELP_TSSR (pFl_Level in Number) RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_ADDR_HELP_TSSR
// Наименование: Функция возвращает True если определены ТССР
// для  социального пособия  на оплату (адресная социальная помощь)
// Автор: Абрамович М.В.
// Состояние на дату 08.12.2010
// Код возврата: True - если есть требуемые данные, False - если их нет
//***************************************************************************************/

  COUNT_TSSR NUMBER;
BEGIN
  --RAISE_APPLICATION_ERROR(-20801,'B_F_ADDR_HELP_TSSR     XLPL.PID=' ||XLPL.GETPID );
 if pFl_Level=2 then
  SELECT COUNT(RID_TSSR) INTO COUNT_TSSR FROM W$PARAM_ADDR_HELP
  WHERE CID = XLPL.CID
  and ENTERED_BY = XLPL.USER_ID
  and STAGE not in (2,3)
  and RID_TSSR IN  ( Select d.RID From W$MRAK_DESIRED_TSSR d,REF_TSSR s
                      Where d.PID = XLPL.GETPID
					  and d.Code_TSSR=s.Code and s.Flag in (2,3)
                     -- and OPINION_TYPE = 5
                      and (d.STAGE not in (2,3) or d.STAGE is null)
                      and d.CLOSE_DATE IS NULL
                      and d.ENTERED_BY = XLPL.USER_ID
                      and ((d.RECORD_START <= XLPL.WorkDate )
					       -- and RECORD_START <= NVL(DIS_TERM, XLPL.WorkDate))
							or    (d.RECORD_START is null))
                      and (d.RECORD_END >= XLPL.WorkDate or d.RECORD_END is null )
					     --  or DIS_TERM >= XLPL.WorkDate or DIS_TERM is null)
                     );
  return COUNT_TSSR != 0;
  else
    if pFl_Level=1 then
	 Select COUNT(d.RID) INTO COUNT_TSSR From W$MRAK_DESIRED_TSSR d,REF_TSSR s
                      Where d.PID = XLPL.GETPID
					  and d.Code_TSSR=s.Code and s.Flag in (2,3)
                     -- and OPINION_TYPE = 5
                      and (d.STAGE not in (2,3) or d.STAGE is null)
                      and d.CLOSE_DATE IS NULL
                      and d.ENTERED_BY = XLPL.USER_ID
                      and ((d.RECORD_START <= XLPL.WorkDate )
					       -- and RECORD_START <= NVL(DIS_TERM, XLPL.WorkDate))
							or    (d.RECORD_START is null))
                      and (d.RECORD_END >= XLPL.WorkDate or d.RECORD_END is null );
	 return COUNT_TSSR != 0;
	else
	  return False;
	end if;

  end if;
END B_F_ADDR_HELP_TSSR;
/
