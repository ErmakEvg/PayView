CREATE FUNCTION       A_F_Relprotnotinterhouse RETURN BOOLEAN AS
/**********************************************************************************************
 Функция            : A_F_RelProtNotInterHouse
 Наименование       : Функция проверки права на назначение по факту проживания в ДИ, ИТУ
 Автор              : Ворошилин В.          Комментарии и корректировка: ОЛВ
 Состояние на дату  :                                                  05.07.2012  12.03.2013
 Код возврата       : логический True - имеет право , False - не имеет права
***********************************************************************************************/
BEGIN
  -- Проживает в ДИ
  IF A_F_Relprotrest_Home(9) THEN
     IF NOT A_F_Relprotabsence_Person(9) THEN  -- не выехал на каникулы -- ОЛВ 05.07.2012
          RETURN FALSE;
	 ELSE    -- выехал на каникулы -- ОЛВ 12.03.2013
	       -- если в ДИ отсутствует меньше месяца -  месяц по ТК =30 дней  (ABSENCE_PERSON)
          IF S_Isinternat(Xlpl.Cid,Xlpl.Aid,Xlpl.Base_Id,Xlpl.WorkDate,Xlpl.GetPid) THEN
             RETURN FALSE;
          END IF;
     END IF;
  END IF;

  -- Проживает в ИТУ
  IF A_F_Relprotrest_Home(14) THEN
     RETURN FALSE;
  END IF;
  RETURN TRUE;
--RAISE_APPLICATION_ERROR(-20801,'A_F_Relprotnotinterhouse   3  XLPL.GetPid='||Xlpl.GetPid||'   Xlpl.WorkDate='||Xlpl.WorkDate );
END A_F_Relprotnotinterhouse;
/
