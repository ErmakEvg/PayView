CREATE FUNCTION       B_DateOfSaveStatus (aCID in NUMBER, aAID in NUMBER) RETURN DATE IS
/***************************************************************************************
 Назначение: B_DateOfSaveStatus
 Наименование: Функция определения даты закрытия пересчитанного назначения с
 				 сохранением статуса
 Автор: Ворошилин В.
 Состояние на дату 31.10.2002
 Коды возврата: дата возобновления назначения пособоя
***************************************************************************************/

Alloc_Start DATE;

BEGIN
begin
	 select max(step_start)
	 into Alloc_Start
	 from W$allocation
	 where cid = aCID and
           aid = aAID and
           stage = 1 and
           alloc_status in (2, 3) and
           parent_rid is null and
           comp_part is null;
exception
    when OTHERS then
		 Alloc_Start := NULL;
end;

return Alloc_Start;

END B_DateOfSaveStatus;
/
