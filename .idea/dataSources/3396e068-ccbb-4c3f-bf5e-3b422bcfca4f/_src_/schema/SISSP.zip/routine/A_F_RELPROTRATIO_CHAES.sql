CREATE FUNCTION       A_F_Relprotratio_Chaes(IndividualRatio IN NUMBER) RETURN NUMBER AS
/**************************************************************************************
 Назначение      : Ограничение инд. коэффициента : 1< IndividualRatio <3
 Основание       : согл. Декрета Президента №21 от 29.04.99
                           действует с 30.04.99
 Автор               :  ОЛВ
 Состояние на дату   16.02.2009
/**************************************************************************************/

   IndividualRatioNew NUMBER;
   IndividualRatioOld  NUMBER;
   RatioChar             VARCHAR2(50);

BEGIN
    IndividualRatioOld:=IndividualRatio;  -- Индивидуальный коэффициент заработка
    IndividualRatioNew:=IndividualRatio;

  IF Xlpl.WorkDate >TO_DATE('29-04-1999','DD-MM-YYYY') THEN
     IF IndividualRatio<1 THEN
          IndividualRatioNew :=1;
     END IF;
      IF IndividualRatio>3 THEN
          IndividualRatioNew :=3;
      END IF;
  END IF;

   RatioChar :=TO_CHAR(IndividualRatioOld, '90.99999');
  IF IndividualRatioNew <>IndividualRatioOld THEN
     RatioChar :=RatioChar || '  (согл. Декрета №21 : '||TO_CHAR(IndividualRatioNew, '90.99999') ||') ';
  END IF;
   Xlpl.S_Protocol('Индивидуальный коэффициент:              ' || RatioChar || CHR(10));

 RETURN IndividualRatioNew;

END A_F_Relprotratio_Chaes;
/
