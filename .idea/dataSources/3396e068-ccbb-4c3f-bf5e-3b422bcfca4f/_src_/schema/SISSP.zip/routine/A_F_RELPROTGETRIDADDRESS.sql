CREATE FUNCTION       A_F_RelProtGetRidAddress(Base_ID in NUMBER,pADDRESS_TYPE in NUMBER)
   RETURN NUMBER AS
/*******************************************************************************
 NAME              : A_F_RelProtGetRidAddress
 Наименование      : Функция возвращает RID из W$ADDRESS
 Автор             : Вахромин О.Ю.    Комментарии и корректировка : ОЛВ
 Состояние на дату :                        19.05.2014    29.08.2018
 Код возврата      : RID из W$ADDRESS
********************************************************************************/
 vsRelation_Table  number;
 vsDRID            NUMBER;
BEGIN
   if Base_ID=0 then
      vsRELATION_TABLE :=S_CodeTableSissp('W$ADDRESS');
   else
      vsRELATION_TABLE :=S_CodeTableSissp('ADDRESS');
   end if;

   begin
      if Base_ID=0 then
         -- Выбрать RID из ADDRESS
         select DATA_RID into vsDRID
           from W$RELATION_PROTOCOL b,W$ADDRESS a
          where CID=XLPL.CID
            and (AID = XLPL.AID or XLPL.AID=0)
            and ((GROUP_NO=XLPL.GROUP_NO) or (XLPL.AID<>0 and XLPL.GROUP_NO=0))
            and ALLOC_CODE=XLPL.ALLOC_CODE
            and b.ENTERED_BY=XLPL.USER_ID
            and a.ENTERED_BY=XLPL.USER_ID
            and RELATION_TABLE=vsRELATION_TABLE
            and RELATION_DATE=XLPL.WorkDate
            and DATA_RID=a.RID
            and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE) and
                                      NVL(a.RECORD_END,XLPL.WORKDATE)
            and a.PID=XLPL.GetPID
            and ((ADDRESS_TYPE=pADDRESS_TYPE) OR (ADDRESS_TYPE=3)); -- 2014-05-19 ОЛВ -- OR
      else
         -- Выбрать RID из W$ADDRESS
         select DATA_RID into vsDRID
           from W$RELATION_PROTOCOL b,ADDRESS a
          where CID=XLPL.CID
            and (AID = XLPL.AID or XLPL.AID=0)
            and ((GROUP_NO=XLPL.GROUP_NO)or(XLPL.AID<>0 and XLPL.GROUP_NO=0))
            and ALLOC_CODE=XLPL.ALLOC_CODE
            and b.ENTERED_BY=XLPL.USER_ID
            and RELATION_TABLE=vsRELATION_TABLE
            and RELATION_DATE=XLPL.WorkDate
            and DATA_RID=a.RID
            and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE) and
                                      NVL(a.RECORD_END,XLPL.WORKDATE)
            and a.PID=XLPL.GetPID
            and ((ADDRESS_TYPE=pADDRESS_TYPE) OR (ADDRESS_TYPE=3)); -- 2014-05-19 ОЛВ -- OR
      end if;
   exception
      when NO_DATA_FOUND then
         vsDRID:=-1;
   end;
   return vsDRID;
END A_F_RelProtGetRidAddress;
/
