CREATE FUNCTION       B_F_MATHELP(wCID in W$CASE.cid%type, wPID in W$PERSON.pid%type) return VARCHAR2
/*******************************************************************************
 Функция      : B_F_MATHELP
 Наименование : Функция определения причины отказа для мат. помощи из ФСЗН
 Автор        : Иванова Т.С.
 Состояние на дату: 28/09/2018 Иванова Т.С.   Редактирование процедуры.
 Коды возврата    : StrNotes
*******************************************************************************/
IS
 StrNotes VARCHAR2(2000);
  vFree       Number;
  Vozrast     Number;
  vActivity   Number;
  Count_Month Number;
  Age_N       Number;
  vSex        Number;
  vCount      Number;
  vGos_ob     Number;-- находится на гособеспечении
  StopDate    Date;
  dtBirthDay  Date;
  need_PID    Number;-- нуждающийся
  v_Entered_by Number;
  vAPPLICATION_DATE Date;
  Count_      Number;
  vNopensioner Number; --759 - получает  пенсию в другом районе или ведомстве
  --759 - получает  пенсию в другом районе или ведомстве
  --651 Пенсионер (кроме СПК) МВД
  --652 Пенсионер по СПК МВД
  --653 Пенсионер (кроме СПК) КГБ
  --654 Пенсионер по СПК КГБ
  --656 Пенсионер по СПК Министерства Обороны
  vMetrics    Varchar2(500);
/******************************************************************************
    Параметры:
      PID$    -   идентификатор пользователя
      CID$    -   идентификатор дела
    Цель:         Функция определения права на мат. помощь из ФСЗН
    АРМ    :  "Материальная помощь из ФЗСН"
    Название таблиц:  w$person_metric , w$person ,w$ACTIVITY,
       W$MRAK_OPINION_ADVICE, W$MRAK_OPINION
   ВЫЗОВ ФУНКЦИИ :  SISSP.P_AGEPENSION_MONTH используется в ней legal_constants,
******************************************************************************/
BEGIN
  Count_Month:= 0;
  Vozrast:= 0;
  vCount:= 0;
  vActivity := 0;
  vGos_ob:=0;
  XLPL.RoleDecl('Needy', '62');
 vNopensioner:=0;
  Select APPLICATION_DATE ,Entered_by Into vAPPLICATION_DATE,v_Entered_by-- дата заявления и инспектор
  From W$APPLICATION
  Where cid= wCID
    and stage =4
    and close_date is null;
 Select PID Into need_PID  From w$Case_person
  Where cid= wCID and role=62 and stage in (1,4);
 Select count(Death_Date) Into count_ --есть ли дата смерти
  From w$person
  Where pid = need_PID
    and stage in (1,4)
    and close_date is null
    and entered_by= v_Entered_by;
  IF (count_ >0 ) THEN --есть дата смерти
   Select Death_Date Into StopDate -- дата смерти
   From w$person
   Where pid= need_PID
    and stage in (1,4)
    and close_date is null;
    IF (StopDate <= vAPPLICATION_DATE  ) THEN StrNotes :='Не имеет права (умер).';
     Return StrNotes;
    END IF;
    end if;
-- Выбираем дату рождения, пол человека
  Select BIRTH_DATE,SEX into dtBirthDay,vSex
  From W$PERSON
  Where PID=need_PID  AND STAGE IN (1,4)
  and entered_by=v_Entered_by;
  --Определяем общеуствновленный пенсионный возраста по дате рождения в месяцах
  Age_N:= SISSP.P_AGEPENSION_MONTH(dtBirthDay, vSex) ; --15.12.2016
  -- Определяем возраст человека в месяцах --15.12.2016
  Count_Month:= MONTHS_BETWEEN(trunc(sysdate), trunc(dtBirthDay));
  Vozrast:=Count_Month ;-- Count_Month / 12;--15.12.2016 было раньше в годах
  --Vozrast:= Trunc(Vozrast);--15.12.2016
  Select Count(*) into  vCount
    From W$MRAK_OPINION_ADVICE
     Where  Advice_Type in (11,12,13,14)
      and nvl(DIS_TERM,sysdate +1) >=sysdate
      and MRAK_RID=(select RID  From W$MRAK_OPINION  --20.01.2016
                     Where stage in (1,4)
                      and  PID= wPID
                      and examed_till =
                      (Select Max(examed_till)  From W$MRAK_OPINION
                            Where stage in (1,4) and PID= wPID)
                      and rownum=1
                   );
 -- Определяем  работает ли?
  Select Count(*)  into  vActivity
  from w$ACTIVITY Where ACTIVITY=1
   and NVL(PERIOD_END,vAPPLICATION_DATE) >= vAPPLICATION_DATE
   and STAGE in (1,4)
   and PID =need_PID
   and entered_by= v_Entered_by;
 -- Определяем  находится ли на гос. обеаспечении
  Select Count(*)  into  vGos_ob
   from w$person_metric
     where PID= wPID
 --  and code in (172,176,177,178,179,180,186,187,188) -- ITS 9.02.2017
     and code in (172,179,719,731,193)-- ITS 9.02.2017
      and stage in (1,4)
      and NVL(record_end ,vAPPLICATION_DATE) >= vAPPLICATION_DATE
      and entered_by= v_Entered_by ;
  -- Определяем  получает ли пенсию в другом районе или ведомстве
  Select Count(*)  into  vNopensioner  -- 28.08.2018
   from w$person_metric
     where PID= need_PID
      and code in (759,651,652,653,654,656)
      and stage in (1,4)
      and NVL(record_end ,vAPPLICATION_DATE) >= vAPPLICATION_DATE
      and entered_by= v_Entered_by ;
   StrNotes:='';
      IF (vActivity>0) THEN StrNotes :='Не имеет права: работает.';  Return StrNotes;
       END IF;
      IF (vGos_ob>0) THEN StrNotes :='Не имеет права: на гособеспечении.';
    Return StrNotes;
     end if;
    IF vNopensioner>0 THEN StrNotes :='Не имеет права: получает  пенсию в другом районе или ведомстве';
    Return StrNotes;
     end if;
     IF  ((Vozrast >= Age_N) -- пенсионер или инвалид
         OR  (vCount >0) ) THEN  Return StrNotes;
        ELSE
         StrNotes :='Не имеет права:не пенсионер по возрасту и не инвалид';

       end if;
   Return StrNotes;
END B_F_MATHELP;
/
