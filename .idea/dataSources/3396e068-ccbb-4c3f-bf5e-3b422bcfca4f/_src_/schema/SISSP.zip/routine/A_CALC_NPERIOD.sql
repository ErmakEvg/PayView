CREATE FUNCTION       A_Calc_Nperiod (rej IN NUMBER, rpid IN NUMBER,  dkon IN DATE, rpolzov IN NUMBER) RETURN VARCHAR2 IS
	summdn NUMBER:=0;
	KOLMES  NUMBER:=0;
	KOL  NUMBER:=0;
	n NUMBER;
	datkon DATE;
	nach DATE;
	kolz NUMBER;

    extra_days NUMBER;
    add_years NUMBER;
    add_month NUMBER;
    add_days NUMBER;

    month2 NUMBER;
    day2 NUMBER;

    start_work DATE;

CURSOR lab IS
 SELECT W$FACTOR_LABOR.PERIOD_START,
        W$FACTOR_LABOR.PERIOD_END,
        T_CalcPeriod(W$FACTOR_LABOR.PERIOD_END,W$FACTOR_LABOR.PERIOD_START) dn
 FROM  LABOR_TYPE ,  W$FACTOR_LABOR
 WHERE LABOR_TYPE .PARENT_CODE <>10
   AND LABOR_TYPE .PARENT_CODE <>14
   AND W$FACTOR_LABOR.LABOR_CODE=LABOR_TYPE.CODE
   AND W$FACTOR_LABOR.PID=rpid
   ORDER BY   period_end DESC;

TYPE points_type IS TABLE OF DATE INDEX BY BINARY_INTEGER;

 cur_lab lab%ROWTYPE;

 sumDN NUMBER;
 curDN NUMBER;

 points points_type; -- точки для разбиения
 point_index NUMBER;

 start_p DATE;
 end_p   DATE;

 in_bad BOOLEAN;
 flag_found BOOLEAN;
 flag_date DATE;
 previous_date DATE;
 previous_bad BOOLEAN;

 flag_day NUMBER;
 flag_year NUMBER;
 flag_month NUMBER;

 cut_add boolean;

 flag_first_work BOOLEAN;


BEGIN
--
  SELECT COUNT(*) INTO kolz FROM  LABOR_TYPE ,  W$FACTOR_LABOR
  WHERE LABOR_TYPE .PARENT_CODE <>10 AND LABOR_TYPE .PARENT_CODE <>14
  AND   W$FACTOR_LABOR.LABOR_CODE=LABOR_TYPE.CODE AND W$FACTOR_LABOR.PID=rpid;

  IF kolz=0 THEN RETURN ' '; END IF;
  -- заполняем коллекцию точками для разбиения
  point_index := 0;
  cut_add := true;
  FOR pnt in (select distinct per."point"
              from
                  (select a.period_start "point"
                   from w$labor a
                   where pid = rpid
                   union
                   select b.period_end "point"
                   from w$labor b
                   where pid = rpid) per
              order by "point" desc  ) LOOP
     points(point_index) := pnt."point";

	 -- нужно обрезать трудовую детельность датой назначения
	 IF (points(point_index) > dkon) THEN
		   -- нужно добавить границу
		   points(point_index) := dkon;
	 END IF;

	 --DBMS_OUTPUT.put_line(points(point_index)); --
     point_index := point_index + 1;
  END LOOP;

  IF points.COUNT = 0 THEN
     RETURN ' ';
  END IF;

  start_p := points(0);
  DATKON := start_p;

  end_p := points(1);
  --DBMS_OUTPUT.put_line(start_p || ' ' || end_p || '           ' ||T_CalcPeriod(end_p, start_p));

  flag_date := end_p; -- первоначальное значение начала периода
  flag_found := false;

  previous_date := start_p + 1;
  previous_bad := true;

  sumDN:=0; -- накопление отработанных дней
  kolmes:=S_Const(103,dkon)*30; -- количество дней для работы по константе 103
  --DBMS_OUTPUT.put_line('kolmes:'||kolmes);

  flag_first_work := true;

  -- цикл, который перебирает все маленькие промежутки
  FOR point_index in 2..(points.LAST + 1) LOOP

      in_bad := false;
      -- находится ли промежуток в списке исключаемых
      FOR c1 in (
                SELECT W$LABOR.PERIOD_START, W$LABOR.PERIOD_END
				FROM LABOR_GROUP,LABOR_TYPE,W$LABOR
				WHERE  LABOR_GROUP.CODE  =LABOR_TYPE.code AND LABOR_GROUP.GROUP_CODE=1 AND SYSTEM_FLAG=1
				AND pid=rpid AND W$LABOR.LABOR_TYPE=LABOR_TYPE.code

				UNION
				SELECT TO_DATE(SUBSTR(W$PERIOD_DELETE.VALUE,0,10))  PERIOD_START,
				TO_DATE(SUBSTR(W$PERIOD_DELETE.VALUE,14,10))  PERIOD_END
				FROM W$PERIOD_DELETE WHERE PID=rpid AND PR_VKL=0

				ORDER BY   period_end DESC
      ) LOOP

        IF  (start_p <= c1.PERIOD_END) AND (end_p >= c1.PERIOD_START) THEN
            -- промежуток в списке

            if flag_first_work then
               flag_first_work := not flag_first_work;
               DATKON := start_p;
            end if;

            --DBMS_OUTPUT.put_line('  ' || c1.PERIOD_START || ' -> ' || c1.PERIOD_END || ' O ');

            IF (previous_date = start_p) and (previous_bad = false)  THEN
               sumDN := sumDN - 1;

               DBMS_OUTPUT.put_line('*** minus 1 ');
            END IF;

            previous_date:=end_p;
            previous_bad := true;
            -- можно перенести флаг на начало этого промежутка
            flag_date := c1.PERIOD_START;
            in_bad := true;
            EXIT;
        ELSE
            -- промежуток не в списке
            --DBMS_OUTPUT.put_line('  ' || c1.PERIOD_START || ' -> ' || c1.PERIOD_END || ' X ');
            in_bad := false;
        END IF;
      END LOOP;

      IF NOT in_bad THEN
            -- может совсем нет трудовой деятельности на этом промежутке
            FOR c2 in (
                /*SELECT W$LABOR.PERIOD_START, W$LABOR.PERIOD_END
                FROM W$LABOR
                WHERE pid=rpid*/

                SELECT a.PERIOD_START, a.PERIOD_END
                FROM W$LABOR a, LABOR_TYPE b
                WHERE a.pid=rpid
                and a.LABOR_TYPE = b.CODE and b.PARENT_CODE Not in (10,14)

            ) LOOP

              IF (start_p <= c2.PERIOD_END) AND (end_p >= c2.PERIOD_START) THEN
                 curDN := T_CalcPeriod(end_p, start_p); -- длина промежутка
                 IF (previous_date = start_p) THEN
                    curDN := curDN - 1;
                    --DBMS_OUTPUT.put_line('*** minus 1 ');
                 END IF;

                 if flag_first_work then
                    flag_first_work := not flag_first_work;
                    DATKON := start_p;
                 end if;

                 previous_bad := false;

                 -- есть деятельность на данном промежутке, необходимо учитывать
                 DBMS_OUTPUT.put_line(' +' || c2.PERIOD_START || ' -> ' || c2.PERIOD_END || ' O ');
                 flag_date := end_p;

                 -- если промежуток слишком длинный, то ставим флаг внутри промежутка
                 IF (sumDN + curDN) >= kolmes THEN
                    -- сколько дней выходит за рамки 25 лет
                    extra_days := sumDN + curDN - kolmes;
                    DBMS_OUTPUT.put_line('*** extra_days -> ' || extra_days);

                    -- прибавляем год
                    add_years := TRUNC (extra_days / 360);

                    flag_date := add_months(flag_date, add_years*12);
                    DBMS_OUTPUT.put_line('*** add_years -> ' || add_years);

                    -- прибавляем месяцы
                    add_month := TRUNC(MOD(extra_days, 360) / 30);
                    flag_date := add_months(flag_date, add_month);
                    DBMS_OUTPUT.put_line('*** add_month -> ' || add_month);

                    -- прибавляем дни
                    add_days := MOD(MOD(extra_days, 360), 30);

                    --flag_date := flag_date + add_days;
                    --хитро прибавляем дни
                    select to_number(to_char(flag_date,'mm')) into flag_month from dual;
                    select to_number(to_char(flag_date,'yyyy')) into flag_year from dual;
                    select to_number(to_char(flag_date,'dd')) into flag_day from dual;


                    IF (add_days + flag_day) > 30 THEN
                       -- нужно прибавить добавить месяц и четко установить дату
                       flag_day := add_days + flag_day - 30;
                       flag_month := flag_month + 1;
                    ELSE
                        flag_day := add_days + flag_day;
                    END IF;

                    IF (flag_day > 28) AND (MOD(flag_year,4)>0) AND (flag_month = 2) THEN
                       -- если год не високосный
                       flag_month := flag_month+1;
                       flag_day := flag_day - 28;
                    END IF;

                    IF (flag_day > 29) AND (MOD(flag_year,4)=0) AND (flag_month = 2) THEN
                       -- если год високосный
                       flag_month := flag_month+1;
                       flag_day := flag_day - 29;
                    END IF;

                    IF flag_month > 12 THEN
                       flag_month := flag_month - 12;
                       flag_year:=flag_year+1;
                    END IF;

                    -- конструируем дату
                    flag_date := TO_DATE(flag_month||'/'||flag_day||'/'||flag_year, 'MM/DD/YYYY');

                    DBMS_OUTPUT.put_line('*** add_days -> ' || add_days);

                    DBMS_OUTPUT.put_line('*** FLAG -> ' || flag_date);
                    flag_found := true;
                 ELSE
                    sumDN := sumDN + curDN;
                    previous_date := end_p;
                    EXIT;
                 END IF;
              END IF;
              --ELSE
                 -- нет ни одной записи для данного промежутка, пропускаем его
                 --DBMS_OUTPUT.put_line(' -' || c2.PERIOD_START || ' -> ' || c2.PERIOD_END || ' X ');
              --END IF;

              IF flag_found THEN EXIT; END IF;

            END LOOP;
      END IF;

      IF flag_found THEN EXIT; END IF;

      start_p := end_p;
      IF point_index <= points.LAST THEN
         end_p := points(point_index);

         --DBMS_OUTPUT.put_line('---');
         --DBMS_OUTPUT.put_line(start_p || ' ' || end_p || '    +'|| sumDN ||'       ' ||T_CalcPeriod(end_p, start_p));
      END IF;
  END LOOP;
  --DBMS_OUTPUT.put_line('с '|| TO_CHAR(flag_date,'DD.MM.RRRR')||' по '||TO_CHAR(DATKON,'DD.MM.RRRR'));

  -- нужно найти дату начала работы
	select min(PERIOD_START) into start_work
	from W$LABOR wl
	where wl.PID  = rpid
	and wl.LABOR_TYPE not in (select lt.CODE from LABOR_TYPE lt where lt.PARENT_CODE in (10,14))
	and wl.LABOR_TYPE not in (select lt1.code from LABOR_TYPE lt1, LABOR_GROUP lg where lg.CODE = lt1.CODE and lg.GROUP_CODE = 1);

 -- период рассчета коэффициента нужно ограничить началом трудовой деятельности
  if flag_date < start_work then
     flag_date := start_work;
  end if;

  DBMS_OUTPUT.put_line('с '|| TO_CHAR(flag_date,'DD.MM.RRRR')||' по '||TO_CHAR(DATKON,'DD.MM.RRRR'));
  RETURN 'с '|| TO_CHAR(flag_date,'DD.MM.RRRR')||' по '||TO_CHAR(DATKON,'DD.MM.RRRR');
/*
  sumDN:=0;

  OPEN lab;

  n:=1;
  LOOP
	FETCH lab INTO cur_lab;
    IF lab%NOTFOUND THEN
       IF n=1 THEN datkon := cur_lab.period_end; END IF;
       nach := cur_lab.period_start;
       EXIT;
    END IF;

	IF n=1 THEN datkon:=cur_lab.period_end; END IF;

	IF (sumDN + cur_lab.dn) > kolmes
	THEN

        nach := cur_lab.period_start;
		-- сколько дней выходит за рамки 25 лет
        extra_days := sumDN + cur_lab.dn - kolmes;

        -- прибавляем год
        add_years := TRUNC (extra_days / 360);
        nach := add_months(nach, add_years*12);

        -- прибавляем месяцы
        add_month := TRUNC(MOD(extra_days, 360) / 30);
        nach := add_months(nach, add_month);

        -- прибавляем дни
        add_days := MOD(MOD(extra_days, 360), 30);
        nach := nach + add_days;

        EXIT;
	END IF;

	sumDN:= sumDN+cur_lab.dn;
    n := n+1;
 END LOOP;

 CLOSE lab;
 DBMS_OUTPUT.put_line('*** SIMPLE ->' || nach);
*/
END A_Calc_Nperiod;
/
