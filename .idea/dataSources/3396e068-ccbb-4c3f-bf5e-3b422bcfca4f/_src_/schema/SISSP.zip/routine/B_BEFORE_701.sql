CREATE FUNCTION       B_BEFORE_701(ACID number) return VARCHAR2 is
/*******************************************************************************
 Назначение        :  B_BEFORE_701
 Наименование      : Функция вызываетяс по кнопке "ПРОВЕРКА ПРАВА" на Семейный капитал
 и определяет ввод необходимых данных для смены получателя на назначение семейного капитала
 Автор             : Иванова Т.С.
 Состояние на дату : 14.06.2017
 Коды возврата     : Tекстовое описание почему не начинается проверка права
                     на смену получателя для назначения семейного капитала
********************************************************************************/
vcount    NUMBER;
vcount_RECIPIENT   NUMBER;
vcount_DEATH_DATE  NUMBER;
vcount_METRIC   NUMBER;
vPID      NUMBER;        -- PID уже имеющегося получателя в ОБД
APP       NUMBER;
BEGIN
APP :=SISSP.A_APPLICATION(ACID,18);
 -- ЕСТЬ НАЗНАЧЕНИЕ СЕМ. КАПИТАЛА?
 SELECT COUNT(*) INTO vcount FROM ALLOCATION WHERE CID=ACID AND STAGE IS NULL AND ALLOC_CODE=701;
 IF vcount=0 THEN RETURN '0';--НЕТ ЕЩЁ НАЗНАЧЕНИЯ СЕМ. КАПИТАЛА
  ELSE--ДА, ТОГДА ПРОВЕРКИ
   IF APP =0 THEN
     RETURN 'Отсутствует заявление';

   END IF;

   IF APP <>1402  THEN
     RETURN '0';
    ELSE
  -- PID БЫВШЕГО ПОЛУЧАТЕЛЯ
   SELECT PID INTO VPID from RECIPIENT WHERE CID=ACID AND STAGE IS NULL;
   --ПОЛУЧАТЕЛЯ МОЖНО СМЕНИТЬ ТОЛЬКО ДО ОТКРЫТИЯ СЧЕИА В БАНКЕ
    Select COUNT(*)  INTO vcount_RECIPIENT   from RECIPIENT
     Where PID =VPID  and stage is null and close_date is null  and PERSONAL_ACCT is not null and cid=ACID;
    IF  vcount_RECIPIENT  >0 THEN --ЕСТЬ СЧЕТ
     RETURN 'Сменить получателя нельзя: уже открыт счет в банке';
    END IF;
   -- ПРОВЕРКА СМЕНЫ ПОЛУЧАТЕЛЯ
   SELECT COUNT(*) INTO vcount_RECIPIENT FROM
   (SELECT PID  from RECIPIENT WHERE CID=ACID AND STAGE IS NULL
    INTERSECT
   SELECT PID FROM W$RECIPIENT WHERE CID=ACID AND STAGE IN (1,4)
   );
    IF vcount_RECIPIENT >0 THEN
     RETURN 'Для смены получателя не изменена адресация выплаты. Получатель тот же';
    END IF;
   -- ЕСТЬ ДАТА СМЕРТИ БЫВШЕГО ПОЛУЧАТЕЛЯ?
   SELECT count(*) INTO vcount_DEATH_DATE FROM w$PERSON WHERE PID=VPID AND STAGE IN (1,4) AND DEATH_DATE IS NOT NULL;
   -- НАЛИЧИЕ МЕТРИК БЫВШЕГО ПОЛУЧАТЕЛЯ
   SELECT COUNT(*) INTO vcount_METRIC  FROM W$PERSON_METRIC WHERE CODE in ( 180,323,175,205) AND PID =VPID;
    IF  vcount_DEATH_DATE>0  OR vcount_METRIC >0 THEN      RETURN '0';
    else
     RETURN 'Для смены получателя не введены необходимые характеристики';
    END IF;

  END IF;

 END IF;
END B_BEFORE_701;
/
