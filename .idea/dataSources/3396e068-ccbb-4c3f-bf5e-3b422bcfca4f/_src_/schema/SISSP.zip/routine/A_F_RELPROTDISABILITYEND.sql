CREATE FUNCTION       A_F_RELPROTDISABILITYEND(aOPINION_TYPE in number,
                                                    aADVICE_TYPE  in varchar2) RETURN date IS
/***************************************************************************************
 Функция             :  A_F_RelProtDisabilityLAST
 Наименование        :  Функция возвращает возвращает дату окончания действия инвалидности
                        по коду согласно W$RELATION_PROTOCOL
 Автор               :  Трухтанов              Комментарии и корректирвка: ОЛВ
 Состояние на дату   :  01.06.1999			 		        10.03.2011    02.06.2011
 Код возврата        :  дата окончания действия инвалидности
***************************************************************************************/
 DRIDS             DBMS_SQL.NUMBER_TABLE;
 xADVICE_TYPE      DBMS_SQL.NUMBER_TABLE;
 vsDRID            number;
 vsADVICE_TYPE     number;
 Disability_End    date default  null;
 pRecord_End       date default  null;
 pRecord_End_MRAK  date default  null;
 pReexam_Date      date default  null;
 pDis_Term         date default  null;
 i                 integer;

BEGIN
 /* * Параметры :
 - XLPL.WorkDate     - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
 - AOPINION_TYPE     - ТИП ЗАКЛЮЧЕНИЯ МРЭК/ВКК; КОД ВЕРХНЕГО УРОВНЯ
   ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION - 1 - инвалидность (при -1 - игнорируется)
 - при AADVICE_TYPE  - КОД РЕКОМЕНДАЦИИ; КОД НИЖНЕГО УРОВНЯ
   ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION -- 11, 12, 13 = "" игнорируется, иначе - список параметров * */

 -- Группа инвалидности -- 11, 12, 13
 xADVICE_TYPE := S_ParseFloatArray (AADVICE_TYPE);

 -- RID из W$RELATION_PROTOCOL для MRAK_OPINION_ADVICE
 --=======================================================
 DRIDS := A_F_RelProtGetRIDMrakOpAdvice (0,AOPINION_TYPE);

 -- EXAMED_FROM из MRAK_OPINION_ADVICE
 ------------------------------------------------------
 if (DRIDS.count <> 0) then
    for i in 1 .. DRIDS.count LOOP
         vsDRID := DRIDS(i);
	   FOR Rec In(
	     select nvl(a.Record_End, null) as pRecord_End,
	            nvl(b.Record_End, null) as pRecord_End_MRAK,
	            nvl(a.DIS_TERM, null) as pDis_Term,
			    nvl(b.REEXAM_DATE, null) as pReexam_Date
		   from W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
	      where a.RID = vsDRID
		    and b.RID = a.MRAK_RID
            and NVL (b.RECORD_END,XLPL.WorkDate) >= XLPL.WorkDate -- OLV 29.03.2012
			and NVL (NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate
			and NVL (NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate) >= XLPL.WorkDate
			and a.entered_by = XLPL.User_ID
			and b.entered_by = XLPL.User_ID)
       LOOP
         if (REC.pRecord_End is null) AND (REC.pRecord_End_MRAK is null)
		     AND (REC.pDis_Term is null) AND (REC.pReexam_Date is null) then
			  return null;
	     end if;
	     --if (REC.pRecord_End_MRAK is not null) then
         if (REC.pRecord_End_MRAK is not null) and (REC.pReexam_Date is not null) then -- можно так обойти ошибку ???-- 17.02.2012 ОЛВ - заплатка ???
	       -- 02.06.2011 ОЛВ - заплатка ??? -- return (REC.pRecord_End_MRAK+1);
	        return (REC.pRecord_End_MRAK); -- 02.06.2011 ОЛВ - заплатка ???
	     end if;
	     if(REC.pRecord_End is not null) then
	        -- 02.06.2011 ОЛВ - заплатка ??? --return (REC.pRecord_End+1);
	        return (REC.pRecord_End); -- 02.06.2011 ОЛВ - заплатка ???
	     else
		    if REC.pDis_Term is not null and  REC.pReexam_Date is null then
              Disability_End := REC.pDis_Term;
            else
			   if REC.pDis_Term is  null and  REC.pReexam_Date is not null then
                   Disability_End := REC.pReexam_Date;
               else
			      if REC.pDis_Term >= REC.pReexam_Date  then
                      Disability_End := REC.pDis_Term;
		          else
				      Disability_End := REC.pReexam_Date;
		          end if;
               end if;
            end if;
	     end if;
       end loop;
	end loop;
 end if;

  return Disability_End;
--RAISE_APPLICATION_ERROR(-20801,' A_F_RELPROTDISABILITYEND 333'|| CHR(10)|| ' REC.pRecord_End='||REC.pRecord_End);

/* --------------------------------------------------------------------
// Автор: Трухтанов
// состояние на 01.06.1999
// Код возврата: возвращает дату окончания действия инвалидности
//               по коду согласно W$RELATION_PROTOCOL
//
//     Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
//     AOPINION_TYPE - одно значение (при -1 - игнорируется)
//     при AADVICE_TYPE = "" будет игнорироваться, иначе интерпритируется как список параметров
// --------------------------------------------------------------------*

DRIDS DBMS_SQL.NUMBER_TABLE;
vsDRID number;

xADVICE_TYPE DBMS_SQL.NUMBER_TABLE;
vsADVICE_TYPE number;

Disability_End date default  null;
pRecord_End  date default  null;
pRecord_End_MRAK  date default  null;
pReexam_Date  date default  null;
pDis_Term  date default  null;
i integer;

BEGIN

  xADVICE_TYPE := S_ParseFloatArray (AADVICE_TYPE);
  DRIDS := A_F_RelProtGetRIDMrakOpAdvice (0,AOPINION_TYPE);

  if (DRIDS.count <> 0) then
    for i in 1 .. DRIDS.count LOOP
    vsDRID := DRIDS(i);
	FOR Rec In(
	  select nvl(a.Record_End, null) as pRecord_End,
	         nvl(b.Record_End, null) as pRecord_End_MRAK,
	         nvl(a.DIS_TERM, null) as pDis_Term,
			 nvl(b.REEXAM_DATE, null) as pReexam_Date
		 from W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
	     where
		   a.RID = vsDRID and
		   b.RID = MRAK_RID and
		   NVL (NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate and
		   NVL (NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate) >= XLPL.WorkDate and
		   a.entered_by = XLPL.User_ID and
		   b.entered_by = XLPL.User_ID)
    LOOP
      if (REC.pRecord_End is null) AND (REC.pRecord_End_MRAK is null) AND
	     (REC.pDis_Term is null) AND (REC.pReexam_Date is null) then return null;
	  end if;
/*	if(pRecord_End_MRAK <> Empty_Date) return LastDayOfMonth(pRecord_End_MRAK)+1;
	if(pRecord_End <> Empty_Date) return LastDayOfMonth(pRecord_End)+1;
	else Disability_End = jtod(int(max(julian(LastDayOfMonth(pDis_Term)), julian(LastDayOfMonth(pReexam_Date)))));*
	  if(REC.pRecord_End_MRAK is not null) then
	    return (REC.pRecord_End_MRAK+1);
	  end if;
	  if(REC.pRecord_End is not null) then
	    return (REC.pRecord_End+1);
	  else if REC.pDis_Term is not null and  REC.pReexam_Date is null then
              Disability_End := REC.pDis_Term;
         else if REC.pDis_Term is  null and  REC.pReexam_Date is not null then
                   Disability_End := REC.pReexam_Date;
              else if REC.pDis_Term >= REC.pReexam_Date  then
                        Disability_End := REC.pDis_Term;
		               else Disability_End := REC.pReexam_Date;
		               end if;
              end if;
         end if;
	  end if;
    end loop;
	end loop;
  end if;
  return Disability_End;
  /* */
END A_F_RELPROTDISABILITYEND;
/
