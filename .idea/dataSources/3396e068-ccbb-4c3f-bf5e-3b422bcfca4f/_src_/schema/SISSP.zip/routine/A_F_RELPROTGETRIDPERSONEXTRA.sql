CREATE FUNCTION       A_F_RelProtGetRidPersonExtra(Base_ID in Number) RETURN NUMBER AS
/******************************************************************************
 NAME              : A_F_RelProtGetRidPersonExtra
 Назначение        : Возращает из (W$)PERSON_EXTRA согласно W$RELATION_PROTOCOL
 Автор             : Вахромин О.Ю.        Комментарии и корректировка: ОЛВ
 Состояние на дату :                                            06.06.2014
 Код возврата      : RID из (W$)PERSON_EXTRA
*******************************************************************************/
 vsRelation_Table   NUMBER;
 vsDRid             NUMBER;
BEGIN
   vsDRid:=-1;
   /* *    if Base_ID=0 then
      vsRelation_Table:=S_CodeTableSissp('W$PERSON_EXTRA');
   else
      vsRelation_Table:=S_CodeTableSissp('PERSON_EXTRA');
   end if; /* */
   BEGIN
      if Base_ID=0 then
             vsRelation_Table:=S_CodeTableSissp('W$PERSON_EXTRA');
  	      select DATA_RID into vsDRID from W$RELATION_PROTOCOL b,W$PERSON_EXTRA a
           where CID=XLPL.Cid
             and (Aid=XLPL.Aid or XLPL.Aid=0)
             and (GROUP_NO=XLPL.Group_No or (XLPL.Aid<>0 and XLPL.Group_No=0))
             and ALLOC_CODE=XLPL.Alloc_Code
             and RELATION_TABLE=vsRelation_Table
             and RELATION_DATE=XLPL.WorkDate
             and b.ENTERED_BY=XLPL.User_ID
             and a.ENTERED_BY=XLPL.User_ID -- 06.06.2014 ЯСА
             and DATA_RID=a.RID
             and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WorkDate)
                                   and NVL(a.RECORD_END,XLPL.WorkDate)
             and a.PID=XLPL.GetPid;
      else
             vsRelation_Table:=S_CodeTableSissp('PERSON_EXTRA');
          select DATA_RID into vsDRID from W$RELATION_PROTOCOL b,PERSON_EXTRA a
           where CID=XLPL.Cid
           and (Aid=XLPL.Aid or XLPL.Aid=0)
           and (GROUP_NO=XLPL.Group_No or (XLPL.Aid<>0 and XLPL.Group_No=0))
           and ALLOC_CODE=XLPL.Alloc_Code
           and RELATION_TABLE=vsRelation_Table
           and RELATION_DATE=XLPL.WorkDate
           and b.ENTERED_BY=XLPL.User_ID
           and DATA_RID=a.RID
           and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WorkDate)
                                 and NVL(a.RECORD_END,XLPL.WorkDate)
           and a.PID=XLPL.GetPid;
      end if;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         vsDRid:=-1;
   END;
   RETURN vsDRid;
END A_F_RelProtGetRidPersonExtra;
/
