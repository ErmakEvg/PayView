CREATE FUNCTION       B_AddYearsMonths_D(Old_Date in DATE, Step in NUMBER) RETURN DATE AS
/*******************************************************************************
 Функция            : B_AddYearsMonths_D
 Наименование       : Ф-я увеличивает дату на заданное количество месяцев
 Автор              : ОЛВ
 Состояние на дату  : 09.02.2011   09.08.2017
 Код возврата       : дата
********************************************************************************/
 Date_New         DATE;
 Dt_Day           Number;

BEGIN
    Date_New:=B_AddYearsMonths(Old_Date, Step);
  IF XLPL.AID<>0 THEN -- 09.08.2017 OLV
    RETURN Date_New;
  ELSE -- исправить погрешность последнего дня месяца для февраля
     IF Old_Date = Last_Day(Old_Date) then
          Dt_Day :=to_number(to_char(Old_Date,'DD'));
       IF Dt_Day<to_number(to_char(Date_New,'DD')) then
          Date_New := S_EncodeDate(to_number(to_char(Date_New,'YYYY')), to_number(to_char(Date_New,'MM')), Dt_Day);
       END IF;
     END IF;
  END IF;
   RETURN Date_New;
END B_AddYearsMonths_D;
/
