CREATE FUNCTION       A_F_AllocStartConvert RETURN DATE IS
/***************************************************************************************
 Функция           :  A_F_AllocStartConvert
 Наименование      :  Функция определения даты первоначального назначения для конвертированного назначения
 Автор             :  Вахромин О.Ю.         Комментарии и корректировка:  ОЛВ
 Состояние на дату :  		   							  				  15.02.2011
 Код возврата      : Дата первоначального назначения
***************************************************************************************/
ALLOC_START_PN   date; -- дата первоначального назначения
BEGIN
  BEGIN
     IF A_F_ArrivedCase THEN -- прибывшее дело
       -- дата первоначального назначения для прибывшего дела
	   ALLOC_START_PN:= A_F_ArrivedCase_Date;
	 ELSE
	   -- дата первоначального назначения для конвертируемых дел
	   select DATA_PN
	     into ALLOC_START_PN
	     from Z$DELO
		where CID=XLPL.CID;
       ---select TO_DATE(b.ASVPD_ALLOCATION_START,'DD.MM.YYYY') into ASVPD_ALLOC_START from ASVPD_CASE b where b.CID=XLPL.CID;
     END IF;

  EXCEPTION
        when NO_DATA_FOUND or TOO_MANY_ROWS then
              ALLOC_START_PN:=XLPL.WorkDate;
  END;
--RAISE_APPLICATION_ERROR(-20801,'A_F_AllocStartConvert ASVPD_ALLOC_START='||ALLOC_START_PN||'  Xlpl.WorkDate'|| Xlpl.WorkDate);
   return ALLOC_START_PN;
END A_F_AllocStartConvert;
/
