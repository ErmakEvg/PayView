CREATE FUNCTION       B_F_ControlPersonSDD_AddrHelp (aCID in number, prBase in number, aDate in date) RETURN VARCHAR2 IS

/******************************************************************************************
 Функция: B_F_ControlPersonSDD_AddrHelp
 Наименование: Состав и число членов семьи, учитываемый при определении СДД (средний душевой доход)
                Адресная социальная помощь
 Автор: Абрамович М.В.
 Состояние на дату 26.01.2012 -UID in W$ACTIVITY
                   в соотв. с изменениями в Постановлении от 22 июля 2011
 Возвращает: массив PIDов лиц, доход которых учитывается при расчете СДД

 prBase = 0 - работа с РБД
 prBase = 1 - работа с OБД
******************************************************************************************/

PIDsList DBMS_SQL.NUMBER_TABLE;
A DBMS_SQL.NUMBER_TABLE;
aRole NUMBER;
aRelation NUMBER;
aPID NUMBER;
pPID NUMBER;
cnt NUMBER;
i NUMBER;
j NUMBER;
Sur VARCHAR2(30);
Nam VARCHAR2(30);
PatNam VARCHAR2(30);
RetStr VARCHAR2(255);
pDate DATE;
UID number;-- заплатка
pDateEnd Date;
pDateStart Date;
Date1 Date;
BEGIN

cnt := 0;
Sur := '';
Nam := '';
PatNam := '';
i := 0;
j := 1;

PIDsList.delete;
A.delete;

------------------------------------------------
-- Определяем дату проверки СДД (в общем случае)
------------------------------------------------
--Dt1 := S_JTOD(S_Const(478, sysdate));
-- 478 - дата начала действия пособия на детей старше 3  лет ??????
--pDate := s_EncodeDate(s_YearOfDate(sysdate), s_MonthOfDate(Dt1), s_DayOfDate(Dt1));
--if aDate is not NULL and aDate > pDate then
    pDate := aDate;            	 	   			   -- Дата, на которую определяется ССД
--end if;
---------------------------------------------------
-- Формируем массив данных для каждого лица из дела
---------------------------------------------------
--raise_application_error(-20004,'pDate'||pDate);
if prBase = 0 then		   						   -- Работа с РБД
   -- ЗАПЛАТКА ELENA
   SELECT entered_by
   into UID
    from W$case where cid=aCID
   and stage in (1,4);
   XLPL.User_ID:=UID;
   -- ЗАПЛАТКА ELENA end
   select count (*) into cnt
   from W$ALLOCATION
   where cid = aCID;
   if cnt <> 0 then
	  for Rec in
	 	   (Select a.PID as aPID,
		   		   nvl(a.ROLE, 0) as aRole,
				   nvl(a.RELATION, 0) as aRelation
            From   W$CASE_PERSON a, W$PERSON b
            Where  a.CID = aCID and
				   a.PID = b.PID and
--                   a.ENTERED_BY = XLPL.USER_ID and
				   b.ENTERED_BY = XLPL.USER_ID and --ELENA 16.05.2011
				   a.STAGE NOT IN (2,3) and
                   b.STAGE NOT IN( 2,3) and
				   b.BIRTH_DATE <= pDate and
				   (b.DEATH_DATE is null or b.DEATH_DATE > pDate))
	  loop
	  A(A.count + 1) := Rec.aPID;   	  		   -- PID
	  A(A.count + 1) := Rec.aRole;  	  		   -- роль лица в деле
	  A(A.count + 1) := Rec.aRelation; 	  		   -- родственные отношения
	  if B_SSD_IsRecipient(aPID, aCID) then
	  	 A(A.count + 1) := 1;
	  else
	     A(A.count + 1) := 0;
	  end if; -- 1 - если получатель
  	  A(A.count + 1) := 0; 	  	  	 	  		   -- метрики
	  A(A.count + 1) := 0;	 	  				   --
	  A(A.count + 1) := S_julian(pDate); 		   -- дата возникновения права
	  end loop;
	else
	  --raise_application_error(-20004,'XLPL.USER_ID='||XLPL.USER_ID);
	  for Rec1 in
	 	   (Select a.PID as aPID,
		   		   nvl(a.ROLE, 0) as aRole,
				   nvl(a.RELATION, 0) as aRelation
            From   W$CASE_PERSON a, W$PERSON b
            Where  a.CID = aCID and
				   a.PID = b.PID and
--                 a.ENTERED_BY = XLPL.USER_ID and
				   b.ENTERED_BY = XLPL.USER_ID and --ELENA 16.05.2011
				   a.STAGE NOT IN (2,3) and
                   b.STAGE NOT IN( 2,3) and
				   (b.DEATH_DATE is null or b.DEATH_DATE > pDate)
           )
	  loop
	  A(A.count + 1) := Rec1.aPID;   	  		   -- PID
	  A(A.count + 1) := Rec1.aRole;  	  		   -- роль лица в деле
	  A(A.count + 1) := Rec1.aRelation; 	  	   -- родственные отношения
	  if B_SSD_IsRecipient(Rec1.aPID, aCID) then
	     A(A.count + 1) := 1;
	  else
	     A(A.count + 1) := 0;
	  end if; -- 1 - если получатель
  	  A(A.count + 1) := 0; 	  	  	 	  		   -- метрики
	  A(A.count + 1) := 0;	 	  				   --
	  A(A.count + 1) := S_julian(pDate); 		   -- дата возникновения права
	  end loop;
   end if;
else  		   			  -- Работа с ОБД
	  for Rec2 in
	 	   (Select a.PID as aPID,
		   		   nvl(a.ROLE, 0) as aRole,
				   nvl(a.RELATION, 0) as aRelation
            From   CASE_PERSON a, PERSON b
            Where  a.CID = aCID and
                   a.PID = b.PID and
				   b.BIRTH_DATE <= pDate and
				  (b.DEATH_DATE is null or b.DEATH_DATE > pDate) and
				  (a.STAGE is null or a.STAGE NOT IN(2,3)) and
                  (b.STAGE is null or b.STAGE NOT IN(2,3)))
	  loop
	  A(A.count + 1) := Rec2.aPID;   	  		   -- PID
	  A(A.count + 1) := Rec2.aRole;  	  		   -- роль лица в деле
	  A(A.count + 1) := Rec2.aRelation; 	  	   -- родственные отношения
	  if B_SSD_IsORecipient(aPID, aCID) then
	  	 A(A.count + 1) := 1;
	  else
	  	 A(A.count + 1) := 0;
	  end if; -- 1 - если получатель
  	  A(A.count + 1) := 0; 	  	  	 	  		   -- метрики для исключения
	  A(A.count + 1) := 0;	 	  				         --
	  A(A.count + 1) := S_julian(pDate); 		   -- дата рождения
	  end loop;
end if;


if A.count > 0 then
   j := 1;
   for i in 1 .. A.count/7 loop
    -- Определение даты рождения
     A(j+6) := S_julian(B_SSD_Date(A(j), prBase));

 	   if ((A(j+1) = 65)and (pDate<TO_DATE('01.11.2011','dd.mm.yyyy'))) then -- было до 01.11.2011
	      if B_SSD_Metric(A(j), pDate, 176, prBase) then
		        A(j+4) := 1; -- ИТУ
		  end if;
		  if B_SSD_Metric(A(j), pDate, 177, prBase) then
		        A(j+4) := 1; -- В местах лишения свободы
		  end if;
          if B_SSD_Metric(A(j), pDate, 175, prBase) then
		        A(j+4) := 1; -- В розыске в свяэи с неуплатой алиментов
		  end if;
		  if B_SSD_Metric(A(j), pDate, 187, prBase) then
		        A(j+4) := 1; -- Находится в ЛТП п.3.2
		  end if;
		  if B_SSD_Metric(A(j), pDate, 121, prBase) then
		        A(j+4) := 1; -- Военнослужащий срочной службы
		  end if;
		  if B_SSD_Metric(A(j), pDate, 125, prBase) then
		        A(j+4) := 1; -- Военнослужащий срочной службы
		  end if;
         if B_SSD_ACTIVITY_AddrHelp(A(j), pDate,2, '331', prBase) then --курсант
		        A(j+4) := 1;
	     end if;

           -- 188- учится на дневном на гос.обеспечении
           -- 172,680,679,682,681  гос.обеспечении
           if B_SSD_METRIC_AddrHelp(A(j), pDate,'188,172,680,679,682,681', prBase) then
           A(j+4) := 1;
          end if;
		  -- по месту жительсва определить SOCHOUSE
	  if B_SSD_SOCHOUS_AddrHELP(A(j), pDate, prBase)then   --   п.3.5
        A(j+4) := 1;
      end if;
      --неработающий трудоспособный не зарегистрированный в качестве безработного

	 if (S_YearsBetween(pDate, B_SSD_Date(A(j), prBase)) >16 ) then
         if B_SSD_NotWork_AddrHelp(A(j), pDate, prBase)then --не работает не учится не безработный не пенсионер
           if  not B_SSD_Metric(A(j), pDate, 260, prBase) then ----  Осуществляет  уход за ребенком до 3 лет
		        A(j+4) := 1;
				else
				A(j+5) := 0;
		   end if;
         else --работает
		     if B_SSD_ACTIVITY_AddrHelp(A(j), pDate,2, '222,224', prBase) then --для школьника проверяем исключение
			  --необходимо определить год окончания
			    if prBase= 0 then
				      select PERIOD_END into pDateEnd
                      from W$ACTIVITY
                      where PID = A(j) and
	                    (STAGE in (1,4,6) or STAGE is null) and
		                 ACTIVITY = 2 and
	                     LABOR in (222,224) and ENTERED_BY = XLPL.USER_ID and
                         (PERIOD_START <= aDate or PERIOD_START is null) and
                         (PERIOD_END <= aDate or PERIOD_END is null);
				 else
				      select PERIOD_END into pDateEnd
                      from ACTIVITY
                      where PID = A(j) and
	                    ( STAGE is null) and
		                 ACTIVITY = 2 and
	                     LABOR in (222,224) and
                         (PERIOD_START <= aDate or PERIOD_START is null) and
                         (PERIOD_END <= aDate or PERIOD_END is null);
				end if; -- prBase
				 if pDateEnd is null then A(j+5) := 0;
				 else
				    Date1:=TO_DATE(S_YearOfDate(pDateEnd),'YYYY');
                    if ((S_YearOfDate(aDate)=S_YearOfDate(pDateEnd))  AND
                    (aDate<ADD_MONTHS(Date1,9)))
                    then
                      A(j+5) := 0;
                    else
                      A(j+5) := 1;
                   end if;

				end if; --pDateEnd is null
			 else
               A(j+5) := 0;
			  -- п.3.7 -  зарегистрированный в качестве безработного
		        if B_SSD_ACTIVITY1_AddrHelp(A(j), pDate,3, prBase) and not(B_SSD_ACTIVITY_AddrHelp(A(j), pDate,1, '246,315', prBase)) then--отпуск и уход за ребенком до 3 лет
                --if not B_SSD_ACTIVITY_AddrHelp(A(j), pDate,1, '246,315', prBase) then--отпуск и уход за ребенком до 3 лет
				 -- проверяем < 3 месяцев
				     if prBase= 0 then
				      select PERIOD_START into pDateStart
                      from W$ACTIVITY
                      where PID = A(j) and
	                    (STAGE in (1,4,6) or STAGE is null) and
		                 ACTIVITY = 3 and ENTERED_BY = XLPL.USER_ID and
                         (PERIOD_START <= aDate or PERIOD_START is null) and
                         (PERIOD_END >= aDate or PERIOD_END is null);
				     else
				       select PERIOD_END into pDateStart
                       from ACTIVITY
                        where PID = A(j) and
	                    ( STAGE is null) and
		                 ACTIVITY = 3 and
                         (PERIOD_START <= aDate or PERIOD_START is null) and
                         (PERIOD_END >= aDate or PERIOD_END is null);
				     end if; -- prBase
				  if pDateStart is null then A(j+5) := 1;
				  else
				   -- raise_application_error(-20004,'pDateStart'||pDateStart);
				     if aDate<ADD_MONTHS(pDateStart,3) then --< 3 месяцев
					  A(j+5) := 1;
					    -- проверяем исключения
						if B_SSD_ActvityDisMiss(A(j),1,'', '2,3,4,5,8,10,11,12',aDate, prBase) then --есть увольнение
						 -- определить дату (зарегистрировался в течении месяца после даты)
						   A(j+5) := 0; --???????????77
						end if;
					 else --  >3
					  A(j+5) := 0;
				     end if;
			      end if; --pDateStart is null
			    end if; --безработн
			 end if; --школьн

         end if; --проверка работы   п.3.6
		 --raise_application_error(-20004,'A(j+5)='||A(j+5));
      end if; --16 лет
      end if; --65
	   j := j + 7;
   end loop;
end if;


---------------------------------------------------------------------------
-- Выбор требуемых PID, удовлетворяющих Положению о порядке исчисления ССД.
---------------------------------------------------------------------------
if A.count > 0 then
   j := 1;
   for i in 1 .. A.count/7 loop
	  if A(j+1) = 0 then
	     pPID := A(j);
		 if prBase = 0 then
		 begin
	 	 	  Select SURNAME, NAME, PATNAME into Sur, Nam, PatNam
              From   W$PERSON
              Where  PID = pPID and
                     ENTERED_BY = XLPL.USER_ID and
                     STAGE NOT IN(2,3);
         exception
		      when No_Data_Found then
			    RAISE_APPLICATION_ERROR(-20851,'Лицо c персональным идентификатором '|| to_char(A(j)) || ' отсутствует в деле' || chr(10));
				return RetStr;
			  when others then
                RAISE_APPLICATION_ERROR(-20851,'Лицо ' || Sur || ' ' || Nam || ' ' || PatNam || ' не имеет роли.' || chr(10) ||
				'Укажите роль лица в назначении' || chr(10));
				return RetStr;
	     end;
		else
	   	  pPID := A(j);
		  begin
	 	 	  Select SURNAME, NAME, PATNAME into Sur, Nam, PatNam
              From   PERSON
              Where  PID = pPID and
                     STAGE is NULL;
          exception
		      when No_Data_Found then
			    RAISE_APPLICATION_ERROR(-20851,'Лицо c персональным идентификатором '|| to_char(A(j)) || ' отсутствует в деле' || chr(10));
				return RetStr;
			  when others then
                RAISE_APPLICATION_ERROR(-20851,'Лицо ' || Sur || ' ' || Nam || ' ' || PatNam || ' не имеет роли.' || chr(10) ||
				'Укажите роль лица в назначении' || chr(10));
				return RetStr;
	      end;
		end if;
	  end if;
		--raise_application_error(-20004,'J+4'||A(j+5)||A(j));

		--if ((A(j+1) = 65)or((A(j+1) = 75)or(A(j+1) = 76)) ) and A(j+4) <> 1  and A(j+5) <> 1  then
		  if ((A(j+1) = 65)and (pDate<TO_DATE('01.11.2011','dd.mm.yyyy'))) then
			 if ((A(j+4)) <> 1  and (A(j+5) <> 1))then
			   PIDsList(PIDsList.count + 1) := A(j);
			 end if;
		  else
		       PIDsList(PIDsList.count + 1) := A(j);
		end if;

	j := j + 7;
	end loop;
end if;
---------------------------------------
-- Формирование строки с выбранными PID
---------------------------------------
RetStr := null;
if PIDsList.count > 0 then
   for i in 1 .. PIDsList.count loop
   	   if RetStr is null then RetStr := to_char(PIDsList(i));
   	   else RetStr := RetStr || ',' || to_char(PIDsList(i));
	   end if;
   end loop;
end if;
--raise_application_error(-20004,'RetStr'||RetStr);
-- dbms_output.PUT_LINE (RetStr);
return RetStr;

END B_F_ControlPersonSDD_AddrHelp;
/
