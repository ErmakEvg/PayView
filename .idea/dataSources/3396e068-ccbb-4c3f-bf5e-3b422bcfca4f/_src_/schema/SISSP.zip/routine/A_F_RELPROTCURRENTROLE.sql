CREATE FUNCTION       A_F_RelProtCurrentRole RETURN NUMBER IS
--==============================================================================
-- Назначение: определяет роль текущего PID в деле
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Возвращаемое значение:
--==============================================================================
xResume NUMBER;
xCID NUMBER;
xPID NUMBER;
xUser NUMBER;
BEGIN
xResume := 0;
xCID := XLPL.CID;
xUser := XLPL.USER_ID;
xPID := XLPL.GETPID;
begin
  select nvl(ROLE, 0) into xResume
  from W$CASE_PERSON
  where CID = xCID
  and PID = xPID
  and STAGE in (1, 4)
  and ENTERED_BY = xUser;
exception
    when NO_DATA_FOUND then
	xResume := 0;
end;
if xResume = 0 then
  begin
    select nvl(ROLE, 0) into xResume
 	from CASE_PERSON
	where CID = xCID
	and PID = xPID
	and (STAGE in (1, 4) or STAGE is NULL);
  exception
    when NO_DATA_FOUND then
	xResume := 0;
  end;
end if;
RETURN xResume;
END A_F_RelProtCurrentRole;
/
