CREATE FUNCTION       B_Child16_Nadbavka_20020701 RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_Child16_Nadbavka_20020701
 Наименование       : Проверка права и вычисление надбавок для пособий детям старше 3 лет
 Автор              : Ворошилин В.               Коректировка: ОЛВ
 Состояние на дату  : 26.09.2002                                10.08.2010
 Код возврата       : массив, содержащий коды надбавок и соответствующие суммы надбавок
***********************************************************************************************/
 K      DBMS_SQL.NUMBER_TABLE;
 Bonus  DBMS_SQL.NUMBER_TABLE;

BEGIN

 K.delete;
 Bonus.delete;
--RAISE_APPLICATION_ERROR(-20801,'B_Child16_Nadbavka_20020701     XLPL.WorkDate='||XLPL.WorkDate);

 --M := B_F_Nad0; -- ОЛВ
 Bonus := B_F_Nad1;  -- ОЛВ
 if Bonus.count <> 0 then
   K := Bonus;
 end if;

 Return K;

END B_Child16_Nadbavka_20020701;
/
