CREATE FUNCTION       B_F_ArrayDateChangeACTIVITYGar(PuskDate date) RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: F_ArrayDateChangeACTIVITYGarden
+ Наименование: возвращает массив с датой наступления 1,5 года
+ Автор: Трухтанов
+ Состояние на дату 03.05.2000
==============================================================================*/

result_array DBMS_SQL.NUMBER_TABLE;
Ch number;
BDate date;
WDt date;
Dtt0 date;
Dtt1 date;
Dtt2 date;
Dtt3 date;

BEGIN

result_array.delete;
if XLPL.CheckRole(56) then
   XLPL.RoleDecl('Child','56');
   XLPL.REPLACEROLE('Child');
   BDate := S_BirthDate(0,XLPL.GETPID,XLPL.WorkDate);	-- дата рождения ребенка
   XLPL.RestoreRole;
else
   return result_array;
end if;
  WDt := Last_day(S_CurrDate);

  Ch := S_Const(401,XLPL.WorkDate);
  Dtt0 := Add_Months(BDate,Ch*12)+1;

  Ch := S_Const(402,XLPL.WorkDate);
  Dtt1 := Add_Months(BDate,Ch*12)+1;

  Ch := S_Const(513,XLPL.WorkDate);
  Dtt2 := Add_Months(BDate,Ch*12)+1;

  Ch := S_Const(514,XLPL.WorkDate);
  Dtt3 := Add_Months(BDate,Ch*12)+1;

  if (Dtt1 > PuskDate) AND (Dtt1 <= WDt) then
    result_array(result_array.count+1) := S_Julian(Dtt1);
  end if;

  if (Dtt2 > PuskDate) AND (Dtt2 <= WDt) then
   result_array(result_array.count+1) := S_Julian(Dtt2);
  end if;

  if (Dtt3 > PuskDate) AND (Dtt3 <= WDt) then
   result_array(result_array.count+1) := S_Julian(Dtt3);
  end if;

return result_array;

END B_F_ArrayDateChangeACTIVITYGar;
/
