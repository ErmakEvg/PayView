CREATE FUNCTION       B_F_Arraydateestchildinvalid RETURN DBMS_SQL.NUMBER_TABLE AS

/***************************************************************************************
 Функция: F_ARRAYDATEESTCHILDINVALID
 Наименование: Ограничение возраста для детей - инвалидов для Estimation
 Автор: Ворошилин В.
 Состояние на дату 29.11.2000   23.10.2012
 Код возврата: Массив, состоящий из даты, кода причины, кода изменения состояния
***************************************************************************************/

  result DBMS_SQL.NUMBER_TABLE;
  StopDt DATE;
  DtBirth DATE;
BEGIN
  result.DELETE;
  Xlpl.RoleDecl('Child', '56');
  IF NOT Xlpl.CHECKROLE(56) THEN
	RETURN result;
  END IF;
  Xlpl.REPLACEROLE('Child');
  DtBirth := A_F_Relprotbirthday;
  StopDt := S_Addyears(DtBirth, S_Const(407, Xlpl.WorkDate));
  IF A_F_Relprotdisability(1, '14') THEN
    IF StopDt > LAST_DAY(S_Currdate) THEN
    -- срок действия пособия перед днем достижения 18 лет разъяснение Коваль СИ
    -- Речицкая А. В. 23.10.2012 --result(1) := S_Julian(StopDt);
      result(1) := S_Julian(StopDt)-1;--Речицкая А. В. 23.10.2012 инвалидность установить "по"
 	  result(2) := 28;
 	  result(3) := 2;
	END IF;
  END IF;
  Xlpl.RESTOREROLE;
  RETURN result;
END B_F_Arraydateestchildinvalid;
/
