CREATE FUNCTION       A_F_RELPROTODISABILITYPERCENT(AOPINION_TYPE IN BINARY_INTEGER, AADVICE_TYPE IN BINARY_INTEGER, AREASON IN VARCHAR2) RETURN NUMBER AS
/*******************************************************************************
 Функция             : A_F_RELPROTODISABILITYPERCENT
 Наименование        : Возвращает % потери трудоспособности по инвалидностям вследствие ЧАЭС
 Автор               :             Комментарии и корректировка: ОЛВ
 Состояние на дату   :                                   16.03.2011    11.07.2016
 Код возврата        : возвращает % потери трудоспособности
*******************************************************************************/
 xReason          DBMS_SQL.NUMBER_TABLE;
 DRIDS            DBMS_SQL.NUMBER_TABLE;
 pRecord_End      DATE;
 pDis_Term        DATE;
 vsADVICE_TYPE    BINARY_INTEGER;
 vsDRID           NUMBER;
 pPercent         NUMBER;
 pReason          NUMBER;

BEGIN
  pPercent := 0;
  xReason.delete;
  DRIDS.delete;

 -- Причина инвалидности REF_DISABILITY_REASON
 xReason := S_ParseFloatArray(AREASON);

 -- RID из W$RELATION_PROTOCOL для MRAK_OPINION_ADVICE
 --=======================================================
 DRIDS := A_F_RelProtGetRIDMrakOpAdvice(1, AOPINION_TYPE);

 if DRIDS.count <> 0 then
   -- DIS_PERCENT из MRAK_OPINION_ADVICE
   ------------------------------------------------------
   for i in 1..DRIDS.count loop
        vsDRID:=DRIDS(i);
     BEGIN
      select nvl(a.DIS_PERCENT,0), nvl(a.DIS_REASON,0)
        INTO pPercent, pReason
        from MRAK_OPINION_ADVICE a, MRAK_OPINION b
       where a.RID = vsDRID --DRIDS(i)
         and b.RID = MRAK_RID
         and a.ADVICE_TYPE = AADVICE_TYPE
         AND NVL (b.RECORD_END,Xlpl.WorkDate) >= Xlpl.WorkDate -- OLV 11.07.2016
         and NVL (NVL(a.RECORD_START,b.EXAMED_FROM),  XLPL.WorkDate) <=  XLPL.WorkDate
         and NVL (NVL(a.RECORD_END,a.DIS_TERM), XLPL.WorkDate) >=  XLPL.WorkDate;
      if pReason <> 0 then
        -- Причина инвалидности REF_DISABILITY_REASON
        for j in 1..xReason.count loop
          if (xReason(j) = pReason) and (pPercent <> 0) then
            return pPercent;
          end if;
        end loop;
      end if;
     EXCEPTION  -- OLV  16.03.2011
         WHEN No_Data_Found THEN null;
     END;
   end loop;
 end if;

 -- RID из W$RELATION_PROTOCOL для w$MRAK_OPINION_ADVICE
 --=======================================================
 DRIDS := A_F_RelProtGetRIDMrakOpAdvice(0, AOPINION_TYPE);

 if DRIDS.count <> 0 then
    -- DATA_RID из W$MRAK_OPINION_ADVICE
    ------------------------------------------------------
   for i in 1..DRIDS.count loop
        vsDRID:=DRIDS(i);
     BEGIN
      select nvl(a.DIS_PERCENT,0), nvl(a.DIS_REASON,0)
      INTO pPercent, pReason
      from W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
      where a.RID = vsDRID --DRIDS(i)
        and b.RID = MRAK_RID
        and a.ADVICE_TYPE = AADVICE_TYPE
        and NVL (NVL(a.RECORD_START,b.EXAMED_FROM),  XLPL.WorkDate) <=  XLPL.WorkDate
        and NVL (NVL(a.RECORD_END,a.DIS_TERM), XLPL.WorkDate) >=  XLPL.WorkDate
        AND NVL (b.RECORD_END,Xlpl.WorkDate) >= Xlpl.WorkDate -- OLV 11.07.2016
        and a.entered_by = XLPL.User_Id
        and b.entered_by = XLPL.User_Id;
      if pReason <> 0 then
        -- Причина инвалидности REF_DISABILITY_REASON
        for j in 1..xReason.count loop
          if (xReason(j) = pReason) and (pPercent <> 0) then
            return pPercent;
          end if;
        end loop;
      end if;
     EXCEPTION  -- OLV  16.03.2011
         WHEN No_Data_Found THEN null;
     END;
   end loop;
 end if;
  return pPercent;
END A_F_RELPROTODISABILITYPERCENT;
/
