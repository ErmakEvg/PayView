CREATE FUNCTION       B_F_ArrayDateEstCASE_SUM_INC RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_ArrayDateEstCASE_SUM_INC
+ Наименование: возвращает массив дат изменения ССД для Estimation
+ Автор: Ворошилин В.
+ Состояние на дату 17/11/2000
==============================================================================*/

  chahge_date_aRecord DBMS_SQL.NUMBER_TABLE;
  aYEAR_Beg DATE;
  aYEAR_End DATE;
BEGIN
  chahge_date_aRecord.delete;
  aYEAR_Beg := S_EncodeDate(S_YearOfDate(S_AddYears(XLPL.WorkDate, -1)), S_MonthOfDate(S_DateConst(478, XLPL.WorkDate)), S_DayOfDate(S_DateConst(478, XLPL.WorkDate)));
  aYEAR_End := S_EncodeDate(S_YearOfDate(S_AddYears(XLPL.WorkDate, -1)), S_MonthOfDate(S_DateConst(479, XLPL.WorkDate)), S_DayOfDate(S_DateConst(479, XLPL.WorkDate)));
  for CASE_SUM_INC in (select nvl(RECORD_START, NULL) as aRecord_start, nvl(RECORD_END, NULL) as aRecord_end
  					   from W$CASE_SUMMARY_INCOME
					   where CID = XLPL.CID
					     and trunc(W$CASE_SUMMARY_INCOME.YEAR, 'YYYY') = trunc((XLPL.WorkDate - 1), 'YYYY')
						 and (NVL(RECORD_START, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate) or NVL(RECORD_END, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate))
						 and STAGE in (1, 4)
						 and ENTERED_BY = XLPL.USER_ID)

  loop
    if (CASE_SUM_INC.aRecord_start is not NULL) and (CASE_SUM_INC.aRecord_start <> aYEAR_Beg) and (CASE_SUM_INC.aRecord_start > LAST_DAY(S_CurrDate)) then
	  chahge_date_aRecord(chahge_date_aRecord.count + 1) := S_Julian(CASE_SUM_INC.aRecord_start) - 1;
	  chahge_date_aRecord(chahge_date_aRecord.count + 1) := 313;
	  chahge_date_aRecord(chahge_date_aRecord.count + 1) := 1;
    end if;
  end loop;
  return A_F_ArrayDataChangeDelDup(chahge_date_aRecord);
END B_F_ArrayDateEstCASE_SUM_INC;
/
