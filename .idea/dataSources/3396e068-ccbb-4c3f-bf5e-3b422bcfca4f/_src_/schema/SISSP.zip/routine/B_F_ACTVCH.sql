CREATE FUNCTION       B_F_ActvCh RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_Actv
// Наименование: Функция определения рабочей активности лица в прошлом
// Автор: Ворошилин.
// Состояние на дату 13.09.2002
// Возвращает: True - если лицо активно, False - если лицо не активно
//***************************************************************************************/

CN_ACTIVITY NUMBER;
BEGIN
  Select COUNT(*) INTO CN_ACTIVITY From W$ACTIVITY
  Where PID = XLPL.GETPID
    and ACTIVITY in (1, 2)
	and LABOR is NULL
	and ENTERED_BY = XLPL.User_ID
	and STAGE NOT IN(2,3)
	and PERIOD_END is not NULL
	and PERIOD_END < XLPL.WorkDate;
  RETURN CN_ACTIVITY <> 0;
END B_F_ActvCh;
/
