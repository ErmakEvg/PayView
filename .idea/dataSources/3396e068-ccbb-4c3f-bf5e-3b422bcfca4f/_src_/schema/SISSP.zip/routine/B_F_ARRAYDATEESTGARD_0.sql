CREATE FUNCTION       B_F_ARRAYDATEESTGARD_0 RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_ArrayDateEstACTIVITYGarden
+ Наименование: возвращает массив с датой наступления 1,5 года для Estimation
+ Автор: Ворошилин В.
+ Состояние на дату 03.05.2000
==============================================================================*/

  result_array DBMS_SQL.NUMBER_TABLE;
BEGIN
  result_array.delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CheckRole(56) then
    return result_array;
  end if;
  XLPL.REPLACEROLE('Child');
  if ((B_AddYearsMonths(A_F_RelProtBirthDay, S_Const(402, XLPL.WorkDate)) + 1) > LAST_DAY(S_CurrDate))
     and ((S_AddYears(A_F_RelProtBirthDay, TRUNC(S_Const(401, XLPL.WorkDate)))) >= LAST_DAY(S_CurrDate)) then
    result_array(1) := S_Julian(B_AddYearsMonths(A_F_RelProtBirthDay, S_Const(402, XLPL.WorkDate)) + 1);
    result_array(2) := 21;
	result_array(3) := 3;
	XLPL.RESTOREROLE;
    return result_array;
  end if;
  XLPL.RESTOREROLE;
  return result_array;
END B_F_ARRAYDATEESTGARD_0;
/
