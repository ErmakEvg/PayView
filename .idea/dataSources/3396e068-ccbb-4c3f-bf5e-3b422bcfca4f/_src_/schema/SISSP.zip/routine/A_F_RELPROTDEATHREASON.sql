CREATE FUNCTION       A_F_RELPROTDEATHREASON return number is
/* --------------------------------------------------------------------
// Автор: Басинюк Я.В.
// состояние на 10.05.1999
// Код возврата: возвращает причину смерти человека согласно W$RELATION_PROTOCOL
//     Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
// --------------------------------------------------------------------*/

  vsResult number;
  vsDRID number;
begin
--RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtDeathReason:');
  vsDRID := A_F_RelProtGetRIDPerson (1);
  if (vsDRID <> -1)  then
     select NVL(DEATH_REASON,0)
     INTO  vsResult from PERSON where RID = vsDRID;

   else
     vsDRID := A_F_RelProtGetRIDPerson(0);
     if (vsDRID <> -1) then
        select NVL(DEATH_REASON,0)
        INTO  vsResult from W$PERSON where RID = vsDRID
        and ENTERED_BY = XLPL.USER_ID;
     else
        RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtDeathReason:'||chr(10)||
            'Нет DATA_RID в W$RELATION_PROTOCOL для данных CID='||to_char(XLPL.CID));
     end if;
   end if;

  return(vsResult);
end A_F_RELPROTDEATHREASON;
/
