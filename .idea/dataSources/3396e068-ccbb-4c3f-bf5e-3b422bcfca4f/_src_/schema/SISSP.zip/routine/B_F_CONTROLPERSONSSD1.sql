CREATE FUNCTION       B_F_ControlPersonSSD1 (aCID in number, prBase in number, aDate in date) RETURN VARCHAR2 IS

/******************************************************************************************
 Функция: B_F_ControlPersonSSD1
 Наименование: Состав и число членов семьи, учитываемый при определении ССД (новый вариант)
 Автор: Ворошилин В.
 Состояние на дату 20.09.2002
 Возвращает: массив PIDов лиц, учитываемых в ССД

 prBase = 0 - работа с РБД
 prBase = 1 - работа с OБД
******************************************************************************************/

PIDsList DBMS_SQL.NUMBER_TABLE;
A DBMS_SQL.NUMBER_TABLE;
result_array DBMS_SQL.NUMBER_TABLE;
aRole NUMBER;
aRelation NUMBER;
aRecipient NUMBER;
aPID NUMBER;
pPID NUMBER;
cnt NUMBER;
i NUMBER;
j NUMBER;
Sur VARCHAR2(30);
Nam VARCHAR2(30);
PatNam VARCHAR2(30);
RetStr VARCHAR2(255);
wDate DATE;
pDate DATE;
Dt1 DATE;
d DATE;
d1 DATE;
bl BOOLEAN;
PrMother BOOLEAN;
PrChild BOOLEAN;
PrFather BOOLEAN;
PrCommon BOOLEAN;
PrOpekun BOOLEAN;
UID NUMBER;

BEGIN

cnt := 0;
Sur := '';
Nam := '';
PatNam := '';
d := NULL;
i := 0;
j := 1;
bl := False;
PrMother := False;
PrChild := False;
PrFather := False;
PrCommon := False;
PrOpekun := False;
PIDsList.delete;
A.delete;

------------------------------------------------
-- Определяем дату проверки ССД (в общем случае)
------------------------------------------------
--Dt1 := S_JTOD(S_Const(478, sysdate));
--pDate := s_EncodeDate(s_YearOfDate(sysdate), s_MonthOfDate(Dt1), s_DayOfDate(Dt1));
Dt1 := S_JTOD(S_Const(478, sysdate));
pDate := s_EncodeDate(s_YearOfDate(sysdate), s_MonthOfDate(Dt1), s_DayOfDate(Dt1));
if aDate is not NULL and aDate > pDate then
    pDate := aDate;            	 	   			   -- Дата, на которую определяется ССД
end if;
---------------------------------------------------
-- Формируем массив данных для каждого дица из дела
---------------------------------------------------
if prBase = 0 then		   						   -- Работа с РБД
-- ЗАПЛАТКА ELENA
  select Entered_by into UID from W$CASE
   where cid=aCid and stage in (1,4);
   XLPL.USER_ID:=UID;
--ЗАПЛАТКА ELENA end
   select count (*) into cnt
   from W$ALLOCATION
   where cid = aCID;
   if cnt <> 0 then
	  for Rec in
	 	   (Select a.PID as aPID,
		   		   nvl(a.ROLE, 0) as aRole,
				   nvl(a.RELATION, 0) as aRelation
            From   W$CASE_PERSON a, W$PERSON b
            Where  a.CID = aCID and
				   a.PID = b.PID and
--                   a.ENTERED_BY = XLPL.USER_ID and
 			   b.ENTERED_BY = XLPL.USER_ID and -- открыла elena 16.05.2011;
				   a.STAGE NOT IN (2,3) and
                   b.STAGE NOT IN( 2,3) and
				   b.BIRTH_DATE <= pDate and
				   (b.DEATH_DATE is null or b.DEATH_DATE > pDate))
	  loop
	  A(A.count + 1) := Rec.aPID;   	  		   -- PID
	  A(A.count + 1) := Rec.aRole;  	  		   -- роль лица в деле
	  A(A.count + 1) := Rec.aRelation; 	  		   -- родственные отношения
	  if B_SSD_IsRecipient(aPID, aCID) then
	  	 A(A.count + 1) := 1;
	  else
	     A(A.count + 1) := 0;
	  end if; -- 1 - если получатель
  	  A(A.count + 1) := 0; 	  	  	 	  		   -- метрики
	  A(A.count + 1) := 0;	 	  				   -- ребенок не является общим, если мать повторно вышла замуж
	  A(A.count + 1) := S_julian(pDate); 		   -- дата возникновения права
	  end loop;
	else
	  for Rec1 in
	 	   (Select a.PID as aPID,
		   		   nvl(a.ROLE, 0) as aRole,
				   nvl(a.RELATION, 0) as aRelation
            From   W$CASE_PERSON a, W$PERSON b
            Where  a.CID = aCID and
				   a.PID = b.PID and
--                 a.ENTERED_BY = XLPL.USER_ID and
 				   b.ENTERED_BY = XLPL.USER_ID and -- открыла elena 16.05.2011;
				   a.STAGE NOT IN (2,3) and
                   b.STAGE NOT IN( 2,3) and
				   (b.DEATH_DATE is null or b.DEATH_DATE > pDate)
           )
	  loop
	  A(A.count + 1) := Rec1.aPID;   	  		   -- PID
	  A(A.count + 1) := Rec1.aRole;  	  		   -- роль лица в деле
	  A(A.count + 1) := Rec1.aRelation; 	  	   -- родственные отношения
	  if B_SSD_IsRecipient(aPID, aCID) then
	     A(A.count + 1) := 1;
	  else
	     A(A.count + 1) := 0;
	  end if; -- 1 - если получатель
  	  A(A.count + 1) := 0; 	  	  	 	  		   -- метрики
	  A(A.count + 1) := 0;	 	  				   -- ребенок не является общим, если мать повторно вышла замуж
	  A(A.count + 1) := S_julian(pDate); 		   -- дата возникновения права
	  end loop;
   end if;
else  		   			  -- Работа с ОБД
	  for Rec2 in
	 	   (Select a.PID as aPID,
		   		   nvl(a.ROLE, 0) as aRole,
				   nvl(a.RELATION, 0) as aRelation
            From   CASE_PERSON a, PERSON b
            Where  a.CID = aCID and
                   a.PID = b.PID and
				   b.BIRTH_DATE <= pDate and
				  (b.DEATH_DATE is null or b.DEATH_DATE > pDate) and
				  (a.STAGE is null or a.STAGE NOT IN(2,3)) and
                  (b.STAGE is null or b.STAGE NOT IN(2,3)))
	  loop
	  A(A.count + 1) := Rec2.aPID;   	  		   -- PID
	  A(A.count + 1) := Rec2.aRole;  	  		   -- роль лица в деле
	  A(A.count + 1) := Rec2.aRelation; 	  	   -- родственные отношения
	  if B_SSD_IsORecipient(aPID, aCID) then
	  	 A(A.count + 1) := 1;
	  else
	  	 A(A.count + 1) := 0;
	  end if; -- 1 - если получатель
  	  A(A.count + 1) := 0; 	  	  	 	  		   -- метрики
	  A(A.count + 1) := 0;	 	  				   -- ребенок не является общим, если мать повторно вышла замуж
	  A(A.count + 1) := S_julian(pDate); 		   -- дата возникновения права
	  end loop;
end if;
------------------------------------------------
-- Определение даты рождения конкретного ребенка
------------------------------------------------
if A.count > 0 then
   j := 1;
   for i in 1 .. A.count/7 loop
	   if A(j+1) = 56 then
	      A(j+6) := S_julian(B_SSD_Date(A(j), prBase));
	   end if;
	   j := j + 7;
   end loop;
end if;
---------------------------------------------------------------------------------------------------
-- Расстановка признаков метрик, опекунства и что отец не занимается трудовой деятельностью для лиц
---------------------------------------------------------------------------------------------------
if A.count > 0 then
   j := 1;
   for i in 1 .. A.count/7 loop
	   if A(j+1) = 52 and A(j+3) = 1 then
	   	  PrOpekun := True;
	   end if;
	   if A(j+1) = 55 and B_SSD_Metric(A(j), pDate, 145, prBase) then
	   	  A(j+4) := 1; PrMother := True;
	   end if;
  	   if (A(j+1) = 56 and (B_SSD_Metric(A(j), S_JToD(A(j+6)), 355, prBase) or B_SSD_Metric(A(j), S_JToD(A(j+6)), 354, prBase))) then
	   	  A(j+4) := 1; PrChild := True;
	   end if;
	   if (A(j+1) = 57 or A(j+1) = 69) and B_SSD_NotWork(A(j), pDate, prBase) then
	   	  A(j+4) := 1;
	   end if;
	   j := j + 7;
   end loop;
end if;
-------------------------------------------------------------------------------------------------------------------------
-- Установка отцу признака того, что он не работает, когда его жена повторно замужем и есть ребенок от предыдущего брака
-------------------------------------------------------------------------------------------------------------------------
if A.count > 0 then
   j := 1;
   for i in 1 .. A.count/7 loop
	   if A(j+1) = 57 and A(j+3) <> 1 and A(j+4) = 1 and PrMother and PrChild then
		  PrFather := True;
	   end if;
	   j := j + 7;
   end loop;
end if;
------------------------------------------------------------------------------------------------------------
-- Установка ребенку признака того, что он не является общим, когда отец не работает и мать повторно замужем
------------------------------------------------------------------------------------------------------------
if A.count > 0 then
   j := 1;
   for i in 1 .. A.count/7 loop
	   if A(j+1) = 56 and A(j+4) = 1 and PrMother and PrFather then
		  A(j+5) := 1; PrCommon := True;
	   end if;
	   j := j + 7;
   end loop;
end if;
---------------------------------------------------------------------------
-- Выбор требуемых PID, удовлетворяющих Положению о порядке исчисления ССД.
---------------------------------------------------------------------------
if A.count > 0 then
   j := 1;
   for i in 1 .. A.count/7 loop
	  if A(j+1) = 0 then
	     pPID := A(j);
		 if prBase = 0 then
		 begin
	 	 	  Select SURNAME, NAME, PATNAME into Sur, Nam, PatNam
              From   W$PERSON
              Where  PID = pPID and
                --     ENTERED_BY = XLPL.USER_ID and
                     STAGE NOT IN(2,3);
         exception
		      when No_Data_Found then
			    RAISE_APPLICATION_ERROR(-20851,'Лицо c персональным идентификатором '|| to_char(A(j)) || ' отсутствует в деле' || chr(10));
				return RetStr;
			  when others then
                RAISE_APPLICATION_ERROR(-20851,'Лицо ' || Sur || ' ' || Nam || ' ' || PatNam || ' не имеет роли.' || chr(10) ||
				'Укажите роль лица в назначении' || chr(10));
				return RetStr;
	     end;
		else
	   	  pPID := A(j);
		  begin
	 	 	  Select SURNAME, NAME, PATNAME into Sur, Nam, PatNam
              From   PERSON
              Where  PID = pPID and
                     STAGE is NULL;
          exception
		      when No_Data_Found then
			    RAISE_APPLICATION_ERROR(-20851,'Лицо c персональным идентификатором '|| to_char(A(j)) || ' отсутствует в деле' || chr(10));
				return RetStr;
			  when others then
                RAISE_APPLICATION_ERROR(-20851,'Лицо ' || Sur || ' ' || Nam || ' ' || PatNam || ' не имеет роли.' || chr(10) ||
				'Укажите роль лица в назначении' || chr(10));
				return RetStr;
	      end;
		end if;
	  end if;

		if (A(j+1) = 52 or
    	    A(j+1) = 55 or
			A(j+1) = 69 or
			A(j+1) = 57 and A(j+3) = 1) and B_SSD_Date(A(j), prBase) <= pDate then
		    PIDsList(PIDsList.count + 1) := A(j);
		end if;
		if A(j+1) = 57 and A(j+3) <> 1 and not PrFather and B_SSD_Date(A(j), prBase) <= pDate then
		    PIDsList(PIDsList.count + 1) := A(j);
		end if;
		if A(j+1) = 56 then
		    wDate := S_AddYears(B_SSD_Date(A(j), prBase), S_Const(404, pDate)); -- было XLPL.WorkDate
		end if;
		if A(j+1) = 56 and pDate <= wDate and not PrOpekun and B_SSD_Date(A(j), prBase) <= pDate and
			(not PrCommon or (PrCommon and A(j+5) = 1)) and
		    (A(j+2) = 3  or
    	     A(j+2) = 4  or
		     A(j+2) = 11 or
		     A(j+2) = 12 or
			 A(j+2) = 0) then
			 PIDsList(PIDsList.count + 1) := A(j);
		end if;
		if  A(j+1) = 56 and pDate > wDate and not PrOpekun and B_SSD_Date(A(j), prBase) <= pDate and
			(not PrCommon or (PrCommon and A(j+5) = 1)) and
		    (B_SSD_School(A(j), pDate, prBase) or B_SSD_Inv(A(j), pDate, prBase)) and
			(A(j+2) = 3  or
    	     A(j+2) = 4  or
		     A(j+2) = 11 or
		     A(j+2) = 12 or
			 A(j+2) = 0) then
			 PIDsList(PIDsList.count + 1) := A(j);
		end if;
		if  A(j+1) = 56 and pDate <= wDate and PrOpekun and B_SSD_Date(A(j), prBase) <= pDate then
			 PIDsList(PIDsList.count + 1) := A(j);
		end if;
		if  A(j+1) = 56 and pDate > wDate and PrOpekun and B_SSD_Date(A(j), prBase) <= pDate and
		    (B_SSD_School(A(j), pDate, prBase) or B_SSD_Inv(A(j), pDate, prBase)) then
			 PIDsList(PIDsList.count + 1) := A(j);
		end if;
	j := j + 7;
	end loop;
end if;
---------------------------------------
-- Формирование строки с выбранными PID
---------------------------------------
RetStr := null;
if PIDsList.count > 0 then
   for i in 1 .. PIDsList.count loop
   	   if RetStr is null then RetStr := to_char(PIDsList(i));
   	   else RetStr := RetStr || ',' || to_char(PIDsList(i));
	   end if;
   end loop;
end if;
-- dbms_output.PUT_LINE (RetStr);
return RetStr;

END B_F_ControlPersonSSD1;
/
