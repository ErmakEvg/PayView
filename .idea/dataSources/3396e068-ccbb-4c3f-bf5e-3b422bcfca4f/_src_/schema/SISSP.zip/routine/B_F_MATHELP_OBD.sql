CREATE FUNCTION       B_F_MATHELP_OBD(wPID in PERSON.pid%type) return VARCHAR2
/*******************************************************************************
 Функция      : B_F_MATHELP_OBD
 Наименование : Функция определения причины отказа в ходатайствах для мат. помощи из ФСЗН
 Автор        : Иванова Т.С.
 Состояние на дату: 9.02.2017, 28.08.2018
 Коды возврата    : StrNotes
*******************************************************************************/
IS
 StrNotes VARCHAR2(2000);
  vFree       Number;
  Vozrast     Number;
  vActivity   Number;
  Count_Month Number;
  Age_N       Number;
  vSex        Number;
  vCount      Number;
  vGos_ob     Number;-- находится на гособеспечении
  StopDate    Date;
  dtBirthDay  Date;
  vMetrics    Varchar2(500);
/******************************************************************************
    Параметры:
      PID$    -   идентификатор пользователя
      CID$    -   идентификатор дела
    Цель:         Функция определения права на мат. помощь из ФСЗН
   АРМ   :  "Материальная помощь из ФЗСН"
      Название таблиц:   , person,allocations , case , case_person ,
                      legal_constants,MRAK_OPINION_ADVICE,ACTIVITY
******************************************************************************/
BEGIN
  Count_Month:= 0;
  Vozrast:= 0;
  vCount:= 0;
  vActivity := 0;
  vGos_ob:=0;
  XLPL.RoleDecl('Needy', '62');
 Select distinct Death_Date Into StopDate
  From PERSON
  Where pid= wPID
    and stage is null
    and close_date is null;
-- Определяем пол и дату рождения человека
  Select SEX, BIRTH_DATE into vSex, dtBirthDay
   From PERSON
    Where PID= wPID AND STAGE IS NULL;
-- Определяем пенсионный возраст человека в месяцах
  Age_N:= SISSP.P_AgePension_Month(dtBirthDay, vSex);--ITS 15.12.2016
-- Определяем возраст человека в месяцах
  Count_Month:= MONTHS_BETWEEN(trunc(sysdate), trunc(dtBirthDay));
  Vozrast:= Count_Month ;-- / 12;--ITS 15.12.2016  в годах
--  Vozrast:= Trunc(Vozrast); --ITS 15.12.2016
                   --20.01.2016
  Select Count(*) into  vCount
    From MRAK_OPINION_ADVICE
     Where  Advice_Type in (11,12,13,14)
      and nvl(DIS_TERM,sysdate +1) >=sysdate
      and MRAK_RID=(select RID  From MRAK_OPINION
                     Where stage IS NULL and  PID= wPID
                      and examed_till = (Select Max(examed_till)  From MRAK_OPINION
                                         Where stage IS NULL and PID= wPID)
                   );
 -- Определяем  работает ли?
 Select Count(*)  into  vActivity
  from ACTIVITY
  Where ACTIVITY=1
   and (PERIOD_END is null or PERIOD_END > sysdate)
   and STAGE IS NULL
   and PID =wPID;
 -- Определяем  находится ли на гос. обеаспечении
  Select Count(*)  into  vGos_ob
   from person_metric
     where PID= wPID
  --  and code in (172,176,177,178,179,180,186,187,188) -- ITS 9.02.2017
     and code in (172,179,719,731,193)-- ITS 9.02.2017
     and stage is null
     and (record_end is null or record_end>= sysdate) ;
   StrNotes:='';
     IF (StopDate <= sysdate ) THEN StrNotes :='Не имеет права (умер).';
    END IF;
      IF (vActivity>0) THEN StrNotes :='Не имеет права: работает.';
      ELSE
        IF  ((Vozrast < Age_N) -- не пенсионер
         OR  (vCount =0) ) THEN StrNotes :='Не имеет права:не пенсионер по возрасту и не инвалид 1 или 2 гр';
       end if;
       END IF;
    IF (vGos_ob>0) THEN StrNotes :='Не имеет права: на гособеспечении.';
     end if;
  Return StrNotes;
END B_F_MATHELP_OBD;
/
