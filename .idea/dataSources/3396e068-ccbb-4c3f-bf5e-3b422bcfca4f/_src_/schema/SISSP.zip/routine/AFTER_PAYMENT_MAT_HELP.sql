CREATE FUNCTION       after_payment_mat_help  return number
is
--Иванова Т.С.24.07.2013
APERIOD date;
acount number;
/*Процедура запускается после выполнения функции before_payment_mat_help
(если код возврата больше 0 и программы Выплата для мат. помощи), чтобы восстановить таблицы как было до выплаты */
begin
select max(period) into APERIOD  from accounting_period
   where sign_close_period is null or sign_close_period=1;
select count(cid) into acount  from result_payment where ACCESS_DATA = 6
 and stage is null AND TRUNC( ENTRY_DATE,'mm')=TRUNC(APERIOD ,'mm') AND TRUNC(ENTRY_DATE,'YYYY') =TRUNC(APERIOD ,'YYYY');
if  acount>0 then
  for c1 in (select rid,cid ,entry_date,aid from result_payment
   where ACCESS_DATA = 6
    and stage is null
   AND TRUNC( ENTRY_DATE,'mm')=TRUNC(APERIOD ,'mm') AND TRUNC(ENTRY_DATE,'YYYY') =TRUNC(APERIOD ,'YYYY'))
   loop
    update calc_amount set stage=5,close_date=c1.entry_date
     where RESULT_PAYMENT_RID=C1.RID and ALLOC_CODE=745;
    update allocation set stage=5,close_date=c1.entry_date
     where cid=c1.cid  and aid=c1.aid
     and close_date IS NULL
     and stage IS NULL;
    update assistance set stage=5,close_date=c1.entry_date
     where stage IS NULL
     and close_date IS NULL;
    update result_payment set stage=5,close_date=c1.entry_date where rid=c1.rid;
   end loop;
  commit;
end if;
return acount ;
end after_payment_mat_help;
/
