CREATE FUNCTION       B_F_ControlChildBirth return BOOLEAN is
/***************************************************************************************
// Функция: F_CONTROLCHILDBIRTH
// Наименование: Функция определяет, родился ли ребенок в период действия пособия на
// 				 детей старше 3 лет
// Автор: Ворошилин В.
// Состояние на дату 21.01.2000
// Возвращает: True, если ребенок родился в период действия пособия, False - нет
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 19.07.2002
//**************************************************************************************/
  ACTSTART number;
  BDay date;
  StartDateBD date;
  Dt date;
begin
  if not XLPL.CheckRole(56) then
    Return False;
  else
    XLPL.ReplaceRole('Child');
  end if;

  BDay := to_date(XLPL.GetGlobalFloat('BIRTHDATE'));

  StartDateBD := S_AddYears(BDay, trunc(S_Const(401, XLPL.WorkDate))) + 1;

  Dt := S_DateConst(478, XLPL.WorkDate);
  Dt := S_EncodeDate(S_YearOfDate(XLPL.WorkDate), S_MonthOfDate(Dt), S_DayOfDate(Dt));

  if (StartDateBD >= Dt) and (StartDateBD <= XLPL.WorkDate) then
   	Dt := StartDateBD;
  end if;

  begin
     Select count (*) into ACTSTART
     From W$PERSON a, W$CASE_PERSON c
     Where  c.CID = XLPL.CID
	   and c.PID <> XLPL.GetPID
	   and c.ROLE in (56, 68)
	   and a.PID = c.PID
	   and a.ENTERED_BY = XLPL.User_ID
	   and c.ENTERED_BY = XLPL.User_ID
	   and a.BIRTH_DATE >= Dt;

  exception
    when NO_DATA_FOUND then
	  ACTSTART := 0;
  end;

  XLPL.RestoreRole;

  Return ACTSTART <> 0;
end;
/
