CREATE FUNCTION       A_F_Intern_Contract RETURN NUMBER IS
/**********************************************************************************************
 Функция            : A_F_Intern_Contract
 Наименование       : Назначение по Международному Договору
 Автор              : ОЛВ
 Состояние на дату  : 24.09.2010   20.12.2011   21.03.2012
 Код возврата       : Код государства - 1 - по Закону о пенс. обесп. РБ
***********************************************************************************************/
 vsCOUNTRY     NUMBER;
BEGIN
  vsCOUNTRY:=1;
 IF (Xlpl.INDIV <>2) then -- не массовый расчет  -- 21.03.2012
    -- Выбрать COUNTRY в РБД из W$CASE
    vsCOUNTRY:=A_F_GetIntern_Contract(0);
 else
    -- Выбрать COUNTRY в ОБД из CASE
    vsCOUNTRY:=A_F_GetIntern_Contract(1);
 end if;
 if vsCOUNTRY=-1 then
    vsCOUNTRY:=1;
 end if;
 return vsCOUNTRY;
--RAISE_APPLICATION_ERROR(-20004,'A_F_Intern_Contract  2 vsCountry='||vsCountry);
/* *
  vsCOUNTRY:=1;
 -- Выбрать COUNTRY в ОБД из CASE
 vsCOUNTRY:=A_F_GetIntern_Contract(1);   -- (1);
 --vsCOUNTRY:=A_F_RelProtGetRIDContract(1);
 if vsCOUNTRY=-1 then
    -- Выбрать COUNTRY в РБД из W$CASE
    vsCOUNTRY:=A_F_GetIntern_Contract(0);
    --vsCOUNTRY:=A_F_RelProtGetRIDContract(0);
    if vsCOUNTRY=-1 then
      vsCOUNTRY:=1;
    end if;
 end if;
 return vsCOUNTRY;
/* */
END A_F_Intern_Contract;
/
