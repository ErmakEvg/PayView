CREATE FUNCTION       A_F_GetkormilW RETURN NUMBER AS
/**********************************************************************************************
 Функция                A_F_GetKormilW
 Наименование        : Ф-я определения главного Кормильца в пенсии по СПК  по рабочей базе
 Автор                      : ОЛВ			Корректировка  Речицкая АВ
 Состояние на дату  : 12.06.2013			20.10.2013
 Код возврата       : Возвращает номер главного Кормильца по рабочей базе
***********************************************************************************************/
 vKormil   NUMBER;
BEGIN
   BEGIN
       SELECT NVL(METHOD_SPK,1)
	        INTO vKormil
          FROM W$CASE
       WHERE cid = Xlpl.CID
            AND stage in (1,4) --	РАВ 20.10.2013
		     AND METHOD_SPK=2;
   EXCEPTION
       WHEN NO_DATA_FOUND THEN
	         vKormil:=1;
   END;
       RETURN vKormil;
END A_F_GetkormilW;
/
