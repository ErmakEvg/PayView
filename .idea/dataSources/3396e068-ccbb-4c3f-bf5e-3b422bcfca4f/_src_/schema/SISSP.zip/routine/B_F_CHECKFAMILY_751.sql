CREATE FUNCTION       B_F_CHECKFAMILY_751(pCodes in VarChar2)
RETURN BOOLEAN AS
/******************************************************************************
 Функция           : B_F_CHECKFAMILY_751
 Назначение        :   Функция, определяющая наличие характеристик семьи
                   : по делу в W$FAMILY_METRIC для проверки права
 Основание         :   Положение о порядке предоставления государственной
                   : адресной социальной помощи по указу Президента
                   : Республики Беларусь № 41 от 19.01.2012 г.
 Автор             : Ярошик А.К.
 Состояние на дату : 09.07.2015 г.
 Код возврата      : True - если есть требуемая характеристика,
                   : False - если ее нет

    Версия        Дата        Автор           Описание
    ---------  ----------  ---------------  ------------------------------------
    1.0        23.07.2012   Ярошик А.К.     Создание функции.

    Примечание:
      Классификатор     :    INFO_FAMILY - характеристики семьи
      АРМ:                   ГИССЗ
      Название программы:    Case.pas ( пособие ГАСП )

 Изменения: 05.07.2018 AMV
********************************************************************************/
  vCID      Number;
  vCount    Number;
  vCode_Rez Number;
  vDate_Ins Date;
  vCodes    DBMS_SQL.NUMBER_TABLE;
BEGIN
  vCount:= 0;
  vCID := XLPL.CID;
  vCodes:= S_ParseFloatArray(pCODES);
  -- Поиск характеристик семьи в W$FAMILY_METRIC
  FOR I in 1..vCODEs.count LOOP
    Select Count(*) INTO vCount
    From W$FAMILY_METRIC
    Where CID = vCID
      and ((ALLOC_CODE= Xlpl.ALLOC_CODE) or (ALLOC_CODE is NULL))  --05.07.2018 AMV
      and CODE = vCODEs(I)
      and STAGE NOT IN (2, 3)
      and ENTERED_BY= XLPL.User_ID;
    IF vCount> 0 THEN
      Return True;
    END IF;
  END LOOP;
  --
  Return False;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      Return False;
  END B_F_CHECKFAMILY_751;
/
