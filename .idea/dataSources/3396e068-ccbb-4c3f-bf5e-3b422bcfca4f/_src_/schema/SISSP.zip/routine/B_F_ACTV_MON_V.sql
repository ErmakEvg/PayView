CREATE FUNCTION       B_F_ACTV_MON_V(A_LABOR IN NUMBER) RETURN boolean IS

/******************************************************************************

   Наименование: Функция определения факта работы, учебы, безработицы лица по одному коду
   Возвращает: True - если лицо активно, False - если лицо не активно
   NAME:       Трухтанов
   10.07.2002
******************************************************************************/
CN_ACTIVITY number;
BEGIN
--RAISE_APPLICATION_ERROR(-20801,'B_F_ACTV_MON     XLPL.GetPid=' ||XLPL.GetPid ||'  XLPL.workdate=' ||XLPL.workdate
--                               ||'  XLPL.USER_ID=' ||XLPL.USER_ID || '   A_LABOR='||A_LABOR);
  Select COUNT(*) into CN_ACTIVITY
  From  W$ACTIVITY
  Where PID   = XLPL.GETPID
    and LABOR = A_LABOR
    and ENTERED_BY = XLPL.USER_ID
    and STAGE NOT IN(2,3)
		/* OLV 29.03.2010
         and         (PERIOD_START <= XLPL.workdate and NVL(PERIOD_END, XLPL.workdate) >= XLPL.workdate);
        /* */
    and ((PERIOD_END is not null) and (PERIOD_END <= XLPL.workdate));

  if (CN_ACTIVITY <> 0)
    then return true;
    else return false;
  end if;

END B_F_ACTV_MON_V;
/
