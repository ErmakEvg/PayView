CREATE FUNCTION       B_F_CalcPension603 (bufDate in date) RETURN NUMBER AS
/***************************************************************************************
 Функция           : B_F_CalcPension603
 Наименование      : Вычисление пенсии лица за месяц, на который попадает рабочая дата
 Автор             : Ворошилин В.              Коректировка : РАВ
 Состояние на дату : 05.02.1999								 15.11.2015
 Код возврата      : число с суммой пенсии
***************************************************************************************/
 aDate DATE;
 bDate DATE;
 pens  NUMBER;
BEGIN
  -- месяц, на который попадает рабочая дата
  aDate := TO_DATE(TO_CHAR( 1,'09')||
           TO_CHAR(TO_NUMBER(TO_CHAR(bufDate,'MM')),'09')||
		   TO_CHAR(TO_NUMBER(TO_CHAR(bufDate, 'YYYY')),'0009'),'DDMMYYYY');
  bDate := LAST_DAY(bufDate);

  ----- размер пенсии  -----
 begin
   Select SISSP_COMMON.GetPayAmount(1, XLPL.GetPid, 603, null, aDate, bDate, 2, 1, null)
     INTO pens from DUAL ;

	  if pens is NULL then
	    pens := 0;
	  end if;
    exception
 when OTHERS then
	  pens := 0;
 end;
	--RAISE_APPLICATION_ERROR(-20801,'B_F_CalcPension     2     XLPL.GetPid='||XLPL.GetPid||'  pens='||pens||'  bDate='||bDate);
  return pens;
END B_F_CalcPension603;
/
