CREATE FUNCTION       A_F_Relprotgetinternpact(Base_ID IN NUMBER) RETURN NUMBER AS
/***********************************************************************************************
 NAME              : A_F_RelprotGetINTERNPACT
 Назначение        : Возращает сумму пенсии, полученную за границей
 Автор             : ОЛВ
 Состояние на дату : 17.03.2014
 Код возврата      : Amount из PENSION_INTERNPACT
************************************************************************************************/
 vAmount        NUMBER;
 xWorkDate      DATE;
BEGIN
 BEGIN
   vAmount:=0;
   xWorkDate := Xlpl.WorkDate;
   IF Base_ID=0 THEN
         SELECT NVL(Amount,-1)
           INTO vAmount
           FROM W$PENSION_INTERNPACT  -- W$PENSION_INTERNPACT
          WHERE PID = Xlpl.GetPid
            AND STAGE in (1,4)
            AND ENTERED_BY=Xlpl.USER_ID -- ???
            AND xWorkDate BETWEEN
                 NVL(START_DATE,xWorkDate) AND NVL(END_DATE,xWorkDate);
   ELSE
         SELECT NVL(Amount,-1)
           INTO vAmount
           FROM PENSION_INTERNPACT
          WHERE PID = Xlpl.GetPid
            AND STAGE IS NULL
            AND xWorkDate BETWEEN
                 NVL(START_DATE,xWorkDate) AND NVL(END_DATE,xWorkDate);
   END IF;

   EXCEPTION
      WHEN TOO_MANY_ROWS OR NO_DATA_FOUND THEN
         vAmount:=-1;
   END;
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelprotGetINTERNPACT 2 Amount='||vAmount|| '  xWorkDate='||xWorkDate);
   RETURN vAmount;
END A_F_Relprotgetinternpact;
/
