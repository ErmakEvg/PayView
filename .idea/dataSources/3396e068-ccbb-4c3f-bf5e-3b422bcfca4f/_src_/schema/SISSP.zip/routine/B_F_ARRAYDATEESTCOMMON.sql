CREATE FUNCTION       B_F_ARRAYDATEESTCOMMON RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: B_F_ARRAYDATEESTCOMMON
+ Наименование: Формирование дат Estimation для ребенка до 3 лет
+ Автор: Ворошилин В.				Корректировка Речицкая А. В.
+ Состояние на дату 20/09/2002		17.11.2014
==============================================================================*/

result_step_start DBMS_SQL.NUMBER_TABLE;
result_function DBMS_SQL.NUMBER_TABLE;
j NUMBER;

BEGIN
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCOMMON  XLPL.GetPid='||XLPL.GetPid );
result_step_start.delete;

result_function.delete;
result_function := B_F_ArrayDateEstMETRIC;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivity(1);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivity(2);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivity(3);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;
--17.11.2014 РАВ  по Закону "О государственных пособиях семьям, воспитывающим детей" от 01.01.2013
-- инвалидность получателя не влияет на срок окончания действия пособия
 if (xlpl.alloc_code=421) or (xlpl.alloc_code=481) then null; --добавлено 481 01.01.2015 Речицкая АВ
 else
  result_function.delete;
  result_function := B_F_ArrayDateEstMrakOpAdvice(1, 11);
   if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
   end if;

  result_function.delete;
  result_function := B_F_ArrayDateEstMrakOpAdvice(1, 12);
   if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
   end if;

  result_function.delete;
  result_function := B_F_ArrayDateEstMrakOpAdvice(1, 13);
   if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
   end if;

  result_function.delete;
  result_function := B_F_ArrayDateEstMrakOpAdvice(1, 14);
   if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
   end if;

  result_function.delete;
  result_function := B_F_ArrayDateEstMrakOpAdvice(1, 15);
   if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
   end if;

  result_function.delete;
  result_function := B_F_ArrayDateEstMrakOpAdvice(2, 21);
   if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
   end if;

 end if;		--17.11.2014 РАВ  по Закону "О государственных пособиях семьям, воспитывающим детей"01.01.2013

result_function.delete;
result_function := B_F_ArrayDateEstAddress;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstAddressAbsent;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstBirthDeath;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

return result_step_start;

END B_F_ARRAYDATEESTCOMMON;
/
