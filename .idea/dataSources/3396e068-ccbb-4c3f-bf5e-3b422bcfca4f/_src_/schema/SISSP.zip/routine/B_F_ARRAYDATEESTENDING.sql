CREATE FUNCTION       B_F_ARRAYDATEESTENDING RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_F_ARRAYDATEESTENDING
 Наименование       : Определение даты окончания года для пособий на детей старше 3 лет
 Автор              : Ворошилин В.              Комментарии и коректировка: ОЛВ
 Состояние на дату  : 17.11.2000                                    20.03.2012
 Код возврата       : возвращает массив из даты окончания года для пособий старше 3 лет
***********************************************************************************************/
  result_array    DBMS_SQL.NUMBER_TABLE;
  pDate           DATE;
BEGIN
  result_array.DELETE;
  -- 479 - Дата окончания действия пособий на детей старше 3 лет (31.12)
    pDate:=S_Jtod(S_Const(479, XLPL.WorkDate));
  IF ((S_EncodeDate(S_YearOfDate(LAST_DAY(S_CurrDate)), S_MonthOfDate(pDate), S_DayOfDate(pDate))) > LAST_DAY(S_CurrDate)) THEN
    result_array(1) := S_Julian(S_EncodeDate(S_YearOfDate(LAST_DAY(S_CurrDate)), S_MonthOfDate(S_Jtod(TRUNC(S_Const(479, XLPL.WorkDate)))), S_DayOfDate(pDate)));
	result_array(2) := 31; -- 31 - Наступление конца года
	result_array(3) := 2;  -- Закрыть
  END IF;
  RETURN result_array;
END B_F_ARRAYDATEESTENDING;
/
