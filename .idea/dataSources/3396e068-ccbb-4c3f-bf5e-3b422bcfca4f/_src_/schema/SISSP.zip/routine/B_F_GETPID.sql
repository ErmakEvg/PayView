CREATE FUNCTION       B_F_GetPid (vpRole IN NUMBER) RETURN NUMBER AS
/*******************************************************************************
Функция           :  B_F_GetPid
Наименование      : Функция определяет PID по роли
Автор             : OLV
Состояние на дату :05.08.2015
Возвращает        : PID по роли
******************************************************************************/
 vPID         NUMBER;
BEGIN
  BEGIN
      SELECT pid
        INTO vPID
        FROM CASE_PERSON
       WHERE cid=XLPL.CID
         AND role=vpRole
         AND stage IS NULL;
  EXCEPTION
     WHEN NO_DATA_FOUND OR TOO_MANY_ROWS THEN
        vPID:=0;
  END;
  RETURN vPID;
END B_F_GetPid;
/
