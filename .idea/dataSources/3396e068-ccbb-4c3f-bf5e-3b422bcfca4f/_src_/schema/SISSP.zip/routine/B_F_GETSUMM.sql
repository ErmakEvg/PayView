CREATE FUNCTION       B_F_GETSUMM (bufDate in date, pPid in number, pCid in NUMBER, pWay in NUMBER) RETURN NUMBER AS
/***************************************************************************************
 -- ПРАВКА : АГАЕВ В.Р. 15.10.2013
 --ITS 22.09.2015 сумма  доплаты
***************************************************************************************/
 naznach  NUMBER;
 procent  NUMBER;
 dprocent NUMBER;
 vypl     NUMBER;
 nazn727  NUMBER;
BEGIN
    naznach := 0;
    procent := 0;
    dprocent:= 0;
    vypl := 0;
    nazn727 :=0;
 case
    when pWay = 1 then
        -------- назначенная сумма---------
       select sum(cca.period_amount*cca.payment_percent) into naznach
        from   (select ca.period_amount, ca.payment_percent-- into procent
                from calc_amount ca
                where ca.stage is null
                and alloc_code <> 727
                and ca.period_amount <> 0
                and ca.cid = pCid
                --and ca.flag is null
                and to_char(ca.period_start, 'mm.yyyy') =to_char(bufDate, 'mm.yyyy')) cca;
        return naznach;
    when pWay = 2 then
        -------- выплаченная сумма---------
       select SUM(ca.period_amount) into procent
        from calc_amount ca
        where ca.stage is null
        and alloc_code <> 727
        and ca.period_amount <> 0
        and ca.cid = pCid
        --and ca.flag is null
        and to_char(ca.period_start, 'mm.yyyy') = to_char(bufDate, 'mm.yyyy');
        -------- удержания---------
       select nvl( sum(dca.amount_payment), 0 ) into dprocent
        from deduction_calc_amount dca
        where dca.stage is null
        and dca.cid = pCid
        and dca.alloc_code_alloc <> 727
        and to_char(dca.period_start, 'mm.yyyy') = to_char(bufDate, 'mm.yyyy');
        vypl := procent + dprocent;
       return vypl ;
     when pWay = 3 then
        -------- сумма  доплаты--------- --ITS 22.09.2015
       select sum(ca.period_amount) into  nazn727
        from  calc_amount ca
         where ca.stage is null
          and alloc_code = 727
          and ca.period_amount <> 0
          and ca.cid = pCid
          and to_char(ca.period_start, 'mm.yyyy') =to_char(add_months(bufDate,1), 'mm.yyyy') ;
        return  nazn727;  --ITS 22.09.2015
 end case;
END B_F_GETSUMM;
/
