CREATE FUNCTION       A_Calc_GetMaxCalcPeriodStart(ACID in Number,AAID in Number)
   RETURN Date IS
/* Возвращает максимальную дату старта рассчитанного периода из W$CALC_AMOUNT
Вахромин О.Ю.*/
vsCount Number;
vsDate Date;
BEGIN
   -- находим макс. дату начала просчитанного шага назначения, чтобы
   -- учесть возможно проводившийся на период старше массовый расчет
   vsDate:=NULL;
   begin
      select MAX(PERIOD_START) into vsDate from W$CALC_AMOUNT where CID=ACID and
         AID=AAID and ENTERED_BY=XLPL.USER_ID and STAGE in (1,2);
   end;
   return vsDate;
END A_Calc_GetMaxCalcPeriodStart;
/
