CREATE FUNCTION       A_P_SIZEMINPENS_20160701 RETURN NUMBER AS
/*******************************************************************************
 Функция           : A_P_SIZEMINPENS_20160701
 Наименование      : Исчисление размера пенсии в минимальном размере
                     (действует с 01.07.2016 округление из справочника)
 Автор             : ОЛВ
 Состояние на дату : 17.03.2016
 Код возврата      : пенсия в минимальном размере
********************************************************************************/
 Min_Size NUMBER;
BEGIN
   Min_Size:=S_VRound_Sum((S_Const(18,XLPL.WorkDate)*S_Const(19,XLPL.WorkDate)/100), S_Valueroundsum(Xlpl.WorkDate));
   RETURN Min_Size;
END A_P_SIZEMINPENS_20160701;
/
