CREATE FUNCTION       A_F_Getperson_Extra_W(CID#  IN NUMBER, AID#  IN NUMBER) RETURN VARCHAR2 IS
/***********************************************************************************************
 Функция                : A_F_GETPERSON_EXTRA_W
 Наименование       : Выбрать инд. коэффициент для протокола по СПК по рабочей базе
 Автор              : ОЛВ			Корректировка Речицкая АВ
 Состояние на дату  : 16.04.2013    11.06.2013	  20.10.2013
 Код возврата        : индивидуальный коэффициент в символьном виде
************************************************************************************************/
 vCount          NUMBER;
 vKormil         NUMBER;
 vKormil2        NUMBER;
 vRATIO         NUMBER;
 vSumRATIO  NUMBER;
 vPID             NUMBER;

BEGIN
    vSumRATIO:= 0;
  -- Определить наличие Кормильца2, чтобы отделить СПК
  SELECT COUNT(*) INTO vCount
     FROM W$CASE_PERSON
  WHERE cid = CID#
       AND  stage in (1,4)  --РАВ 20.10.2013
	   AND ROLE =61;
 --raise_application_error(-20801, 'A_F_Getperson_Extra_W    vSumRATIO='||vSumRATIO);
 IF vCount>0 THEN   -- в СПК 2 кормильца
    -- выбрать главного Кормильца
     IF A_F_GetkormilW = 2 THEN   -- СПК 2 кормильца
          vKormil:= 61;     -- Главный Кормилец
		  vKormil2:= 54;   -- Второй Кормилец
     ELSE
          vKormil:= 54;     -- Главный Кормилец
		  vKormil2:= 61;   -- Второй Кормилец
    END IF;

		  -- Выбрать коэффициент главного Кормильца
		BEGIN
             SELECT INDIVIDUAL_RATIO
             INTO vSumRATIO
           FROM W$PERSON_EXTRA a, W$CASE_PERSON c
         WHERE c.cid = CID#
              AND c.stage in (1,4)	--РАВ 20.10.2013
	          AND ROLE = vKormil
	          AND a.pid=c.pid
	          AND a.stage in (1,4);	--РАВ 20.10.2013
         EXCEPTION
                     WHEN NO_DATA_FOUND   THEN
		  	          vSumRATIO:=0;
		 END;

       -- Проверить, является ли иждивенец круглым сиротой
       SELECT COUNT (*)
	        INTO vCount
          FROM W$CASE_PERSON c, W$ALLOCATION a, W$ALLOCATION_PERSON p, W$PERSON_METRIC m
       WHERE a.cid = CID# --50901000605
             AND a.stage in (1,4)		--РАВ 20.10.2013
             AND p.stage in (1,4)		--РАВ 20.10.2013
             AND a.AID= AID# --2
			 AND a.PARENT_RID IS NULL
			 AND a.STEP_END IS NULL
			 AND a.alloc_status <>3
	         AND c.cid = a.cid
             AND c.stage in (1,4)		--РАВ 20.10.2013
	         AND c.ROLE =53
	         AND p.ROLE =53
			 AND p.ALLOCATION_RID=a.rid
			 AND p.pid=c.pid
			 AND m.pid=c.pid
             AND m.stage in (1,4)	--РАВ 20.10.2013
			 AND ((m.CODE = 233) OR (m.CODE = 234) );
    IF vCount<>0 THEN   -- иждивенец - круглый сирота
	   -- Выбрать коэффициент второго Кормильца
		BEGIN
             SELECT INDIVIDUAL_RATIO
             INTO  vRATIO
           FROM W$PERSON_EXTRA a, W$CASE_PERSON c
         WHERE c.cid = CID#
              AND c.stage in (1,4)		--РАВ 20.10.2013
	          AND ROLE = vKormil2
	          AND a.pid=c.pid
	          AND a.stage in (1,4);	--РАВ 20.10.2013
         EXCEPTION
                     WHEN NO_DATA_FOUND   THEN
		  	          vRATIO:=0;
		 END;
                    vSumRATIO:= vSumRATIO + vRATIO;
    END IF;

 ELSE -- прочие
     BEGIN

        SELECT INDIVIDUAL_RATIO
             INTO vSumRATIO
           FROM W$PERSON_EXTRA a, W$CASE_PERSON c
         WHERE c.cid = CID#
              AND c.stage in (1,4)	--РАВ 20.10.2013
	          AND ROLE IN (51, 54) -- 51 - Пенсионер, 54 - Кормилец1
	          AND a.pid=c.pid
	          AND a.stage in (1,4)--РАВ 20.10.2013
              and a.entered_by=c.entered_by;
      --raise_application_error(-20801, 'A_F_Getperson_Extra_W    vSumRATIO='||vSumRATIO);
     EXCEPTION
       WHEN NO_DATA_FOUND   THEN
	       vSumRATIO:=0;
 	 END;
 END IF;

   IF  vSumRATIO=0 THEN
		RETURN '0.0';
   ELSE
       RETURN  TO_CHAR(vSumRATIO,'990.99999');
   END IF;
END A_F_Getperson_Extra_W;
/
