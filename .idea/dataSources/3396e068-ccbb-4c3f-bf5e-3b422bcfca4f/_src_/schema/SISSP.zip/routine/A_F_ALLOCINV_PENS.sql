CREATE FUNCTION       A_F_AllocInv_Pens(aAlloc_Code IN NUMBER) RETURN boolean IS
/***************************************************************************************
 Функция           : A_F_AllocInv_Pens
 Наименование      : Ф-я проверки является ли назначение пенсией по инв.
                     по Закону "О пенсионном обеспечении"
 Автор             : ОЛВ
 Состояние на дату : 11.05.2011
 Код возврата      : True - назначение - пенсия по инвалидности
***************************************************************************************/
 count_D        NUMBER;
 AllocInv       BOOLEAN;
BEGIN
 -- 300 - Пенсия по инвалидности (по Закону "О пенсионном обеспечении")
 -- 200 - Социальная пенсия
    AllocInv:= False;
 select count(*)
   into count_D
   from ALLOCATIONS
  where code = aAlloc_Code
    and code<>207                         -- социальная пенсия по возрасту
    and parent_code in (300,200)
	and end_date is null;

 IF count_D=1   then
    AllocInv:= True;
 END IF;
  RETURN AllocInv;

END A_F_AllocInv_Pens;
/
