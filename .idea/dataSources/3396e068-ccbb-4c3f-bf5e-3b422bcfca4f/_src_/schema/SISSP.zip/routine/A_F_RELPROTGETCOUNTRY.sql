CREATE FUNCTION       A_F_RelProtGetCountry(Base_ID in NUMBER,pADDRESS_TYPE in NUMBER)
   RETURN NUMBER AS
/**********************************************************************************************
 Функция            : A_F_RelProtGetCountry
 Наименование       : Функция определения кода страны проживания   Country из W$ADDRESS
 Автор              : ОЛВ
 Состояние на дату  : 24.09.2010  16.12.2010  22.12.2010   01.08.2011
 Код возврата       : код страны проживания  1 - РБ, 2 - РФ
***********************************************************************************************/
 vsCountry        NUMBER;
BEGIN
   begin
      if Base_ID=0 then
         select NVL(Country,1) -- Country is null - если есть запись - означает проживание в РБ - со слов С.А. 22.12.2010
		   into vsCountry
		   from W$ADDRESS
		  where PID=XLPL.GetPID
			and ((ADDRESS_TYPE=pADDRESS_TYPE) or (ADDRESS_TYPE=3)) -- ADDRESS_TYPE=pADDRESS_TYPE
		    and STAGE not in (2, 3)
			and ENTERED_BY=XLPL.USER_ID
			and XLPL.WorkDate between
			    NVL(RECORD_START,XLPL.WORKDATE) and NVL(RECORD_END,XLPL.WORKDATE);
      else
         select NVL(Country,1)
		   into vsCountry
		   from ADDRESS
		  where PID=XLPL.GetPID
			and ((ADDRESS_TYPE=pADDRESS_TYPE) or (ADDRESS_TYPE=3)) -- ADDRESS_TYPE=pADDRESS_TYPE
		    and STAGE is null -- 01.08.2011 OLV  -- не работает and STAGE not in (2, 3)
			and XLPL.WorkDate between
			    NVL(RECORD_START,XLPL.WORKDATE) and NVL(RECORD_END,XLPL.WORKDATE);
      end if;

   exception
      when NO_DATA_FOUND then
         vsCountry:=-1;   -- если нет записи - страна м.б. любая
 --RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetCountry  2 vsCountry='||vsCountry);
   end;
   return vsCountry;

	  /* *	 RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetCountry  0 XLPL.CID='||XLPL.CID||chr(10)
	                                                        ||'  XLPL.AID='||XLPL.AID||chr(10)
	                                                        ||'  XLPL.ALLOC_CODE='||XLPL.ALLOC_CODE||chr(10)
	                                                        ||'  XLPL.GROUP_NO='||XLPL.GROUP_NO||chr(10)
	                                                        ||'  XLPL.USER_ID='||XLPL.USER_ID||chr(10)
	                                                        ||'  vsRELATION_TABLE='||vsRELATION_TABLE||chr(10)
	                                                        ||'  XLPL.WorkDate='||XLPL.WorkDate||chr(10)
	                                                        ||'  XLPL.GetPID='||XLPL.GetPID||chr(10)
															); /* */
   /* *
 vsRelation_Table number;
 vsCountry        NUMBER;
BEGIN
   if Base_ID=0 then
      vsRELATION_TABLE :=S_CodeTableSissp('W$ADDRESS');
   else
      vsRELATION_TABLE :=S_CodeTableSissp('ADDRESS');
   end if;

   begin
      if Base_ID=0 then
         select Country
		   into vsCountry
		   from W$RELATION_PROTOCOL b,W$ADDRESS a
		  where CID=XLPL.CID
		    and (AID = XLPL.AID or XLPL.AID=0)
			and ((GROUP_NO=XLPL.GROUP_NO)or(XLPL.AID<>0 and XLPL.GROUP_NO=0))
			and ALLOC_CODE=XLPL.ALLOC_CODE
			and b.ENTERED_BY=XLPL.USER_ID
			and a.ENTERED_BY=XLPL.USER_ID
			and RELATION_TABLE=vsRELATION_TABLE
			and RELATION_DATE=XLPL.WorkDate
			and DATA_RID=a.RID
			and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE) and
                                      NVL(a.RECORD_END,XLPL.WORKDATE)
			--and ADDRESS_TYPE=pADDRESS_TYPE
            and Country is not null
			and a.PID=XLPL.GetPID;
	 --RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetCountry  1 vsCountry='||vsCountry);
      else
         select Country
		   into vsCountry
		   from W$RELATION_PROTOCOL b,ADDRESS a
		  where CID=XLPL.CID
		    and (AID = XLPL.AID or XLPL.AID=0)
			and ((GROUP_NO=XLPL.GROUP_NO) or (XLPL.AID<>0 and XLPL.GROUP_NO=0))
			and ALLOC_CODE=XLPL.ALLOC_CODE and b.ENTERED_BY=XLPL.USER_ID
			and RELATION_TABLE=vsRELATION_TABLE
			and RELATION_DATE=XLPL.WorkDate
			and DATA_RID=a.RID
			and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE) and
                                      NVL(a.RECORD_END,XLPL.WORKDATE)
			--and ADDRESS_TYPE=pADDRESS_TYPE
            and Country is not null
			and a.PID=XLPL.GetPID;
      end if;

   exception
      when NO_DATA_FOUND then
         vsCountry:=-1;
 --RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetCountry  2 vsCountry='||vsCountry);
   end;

   /* */
END A_F_RelProtGetCountry;
/
