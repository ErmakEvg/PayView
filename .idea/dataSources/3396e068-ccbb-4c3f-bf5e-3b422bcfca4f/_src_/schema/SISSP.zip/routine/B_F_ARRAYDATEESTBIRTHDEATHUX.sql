CREATE FUNCTION       B_F_ARRAYDATEESTBIRTHDEATHUX RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_ARRAYDATEESTBIRTHDEATHUX
+ Наименование: Функция возвращает массив дат изменения дат рождения и смерти
+ 				лица для Estimation
+ Автор: Ворошилин В.
+ Состояние на дату 17/11/2000
==============================================================================*/

  chahge_date_aRecord DBMS_SQL.NUMBER_TABLE;
BEGIN
  chahge_date_aRecord.delete;
  for BIRTHDEATHUX in (select nvl(BIRTH_DATE, NULL) as aRecord_start, nvl(DEATH_DATE, NULL) as aRecord_end
                       from W$PERSON
					   where PID = XLPL.GetPid
					     and RECORD_END is NULL
						 and STAGE in (1, 4)
						 and ENTERED_BY = XLPL.User_ID)
  loop
    if (BIRTHDEATHUX.aRecord_end is not NULL) and ((BIRTHDEATHUX.aRecord_end + 1) > LAST_DAY(S_CurrDate)) then
	  chahge_date_aRecord(chahge_date_aRecord.count + 1) := S_Julian(LAST_DAY(BIRTHDEATHUX.aRecord_end));
	  chahge_date_aRecord(chahge_date_aRecord.count + 1) := 999;
	  chahge_date_aRecord(chahge_date_aRecord.count + 1) := 2;
    end if;
  end loop;
  return A_F_ArrayDataChangeDelDup(chahge_date_aRecord);
END B_F_ARRAYDATEESTBIRTHDEATHUX;
/
