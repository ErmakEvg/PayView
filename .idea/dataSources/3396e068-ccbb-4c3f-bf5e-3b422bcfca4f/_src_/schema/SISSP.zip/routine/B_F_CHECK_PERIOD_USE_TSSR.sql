CREATE FUNCTION       B_F_CHECK_PERIOD_USE_TSSR RETURN VarChar2 IS
/*******************************************************************************
 Функция            : B_F_CHECK_PERIOD_USE_TSSR
 Наименование       : ПНазначение: проверяет  окончание срока эксплуатации ТССР
                    : для ГАСП в виде социального пособия на оплату ТССР
 Автор              : Абрамович М.В.
 Состояние на дату  : 09.02.2015, 26.05.2015
 Код возврата       : Возвращаемое значение: '' или строка перечисленных кодов ТССР,
                    : у которых не истек срок эксплуатации
*******************************************************************************/
 vTSSR_Old Number;
 rez_STR VarChar2(2048);
 xPID NUMBER;
 Poz NUMBER;
BEGIN
  rez_STR:= ' ';
  xPID:= XLPL.GETPID;

  for c1 in (select d.CODE_TSSR vCODE_TSSR
            from W$CASE_PERSON c, W$PARAM_ADDR_HELP p,
	             W$MRAK_DESIRED_TSSR d
            where c.CID= XLPL.CID
              and c.Cid= p.CID
              and c.PID= xPID
              and c.PID= d.PID -- 09.02.2015
              and c.STAGE not IN (2,3)
              and p.STAGE not IN (2,3)
              and d.STAGE not IN (2,3)
              and p.entered_by= XLPL.USER_ID
              and p.entered_by= c.entered_by
              and p.RID_TSSR= d.RID)
     Loop
	   vTSSR_Old:= Null;
       BEGIN
        select d.CODE_TSSR INTO vTSSR_Old
              from  ALLOCATION a,
	                CASE_PERSON c,
	                PARAM_ADDR_HELP p,
	                MRAK_DESIRED_TSSR d
              where a.ALLOC_CODE = 753
                    and (a.ALLOC_STATUS = 1 or a.ALLOC_STATUS = 3)
                    and a.CID= p.CID
                    and a.Cid= c.CID
                    and c.PID= xPID
                    and c.PID= d.PID -- 05.02.2015
                    and (a.STAGE is NULL)          -- 26.05.2015
                    and (c.STAGE is NULL)
                    and (p.STAGE is NULL)
                    and (d.STAGE is NULL)
                    and p.RID_TSSR= d.RID
                    and d.CODE_TSSR= c1.vCode_TSSR
		    and d.Record_End> A_F_DATATALK;
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
           rez_STR:= rez_STR;
       END;

       if vTSSR_Old is not null then
         rez_STR:= rez_STR || DECODE_tssr(vTSSR_Old) || ',';  -- To_Char(vTSSR_Old)||',';
       end if;
    End Loop;
  Poz:= INSTR(rez_STR, ',', -1);
  if Poz<> 0 then
    rez_STR:= SUBSTR(rez_STR, 1, Poz-1);
  end if;
  --raise_application_error(-20204,'vTSSR_Old= ' || rez_STR);
  RETURN rez_STR;
END B_F_CHECK_PERIOD_USE_TSSR;
/
