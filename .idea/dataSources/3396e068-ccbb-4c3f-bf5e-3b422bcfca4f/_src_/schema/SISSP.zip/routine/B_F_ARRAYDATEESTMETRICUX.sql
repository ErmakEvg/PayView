CREATE FUNCTION       B_F_ArrayDateEstMETRICUX RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: B_F_ArrayDateEstMETRICUX
+ Наименование: функция возращает массив изменения характеристики пенсионера,
+ 				которому отказано вполучении пенсии
+ Автор: Речицкая А. В..
+ Состояние на дату 10.02.2017
==============================================================================*/

  a DBMS_SQL.NUMBER_TABLE;
  pEnd              DATE;
 BEGIN
 a.Delete;
   BEGIN
   select nvl(RECORD_END, NULL)
       INTO pEnd
       from W$PERSON_METRIC
      where PID = XLPL.GetPid
        and STAGE in (1, 4)
        and ENTERED_BY = XLPL.User_ID
        and code=760
        and NVL(RECORD_END, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate);
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       pEnd:=NULL;
   END;

  if pEnd is not null then

  		for METRICAIDS in (select nvl(RECORD_START, NULL) as metric_start,
                            nvl(RECORD_END, NULL) as metric_end,
							CODE
					 from W$PERSON_METRIC
					 where PID = XLPL.GetPid
					   and STAGE in (1, 4)
					   and (NVL(RECORD_START, NULL) > LAST_DAY(S_CurrDate) or NVL(RECORD_END, NULL) > LAST_DAY(S_CurrDate))
					   and ENTERED_BY = XLPL.User_ID)


 		 loop
			if (METRICAIDS.metric_start is not NULL) and (METRICAIDS.metric_start > LAST_DAY(S_CurrDate)) then
      		 if (METRICAIDS.Code = 760) then
	   		 a(a.count + 1) := S_Julian(METRICAIDS.metric_start) - 1;
			 a(a.count + 1) := 133;
			 a(a.count + 1) := 1;
	  		 end if;
			end if;
			if (METRICAIDS.metric_end is not NULL) and ((METRICAIDS.metric_end + 1) > LAST_DAY(S_CurrDate)) then

      			if (METRICAIDS.Code = 760) then
	    		a(a.count + 1) := S_Julian(LAST_DAY(METRICAIDS.metric_end));
				a(a.count + 1) := 132;
				a(a.count + 1) := 1;
	  			end if;
			end if;
  		end loop;
    else   a:= B_F_ARRAYDATEESTUX;
   end if;
  return a;
 END B_F_ArrayDateEstMETRICUX;
/
