CREATE FUNCTION       A_F_RelProtActvStart(aActivity in NUMBER,
                                                aLabor in VARCHAR2,
                                                aDismiss_Reason in VARCHAR2)
												RETURN DATE IS
--==============================================================================
-- Назначение: возвращает дату начала ACTIVITY по W$RELATION_PROTOCOL
--         Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL)
--------------------------------------------------------------------------------
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Входные праметры:
---------------------
-- aActivity - код верхнего уровня  (Например 1 - работатет)
-- aLabor - код нижнего уровня ('' - игнорируются)
-- aDismiss_Reason - список кодов увольнений ('' - игнорируется)
--==============================================================================

xResume DATE;
xLabor DBMS_SQL.Number_Table;
xRID DBMS_SQL.Number_Table;
i NUMBER;
k NUMBER;
curr_RID NUMBER;
xOut BOOLEAN;
xManyRecord BOOLEAN;
xUser NUMBER;

BEGIN
xResume := NULL;
xUser := XLPL.USER_ID;
xOut := False;
xManyRecord := False;
xLabor.Delete;
if aLabor is NOT NULL then
  xLabor := S_ParseFloatArray(aLabor);
  if xLabor.Count > 1 then
    raise_application_error(-20202,
	                     'A_F_RelProtActvStart: параметры заданы неверно - ' ||
                         'число элементов в aLabor больше 1');
  end if;
end if;
xRID.Delete;
xRID := A_F_RelProtGetRIDActivity(1);  --     1 - ОБД, другое - РБД
k := xRID.Count;
FOR i IN 1..k LOOP
  curr_RID := xRID(i);
  begin
    select PERIOD_START into xResume
	from ACTIVITY
    where RID = curr_RID
	and ACTIVITY.ACTIVITY = aActivity
	and ((ACTIVITY.LABOR = TO_NUMBER(aLabor))
	      or ((aLabor is NULL) and (ACTIVITY.LABOR is NULL)))
	and ((DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason))
	             or ((aDismiss_Reason is NULL) and (DISMISSAL_REASON is NULL)));
	if xOut = True then
	  xManyRecord := True; -- ( > чем одному RIDу найдена запись с PERIOD_START)
	end if;
    xOut := True;
  exception
    when NO_DATA_FOUND then
      NULL;
  end;
END LOOP;
if xManyRecord = True then
      raise_application_error(-20203,
	   'A_F_RelProtActvStart: выбрано > одной строки из ACTIVITY' || CHR(10) ||
            '(aActivity = ' || TO_CHAR(aActivity) || ', aLabor = ' || aLabor ||
		    ', aDismiss_Reason = ' || aDismiss_Reason || ')');
end if;
if xOut = False then
  xOut := False;
  xManyRecord := False;
  xRID.Delete;
  xRID := A_F_RelProtGetRIDActivity(0);  -- по РБД
  k := xRID.Count;
  FOR i IN 1..k LOOP
    curr_RID := xRID(i);
    begin
      select PERIOD_START into xResume
	  from W$ACTIVITY
      where RID = curr_RID
	  and W$ACTIVITY.ACTIVITY = aActivity
	  and ENTERED_BY = xUser
	  and ((W$ACTIVITY.LABOR = TO_NUMBER(aLabor))
	      or ((aLabor is NULL) and (W$ACTIVITY.LABOR is NULL)))
	  and ((DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason))
	             or ((aDismiss_Reason is NULL) and (DISMISSAL_REASON is NULL)));
	  if xOut = True then
	    xManyRecord := True; -- ( > чем одному RIDу найдена запись с PERIOD_START)
	  end if;
      xOut := True;
    exception
      when NO_DATA_FOUND then
        NULL;
    end;
  END LOOP;
  if xManyRecord = True then
      raise_application_error(-20204,
     'A_F_RelProtActvStart: выбрано > одной строки из W$ACTIVITY' || CHR(10) ||
            '(aActivity = ' || TO_CHAR(aActivity) || ', aLabor = ' || aLabor ||
		    ', aDismiss_Reason = ' || aDismiss_Reason || ')');
  end if;
end if;
RETURN xResume;
END A_F_RelProtActvStart;
/
