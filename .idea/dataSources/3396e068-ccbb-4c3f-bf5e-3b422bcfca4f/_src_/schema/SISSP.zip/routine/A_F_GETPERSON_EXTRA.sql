CREATE FUNCTION       A_F_GETPERSON_EXTRA(CID#  IN NUMBER) RETURN NUMBER IS
/***********************************************************************************************
 Функция                : A_F_GETPERSON_EXTRA
 Наименование       : Выбрать инд. коэффициент для выплатных документов
 Автор                     : ОЛВ
 Состояние на дату  : 16.04.2013
 Изменения вносила Юркевич 01.05.2013
 Код возврата          : индивидуальный коэффициент в символьном виде
************************************************************************************************/
 vsRATIO      NUMBER;
BEGIN
    SELECT max(INDIVIDUAL_RATIO)
         INTO vsRATIO
       FROM PERSON_EXTRA a, CASE_PERSON c
     WHERE c.cid = CID#
           AND c.stage IS NULL
           AND ROLE IN (51, 54) -- 51 - Пенсионер, 54 - Кормилец1,  61 -Кормилец2
           AND a.pid=c.pid
           AND a.stage IS NULL;
    RETURN  vsRATIO;
EXCEPTION
       WHEN NO_DATA_FOUND   THEN
        RETURN 0;
END A_F_GETPERSON_EXTRA;
/
