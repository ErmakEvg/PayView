CREATE FUNCTION       B_F_ARRAYDATECHANGEBIRTHDEATH(PuskDate in date, param6m in number)
RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: F_ArrayDateChangePERSON
+ Наименование: Функция возвращает массив дат изменения дат рождения и смерти лица
+ Автор: Трухтанов					Корректировка Речицкая А. В.
+ Состояние на дату 25.08.1999 		12.05.2015
==============================================================================*/
chahge_date_aRecord DBMS_SQL.NUMBER_TABLE;
flg_insert_result boolean;
DateTalk date;
DateTalk1 date;

BEGIN
  DateTalk := A_F_DataTalk();
  DateTalk1 := Last_Day(S_Currdate);
  for c1 in (
  select nvl(BIRTH_DATE, null) as aRecord_start,
         nvl(DEATH_DATE, null) as aRecord_end
  	   from W$PERSON
       where PID = XLPL.GETPID and
	         RECORD_END is NULL and
	         STAGE in (1, 4) and
	         ENTERED_BY = XLPL.USER_ID)
  LOOP

    if (c1.aRecord_start is not null) AND (c1.aRecord_start > PuskDate) AND (c1.aRecord_start <= DateTalk1) then
	 if  (Param6m = 1) AND (XLPL.AID = 0)-- Если прпевышено 6 месяцев со для возникновения права
		then chahge_date_aRecord(chahge_date_aRecord.Count+1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), S_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		else chahge_date_aRecord(chahge_date_aRecord.Count+1) := s_julian(c1.aRecord_start);
	  end if;
	end if;
    if (c1.aRecord_end is not null) AND (c1.aRecord_end > PuskDate) AND(c1.aRecord_End <= DateTalk1) then
	  if  (Param6m = 1) AND (XLPL.AID = 0)  			   	  	  	   	   			  	   				 -- Если прпевышено 6 месяцев со для возникновения права
         then chahge_date_aRecord(chahge_date_aRecord.Count+1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), s_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		 else chahge_date_aRecord(chahge_date_aRecord.Count+1) := s_julian(c1.aRecord_end) + 1;
	 end if;
	  end if;
  end loop;
/*  LOOP Речицкая А. В. 12.05.2015
	 if (c1.aRecord_start is not null) AND (c1.aRecord_start > PuskDate) AND (c1.aRecord_start <= DateTalk1) then

	 if  (Param6m = 1) AND (XLPL.AID = 0)
	   				 -- Если прпевышено 6 месяцев со для возникновения права
		then chahge_date_aRecord(chahge_date_aRecord.Count+1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), S_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		else chahge_date_aRecord(chahge_date_aRecord.Count+1) := s_julian(c1.aRecord_start);
	  end if;
	  if (c1.aRecord_end is not null) AND (c1.aRecord_end > PuskDate) AND
	     (c1.aRecord_End <= DateTalk1) then
	 	 if  (Param6m = 1) AND (XLPL.AID = 0)  			   	  	  	   	   			  	   				 -- Если прпевышено 6 месяцев со для возникновения права
           then chahge_date_aRecord(chahge_date_aRecord.Count+1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), s_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		   else chahge_date_aRecord(chahge_date_aRecord.Count+1) := s_julian(c1.aRecord_end) + 1;
		 end if;
	  end if;
	end if
  end loop;Речицкая А. В. 12.05.2015*/
return A_F_ArrayDataChangeDelDup(chahge_date_aRecord);
END B_F_ARRAYDATECHANGEBIRTHDEATH;
/
