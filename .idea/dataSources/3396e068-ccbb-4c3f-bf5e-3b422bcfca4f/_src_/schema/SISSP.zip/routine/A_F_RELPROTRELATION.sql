CREATE FUNCTION       A_F_RelProtRelation(aRelation in VARCHAR)
                                                               RETURN BOOLEAN IS
--==============================================================================
-- Назначение: Возращает TRUE, если у человека есть хотя бы один код для поля
--             RELATION из переменной ARELATION, согласно W$RELATION_PROTOCOL и
--             CASE_PERSON и W$CASE_PERSON
--------------------------------------------------------------------------------
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Входные праметры:
---------------------
--  aRelation - список кодов отношения
--==============================================================================

xResume BOOLEAN;
xRID DBMS_SQL.Number_Table;
xRelation DBMS_SQL.Number_Table;
i NUMBER;
k NUMBER;
curr_Relation NUMBER;
l NUMBER;
m NUMBER;
curr_RID NUMBER;
xCount NUMBER;
xUser NUMBER;

BEGIN
xResume := False;
xUser := XLPL.USER_ID;
xRelation.Delete;
xRelation := S_ParseFloatArray(aRelation);
xRID.Delete;
xRID := A_F_RelProtGetRIDCasePerson;
k := xRelation.Count;




m := xRID.Count;
if m <> 0 then
  FOR i IN 1..k LOOP
    if xResume = True then
      EXIT;
    end if;
    curr_Relation := xRelation(i);
    FOR l IN 1..m LOOP
      curr_RID := xRID(l);
      select count(*) into xCount
      from CASE_PERSON
	  where RID = curr_RID
	  and RELATION = curr_Relation;
	  if xCount > 0 then
	    xResume := True;
        EXIT;
      end if;
    END LOOP;
  END LOOP;
end if;
if xResume = False then
  xRID.Delete;
  xRID := A_F_RelProtGetRIDWCasePerson;
  m := xRID.Count;
  if m <> 0 then
    FOR i IN 1..k LOOP
      if xResume = True then
        EXIT;
      end if;
      curr_Relation := xRelation(i);
      FOR l IN 1..m LOOP
        curr_RID := xRID(l);
        select count(*) into xCount
		from W$CASE_PERSON
	    where RID = curr_RID
		and ENTERED_BY = xUser
		and RELATION = curr_Relation;
	    if xCount > 0 then
	      xResume := True;
          EXIT;
        end if;
      END LOOP;
    END LOOP;
  end if;
end if;
RETURN xResume;
END A_F_RelProtRelation;
/
