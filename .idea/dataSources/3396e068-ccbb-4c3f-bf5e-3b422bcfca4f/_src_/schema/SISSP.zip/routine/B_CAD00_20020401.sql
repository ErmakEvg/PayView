CREATE FUNCTION       B_CAD00_20020401 RETURN NUMBER AS

/***************************************************************************************
// Функция: B_CAD00_20020401
// Наименование: Функция расчета размера пособия детям до 18 лет, инфицированным ВИЧ или
//               больным СПИД
// Автор: Ворошилин В.
// Состояние на дату 05.02.1999
// Код возврата: число с плавающей точкой с суммой пособия
//***************************************************************************************/

BEGIN
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CHECKROLE(56) then
    XLPL.Payment := 0;
	XLPL.Amount := 0;
	return XLPL.Amount;
  end if;
  XLPL.REPLACEROLE('Child');
  if not A_F_RelProtNotInterHouse then
    XLPL.Payment := 0;
	XLPL.Amount := 0;
    XLPL.RESTOREROLE;
	return XLPL.Amount;
  end if;
  XLPL.Amount := S_Const(18, XLPL.WorkDate) * S_Const(496, XLPL.WorkDate) / 100;
  XLPL.RESTOREROLE;
  return XLPL.Amount;
END B_CAD00_20020401;
/
