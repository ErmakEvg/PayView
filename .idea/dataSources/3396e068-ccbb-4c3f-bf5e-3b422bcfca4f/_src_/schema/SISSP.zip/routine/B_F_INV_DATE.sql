CREATE FUNCTION       B_F_INV_DATE(APID NUMBER,ADATE DATE) RETURN NUMBER IS

/******************************************************************************
 Функция           : B_F_INV_DATE
 Наименование      : Функция определяет наличие инвалидности у конкретного лица
                   : на конкретную дату
 Параметры         : aPID - идентификатор лица
                   : aDate - дата на которую идет проверка
 Автор             : Иванова Т.С.
 Состояние на дату : 26.10.2018
 Возвращает        : ADVICE_TYPE из MRAK_OPINION_ADVICE , если есть (11,12,13,14)
                      0,если не нашли
                      15, если больше 1 записи
*******************************************************************************/
INV   NUMBER;
 BEGIN
 INV:= 0;
 SELECT ADVICE_TYPE INTO INV FROM MRAK_OPINION_ADVICE MRA,MRAK_OPINION B
     WHERE ADVICE_TYPE IN (11,12,13,14)
     AND B.RID=MRA.MRAK_RID
   AND  MRA.STAGE IS NULL AND  B.STAGE IS NULL AND B.EXAMED_FROM<= ADATE
   AND NVL(B.RECORD_END,ADATE)>=ADATE
   AND  MRA.PID=APID;
   RETURN    INV;
   EXCEPTION
    WHEN NO_DATA_FOUND THEN  RETURN 0;
    WHEN OTHERS THEN RETURN 15;
 END B_F_INV_DATE;
/
