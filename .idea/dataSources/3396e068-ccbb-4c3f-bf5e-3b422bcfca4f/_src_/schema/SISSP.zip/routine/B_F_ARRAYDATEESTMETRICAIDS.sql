CREATE FUNCTION       B_F_ArrayDateEstMETRICAIDS RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_ArrayDateEstMETRICAIDS
+ Наименование: функция возращает массив изменения характеристики для больного
+ 				СПИД для Estimation
+ Автор: Ворошилин В.
+ Состояние на дату 17.11.2000
==============================================================================*/

  a DBMS_SQL.NUMBER_TABLE;
BEGIN
  a.Delete;
  for METRICAIDS in (select nvl(RECORD_START, NULL) as metric_start,
                            nvl(RECORD_END, NULL) as metric_end,
							CODE
					 from W$PERSON_METRIC
					 where PID = XLPL.GetPid
					   and STAGE in (1, 4)
					   and (NVL(RECORD_START, NULL) > LAST_DAY(S_CurrDate) or NVL(RECORD_END, NULL) > LAST_DAY(S_CurrDate))
					   and ENTERED_BY = XLPL.User_ID)
  loop
	if (METRICAIDS.metric_start is not NULL) and (METRICAIDS.metric_start > LAST_DAY(S_CurrDate)) then
      if (METRICAIDS.Code = 320) then
	    a(a.count + 1) := S_Julian(METRICAIDS.metric_start) - 1;
		a(a.count + 1) := 86;
		a(a.count + 1) := 1;
	  end if;
	end if;
	if (METRICAIDS.metric_end is not NULL) and ((METRICAIDS.metric_end + 1) > LAST_DAY(S_CurrDate)) then
      if (METRICAIDS.Code = 320) then
	    a(a.count + 1) := S_Julian(LAST_DAY(METRICAIDS.metric_end));
		a(a.count + 1) := 70;
		a(a.count + 1) := 1;
	  end if;
	end if;
  end loop;
  return a;
END B_F_ArrayDateEstMETRICAIDS;
/
