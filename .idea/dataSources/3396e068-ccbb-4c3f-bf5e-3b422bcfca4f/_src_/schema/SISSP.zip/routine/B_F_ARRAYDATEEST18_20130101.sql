CREATE FUNCTION       B_F_Arraydateest18_20130101 RETURN DBMS_SQL.NUMBER_TABLE AS
/*******************************************************************************
 Функция           : B_F_Arraydateest18_20130101
 Наименование      : Функция построения прогнозируемой даты конца характеристики
                     359 - Ребенок второй и последующий
                     для пособий на детей до 3 лет
 Автор             : ОЛВ
 Состояние на дату : 22.05.2013  21.10.2014
 Код возврата      : возвращает массив с датой наступления 18 лет для Estimation
********************************************************************************/
  result_array    DBMS_SQL.NUMBER_TABLE;
  pEnd              DATE;
BEGIN
     result_array.DELETE;
  IF NOT Xlpl.CheckRole(56) THEN
    RETURN result_array;
  END IF;
  Xlpl.RoleDecl('Child', '56');
  Xlpl.REPLACEROLE('Child');
  -- Ребенок второй и последующий -- IF  B_F_Relprotmetricben('359') THEN  pEnd:=B_F_Metricwithoutend(359); END IF;
  -- Определение даты конца действия характеристики по рабочей базе
  BEGIN
   select nvl(RECORD_END, NULL)
       INTO pEnd
       from W$PERSON_METRIC
      where PID = XLPL.GetPid
        and STAGE in (1, 4)
        and ENTERED_BY = XLPL.User_ID
        and code=359
        and NVL(RECORD_END, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate);
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
       pEnd:=NULL;
  END;
  IF pEnd IS NOT NULL THEN
      -- Контроль даты исполнения старшему ребенку возраста 18 лет
      IF (pEnd + 1) > LAST_DAY(S_Currdate) THEN
              result_array(1) := S_Julian(pEnd + 1);
              result_array(2) := 24;
              result_array(3) := 5;
                 Xlpl.RESTOREROLE;
               RETURN result_array;
      END IF;
  END IF;

  Xlpl.RESTOREROLE;
  RETURN result_array;
-- RAISE_APPLICATION_ERROR(-20801,'B_F_Arraydateest18_20130101 2     pEnd = '||pEnd ||' xlpl.getpid='||xlpl.getpid);
END B_F_Arraydateest18_20130101;
/
