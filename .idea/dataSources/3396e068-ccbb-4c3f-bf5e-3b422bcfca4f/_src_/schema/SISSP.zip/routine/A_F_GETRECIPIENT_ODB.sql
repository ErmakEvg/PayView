CREATE FUNCTION       A_F_GetRecipient_ODB(AALLOC_CODE IN DBMS_SQL.Number_Table)
   RETURN Number AS
/*******************************************************************************
 Функция             : A_F_GetRecipient_ODB
 Наименование        : Функция возвращения получателя из ОДБ
 Автор               : Вахромин О.Ю.   Комментарии: ОЛВ
 Состояние на дату   : 	                     22.05.2012 , ITS 27.06.2018
 Код возврата        : Возвращает получателя из ОДБ
********************************************************************************/
 vsPID                Number;
 vsCATEGORY   		  Number;
 vsCONTROL_ALLOC_CODE Number;
 vsALLOC_CODE 		  Number;
 vsCALLOC_CODE 		  Number;
 vCount        		  Number;
BEGIN
 -- FI_PROCESSINGALLOCATION - Интерфейсная функция проверки права и расчета группы назначений
 begin
   -- Выбрать получателя
   select PID into vsPID from RECIPIENT
    where CID=XLPL.CID
	  and AID is NULL
      AND STAGE IS NULL;--ITS 27.06.2018 --and NVL(STAGE,4) not in (2,3);
    if vsPID is NULL then
         vsPID:= 0;
    end if;
 exception
      when No_Data_Found then
         RAISE_APPLICATION_ERROR(-20801,'FI_PROCESSINGALLOCATION: В деле '||
            			              to_char(XLPL.CID)||' нет получателя');
      when Too_Many_Rows then
         RAISE_APPLICATION_ERROR(-20801,'FI_PROCESSINGALLOCATION: В деле '||
                            to_char(XLPL.CID)||' больше одного получателя');
 end;
 -- В пособиях, кроме пособия на погребение, получателем не может быть лицо у которого нет роли
 -- Выбрать вид назначения
 select ACCESS_DATA             -- КАТЕГОРИЯ ДАННЫХ; КЛАССИФИКАТОР REF_ACCESS_DATA
   into vsCATEGORY from ID_CASE -- УНИКАЛЬНЫЕ ИДЕНТИФИКАТОРЫ ДЕЛ, НАХОДЯЩИХСЯ В ОБД
  where CID = XLPL.CID;
 if vsCATEGORY = 2 then -- пособие
    -- если это пособие на погребение - для него м.б. лицо не участвующее в деле
      vsCONTROL_ALLOC_CODE:= 550; -- пособие на погребение
    for i in 1..AALLOC_CODE.count loop
       begin
            vsALLOC_CODE:= i;
            select CODE into vsCALLOC_CODE from ALLOCATIONS
			 where CODE = vsCONTROL_ALLOC_CODE
             start with CODE = vsALLOC_CODE connect by prior PARENT_CODE=CODE;
       exception
            when No_Data_Found then -- это не пособие на погребение
                select count(*) into vCount from CASE_PERSON
				 where CID = XLPL.CID
				   and PID = vsPID
                  AND STAGE IS NULL;--ITS 27.06.2018 -- and NVL(STAGE,4) not in (2,3);
                if vCount=0 then
         		  RAISE_APPLICATION_ERROR(-20801,'FI_PROCESSINGALLOCATION: В деле '||
                   to_char(XLPL.CID)||' у получателя должна быть роль (Получателем не может быть лицо, не проходящее по делу)');
                end if;
       end;
    end loop;
 end if;
   return vsPID;
END A_F_GetRecipient_ODB;
/
