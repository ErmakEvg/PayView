CREATE FUNCTION       B_Child3_Nadbavka_20130101 RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_Child3_Nadbavka_20130101
 Наименование       : Проверка права и вычисление надбавок для пособий детям до 3 лет
 Автор              : Речицкая А.В.
 Состояние на дату  : 09.01.2013
 Код возврата       : массив, содержащий коды надбавок и соответствующие суммы надбавок
***********************************************************************************************/
 K      DBMS_SQL.NUMBER_TABLE;
BEGIN

 K.delete;
 XLPL.SETGLOBALFLOAT('Nadb1', 0);
-- XLPL.SETGLOBALFLOAT('Nadb1', 1);

 -- Сумма увеличения пособия по Закону о ЧАЭС для детей до 3 лет для зон радиоактивного загрязнения 2 - 5:
 if F$CHECK581 then
   K(581) := F$AMOUNT581;
 end if;

 IF XLPL.INDIV = 0 then      -- Индивидуальный расчет --
      XLPL.S_protocol ('   Процент выплаты :      '    || TO_CHAR(XLPL.Payment) || '%' || CHR (10));
 END IF;

 Return K;

 /* *
  K      DBMS_SQL.NUMBER_TABLE;
 Bonus  DBMS_SQL.NUMBER_TABLE;
 Amount1     NUMBER;
 Amount_Sum  NUMBER;
 Percent     NUMBER;

BEGIN

 K.delete;
 Bonus.delete;
 Amount1:=XLPL.GetGlobalFloat('Amount1');
 Amount_Sum:=AMOUNT1;

 XLPL.SETGLOBALFLOAT('Nadb1', 0);
   Bonus := B_F_Nad0();
 XLPL.SETGLOBALFLOAT('Nadb1', 1);
 if Bonus.count <> 0 then
   K := Bonus;
 end if;

 -- Сумма увеличения пособия по Закону о ЧАЭС для детей до 3 лет для зон радиоактивного загрязнения 2 - 5:
 if F$CHECK581 then
   K(581) := F$AMOUNT581;
 end if;

   IF XLPL.INDIV = 0 then      -- Индивидуальный расчет --
      XLPL.S_protocol ('   Процент выплаты :      '    || TO_CHAR(XLPL.Payment) || '%' || CHR (10));
   --  if XLPL.Payment<100 then
    --   XLPL.S_protocol ('Сумма к выплате: '|| CHR(9)|| TO_CHAR(Amount_Sum*XLPL.Payment*0.01, '99999999.99') || CHR (10));
    -- end if;
   END IF;

 Return K;

/* */
END B_Child3_Nadbavka_20130101;
/
