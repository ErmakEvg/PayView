CREATE FUNCTION       B_F_Absentzone RETURN DBMS_SQL.NUMBER_TABLE AS
/***************************************************************************************
 Функция: B_F_AbsentZone
 Наименование: Функция определяет периоды отсутствия лица по адресу прописки и проживания
                          (без привязки к дате)
 Автор: Ворошилин В.
 Состояние на дату 24.07.2000   28.08.2013 Рчицкая АВ
 Возвращает: массив, где первый член - дата начала отсутствия, второй - дата конца  отсутствия
***************************************************************************************/
  a DBMS_SQL.NUMBER_TABLE;
BEGIN
  a.DELETE;
  FOR AbsentZone IN (SELECT NVL(PERIOD_START, Xlpl.WorkDate) AS ACTSTART, NVL(PERIOD_END, Xlpl.WorkDate) AS ACTEND
                     FROM W$ABSENCE_PERSON
                     WHERE PID = Xlpl.GetPid
                       AND ADDRESS_RID =
                                         (SELECT RID FROM W$ADDRESS
                                          WHERE PID = Xlpl.GetPid
                                            AND STAGE IN (1, 4)
                                            and ADDRESS_TYPE in(2,3)-- добавлена строка 28.08.2013 Рчицкая АВ
                                            AND ENTERED_BY = Xlpl.User_ID)
                       AND STAGE IN (1, 4)
                       AND ENTERED_BY = Xlpl.User_ID)
  LOOP
    a(a.COUNT+1) := S_Julian(AbsentZone.ACTSTART);
    a(a.COUNT+1) := S_Julian(AbsentZone.ACTEND);
  END LOOP;
  RETURN a;
END B_F_Absentzone;
/
