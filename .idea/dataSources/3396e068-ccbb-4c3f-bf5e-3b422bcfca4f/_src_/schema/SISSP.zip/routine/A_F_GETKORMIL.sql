CREATE FUNCTION       A_F_Getkormil RETURN NUMBER AS
/**********************************************************************************************
 Функция                 : A_F_GetKormil
 Наименование        : Ф-я определения главного Кормильца в пенсии по СПК
 Автор                      : ОЛВ
 Состояние на дату  : 12.06.2013   10.12.2013
 Код возврата           : Возвращает номер главного Кормильца
***********************************************************************************************/
 vKormil   NUMBER;
 vFeature  NUMBER;
BEGIN
   BEGIN
       SELECT NVL(METHOD_SPK,1)
            INTO vKormil
          FROM CASE
       WHERE cid = Xlpl.CID
             AND stage IS NULL
             AND METHOD_SPK=2;
   EXCEPTION
       WHEN NO_DATA_FOUND THEN
             vKormil:=1;
   END;

 -- 10.12.2013 OLV --"Пенсионер (кроме СПК) МСЗ"
 --Не нужно ставить дату окончания действия особенности "Пенсионер (кроме СПК) МСЗ"
  BEGIN
     SELECT NVL(FEATURE,0)
       INTO vFeature
       FROM ALLOCATION
      WHERE CID=Xlpl.CID
        AND STAGE is null
        AND PARENT_RID is NULL
        AND COMP_PART is NULL
        AND AID = Xlpl.AID
        AND step_start<=XLPL.WORKDATE AND XLPL.WORKDATE <= nvl(step_end, XLPL.WORKDATE);
  EXCEPTION
        WHEN NO_DATA_FOUND THEN
             vFeature:=0;
  END;
   Xlpl.FEATURE:=vFeature;
  RETURN vKormil;
END A_F_Getkormil;
/
