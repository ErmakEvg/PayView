CREATE FUNCTION       A_Calc_Amount(ACID IN NUMBER,AAID IN NUMBER,pDate_Dop IN DATE)
   RETURN NUMBER IS
/*******************************************************************************
 Функция           :  A_Calc_Amount
 Наименование      :  Ф-я определения назначеной суммы
 Автор             : ОЛВ
 Состояние на дату : 14.10.2013   12.02.2015
 Код возврата      : сумма назначения
*******************************************************************************/
 Summa_Pens        NUMBER;
 pStart            DATE;
 pEnd              DATE;
BEGIN
  --Получить дату первого и последнего дня месяца
    pStart:=LAST_DAY(ADD_MONTHS(pDate_Dop,-1))+1;
    pEnd:=ADD_MONTHS(pStart, 1)-1;
    Summa_Pens := 0;
 IF (Xlpl.INDIV <>2) THEN -- не массовый расчет --
   FOR c1 IN (
     --12.02.2015 ОЛВ -- выбирать из ОБД
     SELECT a.period_amount vPeriod_Amount, a.PAYMENT_PERCENT vPayment_Percent
       --12.02.2015 --FROM W$CALC_AMOUNT a, W$RESULT_PAYMENT b
       FROM CALC_AMOUNT a, RESULT_PAYMENT b
      WHERE a.cid=ACID
        AND a.alloc_code<>727
        AND a.aid=AAID
        AND a.PAYMENT_PERCENT>0
        AND a.period_amount>0 -- 12.02.2015 OLV ???
        AND a.stage is null
        --AND a.stage in (1,4)
        --AND a.ENTERED_BY=Xlpl.USER_ID
        AND b.rid=a.result_payment_rid
        AND b.PAYROLL_NO IS NOT NULL  --
        AND b.period_rid IS NOT NULL  --
        AND (((pStart between a.period_start and a.period_end)
        AND (pEnd between a.period_start and a.period_end))
            or (a.period_start between pStart and pEnd) or (a.period_end between pStart and pEnd)) )
   LOOP
      if c1.vPayment_Percent<100 then
         Summa_Pens := Summa_Pens+ c1.vPeriod_Amount/c1.vPayment_Percent*100;
      else
         Summa_Pens := Summa_Pens+ c1.vPeriod_Amount;
      end if;
   END LOOP;
 ELSE   -- массовый расчет --
   FOR c1 IN (
     SELECT a.period_amount vPeriod_Amount, a.PAYMENT_PERCENT vPayment_Percent
       FROM CALC_AMOUNT a, RESULT_PAYMENT b
      WHERE a.cid=ACID
        AND a.alloc_code<>727
        AND a.aid=AAID
        AND a.PAYMENT_PERCENT>0
        AND a.period_amount>0 -- 12.02.2015 OLV
        AND a.stage is null
        AND b.rid=a.result_payment_rid
        AND b.PAYROLL_NO IS NOT NULL
        AND b.period_rid IS NOT NULL
        AND (((pStart between a.period_start and a.period_end)
        AND (pEnd between a.period_start and a.period_end))
            or (a.period_start between pStart and pEnd) or (a.period_end between pStart and pEnd)) )
   LOOP
      if c1.vPayment_Percent<100 then
         Summa_Pens := Summa_Pens+ c1.vPeriod_Amount/c1.vPayment_Percent*100;
      else
         Summa_Pens := Summa_Pens+ c1.vPeriod_Amount;
      end if;
   END LOOP;

 END IF;
   RETURN  Summa_Pens;
END A_Calc_Amount;
/
