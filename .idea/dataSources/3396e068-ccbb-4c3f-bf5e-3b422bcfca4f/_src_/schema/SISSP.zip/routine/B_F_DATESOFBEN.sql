CREATE FUNCTION       B_F_DatesOfBen(aCode IN BINARY_INTEGER) RETURN DBMS_SQL.Number_Table AS

/***************************************************************************************
// Функция: B_F_DatesOfBen
// Наименование: Функция определяет даты начала и конца действия конкретного назначения
// Автор: Ворошилин В.
// Состояние на дату 11.11.1999
// Возвращает: массив
//***************************************************************************************/

  A DBMS_SQL.Number_Table;
  BDay DATE;
  StartDateBD DATE;
  Dt DATE;
BEGIN
  A.Delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CHECKROLE(56) then
	return A;
  end if;
  XLPL.REPLACEROLE('Child');
  BDay := S_Birthdate(XLPL.BASE_ID, XLPL.GetPid, XLPL.WorkDate);
  XLPL.RESTOREROLE;
  StartDateBD := S_AddYears(BDay, TRUNC(S_Const(401, XLPL.WorkDate))) + 1;
  Dt := S_DateConst(478, XLPL.WorkDate);
  Dt := S_EncodeDate(S_YearOfDate(XLPL.WorkDate), S_MonthOfDate(Dt), S_DayOfDate(Dt));
  if (StartDateBD >= Dt) and (StartDateBD <= XLPL.WorkDate) then
   	Dt := StartDateBD;
  end if;
  for curDatesOfBen in (select ALLOCATION_START from ALLOCATION a, ALLOCATION_PERSON b, CASE_PERSON c, RECIPIENT d
                        where a.RID = b.ALLOCATION_RID
						  and b.PID = XLPL.GetPid
						  and c.PID = b.PID
						  and d.CID = c.CID
						  and d.PID = b.PID
						  and (c.STAGE <> 3 or c.STAGE is NULL)
						  and (a.STAGE <> 3 or a.STAGE is NULL)
						  and (b.STAGE <> 3 or b.STAGE is NULL)
						  and (d.STAGE <> 3 or d.STAGE is NULL)
						  and a.ALLOC_CODE in (select CODE from ALLOCATIONS start with CODE = aCode connect by prior CODE = PARENT_CODE)
						  and a.ALLOCATION_START >= Dt
						  and a.ALLOCATION_END is null
						  and (a.STEP_END is null or a.STEP_END >= XLPL.WorkDate))
  LOOP
	A(A.count+1) := S_Julian(curDatesOfBen.ALLOCATION_START);
  end LOOP;
  RETURN A;
END B_F_DatesOfBen;
/
