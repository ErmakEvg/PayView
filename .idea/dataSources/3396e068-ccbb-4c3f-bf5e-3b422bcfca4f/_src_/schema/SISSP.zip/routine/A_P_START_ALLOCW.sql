CREATE FUNCTION       A_P_Start_AllocW RETURN DATE AS
/*******************************************************************************
 Функция            : A_P_Start_AllocW
 Наименование       : Функция определения даты начала действия нового назначения
 Автор              : ОЛВ
 Состояние на дату  : 09.01.2017
 Код возврата       : предположительная дата начала действия нового назначения
********************************************************************************/
 pStart_Alloc DATE;
BEGIN
   BEGIN
    SELECT EXPECT_START_DATE
      INTO pStart_Alloc
      FROM W$ALLOCATION_PROTOCOL
     WHERE cid = Xlpl.CID
       AND aid = Xlpl.AID
       AND GROUP_NO=XLPL.GROUP_NO  --13.01.2017  OLV
       AND alloc_code = Xlpl.ALLOC_CODE;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
          pStart_Alloc := Xlpl.WorkDate;
   END;

    RETURN   pStart_Alloc;
END A_P_Start_AllocW;
/
