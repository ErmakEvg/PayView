CREATE FUNCTION       A_F_RelProtControlRole(aRole in NUMBER)
                                                               RETURN BOOLEAN IS
--==============================================================================
-- Назначение: проверяет роль текущего лица
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Возвращаемое значение: True - если поданная роль лица
--                        совпадает с текущей ролью, в противном случае - False
--==============================================================================
xResume BOOLEAN;
xRole NUMBER;

BEGIN
xRole := A_F_RelProtCurrentRole;
if aRole = xRole then
  xResume := True;
else
  xResume := False;
end if;
RETURN xResume;
END A_F_RelProtControlRole;
/
