CREATE FUNCTION       B_F_AMOUNTTOPAYCONTRIBUTION return NUMBER is
/***************************************************************************************
// Функция: B_F_AMOUNTTOPAYCONTRIBUTION
// Наименование: Функция, определяющая, платили ли родители взносы в ФСЗ
// Автор: Гуз Е.
// Состояние на дату 04.02.1999
// Код возврата: True - лицо платит взносы, False - лицо не платит взносы
/***************************************************************************************/
SumContribution NUMBER;
aCID NUMBER;
DateSql DATE;

BEGIN

DateSql := S_EncodeDate(S_YearOfDate(XLPL.WorkDate)-1,12,31);
aCID := XLPL.CID;
begin
Select CONTRIBUTION_YEAR into SumContribution
From W$CASE_SUMMARY_INCOME
	 Where CID = aCID and
 	 TO_CHAR(W$CASE_SUMMARY_INCOME.YEAR, 'YYYY') = TO_CHAR(DateSql, 'YYYY') and
     STAGE NOT IN(2,3) and
     RECORD_START <= XLPL.WorkDate and
	 (RECORD_END >= XLPL.WorkDate or RECORD_END is null) and
	 ENTERED_BY = XLPL.USER_ID;
exception
     when OTHERS then
	 SumContribution := 0;
end;
Return SumContribution;

END B_F_AMOUNTTOPAYCONTRIBUTION;
/
