CREATE FUNCTION       A_F_ArrayAlocCode(strAlloc_Codes in VarChar2)
   RETURN VarChar2 IS
/*Формирование масива Alloc_code
Вахромин О.Ю.*/
Rab DBMS_SQL.Number_Table;
rez_STR VarChar2(2048);
Rez_ins Boolean;
BEGIN
   rez_STR:='';
   Rez_ins:=False;
   Rab:=S_ParseFloatArray(strAlloc_Codes);
   for i in 1..Rab.count loop
      if i<>561 then
         if not Rez_ins then
            rez_STR:=rez_STR||To_Char(Rab(i));
         else
            rez_STR:=rez_STR||','||To_Char(Rab(i));
         end if;
	     Rez_ins:=True;
      end if;
   end loop;
   return rez_STR;
END A_F_ArrayAlocCode;
/
