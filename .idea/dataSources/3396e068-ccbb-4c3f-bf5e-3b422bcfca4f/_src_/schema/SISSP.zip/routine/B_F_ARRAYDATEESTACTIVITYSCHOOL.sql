CREATE FUNCTION       B_F_Arraydateestactivityschool RETURN DBMS_SQL.NUMBER_TABLE AS
/*==============================================================================
+ Функция: F_ArrayDateEstACTIVITYSchool
+ Наименование: возвращает массив дат окончания учебного года для учащихся
+                 старше 14 лет
+ Автор: Ворошилин В.
+ Состояние на дату 17.11.2000
==============================================================================*/

  result_array DBMS_SQL.NUMBER_TABLE;
  DtBeg14 DATE;
  DtBeg16 DATE;
  StopDtEnd DATE;
  StopDtSept DATE;
  StopDtJuly DATE;
  CN_ACTIVITY NUMBER;
BEGIN
  result_array.DELETE;
  Xlpl.RoleDecl('Child', '56');
  IF NOT Xlpl.CheckRole(56) THEN
    RETURN result_array;
  END IF;
  Xlpl.REPLACEROLE('Child');
  -- 403 - Ограничение возраста ребенка для пособия на детей в возрасте старше 3 лет - в годах =18
  -- 406 - Ограничение возраста ребенка для пособия на детей в возрасте старше 3 лет, обучающихся в общеобразовательной школе, лицее - в годах =14
  -- 479 - Дата окончания действия пособий на детей старше 3 лет (31.12)
  -- 480 - Дата, по которую выплачивается пособие на детей - учащихся старше 14 лет
  -- 492 - Дата, по которую выплачивается пособие на детей - учащихся базовых (9 или 11) классов
  DtBeg14 := S_Addyears(S_Birthdate(0, Xlpl.GetPid, Xlpl.WorkDate), TRUNC(S_Const(406, Xlpl.WorkDate)));
  DtBeg16 := S_Addyears(S_Birthdate(0, Xlpl.GetPid, Xlpl.WorkDate), TRUNC(S_Const(403, Xlpl.WorkDate)));
  StopDtEnd := S_Encodedate(S_Yearofdate(LAST_DAY(S_Currdate)), S_Monthofdate(S_Jtod(TRUNC(S_Const(479, Xlpl.WorkDate)))), S_Dayofdate(S_Jtod(S_Const(479, Xlpl.WorkDate))));
  StopDtSept := S_Encodedate(S_Yearofdate(LAST_DAY(S_Currdate)), S_Monthofdate(S_Jtod(TRUNC(S_Const(480, Xlpl.WorkDate)))), S_Dayofdate(S_Jtod(S_Const(480, Xlpl.WorkDate))));
  StopDtJuly := S_Encodedate(S_Yearofdate(LAST_DAY(S_Currdate)), S_Monthofdate(S_Jtod(TRUNC(S_Const(492, Xlpl.WorkDate)))), S_Dayofdate(S_Jtod(S_Const(492, Xlpl.WorkDate))));
  IF (DtBeg14 > StopDtSept)THEN
    RETURN result_array;
  END IF;
  IF (LAST_DAY(S_Currdate) > StopDtSept) THEN
    RETURN result_array;
  END IF;
  SELECT COUNT(*) INTO CN_ACTIVITY
  FROM W$ACTIVITY
  WHERE PID = Xlpl.GetPid
    AND ACTIVITY = 2
    AND LABOR = 237
    AND ENTERED_BY = Xlpl.User_ID
    AND STAGE NOT IN(2,3)
    AND (NVL(PERIOD_START, Xlpl.WorkDate) >= Xlpl.WorkDate OR NVL(PERIOD_END, Xlpl.WorkDate) >= Xlpl.WorkDate);
  IF ((CN_ACTIVITY != 0) OR (DtBeg16 <= StopDtJuly)) AND (LAST_DAY(S_Currdate) <= StopDtJuly) THEN
    result_array(1) := S_Julian(StopDtJuly);
    result_array(2) := 71;
    result_array(3) := 1;
    Xlpl.RESTOREROLE;
    RETURN result_array;
  END IF;
  IF (DtBeg14 <= StopDtSept) AND (DtBeg16 > StopDtSept) AND (LAST_DAY(S_Currdate) <= StopDtSept) THEN
    result_array(1) := S_Julian(StopDtSept);
    result_array(2) := 39;
    result_array(3) := 1;
    Xlpl.RESTOREROLE;
    RETURN result_array;
  END IF;
  Xlpl.RESTOREROLE;
  RETURN result_array;
END B_F_Arraydateestactivityschool;
/
