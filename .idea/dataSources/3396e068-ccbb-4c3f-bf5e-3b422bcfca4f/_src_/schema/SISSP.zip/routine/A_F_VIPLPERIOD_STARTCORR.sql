CREATE FUNCTION       A_F_Viplperiod_Startcorr  RETURN DATE IS
/**********************************************************************************************
 Функция                 : P_ViplPeriod_Start
 Наименование        : Функция получения даты  начала выплатного периода
 Автор                     : ОЛВ
 Состояние на дату  : 26.06.2013
 Код возврата          : Возвращает дату конца выплатного периода
***********************************************************************************************/
  Metric_Start DATE;
  Metric_End DATE;
BEGIN
   BEGIN
        SELECT NVL(RECORD_START, NULL),  NVL(RECORD_END, NULL)
	         INTO Metric_Start, Metric_End
           FROM W$PERSON_METRIC pm, ACCOUNTING_PERIOD ap
        WHERE pm.PID = Xlpl.GetPid
	          AND pm.code=740 	-- 740 - Требуется ручная корректировка суммы назначения за текущий выплатной период
	    	  AND pm.STAGE IN (1, 4)
		      AND pm.ENTERED_BY = Xlpl.User_ID
		      AND pm.RECORD_START IS NOT NULL
              AND pm.RECORD_START >=ap.period
              AND pm.RECORD_END IS NOT NULL
              AND pm.RECORD_END <=LAST_DAY(ap.period)
              AND ap.sign_close_period IS NULL;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
				 --  RAISE_APPLICATION_ERROR(-20801,'A_F_ViplPeriod_Start 111 '||'  Metric_Start='||Metric_Start||'   XLPL.WorkDate='||  Xlpl.WorkDate);
         Metric_End:= NULL;
   END;

  IF Metric_End IS NULL THEN
                --   RAISE_APPLICATION_ERROR(-20801,'A_F_ViplPeriod_Start  222 '||'  Metric_Start='||Metric_Start||'   XLPL.WorkDate='||  Xlpl.WorkDate);
     Metric_Start :=NULL;
  END IF;
                 --  RAISE_APPLICATION_ERROR(-20801,'A_F_ViplPeriod_Start 333 '||'  Metric_Start='||Metric_Start||'   XLPL.WorkDate='||  Xlpl.WorkDate);
    RETURN Metric_Start;
END A_F_Viplperiod_Startcorr;
/
