CREATE FUNCTION       B_F_ARRAYDATEESTSTEP RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Наименование: Массив шагов по старому существующему Estimation
+ Состояние на дату 17/11/2000
==============================================================================*/

  AllocStep DBMS_SQL.NUMBER_TABLE;
BEGIN
  AllocStep.Delete;
  for BIRTHDEATH in (Select nvl(ESTIMATION_DATE, NULL) as StStart, STATUS_REASON, CHANGE_ALLOC_STATUS
                     from ALLOC_DATE_ESTIMATION
					 Where Cid = XLPL.CID
					   and Aid = XLPL.AID
					   and Close_Date Is Null
					   and ESTIMATION_DATE > LAST_DAY(S_CurrDate)
					   and ALLOC_CODE = XLPL.ALLOC_CODE
					   and stage not in (2,3))
  loop
	if BIRTHDEATH.StStart is not NULL then
	  AllocStep(AllocStep.count+1) := S_Julian(BIRTHDEATH.StStart);
	  AllocStep(AllocStep.count+1) := BIRTHDEATH.STATUS_REASON;
	  AllocStep(AllocStep.count+1) := BIRTHDEATH.CHANGE_ALLOC_STATUS;
	end if;
  end loop;
  return AllocStep;
END B_F_ARRAYDATEESTSTEP;
/
