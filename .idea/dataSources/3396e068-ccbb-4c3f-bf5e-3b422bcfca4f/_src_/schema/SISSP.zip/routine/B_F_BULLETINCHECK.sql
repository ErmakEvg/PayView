CREATE FUNCTION       B_F_BulletinCheck return BOOLEAN is
/*
F_BulletinCheck
Проверка, обратилось ли лицо за пособием раньше окончания больничного листа
по беременности и родам
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 17.07.2002
*/
  BthDate date;
  StartDate date;
  w_StartDate date;
  P_StartDate date;
begin
  if (XLPL.GetGlobalFloat('Bullit') = 1) then
    return true;
  end if;

  if not XLPL.CheckRole(56) then
    return false;
  else
    XLPL.ReplaceRole('Child');
  end if;

  BthDate := A_F_RelProtBirthDay();
  StartDate := BthDate;

  if B_F_MetricWithOutDate(155) then
    w_StartDate := B_F_MetricWithOutStart(155);
	P_StartDate := B_F_MetricWithOutEnd(155);

	if (not (w_StartDate is null)) and (not (p_StartDate is null)) and
	   (w_StartDate <= BthDate) and (p_StartDate >= BthDate) then
	  StartDate := p_StartDate;
	  if (A_F_DataTalk() < StartDate) and (A_F_DataTalk() >= BthDate) then
	    XLPL.RestoreRole;
	    return False;
	  end if;
    end if;

	if (w_StartDate is null) and (not (p_StartDate is null)) and
	   (p_StartDate >= BthDate) then
	  StartDate := p_StartDate;
	  if (A_F_DataTalk() < StartDate) and (A_F_DataTalk() >= BthDate) then
	    XLPL.RestoreRole;
	    return False;
	  end if;
    end if;
  end if;

  if B_F_SPISALLOCCODE1() and not B_F_MetricWithOutDate(155) then
	StartDate := BthDate + trunc(S_const(451, XLPL.WorkDate)) + 1;
	if (A_F_DataTalk() < StartDate) and (A_F_DataTalk() >= BthDate) then
	  XLPL.RestoreRole;
	  return False;
    end if;
  end if;

  XLPL.RestoreRole;
  return True;
end;
/
