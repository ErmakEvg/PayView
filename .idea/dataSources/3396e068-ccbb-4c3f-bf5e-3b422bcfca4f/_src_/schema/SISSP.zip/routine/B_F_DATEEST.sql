CREATE FUNCTION       B_F_DATEEST( aCID in varchar2, PuskDate in date) RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: F_DATEEST
+ Наименование: Получить массив дат предполагаемых завершений действия всех
+ 				назначений дела
+ Автор: Трухтанов
+ Состояние на дату 12.12.2000
==============================================================================*/

A DBMS_SQL.NUMBER_TABLE;
DateTalk date;
dt date;


BEGIN
  A.delete;
  DateTalk := Last_Day(S_CurrDate);

  for REC in ( select nvl(Estimation_Date, null) dt from W$ALLOC_DATE_ESTIMATION
	 	  	  	 	  where CID = aCID and
			  		 		  STAGE in (1, 4) and
			  		 		  ENTERED_BY = XLPL.User_Id
	 	  	 		)
  LOOP
    if (REC.dt != null) AND (dt <= DateTalk) AND (dt > PuskDate) then
	  A(A.Count+1) := s_julian(dt);
	end if;
  end loop;

return A;

END B_F_DATEEST;
/
