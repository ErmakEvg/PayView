CREATE FUNCTION       A_F_Isinternat(Base_Id IN NUMBER,pStep_Start IN DATE,
                                                 pPid IN NUMBER) RETURN BOOLEAN IS
/*******************************************************************************
 NAME         : A_F_Isinternat
 Назначение   : Функция возвращает признак нахождения в ДИ (отсутствие меньше месяца)
 Автор        : ОЛВ
 Дата         : 26.08.2018
 Код возврата : признак нахождения в ДИ (отсутствие меньше месяца)
********************************************************************************/
 vsMONTHS         NUMBER;
BEGIN
 begin
   IF Base_Id=0 THEN
     SELECT MONTHS_BETWEEN(nvl(period_end,pStep_Start), nvl(period_start,pStep_Start))
       INTO vsMONTHS
       FROM W$ABSENCE_PERSON
      where pid=pPid
        and (pStep_Start between nvl(period_start,pStep_Start) and nvl(period_end,pStep_Start))
        and ENTERED_BY=XLPL.USER_ID
        and stage in (1,4);
   ELSE
     SELECT MONTHS_BETWEEN(nvl(period_end,pStep_Start), nvl(period_start,pStep_Start))
       INTO vsMONTHS
       FROM ABSENCE_PERSON
      where pid=pPid
        and (pStep_Start between nvl(period_start,pStep_Start) and nvl(period_end,pStep_Start))
        and stage is null;
   END IF;
 exception
      when OTHERS then -- могут быть две строки ?
        vsMONTHS:=0;
 end;

   IF vsMONTHS<1 THEN -- отсутствие меньше месяца
      RETURN TRUE;
   ELSE
      RETURN FALSE;
   END IF;
END A_F_Isinternat;
/
