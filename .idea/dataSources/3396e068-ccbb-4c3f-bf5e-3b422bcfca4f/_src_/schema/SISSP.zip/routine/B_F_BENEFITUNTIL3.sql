CREATE FUNCTION       B_F_BenefitUntil3 (aCode IN NUMBER, bufDate IN DATE) RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_BenefitUntil3
// Наименование: Проверка на наличие у лица пособий по уходу за детьми до 3 лет
// Автор: Гуз Е.
// Состояние на дату 01.02.1999
// Код возврата: True - имеет право, False - не имеет право
//***************************************************************************************/

  aCount NUMBER;
BEGIN
  select count(*) INTO aCount from ALLOCATION a, ALLOCATION_PERSON b, CASE_PERSON c, RECIPIENT d
  where a.RID = b.ALLOCATION_RID
    and b.PID = XLPL.GetPid
	and c.PID = b.PID
	and d.CID = c.CID
	and d.PID = b.PID
	and (c.STAGE <> 3 or c.STAGE is NULL)
	and (a.STAGE <> 3 or a.STAGE is NULL)
	and (b.STAGE <> 3 or b.STAGE is NULL)
	and (d.STAGE <> 3 or d.STAGE is NULL)
	and a.ALLOC_CODE in (select CODE from ALLOCATIONS start with CODE = aCode connect by prior CODE = PARENT_CODE)
	and a.ALLOCATION_START <= bufDate
	and a.ALLOCATION_END is null
    and a.ALLOC_STATUS=1 --13.04.2017 Речицкая А. В.
	and (a.STEP_END is null or a.STEP_END >= bufDate);
  RETURN aCount != 0;
END B_F_BenefitUntil3;
/
