CREATE FUNCTION       A_P_SIZEMAXBUDJET RETURN NUMBER IS
/******************************************************************************
   NAME         : A_P_SIZEMAXBUDJET
   Назначение   : Функция исчисления соц пенсии из наибольшей величины
                  бюджета прожиточного минимума в среднем на душу населения
				  за два последних квартала
   Дата         : 04.12.2008
******************************************************************************/
Max_Size NUMBER;
BEGIN
    -- Min_Size:=S_VRound_Sum((S_Const(18,XLPL.WorkDate)*S_CONST(19,XLPL.WorkDate)/100),1); */
    -- Max_Size:=S_VRound_Sum(S_Const_20081202(516,XLPL.WorkDate),1);
   Max_Size:=S_VRound_Sum(S_Const_20080701(18,XLPL.WorkDate),1);
    --RAISE_APPLICATION_ERROR(-20801,'Min_Size:'||to_char(Min_Size));
   RETURN Max_Size;
END A_P_SIZEMAXBUDJET;
/
