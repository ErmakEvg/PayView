CREATE FUNCTION       B_F_ARRAYDATEESTAGE18 RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_F_ARRAYDATEESTAGE3
 Наименование       : Функция возвращает массив с датой наступления 3 лет для Estimation
 Автор              : Ворошилин В.          Комментарии и коректировка: ОЛВ
 Состояние на дату  : 03.05.2000                                       25.09.2013
 Код возврата       : массив с датой наступления 3 лет для Estimation
***********************************************************************************************/
 result_array   DBMS_SQL.NUMBER_TABLE;
 Birth_Date     DATE;
 New_Date       DATE;
 Age            NUMBER;
BEGIN
    result_array.Delete;
    Birth_Date:=A_F_RelProtBirthDay;
    Age:=S_CONST(404, XLPL.WorkDate);
    -- Дата наступления 18 лет с учетом високосного года
    New_Date:=B_AddMonths(Birth_Date, TRUNC(Age)*12) + S_YearVisokosny(Birth_Date);
  if New_Date >  Last_Day(S_CurrDate) then
    result_array(result_array.count+1) := S_Julian(New_Date);
    result_array(result_array.count+1) := 100;
    result_array(result_array.count+1) := 2;
  end if; --25.09.2013 ОЛВ

  return result_array;
END B_F_ARRAYDATEESTAGE18;
/
