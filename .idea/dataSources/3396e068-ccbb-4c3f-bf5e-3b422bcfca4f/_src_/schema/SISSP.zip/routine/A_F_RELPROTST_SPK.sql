CREATE FUNCTION       A_F_Relprotst_Spk(rAlloc_Code IN NUMBER)  RETURN NUMBER IS
/***************************************************************************************
 Функция                : A_F_Relprotst_SPK
 Наименование       : Функция проверки права на пенсию по СПК
 Автор                    : OLV             на основ.:  Боровнева 01.02.1999
 Состояние на дату : 22.04.2009
 Код возврата         : число со стажем
***************************************************************************************/
  dateSt                      DATE;
  NSt                          NUMBER;
  Rec                          NUMBER;
  Check_Rec               BOOLEAN;

BEGIN
 /* --------------------------------------------------------------------------------------------------------------------------
                             Проверка права  на назначение у кормильца
-----------------------------------------------------------------------------------------------------------------------------*/
/*  *
     Для rAlloc_Code=191 , 192, 193, 197
  проверяем являлся ли кормилец получателем пенсии до 01.09.1998 г. если да,
  то наличие страхового стажа не требуется
    A_P_Startmetric_659- Определение даты начала действия характеристики "Пенсионер":
  если между датой окончания действия характеристики "Пенсионер" и датой
  возникновения права на пенсию по СПК прошло более 5 лет,то возвращается дата
  возникновения права на пенсию по СПК, иначе - дата начала действия характеристики "Пенсионер"
     A_P_Start_Pension -   определение даты начала получения пенсии лицом
   получал другую пенсию кроме выплаты alloc_code = 40
/* */

      NSt:=-1;

  CASE
    WHEN rAlloc_Code=191 THEN -- причина смерти  вследсвие трудового увечья
               IF (A_F_Relprotdeathreason() = 1) THEN
                  Check_Rec := TRUE;
                 IF ( Xlpl.CONVER_T <> 1)  AND (A_F_Datatalk() >= S_Encodedate(1998,9,1))  AND  (A_F_Relprotrecord(17)<= 0) THEN
                   Check_Rec := FALSE;
                 END IF;

                 IF NOT Check_Rec  AND ((A_P_Start_Pension() IS NOT NULL  AND A_P_Start_Pension() < S_Encodedate(1998,9,1))
                      OR  (A_P_Startmetric_659() IS NOT NULL AND A_P_Startmetric_659() < S_Encodedate(1998,9,1))) THEN
                         Check_Rec := TRUE;
                 END IF;

                IF ( A_F_Relprotrecord(1)>0  AND Check_Rec) OR
                 ( (Xlpl.CONVER_T = 1)  AND (A_F_Allocstartconvert() < S_Encodedate(1998,9,1))) THEN
                     NSt:=0;
                END IF;

              END IF;

    WHEN rAlloc_Code=192 THEN -- причина смерти вследствие общего заболевания
               IF (A_F_Relprotdeathreason = 2) THEN
                     NSt:=0;
--RAISE_APPLICATION_ERROR(-20004,'NSt=' ||NSt );
                 IF A_F_Relprotdeathdate = NULL THEN
                    dateSt := A_F_Relprotmetricstart(180); -- возвращает дату нвчала действия Признан(а) безвестно отсутствующим(ей)
                 ELSE
                   dateSt  := A_F_Relprotdeathdate;
                 END IF;
                   NSt := P_Calc_Nst_Inv(TRUNC(S_Yearsbetween(dateSt , A_F_Relprotbirthday)));   -- необходимый общий стаж
--RAISE_APPLICATION_ERROR(-20004,'NSt2=' ||NSt );
                     Check_Rec := TRUE;
					 /* */
                IF (A_F_Datatalk >= S_Encodedate(1998, 9, 1))  AND (A_F_Relprotrecord(17) <= 0) AND (A_P_Startmetric_659 = NULL) AND (A_P_Start_Pension = NULL) THEN
                  Check_Rec := FALSE;
               /* *
			    IF (A_F_Datatalk >= S_Encodedate(1998, 9, 1)) then

				 if (A_F_Relprotrecord(17) <= 0) then
				 RAISE_APPLICATION_ERROR(-20004,'NSt2=' ||NSt );
				  if (A_P_Startmetric_659 = NULL) AND (A_P_Start_Pension = NULL) THEN

                  Check_Rec := FALSE;
				  end if;
				 end if; /* */
                ELSE
                   IF (A_P_Startmetric_659 IS NOT NULL) OR (A_P_Start_Pension IS NOT NULL) THEN
                      NSt := P_Nrecord_Spk;
	                 IF NSt = 0 THEN
	                   Check_Rec := FALSE;
	                 ELSE
	                   Check_Rec := TRUE;
	                 END IF;
	               END IF;
                END IF;
--RAISE_APPLICATION_ERROR(-20004,'NSt4=' ||NSt );
                IF ( A_F_Relprotrecord(1)>0)  AND Check_Rec  THEN
                 IF A_F_Relprotrecord(1) < NSt THEN
	              Xlpl.PARTIAL_RECORD := 1;
	             END IF;
                ELSE
                   NSt:=-1;
                END IF;

              END IF;


     WHEN rAlloc_Code=193 THEN -- причина смерти вследствие катастрофы на ЧАЭС
               IF ((A_F_Relprotdeathreason = 3) OR (A_F_Relprotdeathreason = 9)) THEN -- вследствие ЧАЭС
                     NSt:=0;

                IF A_F_Relprotdeathdate = NULL THEN
                    dateSt := A_F_Relprotmetricstart(180); -- возвращает дату нвчала действия Признан(а) безвестно отсутствующим(ей)
                 ELSE
                   dateSt  := A_F_Relprotdeathdate;
                 END IF;
                   NSt := P_Calc_Nst_Inv(TRUNC(S_Yearsbetween(dateSt , A_F_Relprotbirthday)));   -- необходимый общий стаж

                  Check_Rec := TRUE;
                IF (A_F_Datatalk >= S_Encodedate(1998, 9, 1))  AND (A_F_Relprotrecord(17) <= 0) AND (A_F_Relprotmetricstart(659) = NULL) AND (A_P_Start_Pension = NULL) THEN
                  Check_Rec := FALSE;
                ELSE
                   IF (A_P_Startmetric_659 IS NOT NULL) OR (A_P_Start_Pension IS NOT NULL) THEN
                      NSt := P_Nrecord_Spk;
	                 IF NSt = 0 THEN
	                   Check_Rec := FALSE;
	                 ELSE
	                   Check_Rec := TRUE;
	                 END IF;
	               END IF;
                END IF;

                IF ( A_F_Relprotrecord(1)>0)  AND Check_Rec  THEN
                 IF A_F_Relprotrecord(1) < NSt THEN
	              Xlpl.PARTIAL_RECORD := 1;
	             END IF;
                ELSE
                   NSt:=-1;
                END IF;

               END IF;

    WHEN rAlloc_Code=194 THEN --     по закону о военнослужащих
               IF A_F_Relprotdisabilityreason(1,'11,12,13','7,8,9,16,17') OR (A_F_Relprotdeathreason = 4) OR (A_F_Relprotdeathreason = 5) OR
	              (A_F_Relprotdeathreason = 6) OR (A_F_Relprotdeathreason = 7) THEN
                      NSt:=0;
               END IF;

    WHEN rAlloc_Code=195 THEN --    по закону о военнослужащих
               IF A_F_Relprotdisabilityreason(1,'11,12,13','7,8,9,16,17') OR (A_F_Relprotdeathreason = 4) OR (A_F_Relprotdeathreason = 5) OR
	              (A_F_Relprotdeathreason = 6) OR (A_F_Relprotdeathreason = 7) THEN
                     NSt:=0;
               END IF;

    WHEN rAlloc_Code=196 THEN --     по закону о военнослужащих
               --определениe окончания периода прохождения военной службы
               IF P_Periodend_Vsl() IS NOT NULL  AND  ADD_MONTHS(P_Periodend_Vsl(),3) >= A_F_Relprotdeathdate AND
                  A_F_Relprotdeathreason() = 8  THEN
                      NSt:=0;
               END IF;

    WHEN rAlloc_Code=197 THEN    --     на общих условиях  (умершего всл. катаст. на ЧАЭС)
               IF (A_F_Relprotdeathreason = 3)  THEN
                     NSt:=0;

                 IF A_F_Relprotdeathdate = NULL THEN
                    dateSt := A_F_Relprotmetricstart(180); -- возвращает дату нвчала действия Признан(а) безвестно отсутствующим(ей)
                 ELSE
                   dateSt  := A_F_Relprotdeathdate;
                 END IF;
                   NSt := P_Calc_Nst_Inv(TRUNC(S_Yearsbetween(dateSt , A_F_Relprotbirthday)));   -- необходимый общий стаж

                  Check_Rec := TRUE;
                IF (A_F_Datatalk >= S_Encodedate(1998, 9, 1))  AND (A_F_Relprotrecord(17) <= 0) AND (A_F_Relprotmetricstart(659) = NULL) AND (A_P_Start_Pension = NULL) THEN
                  Check_Rec := FALSE;
                ELSE
                   IF (A_P_Startmetric_659 IS NOT NULL) OR (A_P_Start_Pension IS NOT NULL) THEN
                      NSt := P_Nrecord_Spk;
	                 IF NSt = 0 THEN
	                   Check_Rec := FALSE;
	                 ELSE
	                   Check_Rec := TRUE;
	                 END IF;
	               END IF;
                END IF;

                IF ( A_F_Relprotrecord(1)>0)  AND Check_Rec  THEN
                 IF A_F_Relprotrecord(1) < NSt THEN
	              Xlpl.PARTIAL_RECORD := 1;
	             END IF;
                ELSE
                   NSt:=-1;
                END IF;

             END IF;

    WHEN rAlloc_Code=198 THEN --   семье погибшего в/c (умершего вследствие катастрофы на ЧАЭС)
               IF A_F_Relprotdisabilityreason(1,'11,12,13','7,8,9,16,17') AND (A_F_Relprotdeathreason = 9) THEN
                     NSt:=0;
               END IF;

     WHEN rAlloc_Code=208 THEN --   социальная пенсия
                     NSt:=0;

    WHEN rAlloc_Code=370 THEN --    (умершего вследствие катастрофы на ЧАЭС)
               IF  (A_F_Relprotdeathreason = 3) OR (A_F_Relprotdeathreason = 9) THEN
                      NSt:=0;
              END IF;

END CASE;

  RETURN NSt;

END A_F_Relprotst_Spk;
/
