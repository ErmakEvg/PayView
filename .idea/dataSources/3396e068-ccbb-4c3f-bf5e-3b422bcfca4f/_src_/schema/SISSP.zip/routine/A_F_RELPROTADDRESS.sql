CREATE FUNCTION       A_F_RelProtAddress(pADDRESS_TYPE in NUMBER,pSITE in NUMBER) RETURN BOOLEAN IS
/***************************************************************************************
 NAME              : A_F_RelProtAddress
 Наименование      : Функция возвращает TRUE, если пенсионер проживает по указанному коду
 Автор             : ОЛВ
 Состояние на дату : 10.05.2011
 Код возврата      : TRUE или FALSE
***************************************************************************************/
 vsDRID     NUMBER;
 vsSite     NUMBER;
BEGIN
-- pADDRESS_TYPE - ТИП АДРЕСА; АДРЕС ПРОПИСКИ И/ИЛИ АДР. ПРОЖИВ. (1 - РЕГИСТР., 2 - ПРОЖИВ., 3 - ТО И  ДР.)
-- pSITE         - НАСЕЛЁННЫЙ ПУНКТ; СПРАВОЧНИК STATE_DIVISION

   -- Выбрать адрес в ОБД RID из ADDRESS
     vsDRID:=A_F_RelProtGetRIDAddress(1,pADDRESS_TYPE);
 if vsDRID<>-1 then
      begin
         select SITE
		   into vsSITE
		   from ADDRESS
		  where RID=vsDRID
		    and ADDRESS_TYPE= pADDRESS_TYPE
			and SITE = pSITE;
      exception
         when NO_DATA_FOUND then
            vsSITE:=0;
      end;
 else
      -- Выбрать адрес в РБД RID из W$ADDRESS
        vsDRID:=A_F_RelProtGetRIDAddress(0,pADDRESS_TYPE);
    if vsDRID<>-1 then
      begin
         select SITE
		   into vsSITE
		   from W$ADDRESS
		  where RID=vsDRID
		    and ADDRESS_TYPE= pADDRESS_TYPE
			and SITE = pSITE;
      exception
         when NO_DATA_FOUND then
            vsSITE:=0;
           -- RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtAddress 0 xlpl.GetPid=' || xlpl.GetPid ||'  vsDRID='||vsDRID );
      end;
    else
       vsSITE:=0;
	end if;
 end if;

 if vsSITE=0 then
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtAddress 1 xlpl.GetPid=' || xlpl.GetPid ||'  vsDRID='||vsDRID );
      RETURN FALSE;
 else
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtAddress 2 xlpl.GetPid=' || xlpl.GetPid ||'  vsDRID='||vsDRID );
      RETURN TRUE;
 end if;
END A_F_RelProtAddress;
/
