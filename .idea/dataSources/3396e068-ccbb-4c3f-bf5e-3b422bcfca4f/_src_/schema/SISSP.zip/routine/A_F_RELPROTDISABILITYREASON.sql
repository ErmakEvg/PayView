CREATE FUNCTION       A_F_RelProtDisabilityReason(aOPINION_TYPE in number,
                                                       aADVICE_TYPE  in VarChar2,
                                                       aDIS_REASON   in VarChar2) RETURN Boolean IS
/***************************************************************************************
 Функция           :  A_F_RelProtDisabilityReason
 Наименование      :  Проверка наличия у пенсионера указанной причины инвалидности по коду
                        согласно W$RELATION_PROTOCOL
 Автор             :  Вахромин        Комментарии и корректировка: ОЛВ
 Состояние на дату :                                       12.07.2010   12.07.2014
 Код возврата      :  возвращает True, если у человека есть указанная причина инвалидности
***************************************************************************************/
 DRIDS          DBMS_SQL.NUMBER_TABLE;
 xADVICE_TYPE   DBMS_SQL.NUMBER_TABLE;
 xDIS_REASON    DBMS_SQL.NUMBER_TABLE;
 vsDRID         NUMBER;
 vsADVICE_TYPE  NUMBER;
 vsDIS_REASON   NUMBER;
BEGIN

 /* * Параметры :
 - XLPL.WorkDate     - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
 - AOPINION_TYPE     - ТИП ЗАКЛЮЧЕНИЯ МРЭК/ВКК; КОД ВЕРХНЕГО УРОВНЯ
   ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION - 1 - инвалидность (при -1 - игнорируется)
 - при AADVICE_TYPE  - КОД РЕКОМЕНДАЦИИ; КОД НИЖНЕГО УРОВНЯ
   ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION -- 11, 12, 13 = "" игнорируется, иначе - список параметров * */

 -- Группа инвалидности -- 11, 12, 13
 xADVICE_TYPE:=S_ParseFloatArray(AADVICE_TYPE);       -- код группы инв.
   if (ADIS_REASON='') then  -- причина инв.
     null;
   end if;
 -- Причина инвалидности REF_DISABILITY_REASON
 xDis_REASON:=S_ParseFloatArray(ADIS_REASON);         -- причина инв.

 -- RID из W$RELATION_PROTOCOL для MRAK_OPINION_ADVICE
 --=======================================================
 DRIDS:=A_F_RelProtGetRIDMrakOpAdvice(1,AOPINION_TYPE); -- 1 - инв-ть   -- OLV 12.07.2010
  -- DRIDS:=A_F_RelProtGetRIDMrakOpAdvice(XLPL.BASE_ID,AOPINION_TYPE);  -- OLV 12.07.2010 при мас.расч. =2 - не видит ОБД

 if DRIDS.count<>0 then
    -- DATA_RID из MRAK_OPINION_ADVICE
    ------------------------------------------------------
    for i in 1..DRIDS.count loop
         vsDRID:=DRIDS(i);
       BEGIN
            select ADVICE_TYPE, DIS_REASON
              into vsADVICE_TYPE, vsDIS_REASON
              from MRAK_OPINION_ADVICE a, MRAK_OPINION b
             where a.RID=vsDRID
               and b.RID=MRAK_RID
               and NVL (b.RECORD_END,XLPL.WorkDate) >= XLPL.WorkDate -- OLV 12.07.2014
               and NVL(NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate)<=XLPL.WorkDate
               and NVL(NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate)>=XLPL.WorkDate;

            if xADVICE_TYPE.count=0 then -- не заданы коды нижнего уровня
               -- Причина инвалидности REF_DISABILITY_REASON
               for l in 1..xDIS_REASON.count loop
                  if xDIS_REASON(l)=vsDIS_REASON then
                     return true;
                  end if;
               end loop;
            else
               -- КОД РЕКОМЕНДАЦИИ; КОД НИЖНЕГО УРОВНЯ ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION -- 11, 12, 13
               for m in 1..xADVICE_TYPE.count loop
                  -- Причина инвалидности REF_DISABILITY_REASON
                  for l in 1..xDIS_REASON.count loop
                     if (xDIS_REASON(l)=vsDIS_REASON)and(xADVICE_TYPE(m)=vsADVICE_TYPE) then
                        return true;
                     end if;
                  end loop;
               end loop;
            end if;
       EXCEPTION
          WHEN No_Data_Found THEN null;
       END;
    end loop;
 end if;

 -- RID из W$RELATION_PROTOCOL для w$MRAK_OPINION_ADVICE
 --=======================================================
 DRIDS:=A_F_RelProtGetRIDMrakOpAdvice(0,AOPINION_TYPE);
--
--if xlpl.getpid=7090003770 then
--RAISE_APPLICATION_ERROR(-20004,' A_F_RelProtDisabilityReason  DRIDS.count='||DRIDS.count);
--end if;
 if DRIDS.count<>0 then
    -- DATA_RID из W$MRAK_OPINION_ADVICE
    ------------------------------------------------------
    for i in 1..DRIDS.count loop
         vsDRID:=DRIDS(i);
       BEGIN
            select ADVICE_TYPE, DIS_REASON
              into vsADVICE_TYPE, vsDIS_REASON
              from w$MRAK_OPINION_ADVICE a, w$MRAK_OPINION b
             where a.RID=vsDRID
               and b.RID=MRAK_RID
               and a.ENTERED_BY=XLPL.USER_ID
               and b.ENTERED_BY=MRAK_ENTERED_BY
               and NVL (b.RECORD_END,XLPL.WorkDate) >= XLPL.WorkDate -- OLV 12.07.2014
               and NVL(NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate)<=XLPL.WorkDate
               and NVL(NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate)>=XLPL.WorkDate;

           if xADVICE_TYPE.count=0 then -- не заданы коды нижнего уровня
               -- Причина инвалидности REF_DISABILITY_REASON
               for l in 1..xDIS_REASON.count loop
                  if xDIS_REASON(l)=vsDIS_REASON then
                     return true;
                  end if;
               end loop;
            else
               -- КОД РЕКОМЕНДАЦИИ; КОД НИЖНЕГО УРОВНЯ ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION -- 11, 12, 13
               for m in 1..xADVICE_TYPE.count loop
                  -- Причина инвалидности REF_DISABILITY_REASON
                  for l in 1..xDIS_REASON.count loop
                     if (xDIS_REASON(l)=vsDIS_REASON)and(xADVICE_TYPE(m)=vsADVICE_TYPE) then
                      return true;
                     end if;
                  end loop;
               end loop;
            end if;

       EXCEPTION
          WHEN No_Data_Found THEN null;
       END;
    end loop;
  end if;
--RAISE_APPLICATION_ERROR(-20004,' A_F_RelProtDisabilityReason  DRIDS.count='||DRIDS.count);
 return false;
END A_F_RelProtDisabilityReason;
/
