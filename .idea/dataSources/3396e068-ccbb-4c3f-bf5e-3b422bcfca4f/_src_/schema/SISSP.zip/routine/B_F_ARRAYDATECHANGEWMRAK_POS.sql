CREATE FUNCTION       B_F_Arraydatechangewmrak_Pos(
AStartDate IN DATE, AOPINION_TYPE IN NUMBER, AADVICE_TYPE IN NUMBER, Param6m IN NUMBER) RETURN DBMS_SQL.NUMBER_TABLE IS
/**********************************************************************************************
 Функция            : B_F_ARRAYDATECHANGEWMRAK
 Наименование       : функция определяет шаги назначения по изменнениям
 Автор              : Трухтанов              Комментарии и корректировка: ОЛВ
 Состояние на дату  : 18.05.1999             03.08.2012            06/06/2014   31/08/2016 Речицкая АВ
 Код возврата       : массив шагов дат
***********************************************************************************************/
 xDATES          DBMS_SQL.NUMBER_TABLE;
 worrdata        DATE;
 vsRECORD_START  DATE;
 vsRECORD_END      DATE;
 vsEXAMED_FROM      DATE;
 vsDIS_TERM      DATE;

 vsMin              DATE;
 vsMax              DATE;
 vsTalkDate      DATE;
 vsNullDate      DATE;

 vsAOPINION_TYPE VARCHAR2(20);
 vsAADVICE_TYPE  VARCHAR2(20);
 cnt              NUMBER;

BEGIN
  xDATES.DELETE;
  IF (AOPINION_TYPE = -1) THEN
     vsAOPINION_TYPE := NULL;
  ELSE
     vsAOPINION_TYPE := AOPINION_TYPE;
  END IF;

  IF (AADVICE_TYPE = -1) THEN
     vsAADVICE_TYPE := NULL;
  ELSE
     vsAADVICE_TYPE := AADVICE_TYPE;
  END IF;

  vsTalkDate := A_F_Datatalk();
  vsNullDate := NULL; -- A_F_CMinDate();

 IF (Param6m = 1) AND (Xlpl.AID = 0) THEN -- Param6m = 1 - признак превышения 6 месяцев
     SELECT COUNT(*)
       INTO cnt
       FROM W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
      WHERE a.PID = Xlpl.GETPID
        AND a.ENTERED_BY = Xlpl.USER_ID
        AND a.STAGE NOT IN (2,3)
        AND b.RID = MRAK_RID
        AND b.ENTERED_BY = MRAK_ENTERED_BY
        AND NVL(NVL(a.RECORD_START, b.EXAMED_FROM), vsTalkDate) <= vsTalkDate
        AND NVL(NVL(a.RECORD_END,a.DIS_TERM), vsTalkDate) >= vsTalkDate
        AND OPINION_TYPE = NVL (vsAOPINION_TYPE, OPINION_TYPE)
        AND ((ADVICE_TYPE = NVL (vsAADVICE_TYPE, ADVICE_TYPE)) OR
                 (ADVICE_TYPE IS NULL AND vsAADVICE_TYPE IS NULL));
    IF cnt > 0 THEN
      SELECT LAST_DAY(ADD_MONTHS(vsTalkDate,1)-1) INTO worrdata FROM dual;
      xDATES(xDATES.COUNT+1) := S_Julian (worrdata);
    END IF;
     ELSE
     FOR REC IN (
          SELECT NVL(a.RECORD_START,vsNullDate) AS a1, NVL(a.RECORD_END,vsNullDate) AS a2,
                 NVL(b.EXAMED_FROM,vsNullDate) AS a3, NVL(a.DIS_TERM ,vsNullDate) AS a4
            FROM W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
           WHERE a.PID = Xlpl.GETPID
             AND a.STAGE NOT IN (2,3)
             AND a.ENTERED_BY = Xlpl.USER_ID
             AND b.RID = MRAK_RID
             AND b.ENTERED_BY = MRAK_ENTERED_BY
             AND ((NVL(NVL(a.RECORD_START, b.EXAMED_FROM), AStartDate) > AStartDate) OR
                  (NVL(NVL(a.RECORD_END,a.DIS_TERM), AStartDate) > AStartDate ))
             AND OPINION_TYPE = NVL (vsAOPINION_TYPE, OPINION_TYPE)
             AND ADVICE_TYPE = NVL (vsAADVICE_TYPE, ADVICE_TYPE)) LOOP

       -- информация для действующей группы инвалидности
       vsRECORD_START := REC.a1; -- ДАТА НАЧАЛА ДЕЙСТВИЯ ЗАПИСИ
       vsRECORD_END   := REC.a2; -- ДАТА ОКОНЧАНИЯ ДЕЙСТВИЯ ЗАПИСИ --Замечание: ??? не заполняется для действующей инв.--OLV 03.08.2012
       vsEXAMED_FROM  := REC.a3; -- ПРОХОДИЛ ОБСЛЕДОВАНИЕ С
       vsDIS_TERM     := REC.a4; -- ИНВАЛИДНОСТЬ НА СРОК

      IF (vsRECORD_START IS NULL) THEN
       --06/06/2014 Речицкая АВ --xDATES(xDATES.COUNT+1) := S_Julian (vsEXAMED_FROM);
        xDATES(xDATES.COUNT+1) := S_Julian (LAST_DAY(vsEXAMED_FROM))+1;--06/06/2014 Речицкая АВ по новому положению пункт 12 Положения № 569 от 28.06.2013
      ELSE

        if (Xlpl.AID = 0) then -- 31/08/2016 Речицкая АВ  Для нового назначения
        xDATES(xDATES.COUNT+1) := S_Julian (vsRECORD_START); -- 31/08/2016 Речицкая АВ
        else
         -- 06/06/2014 Речицкая АВ --xDATES(xDATES.COUNT+1) := S_Julian (vsRECORD_START);
        xDATES(xDATES.COUNT+1) := S_Julian (LAST_DAY(vsRECORD_START)+1); --06/06/2014 Речицкая АВ по новому положению пункт 12 Положения № 569 от 28.06.2013
        end if;
      END IF;

      IF (vsDIS_TERM IS NOT NULL) AND (vsRECORD_END IS NULL) THEN
        SELECT LAST_DAY(vsDIS_TERM) INTO vsDIS_TERM FROM dual;
        --OLV 03.08.2012  --xDATES(xDATES.Count+1) := S_JULIAN (vsDIS_TERM);
        xDATES(xDATES.COUNT+1) := S_Julian (vsDIS_TERM+1);  --OLV 03.08.2012
      END IF;
      IF (vsDIS_TERM IS NULL) AND (vsRECORD_END IS NOT NULL) THEN
        SELECT LAST_DAY(vsRECORD_END) INTO vsRECORD_END FROM dual;
        --OLV 03.08.2012  --xDATES(xDATES.Count+1) := S_JULIAN (vsRECORD_END);
        xDATES(xDATES.COUNT+1) := S_Julian (vsRECORD_END+1); --OLV 03.08.2012
      END IF;

      IF (vsDIS_TERM IS NOT NULL) AND (vsRECORD_END IS NOT NULL) THEN
        SELECT LAST_DAY(vsRECORD_END) INTO vsRECORD_END FROM dual;
        xDATES(xDATES.COUNT+1) := S_Julian (vsRECORD_END);
      END IF;
   END LOOP;
 END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATECHANGEWMRAK_POS 1111 '||vsRECORD_START ||'xDATES(1)='||S_Jtod(xDATES(2)));
RETURN xDATES;

END B_F_Arraydatechangewmrak_Pos;
/
