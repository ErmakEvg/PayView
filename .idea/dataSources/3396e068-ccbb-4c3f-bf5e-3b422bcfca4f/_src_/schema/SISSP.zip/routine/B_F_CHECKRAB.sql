CREATE FUNCTION       B_F_CheckRab (b in number ) RETURN BOOLEAN AS
-- -------------------------------------------------------
-- Проверка, была ли у лица в прошлом характеристика
-- "не получал пособие на ребенка по месту работы (учебы)"
-- Ворошилин
-- -------------------------------------------------------

new_WorkDate date;
old_WorkDate date;

bool boolean;
bool1 boolean;

BEGIN



if b = 0 and B_F_MetricWithOutDate(256) and not B_F_ActvCh then
   return true;
end if;

if b = 1 then
   XLPL.RoleDecl('Father','57, 69');
   XLPL.REPLACEROLE('Father');
   bool := B_F_MetricWithOutDate(256);
   bool1 := B_F_ActvCh;
   XLPL.RestoreRole;
   if bool and not bool1 then
 	  return true;
   end if;
end if;

return false;

END B_F_CheckRab;
/
