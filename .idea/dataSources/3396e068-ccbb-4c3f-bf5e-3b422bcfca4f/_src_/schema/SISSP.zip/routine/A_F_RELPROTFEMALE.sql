CREATE FUNCTION       A_F_RelProtFeMale RETURN Boolean IS
/*TRUE если PID муж. по W$RELATION_PROTOCOL
Вахромин О.Ю.*/
BEGIN
   return A_F_RelProtGender()=2;
END A_F_RelProtFeMale;
/
