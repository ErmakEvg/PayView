CREATE FUNCTION       adressUmershego(cid# VARCHAR2, entered_by# VARCHAR2) RETURN VARCHAR2 IS
text VARCHAR2(2000);
BEGIN
select distinct
oblast.value||' '||oblastr.value||' '||raion.value||' '||raionr.value||' '||derevnia.value ||' '||site.value  ||' '|| street.value||house.value ||house_x.value ||appt.value /*подзапросы возвращают символ пробела, если в базе пустая запись */
into text
from
(select nvl(( select sd.value
from
address ad,
case_person cp,
state_division sd
where
cp.cid =cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code = (select sd.parent_code
from
address ad,
case_person cp,
state_division d
where
cp.cid = cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code =  (select sd.parent_code
from
address ad,
case_person cp,
state_division sd
where
cp.cid = cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code =ad.site))),' ') value from dual) oblast,
(select nvl(( select rsd.catshortname
from
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
where
cp.cid = cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  rsd.code = sd.level_code
and  sd.code =  (select sd.parent_code
from
address ad,
case_person cp,
state_division sd
where
cp.cid = cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code = (select sd.parent_code
from
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
where
cp.cid =cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code =ad.site
and  rsd.code = sd.level_code))),' ') value from dual) oblastr,
(select nvl(( select sd.value
from
address ad,
case_person cp,
state_division sd
where
cp.cid =cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code =  (select sd.parent_code
from
address ad,
case_person cp,
state_division sd
where
cp.cid = cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code = ad.site)),' ') value from dual) raion,
(select nvl(( select rsd.catshortname
from
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
where
cp.cid =cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  rsd.code = sd.level_code
and  sd.code =  (select sd.parent_code
from
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
where
cp.cid = cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code =ad.site
and  rsd.code = sd.level_code)),' ') value from dual) raionr,
(select nvl(( select rsd.catshortname
from
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
where
cp.cid =cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code = ad.site
and  rsd.code = sd.level_code),' ') value from dual) derevnia,
(select nvl(( select sd.value
from
address ad,
case_person cp,
state_division sd
where
cp.cid = cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code = ad.site),' ') value from dual) site,
(select nvl(( select ' ул. '||sd.value
from
address ad,
case_person cp,
state_division sd
where
cp.cid = cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by =  cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code = ad.street),' ') value from dual) street,
(select nvl(( select ' д. '||ad.house
from
address ad,
case_person cp,
state_division sd
where
cp.cid =cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code = ad.site),' ') value from dual) house,
(select nvl(( select ' корп. '||ad.house_x
from
address ad,
case_person cp,
state_division sd
where
cp.cid = cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code = ad.site),' ') value from dual) house_x,
(select nvl(( select ' кв. '||ad.appt
from
address ad,
case_person cp,
state_division sd
where
cp.cid =cid#
and  cp.entered_by =  entered_by#
and  cp.role in(60)
and  ad.pid = cp.pid
and  ad.entered_by = cp.entered_by
and  ad.stage in(1,4)
and  ad.ADDRESS_TYPE in (2,3)
and  sd.code = ad.site),' ') value from dual) appt;
  RETURN TEXT;
END;
/
