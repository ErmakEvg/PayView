CREATE FUNCTION       A_F_RELPROTRATIO_TYPE RETURN NUMBER AS

/* --------------------------------------------------------------------
// Автор: Боровнева
// состояние на 1.03.2001
// Код возврата: возвращает тип ИНДИВИДУАЛЬНого КОЭФФИЦИЕНТа
//                            человека согласно W$RELATION_PROTOCOL из W$PERSON_EXTRA
//     Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
// --------------------------------------------------------------------*/

  vsDRID NUMBER;
  vsRATIO_Type NUMBER;
BEGIN
  vsRATIO_Type := -1;
  vsDRID := A_F_RELPROTGETRIDPERSONEXTRA(1);
  begin
    IF vsDRID <> -1 THEN
      select RATIO_BY INTO vsRATIO_Type from PERSON_EXTRA where RID = vsDRID;
    ELSE
      vsDRID := A_F_RELPROTGETRIDPERSONEXTRA(0);
      IF vsDRID <> -1 THEN
        select RATIO_BY INTO vsRATIO_Type from W$PERSON_EXTRA where RID = vsDRID and ENTERED_BY = XLPL.User_ID;
      END IF;
    END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      vsRATIO_Type := - 1;
    WHEN OTHERS THEN
      vsRATIO_Type := - 1;
  end;
  return vsRATIO_Type;
END A_F_RELPROTRATIO_TYPE;
/
