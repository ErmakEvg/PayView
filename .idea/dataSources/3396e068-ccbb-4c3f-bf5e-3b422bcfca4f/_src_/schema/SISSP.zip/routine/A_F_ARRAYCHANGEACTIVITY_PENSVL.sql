CREATE FUNCTION       A_F_ARRAYCHANGEACTIVITY_PENSVL (pLABOR IN BINARY_INTEGER, StartDate IN DATE) RETURN DBMS_SQL.NUMBER_TABLE AS

/***************************************************************************************
  Наименование: возвращает массив дат по периодам работ лица (для пенсий за выслугу лет)
***************************************************************************************/

  result_array DBMS_SQL.NUMBER_TABLE;
  chahge_date_activity DBMS_SQL.NUMBER_TABLE;
  Prev_Period_End DATE;
  flg_insert_result BOOLEAN;
BEGIN
  result_array.delete;
  chahge_date_activity.delete;
  begin
    for PENSVL in (select nvl(PERIOD_START, NULL) as activity_start,
	                      nvl(PERIOD_END, NULL) as activity_end
			       from w$ACTIVITY
				   where PID = XLPL.GetPid
			         and LABOR = pLabor
			  		 and (PERIOD_START >= StartDate or PERIOD_END >= StartDate)
			  		 and STAGE in (1,4,6)
			  		 and ENTERED_BY = XLPL.User_ID
			       order by (PERIOD_START))
	loop
     if (PENSVL.activity_start >= StartDate) and (PENSVL.activity_start is not NULL) then
       if PENSVL.activity_start is not NULL then
         chahge_date_activity(chahge_date_activity.count +1) := S_Julian(PENSVL.activity_start);
       else
         chahge_date_activity.delete(chahge_date_activity.count);
       end if;
     end if;
     if PENSVL.activity_end is not NULL then
       chahge_date_activity(chahge_date_activity.count +1) := S_Julian(PENSVL.activity_end + 1);
     end if;
     Prev_Period_End := PENSVL.activity_end;
	end loop;
	exception
	  when NO_DATA_FOUND then
	    return result_array;
  end;
  for j in 1..chahge_date_activity.count loop
    flg_insert_result := true;
	for i in 1..result_array.count loop
	  if chahge_date_activity(j) = result_array(i) then
	    flg_insert_result := false;
	  end if;
	end loop;
	if flg_insert_result then
	  result_array(result_array.count + 1) := chahge_date_activity(j);
	end if;
  end loop;
  return result_array;
END A_F_ARRAYCHANGEACTIVITY_PENSVL;
/
