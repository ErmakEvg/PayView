CREATE FUNCTION       B_F_AddressDate RETURN DBMS_SQL.NUMBER_TABLE AS

/***************************************************************************************
// Функция: B_F_AddressDate
// Наименование: Функция определяет даты прописки и проживания
// Автор: Ворошилин В.
// Состояние на дату 24.07.2000
// Возвращает: массив, где первый член - дата начала, второй - дата конца
//***************************************************************************************/

  a DBMS_SQL.NUMBER_TABLE;
BEGIN
  a.Delete;
  for AddressDate in (SELECT nvl(RECORD_START, XLPL.WorkDate) as ACTSTART, nvl(RECORD_END, XLPL.WorkDate) as ACTEND
                      FROM W$ADDRESS
				      WHERE PID = XLPL.GetPid
				        AND STAGE IN (1, 4)
					    AND ENTERED_BY = XLPL.User_ID)
  LOOP
	a(a.count+1) := S_Julian(AddressDate.ACTSTART);
	a(a.count+1) := S_Julian(AddressDate.ACTEND);
  end LOOP;
  RETURN a;
END B_F_AddressDate;
/
