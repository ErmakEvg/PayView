CREATE FUNCTION       A_F_RELPROTDISREASONEND(AOPINION_TYPE number,
                AADVICE_TYPE varchar2, ADIS_REASON varchar2)  RETURN BOOLEAN IS
/*******************************************************************************
 Функция             :  A_F_RELPROTDISREASONEND
 Наименование        :  Ф-я проверяет есть ли у человека дата окончания инвалидности
 Автор               :  Трухтанов            Комментарии и корректировка: ОЛВ
 Состояние на дату   :  01.06.1999             16.11.2016
 Код возврата        :  возвращает True, если у человека есть дата окончания инвалидности
                        по указанной причине  по коду согласно W$RELATION_PROTOCOL
********************************************************************************/
 vsDRID        number;
 DRIDS        DBMS_SQL.NUMBER_TABLE;
 xADVICE_TYPE DBMS_SQL.NUMBER_TABLE;
 xDIS_REASON  DBMS_SQL.NUMBER_TABLE;

BEGIN
 -- Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
 -- AOPINION_TYPE - одно значение (при -1 - игнорируется)
 -- при AADVICE_TYPE = "" будет игнорироваться, иначе интерпритируется как список параметров
  if (ADIS_REASON = '')
    then return false;
  end if;
  xADVICE_TYPE := S_ParseFloatArray (AADVICE_TYPE);
  xDis_REASON := S_ParseFloatArray (ADIS_REASON);

  DRIDS := A_F_RelProtGetRIDMrakOpAdvice (1, AOPINION_TYPE);
  if DRIDS.count <> 0
  then
    for i in DRIDS.first .. DRIDS.last
    LOOP
      if DRIDS.exists(i)
      then
        vsDRID := DRIDS(i);
        -- vsADVICE_TYPE, vsDIS_REASON, vsDIS_TERM
        for c1 IN(
          select ADVICE_TYPE as vsADVICE_TYPE,
                 DIS_REASON as vsDIS_REASON,
                 NVL(NVL(a.RECORD_END,a.DIS_TERM), NULL) as vsDIS_TERM
             from MRAK_OPINION_ADVICE a, MRAK_OPINION b
             where
                 a.RID = vsDRID and
                 b.RID = MRAK_RID and
                 NVL (NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate--)
                 and NVL(NVL(a.RECORD_END,  b.RECORD_END) ,XLPL.WorkDate) >= XLPL.WorkDate) -- 16.11.2016 OLV
        LOOP
           if c1.vsDIS_TERM is not null
          then
              if xADVICE_TYPE.count = 0 -- не заданы коды нижнего уровня
            then
              for l in xDIS_REASON.first .. xDIS_REASON.last
              LOOP
              if xDIS_REASON.exists(l)
              then
                if xDIS_REASON(l) = c1.vsDIS_REASON
                then return true;
                  else
                  for m in xADVICE_TYPE.first .. xADVICE_TYPE.last
                  LOOP
                    if xADVICE_TYPE.exists(m)
                    then
                        for l in xDIS_REASON.first .. xDIS_REASON.last
                      LOOP
                        if xDIS_REASON.exists(l)
                        then
                          if (xDIS_REASON(l) = c1.vsDIS_REASON) AND (xADVICE_TYPE(m) = c1.vsADVICE_TYPE)
                            then return true;
                          end if;
                        end if;
                      end loop;
                    end if;
                  end loop;
                end if;
              end if;
              end loop;
            end if;
          end if;
        end loop;
      end if;
    end loop;
  end if;

  DRIDS := A_F_RelProtGetRidMrakOpAdvice (0, AOPINION_TYPE);
  if (DRIDS.count = 0) then
    return false;
  end if;

  if DRIDS.count <> 0 then
    for i in DRIDS.first .. DRIDS.last
    LOOP
      if DRIDS.exists(i) then
        vsDRID := DRIDS(i);
         -- vsADVICE_TYPE, vsDIS_REASON, vsDIS_TERM
         for c2 IN(select ADVICE_TYPE as vsADVICE_TYPE,
                       DIS_REASON as vsDIS_REASON,
                       NVL(NVL(a.RECORD_END,a.DIS_TERM), null) as vsDIS_TERM
                      -- NVL(NVL(a.RECORD_END,b.RECORD_END), null) as vsDIS_TERM -- 16.11.2016 OLV
                   from W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
                  where a.RID = vsDRID
                  and a.ENTERED_BY = XLPL.USER_ID
                  and b.RID = MRAK_RID
                  and b.ENTERED_BY = MRAK_ENTERED_BY
                  and NVL(NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate
                  and NVL(NVL(a.RECORD_END,  b.RECORD_END) ,XLPL.WorkDate) >= XLPL.WorkDate) -- 16.11.2016 OLV
         LOOP
           if c2.vsDIS_TERM is not null then
              if xADVICE_TYPE.count = 0 then -- не заданы коды нижнего уровня
              for l in xDIS_REASON.first .. xDIS_REASON.last
              LOOP
                if xDIS_REASON.exists(l) then
                  if (xDIS_REASON(l) = c2.vsDIS_REASON) then
                      return true;
                    else
                     for m in xADVICE_TYPE.first .. xADVICE_TYPE.last
                     LOOP
                        if xADVICE_TYPE.exists(m) then
                            for l in xDIS_REASON.first .. xDIS_REASON.last
                           LOOP
                              if xDIS_REASON.exists(l) then
                                if (xDIS_REASON(l) = c2.vsDIS_REASON) AND (xADVICE_TYPE(m) = c2.vsADVICE_TYPE) then
                                  return true;
                                end if;
                              end if;
                           end loop;
                        end if;
                     end loop;
                  end if;
                end if;
              end loop;
            end if;
          end if;
        end loop;
      end if;
    end loop;
  end if;
/**if xlpl.getpid= 5050160384 then
RAISE_APPLICATION_ERROR(-20004,'A_F_RELPROTDISREASONEND 22222 c2.vsDIS_REASON.count=' || c2.vsDIS_REASON ||'  xDIS_REASON='||xDIS_REASON.count ||'  c2.vsDIS_TERMt='||c2.vsDIS_TERM);--
 end if;/**/
  return false;
END A_F_RELPROTDISREASONEND;
/
