CREATE FUNCTION       A_Caseupdate(pCID IN NUMBER, pPID IN NUMBER, pDate IN DATE)
   RETURN NUMBER IS
/***************************************************************************************
 Функция           :  A_CaseUpdate
 Наименование  :  Функция закрытия пенсионного дела при оформлении пособия на погребение
 Автор               :  Кондратюк Е.В.
 Состояние на дату 25.10.2010
 Код возврата    : Признак закрытого пенсионного дела
***************************************************************************************/
vCount NUMBER;
a NUMBER;
BEGIN
 UPDATE W$CASE_CHECKS SET CHECK_DATE=pDAte,CHECK_CODES='550,' WHERE CID=pCID;
 UPDATE W$CASE SET ROLE_GROUP=5 WHERE CID=pCID AND stage=4 ;
 UPDATE W$CASE_PERSON SET ROLE=60 WHERE PID=pPID AND stage=4;
 COMMIT;
 RETURN 1;
END A_Caseupdate;
/
