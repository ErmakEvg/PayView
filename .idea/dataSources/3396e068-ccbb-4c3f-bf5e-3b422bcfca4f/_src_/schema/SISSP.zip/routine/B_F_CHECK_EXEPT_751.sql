CREATE FUNCTION       B_F_CHECK_EXEPT_751(pCID in Number, pCode_Family in Number
                                                    ) RETURN BOOLEAN IS
/*******************************************************************************
 NAME           : B_F_CHECK_EXEPT_751
 Назначение     : Функция проверяет, имеет ли семья (гражданин) исключения для назначения
                :  ежемесячной ГАСП > чем на 6 месяцев (S_CONST(44)).
                :  Max=12
 Автор          : Абрамович М.В.
 Дата  создания : 01.07.2017(20)
 Дата редакт-ия :19.10.2017,27.08.2018(в семье два один-их)
 Код возврата   : True - семья (гражданин) имеет право на 12 месяев
*******************************************************************************/
--vMax_Months_EXEPT constant integer := 12;--кол-во месяцев по исключению
vCount_Metr Number;
err_num     Number;
err_msg     VARCHAR2(500);
aPID        Number;
vCNT_PERSON Number;
vMother     Number;
vFather     Number;
vPID_5800   Number;
vCNT18      Number;
vCNT70      Number; --,27.08.2018
begin
 --находим сколько персон в деле
 vCNT_PERSON:=0;
  begin
   SELECT COUNT (PID) INTO vCNT_PERSON
   FROM( SELECT distinct PID  FROM W$CASE_PERSON
         WHERE CID=pCID  AND STAGE NOT IN (2,3));
  exception
     when No_Data_Found then vCNT_PERSON:=0;
  end;
  if vCNT_PERSON<>0 then
    if vCNT_PERSON =1 then --обратился гражданин
     --проверяем гражданина на исключения
               -- проверить является он одиноким (237- 41 указ) исключения
          if (B_F_RelProtMetricBen('161,237') and --Одинокий (одинокая),Не имеет трудос. родств-ов, обязанных содержать по закону
             ((A_F_RelProtDisabilsoc(1, '11')) or (A_F_RelProtDisabilsoc(1, '12')) or (a_f_relprotage >=70))) --инв1 или 2 гр
              or
             (NVL(pCode_Family,0) =30) or ((NVL(pCode_Family,0) =32) and (a_f_relprotage >=70)) then --Одинокие инв 1 и 2 группы,Одинокие пенсионеры
           RETURN TRUE; --можно на 12 мес
          else
           RETURN FALSE; --нельзя на 12 мес
          end if;
    else --vCNT_PERSON>1 обратилась семья

            if pCode_Family is not Null then
             --,27.08.2018 AMV
              if ((pCode_Family = 30) or (pCode_Family = 32)) then --Одинокие инв 1 и 2 группы,Одинокие пенсионеры>=70 --,27.08.2018 AMV
               if pCode_Family = 30 then RETURN TRUE; --можно на 12 мес --Одинокие инв 1 и 2 группы
               else  --проверяем на 70 лет
                  vCNT70:=0;
                  SELECT COUNT(PID) INTO vCNT70 FROM
                     (SELECT distinct PID,S_Age(0,cp.Pid,XLPL.WORKDATE)  Vozr
                      FROM W$CASE_PERSON cp
                      WHERE CID=pCID)
                   WHERE Vozr>=70;
                  if vCNT70=vCNT_PERSON then   RETURN TRUE; --можно на 12 мес
                  else
                  RETURN FALSE; --нельзя на 12 мес
                  end if;
               end if;
             else --,27.08.2018 AMV
              -- проверить неполная семья и уход за реб.инв <18
                if ((pCode_Family = 29) or(pCode_Family = 2) or (pCode_Family = 13)) then  -- неполная семья
                -- проверить неполная семья и уход за реб.инв <18
                -- 255 Родственник, осуществляющий уход за инвалидом с детства и ребенком-инвалидом до 18 лет, страдающим ДЦП
                --258
                -- временно используемая метрика - за неимением других - м.б. не только ребенок ДЦП --
                 --10.06.2014
                 --Проверяем есть ли пособие 490 или 491(уход за ребенком-инвалидов)
                 --или в ACTIVITY уход 314
                 aPID := XLPL.GETPID; --сохраняем текущий Pid
                 vCount_Metr:=0;
                 for Rec in --выбираем все PID по назначению
                   (Select PID as PID,RELATION as RELATION From  W$CASE_PERSON
                    Where   CID= XLPL.CID and  ENTERED_BY = XLPL.USER_ID and
                            STAGE not in (2, 3))
                 loop
                     XLPL.SetPid(Rec.Pid); --устанавливаем текущий Pid из выборки
                     if  ((B_F_BENEFIT_IS('490,491',1)) or (B_F_ACTV_MON_LAB('314')))  then --   получает пособия или уход
                       vCount_Metr:=vCount_Metr+1;
                      else --новый указ 211
                      if Rec.RELATION is not Null then
                         if ((Rec.RELATION=1) or (Rec.RELATION=2) or(Rec.RELATION=13) or(Rec.RELATION=14)) --отец,мать,отчим,мачеха
                              AND ((B_F_INV_PID_ADDRH_SOC(1,'11,12',Rec.Pid,XLPL.WORKDATE)) ) then --  инв. 1 или 2 группы)
                          if pCode_Family =29 then
                           --есть ли до 18 дети
                           vCNT18:=0;
                           SELECT COUNT(PID) INTO vCNT18 FROM
                            (SELECT distinct PID,S_Age(0,cp.Pid,XLPL.WORKDATE)  Vozr
                             FROM W$CASE_PERSON cp
                             WHERE CID=pCID)
                           WHERE Vozr<18;

                           if vCNT18>0 then --есть дети до 18
                             vCount_Metr:=vCount_Metr+1;
                           end if;
                          else --2,13 неполные с детьми до 18
                            vCount_Metr:=vCount_Metr+1;
                          end if;
                         end if;
                      end if;--Rec.RELATION
                     end if;
                 end loop;
                 XLPL.SetPid(aPid); --возвращаем текущий Pid
                if vCount_Metr<=0 then    --10.06.2014
                begin   --255 Родственник, осуществляющий уход за инвалидом с детства и ребенком-инвалидом до 18 лет, страдающим ДЦП
                        --258 Осуществляет уход за престарелым, инвалидом 1 группы или ребенком - инвалидом до 18 лет
                  Select Count(*) INTO vCount_Metr
                  From W$CASE_PERSON tc, W$PERSON_METRIC tm
                  Where tc.CID= XLPL.CID
                    and tc.pid= tm.pid
                    and tm.code IN (255,258)
                    and NVL (tm.RECORD_START, XLPL.WORKDATE) <= XLPL.WORKDATE
                    and NVL (tm.RECORD_END, XLPL.WORKDATE) >= XLPL.WORKDATE
                    and tc.STAGE IN (1,4)
                    and tm.STAGE IN (1,4);
                  exception
                    when others then vCount_Metr:= 0;
                  end;
                end if; --10.06.2014

                if vCount_Metr<= 0 then
                  RETURN FALSE; --нет исключения для неполной семьи
                else
                  RETURN TRUE;
                end if;

              else  -- Code_Family <> 29
                --в полной семье должны быть оба родителя и дети до 18 лет
                --есть ли дети до 18 лет
              vCNT18:=0;
               SELECT COUNT(PID) INTO vCNT18 FROM
                  (SELECT distinct PID,S_Age(0,cp.Pid,XLPL.WORKDATE)  Vozr
                   FROM W$CASE_PERSON cp
                   WHERE CID=pCID)
               WHERE Vozr<18;

               if vCNT18>0 then --есть дети до 18
                vCount_Metr:=0;
                aPID := XLPL.GETPID; --сохраняем текущий Pid
                vMother:=0;
                begin
                  SELECT distinct PID INTO vMother FROM W$CASE_PERSON
                  WHERE CID=pCID  AND RELATION in(2,14) AND STAGE NOT IN (2,3); --мать, мачеха
                exception
                 when No_Data_Found then
                  RETURN FALSE; -- - нет исключения так как не нашли маму
                end;
                vFather:=0;
                begin
                  SELECT distinct PID  INTO vFather FROM W$CASE_PERSON
                  WHERE CID=pCID  AND RELATION in(1,13) AND STAGE NOT IN (2,3); --отец, отчим
                 exception
                 when No_Data_Found then
                  RETURN FALSE; -- - нет исключения так как не нашли папу
                end;
               if  ((vMother<>0) and (vFather<>0)) then --A_F_RelProtDisabilsoc
                     --RAISE_APPLICATION_ERROR(-20801,'B_F_CHECK_EXEPT_751 ОтладкаАГАТ 1   vMother= '||vMother||' vFather= '||vFather||' XLPL.PID= '||XLPL.GetPid);
                   if (B_F_INV_PID_ADDRH_SOC(1,'11,12',vMother,XLPL.WORKDATE)) then --  инв. 1 или 2 группы мама
                     --RAISE_APPLICATION_ERROR(-20801,'B_F_CHECK_EXEPT_751 ОтладкаАГАТ 1   vMother= '||vMother||' vFather= '||vFather||' XLPL.PID= '||XLPL.GetPid);
                    --проверяем папу
                      if  (B_F_INV_PID_ADDRH_SOC(1,'11,12',vFather,XLPL.WORKDATE)) then
                      --RAISE_APPLICATION_ERROR(-20801,'B_F_CHEK_EXEPT_751 Отладка АГАТ 22222  vMother= '||vMother||' vFather= '||vFather||' XLPL.PID= '||XLPL.GetPid);
                      RETURN TRUE; --есть исключение - оба родители инвалиды

                     else --папа не штвалид
                      --RAISE_APPLICATION_ERROR(-20801,'B_F_CHECK_EXEPT_751 Отладка АГАТ 33333   vMother= '||vMother||' vFather= '||vFather||' XLPL.PID= '||XLPL.GetPid);
                       --проверяе ухаживает ли он за мамой
                       XLPL.SETPID(vFather);
                       if B_F_BENEFIT_IS('533',1) then --папа получает пособие по уходу за инв 1 гр
                        -- ухаживает ли он за мамой
                        vPID_5800:=0;
                        begin
                        select distinct PID into vPID_5800 from CASE_PERSON
                        where CID=
                                (select distinct  C.CID
                                 from ALLOCATION a, ALLOCATION_PERSON b, CASE_PERSON c
                                 where a.RID = b.ALLOCATION_RID  and b.PID = XLPL.GetPid
                                       and c.PID = b.PID and a.CID = c.CID  and c.ROLE= 59 --ухаживающий
                                       and a.ALLOC_STATUS=1
                                       and a.STAGE  is NULL and a.CLOSE_DATE is NULL
                                       and c.STAGE is NULL  and c.CLOSE_DATE is NULL
                                       and b.STAGE is NULL  and a.ALLOC_CODE =533
                                       and a.ALLOCATION_START <= XLPL.WORKDATE  and a.ALLOCATION_END is null
                                       and (a.STEP_END is null or a.STEP_END >= XLPL.WORKDATE))
                               and ROLE=5800 and STAGE is NULL and CLOSE_DATE is NULL  --нуждающийся в уходе
                               and NVL (RECORD_START, XLPL.WORKDATE) <= XLPL.WORKDATE
                               and NVL (RECORD_END, XLPL.WORKDATE) >= XLPL.WORKDATE;
                        exception
                         when others then vPID_5800:=0;
                        end;

                        if vPID_5800=vMother then
                         XLPL.SetPid(aPid); --возвращаем текущий Pid
                         RETURN TRUE; --есть исключение -папа ухаживает за мамой
                        else --19.10.2017 забыла else
                         XLPL.SetPid(aPid); --возвращаем текущий Pid
                         RETURN FALSE; --  уход не за мамой
                        end if;
                       else
                        XLPL.SetPid(aPid); --возвращаем текущий Pid
                        RETURN FALSE; -- нет пособия
                       end if; --папа получает пособие по уходу за инв 1 гр
                     end if;
                   else --мама не инвалид
                    -- проверяе папу на ннв 1 группы
                    --RAISE_APPLICATION_ERROR(-20801,'B_F_CHECK_EXEPT_751 Отладка АГАТ 4   vMother= '||vMother||' vFather= '||vFather);
                      if  B_F_INV_PID_ADDRH_SOC(1,'11',vFather,XLPL.WORKDATE)  then
                       --проверяем маму на уход
                        XLPL.SetPid(vMother); --
                       if B_F_BENEFIT_IS('533',1) then --мама получает пособие по уходу за инв 1 гр
                        --RAISE_APPLICATION_ERROR(-20801,'B_F_CHECK_EXEPT_751 Отладка АГАТ 6   vMother= '||vMother||' vFather= '||vFather);
                        -- ухаживает ли она за папой
                        vPID_5800:=0;
                        begin
                        select distinct PID into vPID_5800 from CASE_PERSON
                        where CID=
                                (select distinct  C.CID
                                 from ALLOCATION a, ALLOCATION_PERSON b, CASE_PERSON c
                                 where a.RID = b.ALLOCATION_RID  and b.PID = XLPL.GetPid
                                       and c.PID = b.PID and a.CID = c.CID  and c.ROLE= 59 --ухаживающий
                                       and a.ALLOC_STATUS=1
                                       and a.STAGE  is NULL and a.CLOSE_DATE is NULL
                                       and c.STAGE is NULL  and c.CLOSE_DATE is NULL
                                       and b.STAGE is NULL  and a.ALLOC_CODE =533
                                       and a.ALLOCATION_START <= XLPL.WORKDATE  and a.ALLOCATION_END is null
                                       and (a.STEP_END is null or a.STEP_END >= XLPL.WORKDATE))
                               and ROLE=5800 and STAGE is NULL and CLOSE_DATE is NULL  --нуждающийся в уходе
                               and NVL (RECORD_START, XLPL.WORKDATE) <= XLPL.WORKDATE
                               and NVL (RECORD_END, XLPL.WORKDATE) >= XLPL.WORKDATE;
                        exception
                         when others then vPID_5800:=0;
                        end;
                --RAISE_APPLICATION_ERROR(-20801,'B_F_CHECK_EXEPT_751 Отладка АГАТ 5800   vMother= '||vMother||' vFather= '||vFather||' нужд. в уходе= '||vPID_5800);

                        if vPID_5800=vFather then
                         XLPL.SetPid(aPid); --возвращаем текущий Pid
                --RAISE_APPLICATION_ERROR(-20801,'B_F_CHECK_EXEPT_751 Отладка АГАТ 9    vMother= '||vMother||' vFather= '||vFather||' XLPL.PID= '|| XLPL.GETPID||' vPID_5800= '|| vPID_5800);
                        RETURN TRUE; --есть исключение -мама ухаживает запапой
                        else--19.10.2017 отс-л else
                          XLPL.SetPid(aPid); --возвращаем текущий Pid
                          RETURN FALSE; --  уход не за папой
                        end if;
                       else
                        XLPL.SetPid(aPid); --возвращаем текущий Pid
                        RETURN FALSE; -- нет пособия по уходу за инв 1 гр
                       end if; --мама получает пособие по уходу за инв 1 гр
                     else  --папа не инвалид 1 гр
                      RETURN FALSE; -- - нет исключения так как у мамы и папы  нет инвалидности
                     end if;
                   end if;

                else
                RETURN FALSE; -- не определены родители - нет исключения
                end if;
              else
               RETURN FALSE; -- нет детей до 18 лет
              end if;
              end if;--Code_Family
             end if; --семья одиноких --27.08.2018
            else --Code_Family is  Null
              RETURN FALSE;
            end if;

    end if; --vCNT_PERSON имеет значение 1 или >
  else --vCNT_PERSON=0
   RAISE_APPLICATION_ERROR(-20801,'Функция B_F_CHECK_EXEPT_751- количество персон в деле = 0!!! ');
   RETURN FALSE; --19.10.2017
  end if; --анализ vCNT_PERSON

 EXCEPTION WHEN OTHERS THEN
  --RAISE_APPLICATION_ERROR(-20801,'Error F_Mrak_Opn_Advice_Soc ');
   err_num := SQLCODE;
   err_msg := SUBSTR(SQLERRM, 1, 500);
   raise_application_error(-20001, 'B_F_CHECK_EXEPT_751 - '|| err_num || ':' ||err_msg);
   RETURN FALSE; --19.10.2017
END B_F_CHECK_EXEPT_751;
/
