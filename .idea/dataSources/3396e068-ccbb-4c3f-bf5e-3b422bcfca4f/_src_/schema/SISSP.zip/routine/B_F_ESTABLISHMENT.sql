CREATE FUNCTION       B_F_ESTABLISHMENT(pADDRESS_TYPE in NUMBER) RETURN NUMBER IS
/*******************************************************************************
 NAME              : B_F_ESTABLISHMENT
 Наименование      : Функция возвращает код ДИ в котором пенсионер проживает
 Автор             : ОЛВ
 Состояние на дату : 07.08.2015
 Код возврата      : TRUE или FALSE
********************************************************************************/
 vsDRID            NUMBER;
 vsEstablishment   NUMBER;
BEGIN
-- pADDRESS_TYPE - ТИП АДРЕСА; АДРЕС ПРОПИСКИ И/ИЛИ АДР. ПРОЖИВ. (1 - РЕГИСТР., 2 - ПРОЖИВ., 3 - ТО И  ДР.)

   -- Выбрать адрес в ОБД RID из ADDRESS
     vsDRID:=A_F_RelProtGetRIDAddress(1,pADDRESS_TYPE);
 if vsDRID<>-1 then
      begin
         select code_establishment
           into vsEstablishment
           from ADDRESS
          where RID=vsDRID
            AND NVL((TRUNC(RECORD_START)),XLPL.WORKDATE)<=XLPL.WORKDATE
            AND NVL((TRUNC(RECORD_END)),XLPL.WORKDATE)>=XLPL.WORKDATE
                    ;
      exception
         when OTHERS then
            vsEstablishment:=NULL;
      end;
 else
      -- Выбрать адрес в РБД RID из W$ADDRESS
        vsDRID:=A_F_RelProtGetRIDAddress(0,pADDRESS_TYPE);
    if vsDRID<>-1 then
      begin
         select code_establishment
           into vsEstablishment
           from W$ADDRESS
          where RID=vsDRID
            AND NVL((TRUNC(RECORD_START)),XLPL.WORKDATE)<=XLPL.WORKDATE
            AND NVL((TRUNC(RECORD_END)),XLPL.WORKDATE)>=XLPL.WORKDATE
                    ;
      exception
         when OTHERS then
            vsEstablishment:=NULL;
      end;
    else
       vsEstablishment:=NULL;
    end if;
 end if;
      RETURN vsEstablishment;
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtAddress 3 xlpl.GetPid=' || xlpl.GetPid ||'  vsDRID='||vsDRID ||' vsEstablishment='||vsEstablishment);
END B_F_ESTABLISHMENT;
/
