CREATE FUNCTION       A_F_Relprot_MinDef RETURN NUMBER IS
/*******************************************************************************
 NAME              : A_F_Relprot_MinDef
 Назначение        : Возращает сумму пенсии, полученную по линии МО
 Автор             : ОЛВ
 Состояние на дату : 01.12.2014
 Код возврата      : Amount из PENSION_MINISTRY_DEFENSE
*******************************************************************************/
 vAmount         NUMBER;
BEGIN
 IF (Xlpl.INDIV <>2) then -- не массовый расчет
   -- Выбрать в РБД из W$PENSION_MINISTRY_DEFENSE
    vAmount:=A_F_RelprotGetMinDef(0);
 else
   -- Выбрать в ОБД из PENSION_MINISTRY_DEFENSE
     vAmount:=A_F_RelprotGetMinDef(1);
 end if;
 if vAmount=-1 then
      vAmount:=null;--0;
 end if;
 return vAmount;

END A_F_Relprot_MinDef;
/
