CREATE FUNCTION       A_WB_F_GETMAINBYWORKCODE(ACODE in Number) RETURN Number IS
/*Преобразование кода рабочей таблицы в код  основной,
                            если передан код таблицы ОДБ, возвращается -1
Вахромин О.Ю.*/
vsCode Number;
BEGIN
   vsCODE:= -1;
   begin
      select CODE into vsCODE from SISSP_TABLES where
         NAME_TABLE = (select SUBSTR(NAME_TABLE,3) from SISSP_TABLES where
         CODE = ACODE and NAME_TABLE like 'W$%');
   exception
      when No_Data_Found then
         vsCODE:=-1;
      when Others then
         RAISE_APPLICATION_ERROR(-20801,'В таблице SISSP_TABLES неверная запись');
   end;
   return vsCODE;
END A_WB_F_GETMAINBYWORKCODE;
/
