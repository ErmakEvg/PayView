CREATE FUNCTION       B_Child3_Nadbavka_20080101 RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_Child3_Nadbavka_20061201
 Наименование       : Проверка права и вычисление надбавок для пособий детям до 3 лет
 Автор              : Ворошилин В.               Коректировка: ОЛВ
 Состояние на дату  : 01.07.2002                              31.03.2010
 Код возврата       : число с плавающей точкой с суммой
***********************************************************************************************/

 K      DBMS_SQL.NUMBER_TABLE;
 Bonus  DBMS_SQL.NUMBER_TABLE;

BEGIN

 K.delete;
 Bonus.delete;

 XLPL.SETGLOBALFLOAT('Nadb1', 0);
   Bonus := B_F_Nad0();
 XLPL.SETGLOBALFLOAT('Nadb1', 1);
 if Bonus.count <> 0 then
   K := Bonus;
 end if;

 -- Сумма увеличения пособия по Закону о ЧАЭС для детей до 3 лет для зон радиоактивного загрязнения 2 - 5:
 if F$CHECK581 then
   K(581) := F$AMOUNT581;
 end if;

 Return K;

END B_Child3_Nadbavka_20080101;
/
