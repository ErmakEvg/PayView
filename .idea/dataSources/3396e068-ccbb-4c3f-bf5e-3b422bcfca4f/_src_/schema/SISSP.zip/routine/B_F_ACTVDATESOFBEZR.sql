CREATE FUNCTION       B_F_ActvDatesOfBezr RETURN DBMS_SQL.Number_Table AS

/***************************************************************************************
// Функция: B_F_ActvDatesOfBezr
// Наименование: Функция определяет, даты получения пособия по безработице
// Автор: Ворошилин В.
// Состояние на дату 11.11.1999
// Возвращает: массив
//***************************************************************************************/

  A DBMS_SQL.Number_Table;
  BDay DATE;
  StartDateBD DATE;
  Dt DATE;
BEGIN
  A.Delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CHECKROLE(56) then
	return A;
  end if;
  XLPL.REPLACEROLE('Child');
  BDay := S_Birthdate(XLPL.BASE_ID, XLPL.GetPid, XLPL.WorkDate);
  XLPL.RESTOREROLE;
  StartDateBD := S_AddYears(BDay, TRUNC(S_Const(401, XLPL.WorkDate))) + 1;
  Dt := S_DateConst(478, XLPL.WorkDate);
  Dt := S_EncodeDate(S_YearOfDate(XLPL.WorkDate), S_MonthOfDate(Dt), S_DayOfDate(Dt));
  if (StartDateBD >= Dt) and (StartDateBD <= XLPL.WorkDate) then
   	Dt := StartDateBD;
  end if;
  for ACTSTART in (Select PERIOD_START From W$ACTIVITY
                   Where PID = XLPL.GetPid
				     and ENTERED_BY = XLPL.User_ID
					 and ACTIVITY = 3
					 and LABOR in (241, 243)
					 and STAGE NOT IN (2, 3)
					 and PERIOD_START >= Dt
				   ORDER BY PERIOD_START)
  LOOP
    if ACTSTART.PERIOD_START is not NULL then
	  A(A.count+1) := S_Julian(ACTSTART.PERIOD_START);
	end if;
  end LOOP;
  RETURN A;
END B_F_ActvDatesOfBezr;
/
