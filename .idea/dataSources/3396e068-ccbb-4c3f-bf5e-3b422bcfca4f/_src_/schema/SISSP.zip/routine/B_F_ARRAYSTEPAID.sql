CREATE FUNCTION       B_F_ARRAYSTEPAID(pAID in number, pCID varchar2) RETURN DBMS_SQL.NUMBER_TABLE IS
AllocStep DBMS_SQL.NUMBER_TABLE;

BEGIN
  for c1 in (Select nvl(Step_Start, null) as StStart from W$ALLOCATION
                          Where Cid = XLPL.Cid and Aid = XLPL.Aid
 						  and PARENT_RID is NULL and Comp_Part is NULL and stage not in (2,3)
					  )
  LOOP
    if(c1.StStart != null) then
	  AllocStep(AllocStep.Count+1) := s_julian(c1.StStart);
	end if;
  end loop;

  return AllocStep;
END B_F_ARRAYSTEPAID;
/
