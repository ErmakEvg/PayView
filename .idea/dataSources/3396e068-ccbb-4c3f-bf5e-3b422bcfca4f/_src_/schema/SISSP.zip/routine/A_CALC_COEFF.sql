CREATE FUNCTION       A_Calc_Coeff (rpid IN NUMBER,
   gobr IN CHAR,polzov IN NUMBER) RETURN NUMBER IS
   --- Якимова С.А. 30.10.2008
-- Функция выбора наилучшего индивидуального коэффициента
nnom NUMBER:=1;
mes NUMBER:=0;
mesvse NUMBER:=0;
luch NUMBER(12,6):=0;
maxk NUMBER(12,6):=0;
lnom NUMBER:=0;
period VARCHAR2(50);
god VARCHAR2(4);
god1 VARCHAR2(20);
mes1 NUMBER:=0;
CURSOR perep IS SELECT SUM(FACTOR) factor,  YEAR ,  MONTH      FROM  W$WORK_SALARY
WHERE   PID =rpid AND entered_by=polzov  GROUP BY YEAR,MONTH;
 cur_perep perep%ROWTYPE;
CURSOR num IS SELECT  YEAR ,  MONTH  FROM  W$WORK
WHERE   PID =rpid AND entered_by=polzov  ORDER BY YEAR,MONTH;
 cur_num num%ROWTYPE;
 ---для переписи в W$salary
CURSOR nnn IS SELECT YEAR,MONTH FROM W$WORK
WHERE pid=rpid AND entered_by=polzov
 AND num>lnom AND num<lnom+mes+1 ORDER BY YEAR,MONTH;
cur_nnn nnn%ROWTYPE;
CURSOR nnn1 IS SELECT SALARY,AVERAGE,FACTOR,COUNTRY FROM W$WORK_SALARY
WHERE pid=rpid AND entered_by=polzov
 AND  YEAR=god1 AND MONTH=mes1  ORDER BY YEAR,MONTH;
cur_nnn1 nnn1%ROWTYPE;

BEGIN
--- переписываем из рабочей
DELETE W$WORK WHERE pid=rpid;
OPEN perep;
 LOOP
  	  FETCH perep INTO cur_perep;

           EXIT WHEN perep%NOTFOUND;
	INSERT INTO   W$WORK (PID,YEAR,MONTH,FACTOR,ENTERED_BY)
	VALUES (rPID,cur_perep.YEAR,cur_perep.MONTH,cur_perep.FACTOR,polzov);
		 END LOOP;
CLOSE perep;
nnom:=1;
OPEN num;
 LOOP
  	  FETCH num INTO cur_num;
           EXIT WHEN num%NOTFOUND;
	UPDATE   W$WORK SET num=nnom
WHERE pid=rPID AND YEAR=cur_num.YEAR AND MONTH=cur_num.MONTH AND ENTERED_BY=polzov;
nnom:=nnom+1;
		 END LOOP;
CLOSE num;
--- коэффициент
-- больщой период
SELECT COUNT(*) INTO mesvse	FROM  LEGAL_CONSTANTS WHERE  code=103 AND TO_CHAR(start_date,'RRRR')=gobr;
  IF MESVSE=1 THEN
  SELECT  value INTO mesvse	FROM  LEGAL_CONSTANTS WHERE  code=103 AND TO_CHAR(start_date,'RRRR')=gobr;
  ELSE
  	--не нашлось
  --- берем за предыдущие данные
      SELECT value  INTO MESVSE  FROM LEGAL_CONSTANTS WHERE TO_CHAR(start_date,'RRRR')=( SELECT  TO_CHAR(start_date,'RRRR') FROM LEGAL_CONSTANTS
  WHERE TO_CHAR(start_date,'RRRR') < gobr	AND code=103) AND code=103;
  END IF;

--период для выбора коэффициента
SELECT COUNT(*) INTO mes	FROM  LEGAL_CONSTANTS WHERE  code=104 AND TO_CHAR(start_date,'RRRR')=gobr;
  IF MES=1 THEN
  SELECT  value INTO mes	FROM  LEGAL_CONSTANTS WHERE  code=104 AND TO_CHAR(start_date,'RRRR')=gobr;
  ELSE
  	--не нашлось
  --- берем за предыдущие данные
      SELECT value  INTO MES  FROM LEGAL_CONSTANTS WHERE TO_CHAR(start_date,'RRRR')=( SELECT  TO_CHAR(start_date,'RRRR') FROM LEGAL_CONSTANTS
  WHERE TO_CHAR(start_date,'RRRR') < gobr	AND code=104) AND code=104;
  END IF;
nnom:=1;
 LOOP
SELECT ROUND(AVG(FACTOR),5) INTO maxk FROM  W$WORK WHERE num>nnom-1 AND num<nnom+mes AND pid=rpid;
  IF maxk>luch THEN
  	luch:=maxk;
  	lnom:=nnom;
  END IF;

           EXIT WHEN nnom+mes=mesvse;
		nnom:=nnom+1;
 END LOOP;
 --- переписываем из рабочей W$WORK в W$SALARY
DELETE W$SALARY WHERE pid=rpid;
nnom:=1;
OPEN nnn;
 LOOP
  	  FETCH nnn INTO cur_nnn;

           EXIT WHEN nnn%NOTFOUND;
           god1:=cur_nnn.YEAR;
           mes1:=cur_nnn.MONTH;
  OPEN nnn1;
   LOOP
  	  FETCH nnn1 INTO cur_nnn1;

           EXIT WHEN nnn1%NOTFOUND;

	INSERT INTO   W$SALARY (PID,YEAR,MONTH,SALARY,AVERAGE,FACTOR,num,ENTERED_BY,COUNTRY )
	VALUES (rPID,god1,mes1,cur_nnn1.SALARY,cur_nnn1.AVERAGE,
	cur_nnn1.FACTOR,nnom,polzov,cur_nnn1.COUNTRY);
	 END LOOP;
CLOSE nnn1;
		nnom:=nnom+1;

		 END LOOP;
CLOSE nnn;
-- запись периодов, избранных для расчета индивидуального коэффициента  в таблицу W$PERIOD_INCLUDE
-- добавляем 01 число, т.к. есть только месяц и год, а надо дату.
SELECT MIN(LTRIM(RTRIM(YEAR))) INTO god FROM W$SALARY WHERE pid=rpid AND entered_by=polzov;
SELECT MIN(MONTH) INTO mes FROM W$SALARY WHERE pid=rpid AND entered_by=polzov AND YEAR=god;

IF mes<10 THEN
	period:='01.0'||TO_CHAR(mes)||'.'||god;
ELSE
	period:='01.'||TO_CHAR(mes)||'.'||god;
	END IF;
SELECT MAX(LTRIM(RTRIM(YEAR))) INTO god FROM W$SALARY WHERE pid=rpid AND entered_by=polzov;
SELECT MAX(MONTH) INTO mes FROM W$SALARY WHERE pid=rpid AND entered_by=polzov AND YEAR=god;

IF mes<10 THEN
	period:=period||'   01.0'||TO_CHAR(mes)||'.'||god;
ELSE
	period:=period||'   01.'||TO_CHAR(mes)||'.'||god;
END IF;
DELETE FROM W$PERIOD_INCLUDE WHERE pid=rpid AND entered_by=polzov and pr_include=1;
INSERT INTO W$PERIOD_INCLUDE (PID,VALUE,ENTERED_BY,PR_INCLUDE)
	VALUES (rPID,period,polzov,1);
	  COMMIT;
  RETURN luch;
END;
/
