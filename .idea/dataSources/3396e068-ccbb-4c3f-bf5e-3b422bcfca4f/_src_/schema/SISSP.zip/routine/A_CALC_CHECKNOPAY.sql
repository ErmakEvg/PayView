CREATE FUNCTION       A_Calc_Checknopay(ACID IN NUMBER,AAID IN NUMBER)
   RETURN BOOLEAN IS
/***************************************************************************************
 Функция                  :  A_Calc_Checknopay
 Наименование         : КОНТРОЛИРОВАНИЕ ВЫПЛАТЫ
                                   (ДЛЯ ОБЕСПЕЧЕНИЯ ПРОВЕДЕНИЯ РАСЧЕТА СУММЫ К ВЫПЛАТЕ
								   С ВОЗМОЖНОСТЬЮ ЗАПРЕЩЕНИЯ ВЫПЛАТЫ ЭТОЙ СУММЫ -
								   ПРИ НЕПОЛУЧЕНИИ ЛИЦОМ БОЛЕЕ 6 МЕСЯЦЕВ, …)
 Автор                      :  Вахромин О.Ю.               Комментарии : OLV
 Состояние на дату   :                                           19.02.2013
 Код возврата           : TRUE если для заданного CID-a AID-a стоит флаг не платить
***************************************************************************************/
vCount NUMBER;
BEGIN
   SELECT COUNT(*) INTO vCount
      FROM W$CONTROL_PAYMENT
	WHERE CID=ACID AND AID=AAID AND ENTERED_BY=Xlpl.USER_ID
	      AND STAGE NOT IN (2,3);
   RETURN vCount>0;
END A_Calc_Checknopay;
/
