CREATE FUNCTION       B_F_Actv_RabSobes RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_Actv_RabSobes
// Наименование: Функция определения работы, дающей право на получение пособия в Собесе
// Автор: Ворошилин В.
// Состояние на дату 10.10.2001
// Возвращает: True - если лицо активно, False - если лицо не активно
//***************************************************************************************/

  CN_ACTIVITY NUMBER;
BEGIN
  Select COUNT(*) INTO CN_ACTIVITY From W$ACTIVITY
  Where PID = XLPL.GETPID
    and ACTIVITY = 1
    and LABOR in (200, 201, 202, 203, 204, 205, 206, 207,208,214,215,216,217)
    and ENTERED_BY = XLPL.User_ID
    and STAGE NOT IN(2,3)
    and (NVL(PERIOD_START, XLPL.WorkDate) <= XLPL.WorkDate
    and NVL(PERIOD_END, XLPL.WorkDate) >= XLPL.WorkDate);
  RETURN CN_ACTIVITY != 0;
END B_F_Actv_RabSobes;
/
