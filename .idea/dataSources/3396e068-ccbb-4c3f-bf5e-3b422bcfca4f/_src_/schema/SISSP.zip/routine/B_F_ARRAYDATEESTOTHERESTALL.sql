CREATE FUNCTION       B_F_ARRAYDATEESTOTHERESTALL RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_ARRAYDATEESTOTHERESTALL
+ Наименование: Получить мах дату из предполагаемых завершений действия всех
+ 				назначений дела
+ Автор: Ворошилин В.
+ Состояние на дату 12.12.2000
==============================================================================*/

  aData DBMS_SQL.NUMBER_TABLE;
  a DBMS_SQL.NUMBER_TABLE;
  pFeature NUMBER;
  max_sum NUMBER;
  max_ind NUMBER;
  max_scd NUMBER;
  i BINARY_INTEGER;
BEGIN
  aData.delete;
  a.delete;
  pFeature := 0;
  begin
    select nvl(feature,0)  INTO pFeature
	from w$CASE_PERSON a, allocation_role_group b, W$Case c
	where parent_code = c.Role_Group
	  and code = role
	  and a.pid = XLPL.GetPid
	  and a.cid = XLPL.CID
	  and a.stage not in (2, 3)
	  and c.cid = XLPL.CID
	  and c.stage not in (2,3);
	exception
	  when No_Data_Found then
	    pFeature := 0;
  end;
  if pFeature <> 1 then
    for OTHERESTALL in (select distinct AID
	                    from  allocation_role_Group b, W$allocation c, W$Allocation_person d, allocations a
						where d.pid <> XLPL.GetPid
						  and d.role = b.code
						  and a.code = c.alloc_Code
						  and a.role_group = b.parent_code
						  and a.close_feature is Null
						  and b.feature = 1
						  and c.Alloc_Code <> XLPL.ALLOC_CODE
						  and c.parent_rid is null
						  and c.comp_part is null
						  and c.cid = XLPL.CID
						  and c.rid = d.allocation_rid
						  and c.stage not in (2,3))
    loop
      a := B_F_CHECKALLOCEST(OTHERESTALL.AID, XLPL.CID);
        if a.count > 0 then
          for i in 1..a.count loop
		    aData(aData.count + 1) := a(i);
		  end loop;
		end if;
    end loop;
    if aData.count > 3 then
      max_sum := aData(1);
      max_ind := aData(2);
      max_scd := aData(3);
	  i := 1;
      while (i < aData.count) loop
        if aData(i) > max_sum then
          max_sum := aData(i);
          max_ind := aData(i + 1);
          max_scd := aData(i + 2);
        end if;
        i := i + 3;
      end loop;
      aData.delete;
      aData(1) := max_sum;
	  aData(2) := max_ind;
	  aData(3) := max_scd;
      return aData;
    end if;
    return a;
  else
    for OTHERESTALL in (select distinct AID
	                    from  allocation_role_Group b, W$allocation c, W$Allocation_person d, allocations a
						where d.pid = XLPL.GetPid
						  and d.role = b.code
						  and a.code = c.alloc_Code
						  and a.role_group = b.parent_code
						  and a.close_feature is Null
						  and b.feature = 1
						  and c.Alloc_Code <> XLPL.ALLOC_CODE
						  and c.parent_rid is null
						  and c.comp_part is null
						  and c.cid = XLPL.CID
						  and c.rid = d.allocation_rid
						  and c.stage not in (2,3))
    loop
      a := B_F_CHECKALLOCEST(OTHERESTALL.AID, XLPL.CID);
        if a.count > 0 then
          for i in 1..a.count loop
		    aData(aData.count + 1) := a(i);
		  end loop;
		end if;
    end loop;
    if aData.count > 3 then
      max_sum := aData(1);
      max_ind := aData(2);
      max_scd := aData(3);
	  i := 1;
      while (i < aData.count) loop
        if aData(i) > max_sum then
          max_sum := aData(i);
          max_ind := aData(i + 1);
          max_scd := aData(i + 2);
        end if;
        i := i + 3;
      end loop;
      aData.delete;
      aData(1) := max_sum;
	  aData(2) := max_ind;
	  aData(3) := max_scd;
      return aData;
    end if;
    return a;
  end if;
  return a;
END B_F_ARRAYDATEESTOTHERESTALL;
/
