CREATE FUNCTION       A_F_RelProtGetRidMrakOpAdvSOC(Base_ID in Number,
   AOPINION_TYPE in number) RETURN DBMS_SQL.NUMBER_TABLE IS
/*******************************************************************************
 Функция             :  A_F_RelProtGetRidMrakOpAdvSOC
 Наименование        :  RID из W$RELATION_PROTOCOL для MRAK_OPINION_ADVICE
 Автор               :  Горбач по Вахромин Для соц. задач   Корректировка: ОЛВ
 Состояние на дату   :  14.12.2014                       18.02.2011  23.05.2016
                     :
 Код возврата        :  RID из W$RELATION_PROTOCOL для MRAK_OPINION_ADVICE
********************************************************************************/
 DRIDS             DBMS_SQL.Number_Table;
 vsRELATION_TABLE  number;
 pDATA_RID         number;
 pRELATION_DATE    date;
BEGIN
   if Base_Id=1 then
      vsRELATION_TABLE:=S_CodeTableSISSP('MRAK_OPN_ADVICE');
   else
      vsRELATION_TABLE:=S_CodeTableSISSP('W$MRAK_OPN_ADVICE');
   end if;
 if Base_Id=1  then
   -- RID из W$RELATION_PROTOCOL для MRAK_OPINION_ADVICE
   ------------------------------------------------------
      for c1 in (
             select DATA_RID
               from  W$RELATION_PROTOCOL b, MRAK_OPN_ADVICE a
              where b.CID=XLPL.CID
                and (Aid=XLPL.Aid or XLPL.Aid=0)
                and ((GROUP_NO=XLPL.GROUP_NO)or(XLPL.Aid<>0 and XLPL.Group_No=0))
                and ALLOC_CODE=XLPL.ALLOC_CODE
                and RELATION_DATE=XLPL.WorkDate
                and RELATION_TABLE=vsRELATION_TABLE  -- 185
                and b.ENTERED_BY=XLPL.USER_ID
                and a.PID=XLPL.GetPID
                and a.CID=XLPL.CID
                and DATA_RID=a.RID
                -- OLV 23.05.2016 --and a.STAGE is NULL
                and ((OPINION_TYPE=aOPINION_TYPE) or (aOPINION_TYPE=-1)))
         loop
             DRIDS(DRIDS.count+1):=c1.DATA_RID;
         end loop;
 else
   -- RID из W$RELATION_PROTOCOL для W$MRAK_OPINION_ADVICE
   ------------------------------------------------------
      for c1 in (
             select DATA_RID
               from W$RELATION_PROTOCOL b, W$MRAK_OPN_ADVICE a
              where b.CID=XLPL.CID
                and (Aid=XLPL.Aid or XLPL.Aid=0)
                and ((GROUP_NO=XLPL.GROUP_NO)or(XLPL.Aid<>0 and XLPL.Group_No=0))
                and ALLOC_CODE=XLPL.ALLOC_CODE
                and RELATION_DATE=XLPL.WorkDate
                and RELATION_TABLE=vsRELATION_TABLE
                and b.ENTERED_BY=XLPL.USER_ID
                and a.ENTERED_BY=XLPL.USER_ID
                and a.PID=XLPL.GetPID
                and a.CID=XLPL.CID
                and DATA_RID=a.RID
                and a.STAGE in (1,4)
                and ((OPINION_TYPE=aOPINION_TYPE) or (aOPINION_TYPE=-1)))
         loop
             DRIDS(DRIDS.count+1):=c1.DATA_RID;
         end loop;
 end if;
   return DRIDS;
END A_F_RelProtGetRidMrakOpAdvSOC;
/
