CREATE FUNCTION       A_F_RelProtZone(pADDRESS_TYPE in NUMBER) RETURN NUMBER IS
/***************************************************************************************
 NAME              : A_F_RelProtZone
 Наименование      : Функция возвращает зону ЧАЭС
 Автор             : Вахромин О.Ю.       Комментарии и корректировка : ОЛВ
 Состояние на дату : 		  			 			   		           10.08.2010
 Код возврата      : зона ЧАЭС
***************************************************************************************/
 vsHouse    VarChar2(2000);
 vsHouse_X  VarChar2(2000);
 vsAppt     VarChar2(2000);
 vsDRID     NUMBER;
 vsSite     NUMBER;
 vsStreet   NUMBER:=0;
 NumZone    NUMBER;
 Num_Zone   NUMBER:=0;
BEGIN
/*float vsCOUNT;
float Type_Org =7; // тип организации дом-интернат*/

   -- Выбрать адрес в ОБД RID из ADDRESS
     vsDRID:=A_F_RelProtGetRIDAddress(1,pADDRESS_TYPE);
   if vsDRID<>-1 then
      begin
         select SITE,STREET,HOUSE,HOUSE_X,APPT into vsSITE,vsSTREET,vsHOUSE,vsHOUSE_X,vsAPPT from
            ADDRESS where RID=vsDRID;
      exception
         when NO_DATA_FOUND then
            num_zone:=0;
      end;
   else
      -- Выбрать адрес в РБД RID из W$ADDRESS
        vsDRID:=A_F_RelProtGetRIDAddress(0,pADDRESS_TYPE);
      if vsDRID<>-1 then
         begin
            select SITE,STREET,HOUSE,HOUSE_X,APPT into vsSITE,vsSTREET,vsHOUSE,vsHOUSE_X,vsAPPT from
               W$ADDRESS where RID=vsDRID and ENTERED_BY=XLPL.USER_ID; -- OLV 10.08.2010 было ADDRESS
         exception
            when NO_DATA_FOUND then
               num_zone:=0;
         end;
      end if;
   end if;

   -- По адресу выбрать зону из ST_DIVISION_POLLUTION_AREA
   if vsDRID<>-1 then
      num_zone:=SISSP_REGISTRY.get_pollution_area(vsSITE,vsSTREET,vsHOUSE,vsHOUSE_X,vsAPPT);
   end if;
   return trunc(num_zone);

END A_F_RelProtZone;
/
