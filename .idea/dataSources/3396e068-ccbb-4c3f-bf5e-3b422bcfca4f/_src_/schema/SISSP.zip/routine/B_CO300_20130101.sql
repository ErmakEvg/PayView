CREATE FUNCTION       B_CO300_20130101 RETURN NUMBER AS
/***************************************************************************************
 Функция            : B_CO300_20130101
 Наименование       : Функция расчета пособия семье, воспитывающей ребенка старше 3 лет в полном объеме
 Автор              : Речицкая
 Состояние на дату  : 10.01.2013
 Код возврата       : число с плавающей точкой с суммой пособия
***************************************************************************************/
Amount      NUMBER;
Percent          NUMBER;
BEGIN
 -- 498 - Размер пособия на детей в возрасте старше 3 лет - в % от БПМ в среднем на душу населения
 --  18 - БПМ в среднем на душу населения
 if  ( A_F_RelProtDisability(1, '14') or B_F_RelProtMetricBen('320') or A_F_RelProtDisabilityReason(-1, '', '4') )  then
        Percent:=   S_Const(485, XLPL.WorkDate); -- 70 новая
 else
        Percent:=   S_Const(498, XLPL.WorkDate);  -- 50
 end if;
    Amount :=  S_VRound_Sum((Percent * S_Const(18, XLPL.WorkDate)/100), s_const(40,XLPL.WorkDate));


   XLPL.AMOUNT := Amount;
  RETURN XLPL.AMOUNT;

END B_CO300_20130101;
/
