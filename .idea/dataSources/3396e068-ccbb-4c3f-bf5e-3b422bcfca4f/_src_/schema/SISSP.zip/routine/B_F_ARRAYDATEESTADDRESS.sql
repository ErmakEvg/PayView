CREATE FUNCTION       B_F_ARRAYDATEESTADDRESS RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Наименование: Функция возвращает массив дат изменения адреса проживания/прописки
+ Автор: Ворошилин В.
+ Состояние на дату 17.11.2000
==============================================================================*/

  chahge_date_aRecord DBMS_SQL.NUMBER_TABLE;
BEGIN
  chahge_date_aRecord.delete;
  for aADDRESS in (select nvl(RECORD_START, NULL) as aRecord_start, nvl(RECORD_END, NULL) as aRecord_end, ADDRESS_TYPE
                   from W$ADDRESS
				   where PID = XLPL.GetPid
				     and (NVL(RECORD_START, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate)
					     or NVL(RECORD_END, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate))
					 and STAGE in (1, 4)
					 and ENTERED_BY = XLPL.User_ID)
  loop
	if (aADDRESS.ADDRESS_TYPE = 1) or (aADDRESS.ADDRESS_TYPE = 3) then
	  if (aADDRESS.aRecord_start is not NULL) and (aADDRESS.aRecord_start > LAST_DAY(S_CurrDate)) then
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := S_Julian(aADDRESS.aRecord_start) - 1;
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := 64;
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := 1;
	  end if;
	  if (aADDRESS.aRecord_end is not NULL) and ((aADDRESS.aRecord_end + 1) > LAST_DAY(S_CurrDate)) then
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := S_Julian(aADDRESS.aRecord_end);
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := 64;
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := 1;
	  end if;
	else
	  if (aADDRESS.aRecord_start is not NULL) and (aADDRESS.aRecord_start > LAST_DAY(S_CurrDate)) then
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := S_Julian(aADDRESS.aRecord_start) - 1;
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := 310;
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := 1;
	  end if;
	  if (aADDRESS.aRecord_end is not NULL) and ((aADDRESS.aRecord_end + 1) > LAST_DAY(S_CurrDate)) then
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := S_Julian(aADDRESS.aRecord_end);
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := 310;
	    chahge_date_aRecord(chahge_date_aRecord.count+1) := 1;
	  end if;
	end if;
  end loop;
return chahge_date_aRecord;
END B_F_ARRAYDATEESTADDRESS;
/
