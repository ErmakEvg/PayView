CREATE FUNCTION       B_COCommittee RETURN NUMBER AS
/**********************************************************************************************
 Функция            : B_COCommittee
 Наименование       : Расчет пособия семье, воспитывающей ребенка старше 3 лет по решению комиссии
 Автор              : ОЛВ                                        согл. Ворошилин В.
 Состояние на дату  : 08.06.2010                                       16.07.2002
 Код возврата       : процент выплаты
***********************************************************************************************/
 --Amount         NUMBER;
 CDMPB40        NUMBER;
 CDMPB50        NUMBER;
 SSD            NUMBER;
 Kod_Father     NUMBER;
 Kod_Parent     NUMBER;
 Kod_Recipient  NUMBER;
 Fl_Comiss      boolean;
 NMask          varchar2(50);

BEGIN
	   --    Определение ролей  в назначении
	   --------------------------------------------
     Kod_Parent:=P_ResP_Role;  -- Родитель (Мать) (Потенциальный получатель)
     Kod_Father:=P_ResP_Role_Father(Kod_Parent);  -- Полная семья или нет
     Kod_Recipient:=P_ResP_Recipient(Kod_Parent,Kod_Father);  -- Получатель
 IF Kod_Recipient=0 THEN    -- В деле нет получателя
   Kod_Recipient:=Kod_Parent;
 END IF;

	   --     Назначение по решению комиссии
	   --------------------------------------------
      Fl_Comiss:=false;
      XLPL.Payment := 0;

	 -- Получатель в назначении
	   XLPL.RoleDecl('Recipient',to_Char(Kod_Recipient));
       XLPL.REPLACEROLE('Recipient');
	   if B_F_RelProtMetricBen('156') then 	   	 	  -- по решению комиссии в полном объеме
     	 XLPL.Payment := 100;     					  -- процент выплаты
		 Fl_Comiss:=true;
	   end if;
	   if B_F_RelProtMetricBen('157') then 	   	 	  -- по решению комиссии в половинном объеме
     	  XLPL.Payment := 50;     					  -- процент выплаты
		 Fl_Comiss:=true;
	   end if;
         XLPL.RestoreRole;

     -- Отец в назначении, если семья полная - в назначении есть Отец (Супруг(а) опекуна)
	 if not Fl_Comiss then
       if (kod_Father<>0) AND (kod_Father<>Kod_Recipient) then
           XLPL.RoleDecl('Father',to_Char(Kod_Father));
           XLPL.REPLACEROLE('Father');
	     if B_F_RelProtMetricBen('156') then 	   	 	  -- по решению комиссии в полном объеме
     	   XLPL.Payment := 100;     					  -- процент выплаты
		   Fl_Comiss:=true;
	     end if;
	     if B_F_RelProtMetricBen('157') then 	   	 	  -- по решению комиссии в половинном объеме
     	    XLPL.Payment := 50;     					  -- процент выплаты
		   Fl_Comiss:=true;
	     end if;
           XLPL.RestoreRole;
	   end if;
	 end if;

     --  Ребенок в назначении
     if not Fl_Comiss then
	   XLPL.RoleDecl('Child','56');
       XLPL.REPLACEROLE('Child');
	   if B_F_RelProtMetricBen('156') then 	   	 	  -- по решению комиссии в полном объеме
     	 XLPL.Payment := 100;     					  -- процент выплаты
	   end if;
	   if B_F_RelProtMetricBen('157') then 	   	 	  -- по решению комиссии в половинном объеме
     	  XLPL.Payment := 50;     					  -- процент выплаты
	   end if;
         XLPL.RestoreRole;
	 end if;

 return XLPL.Payment;

  /*-------------------------------------------------------------*
       Размер пособия - в % от БПМ в среднем на душу населения
  /*-------------------------------------------------------------*
 Amount := S_VRound_Sum(B_CO300, S_Const(40, XLPL.WorkDate));
/* */
  /*-------------------------------------------------------------*
                          Процент выплаты
  /*-------------------------------------------------------------*/

 /* *
 if XLPL.INDIV = 2 then    -- Массовый расчет
    XLPL.Payment := B_F_GETPAYMENTPROCENTINDIV2;     -- процент выплаты

 else                      -- Не массовый расчет
/* */
 --  if XLPL.CheckRole(56) then   -- ?????

  -- else
  --    XLPL.Payment := 0;
     -- Amount := 0;
  -- end if;

  /*-------------------------------------------------------------*
                              Протокол
  /*-------------------------------------------------------------*
   if Fl_Comiss then
	 NMask := LPad('9', length(to_char(Amount)), '9') || '.99';
	 XLPL.S_protocol ('Сумма основного назначения: '|| CHR(9)|| TO_CHAR(Amount, NMask) || CHR (10));
	 XLPL.S_protocol ('Процент выплаты основного назначения:      '    || TO_CHAR(XLPL.Payment) || '%' || CHR (10));
   end if;
 end if;
 return XLPL.Payment;
   /* */


/***************************************************************************************/
/* Функция: B_COCommittee
/* Наименование: Расчет суммы пособия на детей старше 3 лет по решению комиссии
/* Автор: Ворошилин В.
/* Состояние на дату 16.07.2002
/* Код возврата: число с суммой пособия
/***************************************************************************************

b NUMBER;
bool BOOLEAN;

BEGIN

if XLPL.INDIV = 2 then
     XLPL.Payment := B_F_GETPAYMENTPROCENTINDIV2;     -- процент выплаты
 	 XLPL.AMOUNT := B_CO300; 					  	  -- вычислить и вернуть сумму
	 XLPL.SetGlobalfloat('Amount1', XLPL.AMOUNT);
	 return XLPL.AMOUNT;
else
	 b := 0;
	 if XLPL.CheckRole(56) = False then
     	XLPL.Payment := 0;      	   	   			  -- процент выплаты
 	 	XLPL.AMOUNT := 0; 							  -- вычислить и вернуть сумму
	 	XLPL.SetGlobalfloat('Amount1', XLPL.AMOUNT);
	 	return XLPL.AMOUNT;
  	 else
     	XLPL.RoleDecl('Child','56');   				  -- Ребенок в назначении
	 	if XLPL.CheckRole(57) and B_F_RelProtRecipient(57) = False or
	 	   XLPL.CheckRole(69) and B_F_RelProtRecipient(69) = False then
		   XLPL.RoleDecl('Father','57, 69'); 		  -- Отец в назначении
		   b := 1;
	 	end if;
  	 end if;

	 if B_F_RelProtMetricBen('156') then 	   	 	  -- по решению комиссии в полном объеме
     	XLPL.Payment := 100;     					  -- процент выплаты
 	 	XLPL.AMOUNT := B_CO300; 				  	  -- вычислить и вернуть сумму
	 	XLPL.SetGlobalfloat('Amount1', XLPL.AMOUNT);
	 	return XLPL.AMOUNT;
	 end if;
	 if B_F_RelProtMetricBen('157') then 	   	 	  -- по решению комиссии в половинном объеме
     	XLPL.Payment := 50;     					  -- процент выплаты
 	 	XLPL.AMOUNT := B_CO300; 					  -- вычислить и вернуть сумму
	 	XLPL.SetGlobalfloat('Amount1', XLPL.AMOUNT);
	 	return XLPL.AMOUNT;
	 end if;

	 XLPL.REPLACEROLE('Father');
	 if b = 1 then
	    bool := B_F_RelProtMetricBen('156');
	 end if;
	 if b = 1 and bool then 	  		 			  -- по решению комиссии в полном объеме
     	XLPL.Payment := 100;     					  -- процент выплаты
 	 	XLPL.AMOUNT := B_CO300; 				  	  -- вычислить и вернуть сумму
	 	XLPL.SetGlobalfloat('Amount1', XLPL.AMOUNT);
	 	XLPL.RestoreRole;
	 	return XLPL.AMOUNT;
	 end if;
	 if b = 1 then
	 	bool := B_F_RelProtMetricBen('157');
	 end if;
	 if b = 1 and bool then 	  		 			  -- по решению комиссии в половинном объеме
     	XLPL.Payment := 50;     					  -- процент выплаты
 	 	XLPL.AMOUNT := B_CO300; 				  	  -- вычислить и вернуть сумму
	 	XLPL.SetGlobalfloat('Amount1', XLPL.AMOUNT);
	 	XLPL.RestoreRole;
	 	return XLPL.AMOUNT;
	 end if;
	 XLPL.RestoreRole;

	 XLPL.REPLACEROLE('Child');
	 if B_F_RelProtMetricBen('156') then 	  		  -- по решению комиссии в полном объеме
     	XLPL.Payment := 100;     					  -- процент выплаты
 	 	XLPL.AMOUNT := B_CO300; 				  	  -- вычислить и вернуть сумму
	 	XLPL.SetGlobalfloat('Amount1', XLPL.AMOUNT);
	 	XLPL.RestoreRole;
	 	return XLPL.AMOUNT;
	 end if;
	 if B_F_RelProtMetricBen('157') then 	  		  -- по решению комиссии в половинном объеме
     	XLPL.Payment := 50;     					  -- процент выплаты
 	 	XLPL.AMOUNT := B_CO300; 				  	  -- вычислить и вернуть сумму
	 	XLPL.SetGlobalfloat('Amount1', XLPL.AMOUNT);
	 	XLPL.RestoreRole;
	 	return XLPL.AMOUNT;
	 end if;
	 XLPL.RestoreRole;
end if;
XLPL.Payment := 0;      	   	   			  		  -- процент выплаты
XLPL.AMOUNT := 0; 					 	 	  		  -- вычислить и вернуть сумму
XLPL.SetGlobalfloat('Amount1', XLPL.AMOUNT);
return XLPL.AMOUNT;

/* */
END B_COCommittee;
/
