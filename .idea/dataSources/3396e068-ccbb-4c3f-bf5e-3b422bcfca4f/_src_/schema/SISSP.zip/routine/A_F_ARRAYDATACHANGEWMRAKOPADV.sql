CREATE FUNCTION       A_F_ARRAYDATACHANGEWMRAKOPADV (AStartDate IN DATE, AOPINION_TYPE IN BINARY_INTEGER, AADVICE_TYPE IN BINARY_INTEGER, Param6m IN BINARY_INTEGER) RETURN DBMS_SQL.NUMBER_TABLE AS

/*****************************************************************
  Автор: Басинюк Я.В.
  Состояние на 18.05.1999
  Код возврата: массив дат
*****************************************************************/

  xDATES DBMS_SQL.NUMBER_TABLE;
  bufNumber NUMBER;
  vsAOPINION_TYPE VARCHAR2(2000);
  vsAADVICE_TYPE VARCHAR2(2000);
  vsRECORD_START DATE;
  vsRECORD_END DATE;
  vsEXAMED_FROM DATE;
  vsDIS_TERM DATE;
BEGIN
  xDATES.delete;
  if AOPINION_TYPE = -1  then
    vsAOPINION_TYPE := '';
  else
    vsAOPINION_TYPE := TO_CHAR(AOPINION_TYPE);
  end if;
  if AADVICE_TYPE = -1 then
    vsAADVICE_TYPE := '';
  else
    vsAADVICE_TYPE := TO_CHAR(AADVICE_TYPE);
  end if;
  if (Param6m = 1) and (XLPL.AID = 0) then
    select count(*) INTO bufNumber from W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
	where a.PID = XLPL.GetPID
	  and a.ENTERED_BY = XLPL.User_ID
	  and a.STAGE NOT IN (2,3)
	  and b.RID = MRAK_RID
	  and b.ENTERED_BY = MRAK_ENTERED_BY
	  and NVL(NVL(a.RECORD_START, b.EXAMED_FROM), A_F_DataTalk) <= A_F_DataTalk
	  and NVL(NVL(a.RECORD_END,a.DIS_TERM), A_F_DataTalk) >= A_F_DataTalk
	  and OPINION_TYPE = NVL (vsAOPINION_TYPE, OPINION_TYPE) and ((ADVICE_TYPE = NVL (vsAADVICE_TYPE, ADVICE_TYPE))
	   or (ADVICE_TYPE IS NULL and vsAADVICE_TYPE is NULL));
    if bufNumber > 0 then
      xDATES(xDATES.count + 1) := S_JULIAN(TRUNC(A_F_DataTalk, 'Month'));
    end if;
  else
    for MRAKOPADVICE in (select NVL(a.RECORD_START, A_F_CMinDate) as vsRECORD_START,
	                            NVL(a.RECORD_end, A_F_CMinDate) as vsRECORD_END,
								NVL(b.EXAMED_FROM, A_F_CMinDate) as vsEXAMED_FROM,
								NVL(a.DIS_TERM, A_F_CMinDate)	as vsDIS_TERM
						 from W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
						 where a.PID = XLPL.GetPID
						   and a.STAGE NOT IN (2,3)
						   and a.ENTERED_BY = XLPL.User_ID
						   and b.RID = MRAK_RID
						   and b.ENTERED_BY = MRAK_ENTERED_BY
						   and ((NVL(NVL(a.RECORD_START, b.EXAMED_FROM), AStartDate) > AStartDate)
						    or (NVL(NVL(a.RECORD_end,a.DIS_TERM), AStartDate) > AStartDate ))
						   and OPINION_TYPE = NVL (vsAOPINION_TYPE, OPINION_TYPE) and ADVICE_TYPE = NVL (vsAADVICE_TYPE, ADVICE_TYPE))
    loop
      vsRECORD_START := B_F_DATACONVERT(MRAKOPADVICE.vsRECORD_START);
      vsRECORD_end := B_F_DATACONVERT(MRAKOPADVICE.vsRECORD_end);
      vsEXAMED_FROM := B_F_DATACONVERT(MRAKOPADVICE.vsEXAMED_FROM);
      vsDIS_TERM := B_F_DATACONVERT(MRAKOPADVICE.vsDIS_TERM);
      if vsRECORD_START is NULL then
        xDATES(xDATES.count + 1) := S_JULIAN(vsEXAMED_FROM);
      else
        xDATES(xDATES.count + 1) := S_JULIAN(vsRECORD_START);
      end if;
      if (vsDIS_TERM is not NULL) and (vsRECORD_end is NULL) then
        xDATES(xDATES.count + 1) := S_JULIAN(Last_Day(vsDIS_TERM));
      end if;
      if (vsDIS_TERM is NULL) and (vsRECORD_end is not NULL) then
        xDATES(xDATES.count + 1) := S_JULIAN(Last_Day(vsRECORD_end));
      end if;
      if (vsDIS_TERM is not NULL) and (vsRECORD_end is not NULL) then
        xDATES(xDATES.count + 1) := S_JULIAN(Last_Day(vsRECORD_end));
      end if;
    end loop;
  end if;
  return xDATES;
end A_F_ARRAYDATACHANGEWMRAKOPADV;
/
