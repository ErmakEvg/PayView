CREATE FUNCTION       A_F_RelProtDisabilityLAST(aOPINION_TYPE in number,
                                                     aADVICE_TYPE  in VarChar2,
                                                     aDIS_REASON   in VarChar2) RETURN Boolean IS
/***************************************************************************************
 Функция           : A_F_RelProtDisabilityLAST
 Наименование      : Функция возвращает True, если у человека есть указанная причина инвалидности
                     по коду согласно  W$RELATION_PROTOCOL и она является
                     максимальной по дате переосвидетельствования
 Автор             : Боровнева        омментарии и корректирвка: ОЛВ
 Состояние на дату : 01.06.1999                 10.03.2011   12.07.2014
 Код возврата      : логический TRUE - есть указанная причина инвалидности, FALSE - нет
***************************************************************************************/
 DRIDS                 DBMS_SQL.NUMBER_TABLE;
 xADVICE_TYPE          DBMS_SQL.NUMBER_TABLE;
 xDIS_REASON           DBMS_SQL.NUMBER_TABLE;
 vsDRID                Number;
 vsADVICE_TYPE         Number;
 vsDIS_REASON          Number;
 vsExamened_From       date;
 Last_Start_Disability date;

BEGIN
 /* * Параметры :
 - XLPL.WorkDate     - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
 - AOPINION_TYPE     - ТИП ЗАКЛЮЧЕНИЯ МРЭК/ВКК; КОД ВЕРХНЕГО УРОВНЯ
   ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION - 1 - инвалидность (при -1 - игнорируется)
 - при AADVICE_TYPE  - КОД РЕКОМЕНДАЦИИ; КОД НИЖНЕГО УРОВНЯ
   ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION -- 11, 12, 13 = "" игнорируется, иначе - список параметров * */

 vsExamened_From := NULL;
 Last_Start_Disability := NULL; --to_date('01.01.1800','dd.mm.yyyy'); -- ОЛВ закрыла

 -- Группа инвалидности -- 11, 12, 13
 xADVICE_TYPE := S_ParseFloatArray (aADVICE_TYPE);
 -- Причина инвалидности REF_DISABILITY_REASON
 xDis_REASON := S_ParseFloatArray (aDIS_REASON);

 -- RID из W$RELATION_PROTOCOL для MRAK_OPINION_ADVICE
 --=======================================================
 DRIDS := A_F_RelProtGetRIDMrakOpAdvice (1,AOPINION_TYPE);

 -- EXAMED_FROM из MRAK_OPINION_ADVICE
 ------------------------------------------------------
 if DRIDS.count <> 0  THEN
    for i in 1..DRIDS.count loop
         vsDRID := DRIDS(i);
       BEGIN
            SELECT EXAMED_FROM
           INTO vsExamened_From
           FROM MRAK_OPINION_ADVICE a, MRAK_OPINION b
          WHERE a.RID = vsDRID
            AND b.RID = MRAK_RID
            AND NVL (b.RECORD_END,XLPL.WorkDate) >= XLPL.WorkDate -- OLV 12.07.2014
            AND NVL (NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate
            AND NVL (NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate) >= XLPL.WorkDate;

         IF (Last_Start_Disability IS NULL) OR (Last_Start_Disability < vsExamened_From) THEN
            Last_Start_Disability := vsExamened_From;
          END IF;
       EXCEPTION
          WHEN No_Data_Found THEN null;
       END;
  END LOOP;
 END IF;

 IF Last_Start_Disability IS NOT NULL THEN
 -- ADVICE_TYPE, DIS_REASON из MRAK_OPINION_ADVICE
 ------------------------------------------------------
   IF DRIDS.count <> 0 THEN
     FOR i in 1..DRIDS.count loop
         vsDRID := DRIDS(i);
       BEGIN
           SELECT ADVICE_TYPE, DIS_REASON
           INTO vsADVICE_TYPE, vsDIS_REASON
           FROM MRAK_OPINION_ADVICE a, MRAK_OPINION b
          WHERE a.RID = vsDRID
              AND b.RID = MRAK_RID
             AND b.EXAMED_FROM = Last_Start_Disability
            AND NVL (b.RECORD_END,XLPL.WorkDate) >= XLPL.WorkDate -- OLV 12.07.2014
             AND NVL (NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate
            AND NVL (NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate) >= XLPL.WorkDate;

         IF xADVICE_TYPE.count = 0 THEN  -- не заданы коды нижнего уровня
            -- Причина инвалидности REF_DISABILITY_REASON
            FOR l in 1..xDIS_REASON.count loop
                IF xDIS_REASON(l) = vsDIS_REASON then
                   return true;
                END IF;
            END LOOP;
         ELSE
            -- КОД РЕКОМЕНДАЦИИ; КОД НИЖНЕГО УРОВНЯ ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION -- 11, 12, 13
            FOR m in 1..xADVICE_TYPE.count loop
               -- Причина инвалидности REF_DISABILITY_REASON
                 FOR l in 1..xDIS_REASON.count loop
                  IF (xDIS_REASON(l)= vsDIS_REASON) AND (xADVICE_TYPE(m) = vsADVICE_TYPE) THEN
                     return true;
                  END IF;
               END LOOP;
            END LOOP;
         END IF;

       EXCEPTION
          WHEN No_Data_Found THEN null;
       END;
     END LOOP;
   END IF; -- IF DRIDS.count <> 0
 END IF;   -- IF Last_Start_Disability IS NOT NULL

 -- RID из W$RELATION_PROTOCOL для w$MRAK_OPINION_ADVICE
 --=======================================================

 DRIDS := A_F_RelProtGetRIDMrakOpAdvice (0,AOPINION_TYPE);

 -- EXAMED_FROM из W$MRAK_OPINION_ADVICE
 ------------------------------------------------------
 if DRIDS.count <> 0  THEN
    for i in 1..DRIDS.count loop
          vsDRID := DRIDS(i);
       BEGIN
            SELECT EXAMED_FROM
           INTO vsExamened_From
            FROM W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
             WHERE a.RID = vsDRID
               AND a.ENTERED_BY = XLPL.USER_ID
             AND b.RID = MRAK_RID
             AND b.ENTERED_BY = MRAK_ENTERED_BY
            AND a.ENTERED_BY = xlpl.User_ID
            AND b.ENTERED_BY = xlpl.User_ID
            AND NVL (b.RECORD_END,XLPL.WorkDate) >= XLPL.WorkDate -- OLV 12.07.2014
             AND NVL (NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate
             AND NVL (NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate) >= XLPL.WorkDate;

         IF (Last_Start_Disability IS NULL) OR (Last_Start_Disability < vsExamened_From) THEN
             Last_Start_Disability := vsExamened_From;
         END IF;
       EXCEPTION
          WHEN No_Data_Found THEN null;
       END;
   END LOOP;
 END IF;

 IF Last_Start_Disability IS NOT NULL THEN
 -- ADVICE_TYPE, DIS_REASON из W$MRAK_OPINION_ADVICE
 ------------------------------------------------------
   IF DRIDS.count <> 0 THEN
     FOR i in 1..DRIDS.count loop
         vsDRID := DRIDS(i);
        BEGIN
--RAISE_APPLICATION_ERROR(-20004,'ggggggggggggggg'  );
           SELECT ADVICE_TYPE, DIS_REASON
           INTO vsADVICE_TYPE, vsDIS_REASON
           FROM W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
          WHERE a.RID = vsDRID
              AND b.RID = MRAK_RID
            AND b.ENTERED_BY = MRAK_ENTERED_BY
            AND a.ENTERED_BY = xlpl.User_ID
            AND b.ENTERED_BY = xlpl.User_ID
             AND b.EXAMED_FROM = Last_Start_Disability
            AND NVL (b.RECORD_END,XLPL.WorkDate) >= XLPL.WorkDate -- OLV 12.07.2014
             AND NVL (NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate
             AND NVL (NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate) >= XLPL.WorkDate;
--RAISE_APPLICATION_ERROR(-20004,'ggggggggggggggg' || xlpl.ALLOC_CODE );
         IF xADVICE_TYPE.count = 0 THEN  -- не заданы коды нижнего уровня
            -- Причина инвалидности REF_DISABILITY_REASON
            FOR l in 1..xDIS_REASON.count loop
                IF xDIS_REASON(l) = vsDIS_REASON then
                   return true;
                END IF;
            END LOOP;
         ELSE
         -- КОД РЕКОМЕНДАЦИИ; КОД НИЖНЕГО УРОВНЯ ИЗ КЛАССИФИКАТОРА REF_MRAK_OPINION -- 11, 12, 13
            FOR m in 1..xADVICE_TYPE.count loop
               -- Причина инвалидности REF_DISABILITY_REASON
                 FOR l in 1..xDIS_REASON.count loop
                  IF (xDIS_REASON(l)= vsDIS_REASON) AND (xADVICE_TYPE(m) = vsADVICE_TYPE) THEN
                     return true;
                  END IF;
               END LOOP;
            END LOOP;
         END IF;

       EXCEPTION
          WHEN No_Data_Found THEN null;
       END;
     END LOOP;
   END IF; -- IF DRIDS.count <> 0
 END IF;   -- IF Last_Start_Disability IS NOT NULL

 return false;

END A_F_RelProtDisabilityLAST;
/
