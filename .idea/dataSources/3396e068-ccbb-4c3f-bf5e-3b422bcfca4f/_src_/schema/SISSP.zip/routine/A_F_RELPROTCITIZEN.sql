CREATE FUNCTION       A_F_RelProtCITIZEN RETURN NUMBER IS
/**********************************************************************************************
 Функция            : A_F_RelProtCITIZEN
 Наименование       : Функция определения гражданства   IZ_CITIZEN из W$PERSON
 Автор              : ОЛВ                                       согл. Вахромин О.Ю.
 Состояние на дату  : 24.09.2010   21.03.2012
 Код возврата       : Код гражданства : 1 - РБ, 2 - РФ
***********************************************************************************************/
 vsCITIZEN     NUMBER;
BEGIN
  vsCITIZEN:=0;
 IF (Xlpl.INDIV <>2) then -- не массовый расчет -- 21.03.2012
   -- Выбрать адрес в РБД IZ_CITIZEN из W$PERSON
    vsCITIZEN:=A_F_RelProtGetCITIZEN(0);
 else
   -- Выбрать адрес в ОБД IZ_CITIZEN из PERSON
     vsCITIZEN:=A_F_RelProtGetCITIZEN(1);
 end if;
 if vsCITIZEN=-1 then
      vsCITIZEN:=0;  -- запись о гражданстве будет всегда = 1/ 2 /....
 end if;
 return vsCITIZEN;
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtCITIZEN   222   vsCITIZEN='||vsCITIZEN);
/* *
  vsCITIZEN:=0;
 -- Выбрать адрес в ОБД IZ_CITIZEN из PERSON
 vsCITIZEN:=A_F_RelProtGetCITIZEN(1);
 if vsCITIZEN=-1 then
    -- Выбрать адрес в РБД IZ_CITIZEN из W$PERSON
    vsCITIZEN:=A_F_RelProtGetCITIZEN(0);
   if vsCITIZEN=-1 then
      vsCITIZEN:=0;  -- запись о гражданстве будет всегда = 1/ 2 /....
    end if;
 end if;
 return vsCITIZEN;

/* */
END A_F_RelProtCITIZEN;
/
