CREATE FUNCTION       A_Calc_Nperiod_G_SA (rej IN NUMBER, rpid IN NUMBER,  dkon IN DATE, rpolzov IN NUMBER) RETURN VARCHAR2 IS
   --- Якимова С.А. 28.07.09
-- Функция подсчета начала-конца периода для ввода заработной платы для госслужащих
summdn NUMBER:=0;
KOLMES  NUMBER:=0;
KOL  NUMBER:=0;
n NUMBER;
datkon DATE;
nach DATE;
kolz NUMBER;

--- для выборки периодов работы госслужащим для подсчета коэффициента
CURSOR lab IS SELECT  W$FACTOR_LABOR.PERIOD_START,W$FACTOR_LABOR.PERIOD_END,
 T_CALCPERIOD(W$FACTOR_LABOR.PERIOD_END,W$FACTOR_LABOR.PERIOD_START)dn
 FROM  W$FACTOR_LABOR,LABOR_GROUP
 WHERE  W$FACTOR_LABOR.PID=rpid and W$FACTOR_LABOR.ENTERED_BY=rpolzov
 and LABOR_GROUP.GROUP_CODE=2 and W$FACTOR_LABOR.LABOR_CODE=LABOR_GROUP.CODE
and W$FACTOR_LABOR.stage in (1,4)and
W$FACTOR_LABOR.LABOR_CODE not in (SELECT LABOR_TYPE.code FROM LABOR_GROUP,LABOR_TYPE
WHERE  LABOR_GROUP.CODE  =LABOR_TYPE.code AND LABOR_GROUP.GROUP_CODE=6 AND SYSTEM_FLAG=1)
 ORDER BY   period_end DESC;
  cur_lab lab%ROWTYPE;

 CURSOR isklr IS    SELECT  TO_DATE(SUBSTR( W$PERIOD_INCLUDE.value,0,10))  PERIOD_START,
 TO_DATE(SUBSTR( W$PERIOD_INCLUDE.value,14,10))  PERIOD_END,
 T_CALCPERIOD(TO_DATE(SUBSTR( W$PERIOD_INCLUDE.value,14,10)),TO_DATE(SUBSTR( W$PERIOD_INCLUDE.value,0,10)) )dn
 FROM W$PERIOD_INCLUDE WHERE W$PERIOD_INCLUDE.pid=rpid AND   W$PERIOD_INCLUDE.ENTERED_BY=rpolzov
 AND W$PERIOD_INCLUDE.PR_INCLUDE=0  ORDER BY 2 DESC;
  cur_isklr isklr%ROWTYPE;


  CURSOR iskla IS  SELECT W$LABOR.PERIOD_START, W$LABOR.PERIOD_END, T_CALCPERIOD(W$LABOR.PERIOD_END,W$LABOR.PERIOD_START)dn
  FROM LABOR_GROUP,LABOR_TYPE,W$LABOR
WHERE  LABOR_GROUP.CODE  =LABOR_TYPE.code AND LABOR_GROUP.GROUP_CODE=6 AND SYSTEM_FLAG=1
AND pid=rpid AND W$LABOR.ENTERED_BY=rpolzov AND W$LABOR.LABOR_TYPE=LABOR_TYPE.code
and W$LABOR.ENTERED_BY=rpolzov
UNION
SELECT TO_DATE(SUBSTR(W$PERIOD_DELETE.VALUE,0,10))  PERIOD_START,
TO_DATE(SUBSTR(W$PERIOD_DELETE.VALUE,14,10))  PERIOD_END,
 T_CALCPERIOD(TO_DATE(SUBSTR(W$PERIOD_DELETE.VALUE,14,10)),TO_DATE(SUBSTR(W$PERIOD_DELETE.VALUE,0,10)))dn

FROM W$PERIOD_DELETE WHERE PID=rpid  AND PR_VKL=0
 ORDER BY   period_end DESC;
  cur_iskla iskla%ROWTYPE;

BEGIN
--RAISE_APPLICATION_ERROR(-20004, 'ffff='||kolmes);
   SELECT COUNT(*) INTO kolz FROM  W$FACTOR_LABOR,LABOR_GROUP
 WHERE  W$FACTOR_LABOR.PID=rpid and W$FACTOR_LABOR.ENTERED_BY=rpolzov
 and LABOR_GROUP.GROUP_CODE=2 and W$FACTOR_LABOR.LABOR_CODE=LABOR_GROUP.CODE
and W$FACTOR_LABOR.stage in (1,4) and
W$FACTOR_LABOR.LABOR_CODE not in (SELECT LABOR_TYPE.code FROM LABOR_GROUP,LABOR_TYPE
WHERE  LABOR_GROUP.CODE  =LABOR_TYPE.code AND LABOR_GROUP.GROUP_CODE=6 AND SYSTEM_FLAG=1);
IF kolz<>0 THEN
  --длина периода расчета
  kolmes:=S_Const(518,dkon);
 ---RAISE_APPLICATION_ERROR(-20004, 'ffff='||kolmes);
  	 --- kolmes - необходимая длина периода
 OPEN lab;
 n:=1;
 LOOP
  	  FETCH lab INTO cur_lab;
           EXIT WHEN lab%NOTFOUND;
 IF n=1 THEN
   datkon:=cur_lab.period_end;
	 	END IF;
 IF summdn+cur_lab.dn>(kolmes*(((365*3)+366)/48)) THEN
 	 -- сколько не хватает?
 		summdn:=summdn+cur_lab.dn;
 	kol:=summdn-(kolmes*(((365*3)+366)/48));
 	nach:=cur_lab.period_start+kol;
  EXIT;
 ELSIF summdn=(kolmes*(((365*3)+366)/48)) THEN
  nach:=cur_lab.period_start;
  ELSIF summdn+cur_lab.dn<(kolmes*(((365*3)+366)/48))AND kolz=n THEN
  nach:=cur_lab.period_start;
   ELSE
 	summdn:=summdn+cur_lab.dn;
 	END IF;
	n:=n+1;
 END LOOP;
 CLOSE lab;

---RAISE_APPLICATION_ERROR(-20004,'fff'||nach);
--- nach - дата начала периода без исключенных месяцев
-- если режим ручной, то надо сдвинуть только на исключаемые периоды
 IF rej=1 THEN
 n:=0;
 SELECT COUNT(*) INTO n FROM W$PERIOD_INCLUDE WHERE W$PERIOD_INCLUDE.pid=rpid AND   W$PERIOD_INCLUDE.ENTERED_BY=rpolzov
 AND W$PERIOD_INCLUDE.PR_INCLUDE=0  ;
 IF n<>0 THEN
 OPEN isklr;
 n:=1;
 LOOP
  	  FETCH isklr INTO cur_isklr;
           EXIT WHEN isklr%NOTFOUND;
 -- проверяем, входит ли исключаемый период в расчитанный период
 IF cur_isklr.PERIOD_START>=NACH AND cur_isklr.PERIOD_END<=DATKON THEN
-- ВХОДИТ
-- от даты - количество дней исключаемого периода, т.е. сдвигаемся вправо
Nach:=nach-cur_isklr.dn;
 	ELSIF cur_isklr.PERIOD_END<=DATKON AND cur_isklr.PERIOD_START<nach THEN
--входит частично
-- от даты - количество дней входящего исключаемого периода, т.е. сдвигаемся вправо
nach:=nach-(cur_isklr.dn-(cur_isklr.PERIOD_END-nach));
 	END IF;
 		 END LOOP;
CLOSE isklr;
END IF;
 ELSE
 	-- если режим автоматический, то надо сдвинуть на исключаемые периоды, которые есть в базе
n:=0;
 SELECT COUNT(*) INTO n FROM (SELECT W$LABOR.PERIOD_START
  FROM LABOR_GROUP,LABOR_TYPE,W$LABOR
WHERE  LABOR_GROUP.CODE  =LABOR_TYPE.code AND LABOR_GROUP.GROUP_CODE=6 AND SYSTEM_FLAG=1
AND pid=rpid AND W$LABOR.ENTERED_BY=rpolzov AND W$LABOR.LABOR_TYPE=LABOR_TYPE.code
UNION
SELECT TO_DATE(SUBSTR(W$PERIOD_DELETE.VALUE,0,10))  PERIOD_START
FROM W$PERIOD_DELETE WHERE PID=rpid  AND PR_VKL=0);
IF n<>0 THEN
 OPEN iskla;
 LOOP
  	  FETCH iskla INTO cur_iskla;
           EXIT WHEN iskla%NOTFOUND;
 -- проверяем, входит ли исключаемый период в расчитанный период
 IF cur_iskla.PERIOD_START>=NACH AND cur_iskla.PERIOD_END<=DATKON THEN
-- ВХОДИТ
-- от даты - количество дней исключаемого периода, т.е. сдвигаемся вправо
Nach:=nach-cur_iskla.dn;
 	ELSIF cur_iskla.PERIOD_END<=DATKON AND cur_iskla.PERIOD_START<nach THEN
--входит частично
-- от даты - количество дней входящего исключаемого периода, т.е. сдвигаемся вправо
nach:=nach-(cur_iskla.dn-(cur_iskla.PERIOD_END-nach));
 	END IF;
 		 END LOOP;
CLOSE iskla;
END IF;
  END IF;
--RAISE_APPLICATION_ERROR(-20004,TO_CHAR(NACH,'DD.MM.RRRR')||TO_CHAR(DATKON,'DD.MM.RRRR'));
  RETURN 'с '||TO_CHAR(NACH,'DD.MM.RRRR')||' по '||TO_CHAR(DATKON,'DD.MM.RRRR');
  ELSE
  RETURN ' ';
  END IF;
END;
/
