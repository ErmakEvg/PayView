CREATE FUNCTION       A_F_RelProtRestHome_F(AORGANISATION_CODE in number)
   RETURN BOOLEAN IS
/*******************************************************************************
 NAME              : A_F_RelProtRest_Home_F
 Наименование      : Функция определяет проживает ли человек
                     в детском доме семейного типа по коду этой организации
                      пока не объединят под одним родительским кодом !!!!!!
 Автор             : ОЛВ
 Состояние на дату : 19.02.2015
 Код возврата      : TRUE или FALSE
********************************************************************************/
 vsDRID  number;
 vsCOUNT number;

BEGIN
   vsDRID:=A_F_RelProtGetRIDAddress(1,2);
   begin
      if vsDRID<>-1 then
         SELECT a.code_establishment
           into vsCOUNT
           from address a
          where a.rid=vsDRID
            AND a.STAGE Is Null
            AND XLPL.WORKDATE between NVL(a.RECORD_START,XLPL.WORKDATE)
                                  AND NVL(a.RECORD_END,XLPL.WORKDATE);
      else
         vsDRID:=A_F_RelProtGetRIDAddress(0,2);

         SELECT a.code_establishment
           into vsCOUNT
           from W$address a
          where a.rid=vsDRID
            AND a.STAGE in (1,4)
            AND a.ENTERED_BY=XLPL.USER_ID
            AND XLPL.WORKDATE between NVL(a.RECORD_START,XLPL.WORKDATE)
                                  AND NVL(a.RECORD_END,XLPL.WORKDATE);
      end if;
   exception
      when No_Data_Found then
         return FALSE;
   end;
   if vsCOUNT=AORGANISATION_CODE then
      return TRUE;
   else
      return FALSE;
   end if;
--RAISE_APPLICATION_ERROR(-20004,' A_F_RelProtRestHome_F   vsDRID='||vsDRID||'   vsCOUNT='||vsCOUNT||'   AORGANISATION_CODE='||AORGANISATION_CODE);
END A_F_RelProtRestHome_F;
/
