CREATE FUNCTION       A_F_PERSON_HISTORY (pPID  IN  NUMBER)
RETURN VARCHAR2 IS
/***************************************************************************
  Функция                     :  A_F_PERSON_HISTORY
  Наименование           :  Выбор измененных данных персоны из таблицы
  Автор                         :  Ярошик А.К.
  Состояние на дату  :  10.09.2018

  Название программ  :  psPerson_Inf_Msg2, unPersonHistory
***************************************************************************/
  vCount                    Number;
  vNumRec                Number;
  vModRec                Number;
  vFlMod                   Number;
  vPerson_Modify_1 Varchar2(2000);
  vPerson_Modify     Long;  --varchar2(32000);
  vFam                      Varchar2(50);
  vNam                      Varchar2(50);
  vPat                        Varchar2(50);
  vPol                       Number;
  vPIK                      Varchar2(14);
  vLIK                      Varchar2(14);
  vBirth_Date           Varchar2(14);
  vErrorCode            Number;             -- переменная для хранения кода ошибки
  vErrorText             Varchar2(200);   -- переменная для хранения текста сообщения об ошибке
  Cursor C_PERSON IS   -- выбор данных по таблице персон
    Select tp.SURNAME Fam, tp.NAME Nam, tp.PATNAME Pat,
       tp.PIK, tp.LIK, tp.SEX,
       SISSP.DECODE_GENDER(tp.SEX) POL,
       to_char(tp.BIRTH_DATE, 'dd.mm.yyyy') BIRTH_DATE,
       to_char(tp.ENTRY_DATE, 'dd.mm.yyyy  hh24:mm:ss') ENTRY_DATE,
       ts.SURNAME  || ' ' || ts.NAME || ' ' || ts.PATNAME ORG, ts.USER_ID
    From PERSON tp,
      (Select SURNAME, NAME, PATNAME, USER_ID
       From ORG_SOCIAL_PERSONS) ts
    Where tp.PID= pPID
         and ((tp.STAGE = 2) OR (tp.STAGE IS NULL))
         and tp.ENTERED_BY= ts.USER_ID(+)
    Order By tp.ENTRY_DATE;
BEGIN
  vPerson_Modify_1:= ' ';
  vFlMod:= 0;
  --
  Select count(*) INTO vCount
  From PERSON
  Where PID= pPID
       and ((STAGE = 2) OR (STAGE IS NULL))
  Order By ENTRY_DATE;
  --
  IF vCount = 1 THEN
    vPerson_Modify:= 'Изменения анкетных данных не производились.';
  END IF;
  --
  vNumRec:= 1;
  IF vCount > 1 THEN
    FOR rec1 IN C_PERSON
    LOOP
      IF vNumRec = 1  THEN
        vPerson_Modify:= 'Дата ввода:  ' || rec1.ENTRY_DATE || CHR(10);
        vFam:= rec1.Fam;
        vNam:= rec1.Nam;
        vPat:= rec1.Pat;
        vPol:= rec1.SEX;
        vPik:= rec1.PIK;
        vLik:= rec1.LIK;
        vBirth_Date:= rec1.BIRTH_DATE;
        vPerson_Modify:= vPerson_Modify || 'Фамилия:  ' || rec1.Fam || CHR(10);
        vPerson_Modify:= vPerson_Modify || 'Имя:           ' || rec1.Nam || CHR(10);
        vPerson_Modify:= vPerson_Modify || 'Отчество:  ' || rec1.Pat || CHR(10);
        vPerson_Modify:= vPerson_Modify || 'Пол:           ' || rec1.Pol || CHR(10);
        vPerson_Modify:= vPerson_Modify || 'Страховой номер:                     ' || rec1.PIK || CHR(10);
        vPerson_Modify:= vPerson_Modify || 'Идентификационный номер:  ' || rec1.LIK || CHR(10);
        vPerson_Modify:= vPerson_Modify || 'Дата рождения:  ' || rec1.BIRTH_DATE || CHR(10);
        IF NVL(trim(rec1.ORG ), ' ') = ' ' THEN
          vPerson_Modify:= vPerson_Modify || 'Инспектор отсутствует в БД. ' || CHR(10);
        ELSE
          vPerson_Modify:= vPerson_Modify || 'Инспектор:  ' || rec1.ORG || CHR(10);
        END IF;
        vPerson_Modify:= vPerson_Modify || '******************************************************************' || CHR(10);
      ELSE
        vModRec:= 0;
        vPerson_Modify_1:=  'Дата изменения:  ' || rec1.ENTRY_DATE || CHR(10);
      END IF;
      IF NVL(trim(vFam), ' ') <> NVL(trim(rec1.Fam), ' ') THEN
        vModRec:= 1;
        vPerson_Modify_1:= vPerson_Modify_1 || 'Фамилия: ' || rec1.Fam || CHR(10);
      END IF;
      IF NVL(trim(vNam), ' ') <> NVL(trim(rec1.Nam), ' ') THEN
        vModRec:= 1;
        vPerson_Modify_1:= vPerson_Modify_1 || 'Имя:           ' || rec1.Nam || CHR(10);
      END IF;
      IF NVL(trim(vPat), ' ') <> NVL(trim(rec1.Pat), ' ') THEN
        vModRec:= 1;
        vPerson_Modify_1:= vPerson_Modify_1 || 'Отчество:  ' || rec1.Pat || CHR(10);
      END IF;
      IF NVL(vPol, 0) <> NVL(rec1.Sex, 0) THEN
        vModRec:= 1;
        vPerson_Modify_1:= vPerson_Modify_1 || 'Пол:           ' || rec1.Pol || CHR(10);
      END IF;
      IF NVL(trim(vPik), ' ') <> NVL(trim(rec1.PIK), ' ') THEN
        vModRec:= 1;
        vPerson_Modify_1:= vPerson_Modify_1 || 'Страховой номер:                     ' || rec1.PIK || CHR(10);
      END IF;
      IF NVL(trim(vLik), ' ') <> NVL(trim(rec1.LIK), ' ') THEN
        vModRec:= 1;
        vPerson_Modify_1:= vPerson_Modify_1 || 'Идентификационный номер:  ' || rec1.LIK || CHR(10);
      END IF;
      IF NVL(trim(vBirth_Date), ' ') <> NVL(trim(rec1.BIRTH_DATE), ' ') THEN
        vModRec:= 1;
        vPerson_Modify_1:= vPerson_Modify_1 || 'Дата рождения:  ' || rec1.BIRTH_DATE || CHR(10);
      END IF;
      IF vModRec > 0  THEN
        IF NVL(trim(rec1.ORG ), ' ') = ' ' THEN
          vPerson_Modify_1:= vPerson_Modify_1 || 'Инспектор отсутствует в БД. ' || CHR(10);
        ELSE
          vPerson_Modify_1:= vPerson_Modify_1 || 'Инспектор:  ' || rec1.ORG || CHR(10);
        END IF;
        vPerson_Modify_1:= vPerson_Modify_1 || '******************************************************************' || CHR(10);
        vPerson_Modify:= vPerson_Modify || vPerson_Modify_1;
      END IF;
      vFam:= rec1.Fam;
      vNam:= rec1.Nam;
      vPat:= rec1.Pat;
      vPol:= rec1.SEX;
      vPik:= rec1.PIK;
      vLik:= rec1.LIK;
      vBirth_Date:= rec1.BIRTH_DATE;
      vNumRec:= vNumRec+ 1;
      IF vModRec = 1  THEN
        vFlMod:= 1;
      END IF;
    END LOOP;
  END IF;
  -- Если данные были сохранены в БД без их изменения
  --
  IF vFlMod = 0  THEN
    vPerson_Modify:= 'Изменения анкетных данных не производились.';
  END IF;
  --
  RETURN vPerson_Modify;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
      vErrorCode := SQLCODE;
      vErrorText := substr(SQLERRM,1,200);
      --raise_application_error(-20001, v_ErrorText);
      RETURN '';
    WHEN OTHERS THEN
      vErrorCode := SQLCODE;
      vErrorText := substr(SQLERRM,1,200);
      --raise_application_error(-20001, SQLCODE || ': ' || SQLERRM);
      --raise_application_error(-20001, v_ErrorText);
      RETURN '';
END A_F_PERSON_HISTORY;
/
