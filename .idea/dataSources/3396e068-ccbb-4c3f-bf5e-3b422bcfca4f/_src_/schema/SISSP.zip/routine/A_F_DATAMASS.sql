CREATE FUNCTION       A_F_DataMass RETURN Date IS
/******************************************************************************
 Функция             : A_F_DataMass
 Наименование        : Функция получения даты последнего массового расчета
 Автор               : ОЛВ
 Состояние на дату   : 05.09.2014
 Код возврата        : Дата последнего массового расчета
*******************************************************************************/
 vCalc_Date   date;
BEGIN
 BEGIN
   SELECT mp.Calc_Date INTO vCalc_Date
     FROM M$MASS_PREFERENCE mp, W$CASE c
    WHERE mp.dept_id = c.dept_id
      AND mp.END_YTV is not NULL
      AND c.stage in (1,4)
      AND c.cid= XLPL.CID;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
    vCalc_Date:=XLPL.WorkDate; --NULL;
 END;
   return vCalc_Date;
END A_F_DataMass;
/
