CREATE FUNCTION       A_F_Relprot_INTERNPACT RETURN NUMBER IS
/*******************************************************************************
 NAME              : A_F_Relprot_RESIDING
 Назначение        : Возращает сумму пенсии, полученную за границей
 Автор             : ОЛВ
 Состояние на дату : 17.03.2014
 Код возврата      : Amount из PENSION_INTERNPACT
*******************************************************************************/
 vAmount         NUMBER;
BEGIN
 IF (Xlpl.INDIV <>2) then -- не массовый расчет
   -- Выбрать в РБД из W$PENSION_INTERNPACT
    vAmount:=A_F_RelprotGetINTERNPACT(0);
 else
   -- Выбрать в ОБД из PENSION_INTERNPACT
     vAmount:=A_F_RelprotGetINTERNPACT(1);
 end if;
 if vAmount=-1 then
      vAmount:=null;--0;
 end if;
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelprotGetINTERNPACT 2 Amount='||vAmount);
 return vAmount;

END A_F_Relprot_INTERNPACT;
/
