CREATE FUNCTION       A_F_ArrayDataChangeDelDup(pArray in DBMS_SQL.NUMBER_Table)
   RETURN DBMS_SQL.NUMBER_Table IS
/*Удаляет нулевые элементы из массива и сортирует по возрастанию
Вахромин О.Ю.*/
xDATA DBMS_SQL.NUMBER_Table;
rData DBMS_SQL.NUMBER_Table;
vsR number;
BEGIN
   xDATA.delete;
   rData.delete;
   if pArray.count=0 then
      return rData;
   end if;
   for i in 1..pArray.count loop
      if pArray(i) is not NULL then
         xDATA(xDATA.count+1):=pArray(i);
      end if;
   end loop;
   for i in 1..xData.count-1 loop
      for l in i+1..xData.count loop
         if xData(i)>xData(l) then
            vsR:=xData(l);
            xData(l):=xData(i);
            xData(i):=vsR;
         end if;
      end loop;
   end loop;
   if xData.count>0 then
      rData(rData.count+1):=xData(1);
      for i in 2..xData.Count loop
         if xData(i)<>xData(i-1) then
            rData(rData.count+1):=xData(i);
         end if;
      end loop;
   end if;
   return rDATA;
END A_F_ArrayDataChangeDelDup;
/
