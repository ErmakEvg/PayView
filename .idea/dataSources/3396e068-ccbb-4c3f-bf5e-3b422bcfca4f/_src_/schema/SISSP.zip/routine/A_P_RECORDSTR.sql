CREATE FUNCTION       A_P_RecordStr RETURN NUMBER AS
/******************************************************************************
   NAME         : A_P_RecordStr
   Назначение   : Функция определения требуемого страхового стажа
   Автор        : ОЛВ
   Дата         : 10.01.2014...  16.12.2015 20.12.2016 18.12.2017
   Код возврата :
******************************************************************************/
 St_Str        NUMBER;
 date_recalc   DATE;
BEGIN
  IF (Xlpl.CONVER_T = 1) AND (XLPL.AID=0) THEN   --  Для прибывших и конвертированных дел
       IF A_F_Allocstartconvert() >= S_Encodedate(2015,1,1)  -- 15.12.2014 OLV
             AND (XLPL.ALLOC_CODE NOT IN (61,62,63,64,65,66,67,68)
                   AND Xlpl.ADD_BASE_CODE NOT IN (61,62,63,64,65,66,67,68) ) THEN

         IF A_F_Allocstartconvert() >= S_Encodedate(2018,1,1)  THEN  -- 18.12.2017 OLV
               St_Str:=5940;  -- 16 лет 6 месяцев
         ELSE
           IF A_F_Allocstartconvert() >= S_Encodedate(2017,1,1)  THEN  -- 20.12.2016 OLV
               St_Str:=5760;  -- 16 лет
           ELSE
              IF A_F_Allocstartconvert() >= S_Encodedate(2016,1,1)  THEN  -- 16.12.2015 OLV
                St_Str:=5580;  -- 15 лет 6 месяцев
              ELSE
                St_Str:=5400;  -- 15 лет
              END IF;
           END IF;
         END IF;

       ELSE
            IF A_F_Allocstartconvert() >= S_Encodedate(2014,1,1)
                AND (XLPL.ALLOC_CODE NOT IN (61,62,63,64,65,66,67,68)
                      AND Xlpl.ADD_BASE_CODE NOT IN (61,62,63,64,65,66,67,68) ) THEN -- Перерасчет -- 20.06.2014 ОЛВ
              St_Str:=3600;  -- 10 лет
            ELSE
               IF  (A_F_Allocstartconvert() >= S_Encodedate(2006,8,1)) THEN
                  St_Str:=1800;  -- 5 лет -- необходимый страховой стаж для назначения
               ELSE
                  IF   (A_F_Allocstartconvert() >= S_Encodedate(1998,9,1))  THEN
                     St_Str :=1;   -- наличие страхового стажа
                  ELSE
                     St_Str :=0;
                  END IF;
               END IF;
            END IF;
       END IF;
  ELSE                    --  Для новых дел и перерасчета
     IF XLPL.AID<>0 THEN -- перерасчет
       IF A_P_Start_Allocation = Xlpl.WorkDate then -- 30.12.2014 перевод на новое
               -- дата обращения за назначением
                 date_recalc:=A_F_Datatalk();
           IF (Xlpl.WorkDate >= TO_DATE('01-01-2015','DD-MM-YYYY')) -- 15.12.2014 OLV
                   AND (date_recalc >=  TO_DATE('01-01-2015','DD-MM-YYYY'))
                   AND (XLPL.ALLOC_CODE NOT IN (61,62,63,64,65,66,67,68)
                   AND Xlpl.ADD_BASE_CODE NOT IN (61,62,63,64,65,66,67,68) )
                 THEN

              IF (Xlpl.WorkDate >= TO_DATE('01-01-2018','DD-MM-YYYY')) -- 18.12.2017 OLV
               AND (date_recalc >=  TO_DATE('01-01-2018','DD-MM-YYYY')) THEN
                    St_Str:=5940;  -- 16 лет 6 месяцев
              ELSE
                  IF (Xlpl.WorkDate >= TO_DATE('01-01-2017','DD-MM-YYYY')) -- 20.12.2016 OLV
                      AND (date_recalc >=  TO_DATE('01-01-2017','DD-MM-YYYY')) THEN
                    St_Str:=5760;  -- 16 лет
                  ELSE
                    IF (Xlpl.WorkDate >= TO_DATE('01-01-2016','DD-MM-YYYY')) -- 16.12.2015 OLV
                      AND (date_recalc >=  TO_DATE('01-01-2016','DD-MM-YYYY')) THEN
                      St_Str:=5580;  -- 15 лет 6 месяцев
                    ELSE
                      St_Str:=5400;  -- 15 лет
                    END IF;
                  END IF;
              END IF;
           ELSE
                  IF (Xlpl.WorkDate >= TO_DATE('01-01-2014','DD-MM-YYYY'))
                      -- 16.06.2014 OLV--AND XLPL.ALLOC_CODE NOT IN (61,62,63,64,65,66,67,68)
                      AND (XLPL.ALLOC_CODE NOT IN (61,62,63,64,65,66,67,68)
                       AND Xlpl.ADD_BASE_CODE NOT IN (61,62,63,64,65,66,67,68) ) -- 17.06.2014 ОЛВ
                    THEN
                     St_Str:=3600;  -- 10 лет
                  ELSE
                    IF Xlpl.WorkDate >= TO_DATE('01-08-2006','DD-MM-YYYY') THEN    --OLV 09.03.2010
                       St_Str:=1800;  -- 5 лет -- необходимый страховой стаж для назначения
                    ELSE
                       St_Str:=1;
                    END IF;
                  END IF;
           END IF;

       ELSE
              -- перерасчет
         IF (A_P_Start_Allocation >= S_Encodedate(2015,01,01) -- 15.12.2014 OLV
                  AND (XLPL.ALLOC_CODE NOT IN (61,62,63,64,65,66,67,68)
                      AND Xlpl.ADD_BASE_CODE NOT IN (61,62,63,64,65,66,67,68) ) )
                      THEN
           IF (A_P_Start_Allocation >= S_Encodedate(2018,01,01))  THEN  -- 18.12.2017 OLV
                    St_Str:=5940;  -- 16 лет 6 месяцев
           ELSE
                IF (A_P_Start_Allocation >= S_Encodedate(2017,01,01))  THEN  -- 20.12.2016 OLV
                    St_Str:=5760;  -- 16 лет
                ELSE
                  IF (A_P_Start_Allocation >= S_Encodedate(2016,01,01))  THEN  -- 16.12.2015 OLV
                    St_Str:=5580;  -- 15 лет 6 месяцев
                  ELSE
                    St_Str:=5400;  -- 15 лет
                  END IF;
                END IF;
           END IF;

         ELSE

           IF  (A_P_Start_Allocation >= S_Encodedate(2014,01,01)
                     AND (XLPL.ALLOC_CODE NOT IN (61,62,63,64,65,66,67,68)
                     AND Xlpl.ADD_BASE_CODE NOT IN (61,62,63,64,65,66,67,68) ) ) THEN -- Перерасчет -- 20.06.2014 ОЛВ
                      St_Str:=3600;  -- 10 лет
           ELSE
                     IF  (A_P_Start_Allocation >= S_Encodedate(2006,08,01)) THEN -- Перерасчет
                        St_Str:=1800;  -- 5 лет
                     ELSE
                        IF  (A_P_Start_Allocation >= S_Encodedate(1998,09,01)) THEN -- Перерасчет
                           St_Str:=1;  -- 5 лет
                        ELSE
                           St_Str:=0;
                        END IF;
                     END IF;
           END IF;
         END IF;
       END IF;

     ELSE
         -- дата обращения за назначением
         date_recalc:=A_F_Datatalk();
       IF (Xlpl.WorkDate >= TO_DATE('01-01-2015','DD-MM-YYYY')) -- 15.12.2014 OLV
             AND (date_recalc >=  TO_DATE('01-01-2015','DD-MM-YYYY'))
             AND (XLPL.ALLOC_CODE NOT IN (61,62,63,64,65,66,67,68)
                   AND Xlpl.ADD_BASE_CODE NOT IN (61,62,63,64,65,66,67,68) )
             THEN
         IF (Xlpl.WorkDate >= TO_DATE('01-01-2018','DD-MM-YYYY'))   -- 18.12.2017 OLV
                      AND (date_recalc >=  TO_DATE('01-01-2018','DD-MM-YYYY')) THEN
                    St_Str:=5940;  -- 16 лет 6 месяцев
         ELSE
                IF (Xlpl.WorkDate >= TO_DATE('01-01-2017','DD-MM-YYYY'))   -- 20.12.2016 OLV
                      AND (date_recalc >=  TO_DATE('01-01-2017','DD-MM-YYYY')) THEN
                    St_Str:=5760;  -- 16 лет
                ELSE
                   IF (Xlpl.WorkDate >= TO_DATE('01-01-2016','DD-MM-YYYY')) -- 16.12.2015 OLV
                      AND (date_recalc >=  TO_DATE('01-01-2016','DD-MM-YYYY')) THEN
                      St_Str:=5580;  -- 15 лет 6 месяцев
                   ELSE
                      St_Str:=5400;  -- 15 лет
                   END IF;
                END IF;
         END IF;
       ELSE
              IF (Xlpl.WorkDate >= TO_DATE('01-01-2014','DD-MM-YYYY'))
                   AND (XLPL.ALLOC_CODE NOT IN (61,62,63,64,65,66,67,68)
                   AND Xlpl.ADD_BASE_CODE NOT IN (61,62,63,64,65,66,67,68) ) -- 17.06.2014 ОЛВ
                THEN
                  St_Str:=3600;  -- 10 лет
              ELSE
                 IF Xlpl.WorkDate >= TO_DATE('01-08-2006','DD-MM-YYYY') THEN    --OLV 09.03.2010
                    St_Str:=1800;  -- 5 лет -- необходимый страховой стаж для назначения
                 ELSE
                    St_Str:=1;
                 END IF;
              END IF;
       END IF;
     END IF;
  END IF;
  RETURN St_Str;
/**if xlpl.cid=40901051846 then
  RAISE_APPLICATION_ERROR(-20801,'A_P_RecordStr:   44444  Xlpl.CONVER_T='||Xlpl.CONVER_T||'  XLPL.AID='||XLPL.AID||'   St_Str='||St_Str);
end if;/**/
END A_P_RecordStr;
/
