CREATE FUNCTION       A_F_DataDisabilitySPK(pPID in NUMBER) RETURN Date IS
/******************************************************************************
 Функция             : A_F_DataDisabilitySPK
 Наименование        : Функция получения даты окончания инвалидности у иждивенца
 Автор               : ОЛВ
 Состояние на дату   : 18.03.2011    12.09.2014
 Код возврата        : Дата окончания предыдущей инвалидности
*******************************************************************************/
 End_Disability   date;
BEGIN
  End_Disability := NULL;
      BEGIN
             Select max(b.DIS_TERM)  -- max() 12.09.2014 OLV
			   INTO End_Disability
			   From W$MRAK_OPINION a,W$MRAK_OPINION_ADVICE b
              Where a.PID = pPID --XLPL.GETPID
			    and b.MRAK_RID = a.rid
				and a.ENTERED_BY = XLPL.USER_ID
				and b.ENTERED_BY = XLPL.USER_ID
                and b.advice_type in (11,12,13,14) --Group_Inv  		 -- номер группы инвалидности
				AND b.dis_reason IN (4,5,6,15)
				and b.opinion_type = 1		                  		 -- инвалидность
				and a.STAGE in (1,4)
				and a.RECORD_END is not null;
     EXCEPTION
        WHEN NO_DATA_FOUND THEN
            End_Disability := NULL;
     END;
   /* *
 raise_application_error(-20004,'A_F_DataDisability    '||CHR(10)||'  Date_talk='||aDate_talk||'   pPID='||aPID
 ||'   Start_Disability ='||Start_Disability
 ||'   Date_Alloc_Restor='||aDate_Alloc_Restore); /* */


   return End_Disability;
END A_F_DataDisabilitySPK;
/
