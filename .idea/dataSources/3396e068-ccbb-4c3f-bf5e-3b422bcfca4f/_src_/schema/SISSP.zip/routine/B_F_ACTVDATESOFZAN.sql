CREATE FUNCTION       B_F_ActvDatesOfZan RETURN DBMS_SQL.Number_Table AS
/**********************************************************************************************
 Функция            : B_F_ActvDatesOfZan
 Наименование       : Функция определяет даты начала занятости уходом, дающей право на пособия в ОСЗ
 Автор              : ОЛВ                        согл. Ворошилин В.
 Состояние на дату  : 28.07.10                              11.11.1999
 Код возврата       : массив
***********************************************************************************************/
 A           DBMS_SQL.Number_Table;
 BDay        DATE;
 StartDateBD DATE;
 Dt          DATE;
BEGIN
    A.Delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CHECKROLE(56) then
	return A;
  end if;

  XLPL.REPLACEROLE('Child');
    BDay := S_Birthdate(XLPL.BASE_ID, XLPL.GetPid, XLPL.WorkDate);
  XLPL.RESTOREROLE;

 -- 401 - Ограничение возраста ребенка для пособия по уходу за ребенком в возрасте до 3 лет - в годах
  StartDateBD := S_AddYears(BDay, TRUNC(S_Const(401, XLPL.WorkDate))) + 1;  -- 3 года + 1 день

 -- 478 - Дата начала действия пособий на детей старше 3 лет (01.01) - в числовом виде дата 01.01.1997
 -- день и месяц выбираем из справочника, а год - год расчета XLPL.WorkDate -1
  Dt := S_DateConst(478, XLPL.WorkDate);      -- Дата начала действия пособий на детей старше 3 лет (01.01)
  Dt := S_EncodeDate(S_YearOfDate(XLPL.WorkDate), S_MonthOfDate(Dt), S_DayOfDate(Dt));

  -- Дата начала действия
  if (StartDateBD >= Dt) and (StartDateBD <= XLPL.WorkDate) then
   	Dt := StartDateBD;
  end if;

  for ACTSTART in (Select PERIOD_START From W$ACTIVITY
                   Where PID = XLPL.GetPid
				     and ENTERED_BY = XLPL.User_ID
					 and ACTIVITY = 1
					 and LABOR in (313,314)
					 and STAGE NOT IN (2, 3)
					 and PERIOD_START >= Dt
				   ORDER BY PERIOD_START)
  LOOP
    if ACTSTART.PERIOD_START is not NULL then
	  A(A.count+1) := S_Julian(ACTSTART.PERIOD_START);
	end if;
  end LOOP;

  RETURN A;

END B_F_ActvDatesOfZan;
/
