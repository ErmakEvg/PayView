CREATE FUNCTION       A_F_GETROLE RETURN NUMBER AS
/**********************************************************************************************
 Функция            : A_F_GETROLE
 Наименование       : Ф-я определения роли лица в деле из РБД
 Автор              : ОЛВ
 Состояние на дату  : 17.07.2012
 Код возврата       : Возвращает роль лица в деле из РБД
***********************************************************************************************/
 vsRole NUMBER;
BEGIN
    BEGIN
      select ROLE INTO vsRole from W$CASE_PERSON
	  where CID = XLPL.CID
	    and PID = XLPL.GetPid
		and STAGE in (1,4);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vsRole := 0;
      WHEN OTHERS THEN
        vsRole := 0;
    END;
RETURN vsRole;
END A_F_GETROLE;
/
