CREATE FUNCTION       B_F_ControlPersonSDD_SocHelp (aCID in number, prBase in number, aDate in date) RETURN VARCHAR2 IS

/******************************************************************************************
 Функция: B_F_ControlPersonSDD_SocHelp
 Наименование: Состав и число членов семьи, учитываемый при определении СДД (средний душевой доход)
               социальное обслуживание
 Автор: Иванова Т.С.
 Состояние на дату 07.04.2012
 Возвращает: массив PIDов лиц, доход которых учитывается при расчете СДД

 prBase = 0 - работа с РБД
 prBase = 1 - работа с OБД
******************************************************************************************/

PIDsList DBMS_SQL.NUMBER_TABLE;
A DBMS_SQL.NUMBER_TABLE;
aRole NUMBER;
aRelation NUMBER;
aPID NUMBER;
pPID NUMBER;
cnt NUMBER;
i NUMBER;
j NUMBER;
Sur VARCHAR2(30);
Nam VARCHAR2(30);
PatNam VARCHAR2(30);
RetStr VARCHAR2(255);
pDate DATE;
UID number;-- заплатка
pDateEnd Date;
pDateStart Date;
Date1 Date;
BEGIN

cnt := 0;
Sur := '';
Nam := '';
PatNam := '';
i := 0;
j := 1;

PIDsList.delete;
A.delete;

   pDate := aDate;        -- Дата, на которую определяется ССД

---------------------------------------------------
-- Формируем массив данных для каждого лица из дела
---------------------------------------------------
--raise_application_error(-20004,'pDate'||pDate);
if prBase = 0 then                                      -- Работа с РБД
   -- ЗАПЛАТКА ELENA
   SELECT entered_by
   into UID
    from W$case where cid=aCID
   and stage in (1,4);
   XLPL.User_ID:=UID;
   -- ЗАПЛАТКА ELENA end
   select count (*) into cnt
   from W$ALLOCATION
   where cid = aCID;
   if cnt <> 0 then
      for Rec in
            (Select a.PID as aPID,
                      nvl(a.ROLE, 0) as aRole,
                   nvl(a.RELATION, 0) as aRelation
            From   W$CASE_PERSON a, W$PERSON b
            Where  a.CID = aCID and
                   a.PID = b.PID and
--                   a.ENTERED_BY = XLPL.USER_ID and
                   b.ENTERED_BY = XLPL.USER_ID and --ELENA 16.05.2011
                   a.STAGE NOT IN (2,3) and
                   b.STAGE NOT IN( 2,3) and
                   b.BIRTH_DATE <= pDate and
                   (b.DEATH_DATE is null or b.DEATH_DATE > pDate))
      loop
      A(A.count + 1) := Rec.aPID;                    -- PID
      A(A.count + 1) := Rec.aRole;                   -- роль лица в деле
      A(A.count + 1) := Rec.aRelation;                  -- родственные отношения
      if B_SSD_IsRecipient(aPID, aCID) then
           A(A.count + 1) := 1;
      else
         A(A.count + 1) := 0;
      end if; -- 1 - если получатель
        A(A.count + 1) := 0;                                   -- метрики
      A(A.count + 1) := 0;                              --
      A(A.count + 1) := S_julian(pDate);            -- дата возникновения права
      end loop;
    else
      --raise_application_error(-20004,'XLPL.USER_ID='||XLPL.USER_ID);
      for Rec1 in
            (Select a.PID as aPID,
                      nvl(a.ROLE, 0) as aRole,
                   nvl(a.RELATION, 0) as aRelation
            From   W$CASE_PERSON a, W$PERSON b
            Where  a.CID = aCID and
                   a.PID = b.PID and
--                 a.ENTERED_BY = XLPL.USER_ID and
                   b.ENTERED_BY = XLPL.USER_ID and --ELENA 16.05.2011
                   a.STAGE NOT IN (2,3) and
                   b.STAGE NOT IN( 2,3) and
                   (b.DEATH_DATE is null or b.DEATH_DATE > pDate)
           )
      loop
      A(A.count + 1) := Rec1.aPID;                    -- PID
      A(A.count + 1) := Rec1.aRole;                   -- роль лица в деле
      A(A.count + 1) := Rec1.aRelation;              -- родственные отношения
      if B_SSD_IsRecipient(Rec1.aPID, aCID) then
         A(A.count + 1) := 1;
      else
         A(A.count + 1) := 0;
      end if; -- 1 - если получатель
        A(A.count + 1) := 0;                                   -- метрики
      A(A.count + 1) := 0;                              --
      A(A.count + 1) := S_julian(pDate);            -- дата возникновения права
      end loop;
   end if;
else                           -- Работа с ОБД
      for Rec2 in
            (Select a.PID as aPID,
                      nvl(a.ROLE, 0) as aRole,
                   nvl(a.RELATION, 0) as aRelation
            From   CASE_PERSON a, PERSON b
            Where  a.CID = aCID and
                   a.PID = b.PID and
                   b.BIRTH_DATE <= pDate and
                  (b.DEATH_DATE is null or b.DEATH_DATE > pDate) and
                  (a.STAGE is null or a.STAGE NOT IN(2,3)) and
                  (b.STAGE is null or b.STAGE NOT IN(2,3)))
      loop
      A(A.count + 1) := Rec2.aPID;                    -- PID
      A(A.count + 1) := Rec2.aRole;                   -- роль лица в деле
      A(A.count + 1) := Rec2.aRelation;              -- родственные отношения
      if B_SSD_IsORecipient(aPID, aCID) then
           A(A.count + 1) := 1;
      else
           A(A.count + 1) := 0;
      end if; -- 1 - если получатель
        A(A.count + 1) := 0;                                   -- метрики для исключения
      A(A.count + 1) := 0;                                    --
      A(A.count + 1) := S_julian(pDate);            -- дата рождения
      end loop;
end if;

---------------------------------------------------------------------------
-- Выбор требуемых PID, удовлетворяющих Положению о порядке исчисления ССД.
---------------------------------------------------------------------------
if A.count > 0 then
   j := 1;
   for i in 1 .. A.count/7 loop
      if A(j+1) = 0 then
         pPID := A(j);
         if prBase = 0 then
         begin
                Select SURNAME, NAME, PATNAME into Sur, Nam, PatNam
              From   W$PERSON
              Where  PID = pPID and
                     ENTERED_BY = XLPL.USER_ID and
                     STAGE NOT IN(2,3);
         exception
              when No_Data_Found then
                RAISE_APPLICATION_ERROR(-20851,'Лицо c персональным идентификатором '|| to_char(A(j)) || ' отсутствует в деле' || chr(10));
                return RetStr;
              when others then
                RAISE_APPLICATION_ERROR(-20851,'Лицо ' || Sur || ' ' || Nam || ' ' || PatNam || ' не имеет роли.' || chr(10) ||
                'Укажите роль лица в назначении' || chr(10));
                return RetStr;
         end;
        else
             pPID := A(j);
          begin
                Select SURNAME, NAME, PATNAME into Sur, Nam, PatNam
              From   PERSON
              Where  PID = pPID and
                     STAGE is NULL;
          exception
              when No_Data_Found then
                RAISE_APPLICATION_ERROR(-20851,'Лицо c персональным идентификатором '|| to_char(A(j)) || ' отсутствует в деле' || chr(10));
                return RetStr;
              when others then
                RAISE_APPLICATION_ERROR(-20851,'Лицо ' || Sur || ' ' || Nam || ' ' || PatNam || ' не имеет роли.' || chr(10) ||
                'Укажите роль лица в назначении' || chr(10));
                return RetStr;
          end;
        end if;
      end if;
        --raise_application_error(-20004,'J+4'||A(j+5)||A(j));

    PIDsList(PIDsList.count + 1) := A(j);
    j := j + 7;
    end loop;
end if;

---------------------------------------
-- Формирование строки с выбранными PID
---------------------------------------
RetStr := null;
if PIDsList.count > 0 then
   for i in 1 .. PIDsList.count loop
          if RetStr is null then RetStr := to_char(PIDsList(i));
          else RetStr := RetStr || ',' || to_char(PIDsList(i));
       end if;
   end loop;
end if;
--raise_application_error(-20004,'RetStr'||RetStr);
-- dbms_output.PUT_LINE (RetStr);
return RetStr;

END B_F_ControlPersonSDD_SocHelp;
/
