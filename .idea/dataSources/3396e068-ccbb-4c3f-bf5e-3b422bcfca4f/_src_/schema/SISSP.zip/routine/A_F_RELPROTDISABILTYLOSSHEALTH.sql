CREATE FUNCTION       A_F_Relprotdisabiltylosshealth RETURN NUMBER IS
/*******************************************************************************
 Функция           : A_F_RelProtDisabiltyLossHealth
 Наименование      : Функция определяет степень утраты здоровья
 Автор             : Ворошилин В.Я. (РМП)   Корректировка:  OLV
 Состояние на дату :                        21.06.2010  27.11.2012  20.12.2013
 Код возврата      : -1 означает, что информация отсутствует
/*******************************************************************************/
xRID        DBMS_SQL.Number_Table;
i           NUMBER;
k           NUMBER;
curr_RID    NUMBER;
xLossHealth NUMBER;
xWorkDate   DATE;

BEGIN
xLossHealth := -1;
xWorkDate := Xlpl.WORKDATE;
xRID.DELETE;

 --                  ОБД
 --------------------------------------------
    xRID := A_F_Relprotgetridmrakopadvice(1, -1);
    k := xRID.COUNT;
  FOR i IN 1..k LOOP
    curr_RID := xRID(i);
    BEGIN
  	  SELECT NVL(LOSS_HEALTH, -1) INTO xLossHealth
	    FROM MRAK_OPINION_ADVICE a, MRAK_OPINION b
	   WHERE LOSS_HEALTH IS NOT NULL
	     AND NVL(NVL(a.RECORD_START, b.EXAMED_FROM), xWorkDate) <= xWorkDate
         AND NVL(NVL(a.RECORD_END, b.RECORD_END), xWorkDate) >= xWorkDate -- 20.12.2013 ОЛВ
         -- 20.12.2013 ОЛВ --AND NVL(NVL(a.RECORD_END, a.DIS_TERM), xWorkDate) >= xWorkDate
	     AND b.RID = a.MRAK_RID
	     AND a.RID = curr_RID;

	  -- ОЛВ 21.06.2010 - если есть уход - идет в цикле дальше и дает xLossHealth := -1
	  IF xLossHealth>0 THEN
             --RAISE_APPLICATION_ERROR(-20004,' A_F_RelProtDisabiltyLossHealth  xLossHealth='||xLossHealth);
	    RETURN xLossHealth;
      END IF;
      /* */
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        xLossHealth := -1;
    END;
  END LOOP;

IF xLossHealth = -1 THEN
  xRID.DELETE;
 --                  РБД
 --------------------------------------------
    xRID := A_F_Relprotgetridmrakopadvice(0, -1);
    k := xRID.COUNT;
  FOR i IN 1..k LOOP
    curr_RID := xRID(i);
    BEGIN
      SELECT NVL(LOSS_HEALTH, -1) INTO xLossHealth
	    FROM W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
	   WHERE a.LOSS_HEALTH IS NOT NULL
	     AND NVL(NVL(a.RECORD_START,b.EXAMED_FROM), xWorkDate) <= xWorkDate
	     AND NVL(NVL(a.RECORD_END,b.RECORD_END), xWorkDate) >= xWorkDate -- 20.12.2013 ОЛВ
         -- 20.12.2013 ОЛВ --AND NVL(NVL(a.RECORD_END,a.DIS_TERM), xWorkDate) >= xWorkDate
         AND a.entered_by = Xlpl.USER_ID -- 27.11.2012 OLV
         AND b.entered_by = Xlpl.USER_ID -- 27.11.2012 OLV
	     AND b.RID = a.MRAK_RID
	     AND a.RID = curr_RID;
	  /* ОЛВ 21.06.2010 - если есть уход - идет в цикле дальше и дает xLossHealth := -1*/
	  IF xLossHealth>0 THEN
             --RAISE_APPLICATION_ERROR(-20004,' A_F_RelProtDisabiltyLossHealth  xLossHealth='||xLossHealth);
	    RETURN xLossHealth;
      END IF;
      /* */
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        xLossHealth := -1;
    END;
	/* */
  END LOOP;
END IF;

RETURN xLossHealth;

END A_F_Relprotdisabiltylosshealth;
/
