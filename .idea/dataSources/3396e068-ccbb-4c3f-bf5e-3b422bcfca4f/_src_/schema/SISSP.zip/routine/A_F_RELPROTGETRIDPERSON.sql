CREATE FUNCTION       A_F_RelProtGetRidPerson(Base_ID in Number) RETURN NUMBER AS
/*Возращает RID из W$PERSON (PERSON) для заданного PID согласно W$RELATION_PROTOCOL
Вахромин О.Ю.*/
vsRelation_Table number;
vsDRid NUMBER;
BEGIN
   vsDRid:=-1;
   if Base_ID=0 then
      vsRelation_Table:=S_CodeTableSissp('W$PERSON');
   else
      vsRelation_Table:=S_CodeTableSissp('PERSON');
   end if;
   BEGIN

      if Base_ID=0 then
         select DATA_RID into vsDRID from W$RELATION_PROTOCOL b,W$PERSON a where
            CID=XLPL.Cid and (Aid=XLPL.Aid or XLPL.Aid=0) and
            (GROUP_NO=XLPL.Group_No or (XLPL.Aid<>0 and XLPL.Group_No=0)) and
            ALLOC_CODE=XLPL.Alloc_Code and
            RELATION_TABLE=vsRelation_Table and RELATION_DATE=XLPL.WorkDate
			and b.ENTERED_BY=XLPL.User_ID
			and a.ENTERED_BY=XLPL.User_ID  -- elena 16.05.2011
			and DATA_RID=a.RID and
            XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WorkDate) and
            NVL(a.RECORD_END,XLPL.WorkDate) and a.PID=XLPL.GetPid;
			-- RAISE_APPLICATION_ERROR(-20851,'A_F_RelProtGetRidPerson  ');
  --- RAISE_APPLICATION_ERROR(-20851,'A_F_RelProtGetRidPerson  '||'  XLPL.WorkDate'||XLPL.WorkDate
  -- ||' XLPL.Aid'||XLPL.Aid||'  XLPL.User_ID'||XLPL.User_ID||'  XLPL.GetPid'||XLPL.GetPid
   --  );
      else
         select DATA_RID into vsDRID from W$RELATION_PROTOCOL b,PERSON a where
            CID=XLPL.Cid and (Aid=XLPL.Aid or XLPL.Aid=0) and
            (GROUP_NO=XLPL.Group_No or (XLPL.Aid<>0 and XLPL.Group_No=0)) and
            ALLOC_CODE=XLPL.Alloc_Code and
            RELATION_TABLE=vsRelation_Table and RELATION_DATE=XLPL.WorkDate
			and b.ENTERED_BY=XLPL.User_ID
			and DATA_RID=a.RID and
            XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WorkDate) and
            NVL(a.RECORD_END,XLPL.WorkDate) and a.PID=XLPL.GetPid;
      end if;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         vsDRid:=-1;
   END;
   RETURN vsDRid;
END A_F_RelProtGetRidPerson;
/
