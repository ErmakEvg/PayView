CREATE FUNCTION       A_F_RelprotgetMinDef(Base_ID IN NUMBER) RETURN NUMBER AS
/******************************************************************************
 NAME              : A_F_RelprotgetMinDef
 Назначение        : Возращает сумму пенсии, полученную по линии МО
 Автор             : ОЛВ
 Состояние на дату : 01.12.2014
 Код возврата      : Amount из PENSION_MINISTRY_DEFENSE
*******************************************************************************/
 vAmount        NUMBER;
 xWorkDate      DATE;
BEGIN
 BEGIN
   vAmount:=0;
   xWorkDate := Xlpl.WorkDate;
   IF Base_ID=0 THEN
         SELECT NVL(Amount,-1)
           INTO vAmount
           FROM W$PENSION_MINISTRY_DEFENSE
          WHERE PID = Xlpl.GetPid
            AND STAGE in (1,4)
            AND ENTERED_BY=Xlpl.USER_ID --
            AND xWorkDate BETWEEN
                 NVL(START_DATE,xWorkDate) AND NVL(END_DATE,xWorkDate);
   ELSE
         SELECT NVL(Amount,-1)
           INTO vAmount
           FROM PENSION_MINISTRY_DEFENSE
          WHERE PID = Xlpl.GetPid
            AND STAGE IS NULL
            AND xWorkDate BETWEEN
                 NVL(START_DATE,xWorkDate) AND NVL(END_DATE,xWorkDate);
   END IF;

   EXCEPTION
      WHEN TOO_MANY_ROWS OR NO_DATA_FOUND THEN
         vAmount:=-1;
   END;
   RETURN vAmount;
END A_F_RelprotgetMinDef;
/
