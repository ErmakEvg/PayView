CREATE FUNCTION       A_F_Translate_Disability(pr_mindate IN NUMBER) RETURN DATE IS
/******************************************************************************
 NAME         : A_F_Translate_Disability
 Назначение   : Функция возвращает дату начала дейсвия следующей инвалидности
 Автор        : Вахромин О.Ю.                     Комментарии  : ОЛВ
 Дата         :					  			  		   03.03.2011   13.04.2011
 Код возврата : Возвращает дату начала дейсвия следующей инвалидности
******************************************************************************/
 Old_Start_Dis    DATE;
 Old_Examed_From  DATE;
 Old_End_Dis      DATE;
 New_Start_Dis    DATE;
 New_End_Dis      DATE;

BEGIN
 -- pr_mindate=1 из P_MINDATERECALC_INV
 -- pr_mindate=0 из P_StepArrayPensAge

 -- ОЛВ 03.03.2011  -- ?????????
 BEGIN
      -- Из действующей информации (скопирована из ОБД, изменения не проводились)
      SELECT a.EXAMED_FROM, NVL(a.REEXAM_DATE,XLPL.WorkDate), b.DIS_TERM
	    INTO Old_Examed_From,						 -- начало освидетельствования
		     Old_Start_Dis,							 -- дата освидетельствования
			 Old_End_Dis							 -- инвалидность на срок
		FROM W$MRAK_OPINION a, W$MRAK_OPINION_ADVICE b
	   WHERE a.PID=XLPL.GetPID
	     AND b.MRAK_RID=a.rid
		 AND b.advice_type IN (11,12,13)
		 AND b.opinion_type=1
		 AND b.stage=1		  			 		      -- Информация действует - =2 - не правильно -- OLV 13.04.2011
		 AND b.entered_by=XLPL.User_Id
		 AND a.entered_by=XLPL.User_Id
		 AND a.EXAMED_FROM=
              -- Из действующей информации
              ( SELECT MAX(c.EXAMED_FROM)			 -- начало освидетельствования
			      FROM W$MRAK_OPINION c, W$MRAK_OPINION_ADVICE d
				 WHERE c.PID=XLPL.GetPID
				   AND c.EXAMED_FROM<=XLPL.WorkDate
				   AND d.MRAK_RID=c.rid
				   AND d.advice_type IN (11,12,13)
				   AND d.opinion_type=1
				   AND d.stage=1				     -- Информация действует - =2 - не правильно -- OLV 13.04.2011
				   AND d.entered_by=XLPL.User_Id
				   AND c.entered_by=XLPL.User_Id);
     BEGIN
	     -- Из новой информации (информация введена с клавиатуры)
         SELECT a.EXAMED_FROM, b.DIS_TERM
		   INTO New_Start_Dis, 			  		     -- начало освидетельствования
		        New_End_Dis						     -- инвалидность на срок
		   FROM W$MRAK_OPINION a, W$MRAK_OPINION_ADVICE b
		  WHERE a.PID=XLPL.GetPID
		    AND b.MRAK_RID=a.rid
		    AND b.advice_type IN (11,12,13)
		    AND b.opinion_type=1
		    AND b.stage=4
		    AND b.entered_by=XLPL.User_Id
		    AND a.entered_by=XLPL.User_Id
		    AND a.EXAMED_FROM=			  			 -- начало освидетельствования
	              -- Из новой информации
                  (SELECT MIN(c.EXAMED_FROM)
				     FROM W$MRAK_OPINION c, W$MRAK_OPINION_ADVICE d
					WHERE c.PID=XLPL.GetPID
					  AND c.EXAMED_FROM>Old_Examed_From
					  AND d.MRAK_RID=c.rid
					  AND d.advice_type IN (11,12,13)
					  AND d.opinion_type=1
					  AND d.stage=4		   			  -- Новая информация
					  AND d.entered_by=XLPL.User_Id
					  AND c.entered_by=XLPL.User_Id);
--raise_application_error(-20004,'A_F_Translate_Disability  111   New_Start_Dis='|| New_Start_Dis||'  XLPL.WorkDate='||XLPL.WorkDate||'   Old_End_Dis='||Old_End_Dis);

		 -- из P_MINDATERECALC_INV - pr_mindate=1
		 IF (pr_mindate=1) AND (XLPL.WorkDate < New_Start_Dis) THEN
             RETURN XLPL.WorkDate;
         END IF;

         IF (S_MonthsBetween(LAST_DAY(Old_End_Dis)+1,LAST_DAY(New_Start_Dis)+1)>=1) OR
		     (Old_End_Dis IS NULL) THEN
             RETURN New_Start_Dis;
		 ELSE
		    IF (S_MonthsBetween(LAST_DAY(Old_End_Dis)+1,LAST_DAY(New_Start_Dis)+1)=0) THEN
                RETURN LAST_DAY(Old_End_Dis)+1;
            ELSE
                RETURN LAST_DAY(XLPL.WorkDate)+1;
            END IF;
         END IF;
 	 EXCEPTION
          WHEN NO_DATA_FOUND THEN
--raise_application_error(-20004,'A_F_Translate_Disability  222   New_Start_Dis='|| New_Start_Dis||'  XLPL.WorkDate='||XLPL.WorkDate||'   Old_End_Dis='||Old_End_Dis);
             RETURN XLPL.WorkDate;-- LastDayOfMonth(WorkDate)+1;
     END; -- под вопросом

 EXCEPTION
      WHEN NO_DATA_FOUND THEN
--raise_application_error(-20004,'A_F_Translate_Disability  333   New_Start_Dis='|| New_Start_Dis||'  XLPL.GetPID='||XLPL.GetPID||'   Old_End_Dis='||Old_End_Dis);
          BEGIN
		     -- Из новой информации (информация введена с клавиатуры)
             SELECT a.EXAMED_FROM, b.DIS_TERM
			   INTO New_Start_Dis, 			         -- начало освидетельствования
			        New_End_Dis						 -- инвалидность на срок
			   FROM W$MRAK_OPINION a, W$MRAK_OPINION_ADVICE b
			  WHERE a.PID=XLPL.GetPID
			    AND b.MRAK_RID=a.rid
			    AND b.advice_type IN (11,12,13)
			    AND b.opinion_type=1
			    AND b.stage=4
			    AND a.entered_by=XLPL.User_Id
			    AND b.entered_by=XLPL.User_Id
			    AND a.EXAMED_FROM=			  		 -- начало освидетельствования
				     -- Из новой информации
	                 ( SELECT MIN(c.EXAMED_FROM)
				         FROM W$MRAK_OPINION c, W$MRAK_OPINION_ADVICE d
					    WHERE c.PID=XLPL.GetPID
					      AND d.MRAK_RID=c.rid
					      AND c.EXAMED_FROM>Old_Examed_From
					  	  AND d.advice_type IN (11,12,13)
					      AND d.stage=4
						  AND d.opinion_type=1
						  AND c.entered_by=XLPL.User_Id
						  AND d.entered_by=XLPL.User_Id );

             RETURN LAST_DAY(XLPL.WorkDate)+1;
          EXCEPTION
             WHEN NO_DATA_FOUND THEN
--raise_application_error(-20004,'A_F_Translate_Disability  333   New_Start_Dis='|| New_Start_Dis||'  XLPL.WorkDate='||XLPL.WorkDate||'   Old_End_Dis='||Old_End_Dis);
                RETURN XLPL.WorkDate;
          END;
 END;
  RETURN XLPL.WorkDate;

/*Возвращает дату начала дейсвия следующей инвалидности
Вахромин О.Ю.*
Old_Start_Dis date;
Old_Examed_From date;
Old_End_Dis date;
New_Start_Dis date;
New_End_Dis date;
BEGIN
   begin
      Select a.EXAMED_FROM,nvl(a.REEXAM_DATE,XLPL.WorkDate),b.DIS_TERM into
         Old_Examed_From,Old_Start_Dis,Old_End_Dis From
         W$MRAK_OPINION a,W$MRAK_OPINION_ADVICE b Where
         a.PID=XLPL.GetPID and b.MRAK_RID=a.rid and b.advice_type in (11,12,13) and
         b.opinion_type=1 and b.stage=1 and a.entered_by=XLPL.User_Id and
         b.entered_by=XLPL.User_Id and a.EXAMED_FROM=
         (Select max(c.EXAMED_FROM) from W$MRAK_OPINION c,W$MRAK_OPINION_ADVICE d Where
            c.PID=XLPL.GetPID and d.MRAK_RID=c.rid and c.EXAMED_FROM<=XLPL.WorkDate and
            d.advice_type in (11,12,13) and d.stage=1 and d.opinion_type=1 and
            c.entered_by=XLPL.User_Id and d.entered_by=XLPL.User_Id);
      begin
         Select a.EXAMED_FROM,b.DIS_TERM into New_Start_Dis,New_End_Dis From
            W$MRAK_OPINION a,W$MRAK_OPINION_ADVICE b Where
            a.PID=XLPL.GetPID and b.MRAK_RID=a.rid and b.advice_type in (11,12,13) and
            b.opinion_type=1 and b.stage=4 and a.entered_by=XLPL.User_Id and
            b.entered_by=XLPL.User_Id and a.EXAMED_FROM=
            (Select min(c.EXAMED_FROM) From W$MRAK_OPINION c,W$MRAK_OPINION_ADVICE d where
            c.PID=XLPL.GetPID and d.MRAK_RID=c.rid and c.EXAMED_FROM>Old_Examed_From and
            d.advice_type in (11,12,13) and d.stage=4 and d.opinion_type=1 and
            c.entered_by=XLPL.User_Id and d.entered_by=XLPL.User_Id);
		  if (pr_mindate=1)and(XLPL.WorkDate<New_Start_Dis) then
             return XLPL.WorkDate;
          end if;
          if (S_MonthsBetween(Last_Day(Old_End_Dis)+1,Last_Day(New_Start_Dis)+1)>=1)or
		     (Old_End_Dis is NULL) then
             return New_Start_Dis;
		  else
		     if (S_MonthsBetween(Last_Day(Old_End_Dis)+1,Last_Day(New_Start_Dis)+1)=0) then
                return Last_Day(Old_End_Dis)+1;
             else
                return Last_Day(XLPL.WorkDate)+1;
             end if;
          end if;
       exception
          when NO_DATA_FOUND then
             return XLPL.WorkDate;-- LastDayOfMonth(WorkDate)+1;
       end; -- под вопросом
    exception
       when NO_DATA_FOUND then
          begin
             Select a.EXAMED_FROM,b.DIS_TERM into New_Start_Dis, New_End_Dis From
                W$MRAK_OPINION a,W$MRAK_OPINION_ADVICE b Where
                a.PID=XLPL.GetPID and b.MRAK_RID=a.rid and b.advice_type in (11,12,13) and
                b.opinion_type=1 and b.stage=4 and a.entered_by=XLPL.User_Id and
                b.entered_by=XLPL.User_Id and a.EXAMED_FROM=
                (Select min(c.EXAMED_FROM) From W$MRAK_OPINION c,W$MRAK_OPINION_ADVICE d Where
                c.PID=XLPL.GetPID and d.MRAK_RID=c.rid and c.EXAMED_FROM>Old_Examed_From and
                d.advice_type in (11,12,13) and d.stage=4 and d.opinion_type=1 and
                c.entered_by=XLPL.User_Id and d.entered_by=XLPL.User_Id);
             return Last_Day(XLPL.WorkDate)+1;
          exception
             when NO_DATA_FOUND then
                return XLPL.WorkDate;
          end;
    end;
    return XLPL.WorkDate;
	/* */
END A_F_Translate_Disability;
/
