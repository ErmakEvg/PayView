CREATE FUNCTION       B_F_DISABIL_11_12_END_PAST RETURN date IS
/***************************************************************************************
 Функция             :  B_F_DISABIL_11_12_END_PAST
 Наименование        :  Функция возвращает  max дату окончания действия инвалидности
                        1,2 группы до даты  проверки права по  ГАСП 751
 Автор               :  Абрамович М.В.
 Состояние на дату   :  01.02.2017
 Код возврата        :  дата окончания действия инвалидности
***************************************************************************************/
 Disability_End    date default  null;
 pRecord_End       date default  null;
 pRecord_End_MRAK  date default  null;
 pReexam_Date      date default  null;
 pDis_Term         date default  null;
 maxDisability_End      date default  null;
BEGIN
        FOR Rec IN(
         select nvl(a.Record_End, null) as pRecord_End,
                nvl(b.Record_End, null) as pRecord_End_MRAK,
                nvl(a.DIS_TERM, null) as pDis_Term,
                nvl(b.REEXAM_DATE, null) as pReexam_Date
          from W$MRAK_OPN_ADVICE a, W$MRAK_OPN b
          where a.CID = XLPL.CID and a.CID = b.CID
            and a.PID = XLPL.GETPID AND b.PID = a.PID
            and a.OPINION_TYPE = 1  and a.ADVICE_TYPE in (11,12)
            and b.RID = a.MRAK_RID
            and NVL (b.RECORD_END,XLPL.WorkDate) <= XLPL.WorkDate -- OLV 29.03.2012
            and NVL (NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate
            and NVL (NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate) <= XLPL.WorkDate
            and a.entered_by = XLPL.User_ID
            and b.entered_by = XLPL.User_ID
            and a.stage in (1,4) and b.stage in (1,4)
            )
       LOOP
         if (REC.pRecord_End is null) AND (REC.pRecord_End_MRAK is null)
             AND (REC.pDis_Term is null) AND (REC.pReexam_Date is null) then
             Disability_End := null;
         else
         if (REC.pRecord_End_MRAK is not null) and (REC.pReexam_Date is not null) then
            Disability_End:=REC.pRecord_End_MRAK;
         end if;
         if(REC.pRecord_End is not null) then
            Disability_End:=REC.pRecord_End;
         else
            if REC.pDis_Term is not null and  REC.pReexam_Date is null then
              Disability_End := REC.pDis_Term;
            else
               if REC.pDis_Term is  null and  REC.pReexam_Date is not null then
                   Disability_End := REC.pReexam_Date;
               else
                  if REC.pDis_Term >= REC.pReexam_Date  then
                      Disability_End := REC.pDis_Term;
                  else
                      Disability_End := REC.pReexam_Date;
                  end if;
               end if;
            end if;
         end if;
        end if;
         if Disability_End is not NULL then
          if (maxDisability_End is null) or (maxDisability_End < Disability_End) then
                maxDisability_End:= Disability_End;
             end if;
         end if;
       end loop;

       if maxDisability_End is null then --ищем по ОБД
        FOR Rec IN(
         select nvl(a.Record_End, null) as pRecord_End,
                nvl(b.Record_End, null) as pRecord_End_MRAK,
                nvl(a.DIS_TERM, null) as pDis_Term,
                nvl(b.REEXAM_DATE, null) as pReexam_Date
          from MRAK_OPN_ADVICE a, MRAK_OPN b
          where a.CID = XLPL.CID and a.CID = b.CID
            and a.PID = XLPL.GETPID AND b.PID = a.PID
            and a.OPINION_TYPE = 1  and a.ADVICE_TYPE in (11,12)
            and b.RID = a.MRAK_RID
            and NVL (b.RECORD_END,XLPL.WorkDate) <= XLPL.WorkDate -- OLV 29.03.2012
            and NVL (NVL(a.RECORD_START,b.EXAMED_FROM),XLPL.WorkDate) <= XLPL.WorkDate
            and NVL (NVL(a.RECORD_END,a.DIS_TERM),XLPL.WorkDate) <= XLPL.WorkDate
            and a.stage is null and b.stage is NULL)

       LOOP
         if (REC.pRecord_End is null) AND (REC.pRecord_End_MRAK is null)
             AND (REC.pDis_Term is null) AND (REC.pReexam_Date is null) then
             Disability_End := null;
         else
         if (REC.pRecord_End_MRAK is not null) and (REC.pReexam_Date is not null) then
            Disability_End:=REC.pRecord_End_MRAK;
         end if;
         if(REC.pRecord_End is not null) then
            Disability_End:=REC.pRecord_End;
         else
            if REC.pDis_Term is not null and  REC.pReexam_Date is null then
              Disability_End := REC.pDis_Term;
            else
               if REC.pDis_Term is  null and  REC.pReexam_Date is not null then
                   Disability_End := REC.pReexam_Date;
               else
                  if REC.pDis_Term >= REC.pReexam_Date  then
                      Disability_End := REC.pDis_Term;
                  else
                      Disability_End := REC.pReexam_Date;
                  end if;
               end if;
            end if;
         end if;
        end if;
         if Disability_End is not NULL then
          if (maxDisability_End is null) or (maxDisability_End < Disability_End) then
                maxDisability_End:= Disability_End;
             end if;
         end if;
       end loop;
       end if; --OBD
  return maxDisability_End;
END B_F_DISABIL_11_12_END_PAST;
/
