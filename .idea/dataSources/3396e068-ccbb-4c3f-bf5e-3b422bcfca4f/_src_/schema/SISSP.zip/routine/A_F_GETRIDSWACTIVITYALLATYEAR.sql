CREATE FUNCTION       A_F_GetRidsWActivityAllAtYear(aRelation_Date in DATE,
     aActivity in NUMBER,
     aLabor in NUMBER,
     aDismissal_Reason in DBMS_SQL.Number_Table) RETURN DBMS_SQL.Number_Table IS
--==============================================================================
-- Назначение: возращает массив RID-ов по условию для W$ACTIVITY
--------------------------------------------------------------------------------
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Входные праметры:
---------------------
-- если aLabor = -1, то данный параметр не учитывается
--==============================================================================

xResume DBMS_SQL.Number_Table;
xPID NUMBER;
xUser NUMBER;
i NUMBER;
k NUMBER;

BEGIN
xPID := XLPL.GETPID;
xUser := XLPL.USER_ID;
xResume.Delete;
k := aDismissal_Reason.Count;
if aLabor = -1 then -- параметр aLabor не учитывается
  FOR cRec1 IN (select RID, NVL(DISMISSAL_REASON, -1) as D_REASON
                from W$ACTIVITY
                where PID = xPID
				and ENTERED_BY = xUser
				and STAGE in (1,4)
				and W$ACTIVITY.ACTIVITY = aActivity
				and ((TRUNC(NVL(PERIOD_START, aRelation_Date), 'YEAR')
			                         <= TRUNC(aRelation_Date, 'YEAR')) and
					 (TRUNC(NVL (PERIOD_END, aRelation_Date), 'YEAR')
				                     >= TRUNC(aRelation_Date, 'YEAR'))))
  LOOP
    if k = 0 then
	  xResume(xResume.Count + 1) := cRec1.RID;
	else
      FOR i IN 1..k LOOP
	    if cRec1.D_REASON = aDismissal_Reason(i) then
    	  xResume(xResume.Count + 1) := cRec1.RID;
        end if;
	  END LOOP;
    end if;
  END LOOP;
else
  FOR cRec2 IN (select RID, NVL(DISMISSAL_REASON, -1) as D_REASON
                from W$ACTIVITY
                where PID = xPID
				and ENTERED_BY = xUser
				and STAGE in (1,4)
				and ACTIVITY = aActivity
				and LABOR = aLabor
				and ((TRUNC(NVL (PERIOD_START, aRelation_Date), 'YEAR')
				                     <= TRUNC(aRelation_Date,'YEAR')) and
				     (TRUNC(NVL (PERIOD_END, aRelation_Date), 'YEAR')
					                 >= TRUNC(aRelation_Date, 'YEAR'))))
  LOOP
    if k = 0 then
	  xResume(xResume.Count + 1) := cRec2.RID;
	else
      FOR i IN 1..k LOOP
	    if cRec2.D_REASON = aDismissal_Reason(i) then
    	  xResume(xResume.Count + 1) := cRec2.RID;
        end if;
	  END LOOP;
    end if;
  END LOOP;
end if;
RETURN xResume;
END A_F_GetRidsWActivityAllAtYear;
/
