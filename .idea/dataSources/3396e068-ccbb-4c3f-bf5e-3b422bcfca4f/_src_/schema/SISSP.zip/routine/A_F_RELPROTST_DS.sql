CREATE FUNCTION       A_F_Relprotst_Ds(rAlloc_Code IN NUMBER, N_Age  IN NUMBER)  RETURN BOOLEAN IS
/************************************************************************************
 NAME           : P_Result_DS
 Назначение   : Функция проверки наличия cтажа работы необходимого
                        для ежемесячного содержания отдельным категориям гос. служащих
 Автор            :  ОЛВ
 Дата              : 03.06.2009
 Код возврата :  логический True - есть стаж, False - нет стажа
*************************************************************************************/
  StopDate      DATE;
  --N_Age          NUMBER;        -- базовый возраст для выхода на пенсию
  N_SpSt        NUMBER;          -- необходимый стаж работы для назначения
  StSp            NUMBER;          -- стаж работы для назначения
  StSp_S         NUMBER;          -- стаж работы специальный
  Rec              NUMBER;          -- общий стаж

BEGIN

  CASE
    WHEN rAlloc_Code=1216 THEN -- Высш. гос.долж.
      N_SpSt   := 1800;
      StSp_S:=A_F_Relprotrecord(73);
     StSp     := StSp_S+A_F_Relprotrecord(74)+A_F_Relprotrecord(76);

    WHEN rAlloc_Code=1217 THEN -- Зам.высш.гос.долж
      N_SpSt   := 1800;
      StSp_S:=A_F_Relprotrecord(74) ;
     StSp     := A_F_Relprotrecord(73)+StSp_S+A_F_Relprotrecord(76);

    WHEN rAlloc_Code=1218 THEN --  Лица,  осущ. на  проф.основе полн.депутата 1 созыв
      N_SpSt   := 0;           -- так сказала С.А.  и Е.В.
      StSp_S:=A_F_Relprotrecord(75) ;
     StSp     := StSp_S;

    WHEN rAlloc_Code=1219 THEN --  Чл.Пр.РБ
      N_SpSt   := 1800;
      StSp_S:=A_F_Relprotrecord(76) ;
     StSp     := A_F_Relprotrecord(73)+A_F_Relprotrecord(74)+StSp_S;

    WHEN rAlloc_Code=1220 THEN --  Лица,  осущ. на  проф.основе полн.депутата неск. созывов >=5
      N_SpSt   := 1800;
      StSp_S     := A_F_Relprotrecord(77);
	 if A_F_Relprotrecord(80)>StSp_S then
	  StSp_S     := A_F_Relprotrecord(80);
	 end if;
     StSp     := StSp_S;

  END CASE;

  /*  Протокол */
  IF N_Age>0 THEN
    A_P_Protoinf_Ds( N_SpSt,StSp,N_Age);
   END IF;

  IF (StSp_S>0) AND ( StSp >=  N_SpSt) THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;

END A_F_Relprotst_Ds;
/
