CREATE FUNCTION       A_F_RELPROTMETRICEND (ACODE IN BINARY_INTEGER) RETURN DATE AS

/* --------------------------------------------------------------------
// Автор: Басинюк Я.В.
// состояние на 10.05.1999
// Код возврата: возвращает дату конца действия метрики
// человека согласно W$RELATION_PROTOCOL и кода
//     Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
//     ACODES - код метрии
// --------------------------------------------------------------------*/

  xDRIDs DBMS_SQL.NUMBER_TABLE;
  vsDRID NUMBER;
  vsDate DATE;
BEGIN
  xDRIDs.delete;
  BEGIN
    xDRIDs := A_F_RELPROTGETRIDPERSONMETRIC(1, ACODE);
    IF xDRIDs.count = 1 THEN
      vsDRID := xDRIDs(1);
      select RECORD_END INTO vsDate from PERSON_METRIC where RID = vsDRID;
    ELSE
      IF xDRIDs.count > 1 THEN
        raise_application_error(10200, 'F_RelProtMetricEnd: Выбрано больше одной метрики');
      ELSE
        xDRIDs := A_F_RELPROTGETRIDPERSONMETRIC(0, ACODE);
        IF xDRIDs.count = 0 THEN
          raise_application_error(10200, 'Нет данных для кода метрики '||TO_CHAR(ACODE)||' для CID:'||TO_CHAR(XLPL.CID)||' и PID:'||TO_CHAR(XLPL.GetPid)||' на дату '||TO_CHAR(XLPL.WorkDate,'DD.MM.YYYY'));
        ELSE
          IF xDRIDs.count > 1 THEN
            raise_application_error(10200, 'F_RelProtMetricEnd: Выбрано больше одной метрики');
          ELSE
            vsDRID := xDRIDs(1);
            select RECORD_END INTO vsDate from W$PERSON_METRIC where RID = vsDRID and ENTERED_BY = XLPL.User_ID;
          END IF;
        END IF;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      vsDate := NULL;
  END;
  RETURN vsDate;
END A_F_RELPROTMETRICEND;
/
