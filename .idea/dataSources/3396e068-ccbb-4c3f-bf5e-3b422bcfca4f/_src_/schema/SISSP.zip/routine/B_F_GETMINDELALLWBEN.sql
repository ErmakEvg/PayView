CREATE FUNCTION       B_F_GetMinDelAllWBen return DATE is
/*==============================================================================
+ Функция: F_GetMinDelAllWBen
+ Наименование: Определяет min дату окончания действия пообия для лица
+ Автор: Ворошилин В.
+ Состояние на дату 07.05.1999
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 15.07.2002
==============================================================================*/

  result_date date := null;
  alloc_date date;
begin
  alloc_date := B_F_StartDateAllocation();

  begin
    Select min(ALLOCATION_END) into result_date
  	from ALLOCATION a, ALLOCATION_PERSON b, CASE_PERSON c, RECIPIENT d
	where a.RID = b.ALLOCATION_RID
	  and b.PID = XLPL.GetPID
	  and c.PID = b.PID
	  and d.CID = c.CID
	  and d.PID = b.PID
	  and (c.STAGE <> 3 or c.STAGE is NULL)
	  and (a.STAGE <> 3 or a.STAGE is NULL)
	  and (b.STAGE <> 3 or b.STAGE is NULL)
	  and (d.STAGE <> 3 or d.STAGE is NULL)
	  and a.ALLOC_CODE in
	    (select CODE
		 from ALLOCATIONS
		 start with CODE = 2
		 connect by prior CODE = PARENT_CODE);
  exception
    when NO_DATA_FOUND then
      result_date := NULL;
  end;
/*
  if result_date is not null and result_date > alloc_date then
    return result_date;
  else
    return null;
  end if;
*/
return result_date;
end;
/
