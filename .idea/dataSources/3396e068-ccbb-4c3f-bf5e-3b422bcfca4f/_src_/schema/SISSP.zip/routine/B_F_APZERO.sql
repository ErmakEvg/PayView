CREATE FUNCTION       B_F_APZero RETURN BOOLEAN IS
--==============================================================================
-- Назначение: определяет, закрыто или приостановлено назначение
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Возвращаемое значение: False - назначение закрыто или приостановлено  ???
--                        True - назначение действует  ???
--==============================================================================
xResume BOOLEAN;

xBuff DBMS_SQL.Number_Table;
xCID NUMBER;
xAID NUMBER;
xWorkDate DATE;
xStatusNew NUMBER;
xStatusOld NUMBER;
xCount NUMBER;

BEGIN
xResume := False;
xBuff.Delete;
xStatusNew := NULL;
xStatusOld := NULL;
xCID := XLPL.CID;
xAID := XLPL.AID;
xWorkDate := XLPL.WORKDATE;
xBuff := B_F_ManageAllocStatus;
if xBuff.Count > 0 then
  xStatusNew := xBuff(1);
  xStatusOld := xBuff(2);
  if (xStatusNew = 1) and ((xStatusOld = 2) or (xStatusOld = 3)) then
    xResume := False;
  end if;
else
  select count (*)
  into xCount
  from W$ALLOCATION
  where CID = xCID
  and AID = xAID
  and PARENT_RID is NULL
  and (ALLOC_STATUS <> 1 or (AMOUNT = 0 and PAYMENT_PERCENT = 0))
  and STEP_START <= xWorkDate
  and (STEP_END >= xWorkDate or STEP_END is NULL)
  and STAGE in (4, 1);
  if xCount > 0 then
    xResume := True;
  else
    select count (*)
	into xCount
	from ALLOCATION
	where CID = xCID
	and AID = xAID
	and PARENT_RID is NULL
	and (ALLOC_STATUS <> 1 or (AMOUNT = 0 and PAYMENT_PERCENT = 0))
	and STEP_START <= xWorkDate
	and (STEP_END >= xWorkDate or STEP_END is NULL)
	and (STAGE = 1 or STAGE is null);
    if xCount > 0 then
      xResume := True;
    else
      xResume := False;
    end if;
  end if;
end if;
RETURN xResume;
END B_F_APZero;
/
