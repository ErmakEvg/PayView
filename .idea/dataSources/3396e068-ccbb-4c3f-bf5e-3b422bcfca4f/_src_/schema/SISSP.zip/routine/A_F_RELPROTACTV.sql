CREATE FUNCTION       A_F_RelProtActv(AACTIVITY in VarChar2,ALABOR in VarChar2)
   RETURN boolean IS
/*возвращает TRUE, если у человека на WorkDate есть заданные "активности"
Вахромин О.Ю.*/
xDRIDS DBMS_SQL.Number_Table;
xLABOR DBMS_SQL.Number_Table;
xACTIVITY DBMS_SQL.Number_Table;
vcount NUMBER;
WorkDate Date;
BEGIN
   WorkDate:=XLPL.Workdate;
   xACTIVITY:=S_ParseFloatArray(AACTIVITY);
   xLABOR:=S_ParseFloatArray(ALABOR);
   xDRIDS:=A_F_RelProtGetRIDActivity(1);
   for i in 1..xDRIDS.count loop
	  if (xLABOR.count=0) then -- нет кодов нижнего уровня
         for m in 1..xACTIVITY.count loop
            for ss1 in (select count(*) vcount from ACTIVITY where RID=xDRIDS(i) and
               ACTIVITY=xACTIVITY(m) and
               Workdate between nvl(PERIOD_START,workdate) and nvl(PERIOD_END,workdate)) loop
               if ss1.vCount>0 then
                  return true;
               end if;
            end loop;
         end loop;
	  else -- есть кода нижнего уровня
         for m in 1..xACTIVITY.count loop
            for l in 1..xLABOR.count loop
               select count(*) into vCount from ACTIVITY where RID=xDRIDS(i) and
                  ACTIVITY=xACTIVITY(m) and LABOR=xLABOR(l) and
                  Workdate between nvl(PERIOD_START,workdate) and nvl(PERIOD_END,workdate);
               if vCount>0 then
                  return true;
               end if;
            end loop;
         end loop;
      end if;
   end loop;
   xDRIDS:=A_F_RelProtGetRIDActivity(0);
   for i in 1..xDRIDS.count loop
	  if (xLABOR.count=0) then -- нет кодов нижнего уровня
         for m in 1..xACTIVITY.count loop
            for ss1 in (select count(*) vcount from w$ACTIVITY where RID=xDRIDS(i) and
               ACTIVITY=xACTIVITY(m) and
               Workdate between nvl(PERIOD_START,workdate) and nvl(PERIOD_END,workdate)) loop
               if ss1.vCount>0 then
                  return true;
               end if;
            end loop;
         end loop;
	  else -- есть кода нижнего уровня
         for m in 1..xACTIVITY.count loop
            for l in 1..xLABOR.count loop
               select count(*) into vCount from w$ACTIVITY where RID=xDRIDS(i) and
                  ACTIVITY=xACTIVITY(m) and LABOR=xLABOR(l) and
                  Workdate between nvl(PERIOD_START,workdate) and nvl(PERIOD_END,workdate);
               if vCount>0 then
                  return true;
               end if;
            end loop;
         end loop;
      end if;
   end loop;
   return false;
END A_F_RelProtActv;
/
