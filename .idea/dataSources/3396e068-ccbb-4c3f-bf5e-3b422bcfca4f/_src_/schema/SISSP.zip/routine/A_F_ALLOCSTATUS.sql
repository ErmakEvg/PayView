CREATE FUNCTION       A_F_AllocStatus(pCid in Number,ALLOC_CODE in Number,
   pGROUP_NO in Number) RETURN DBMS_SQL.NUMBER_TABLE IS
/******************************************************************************
 NAME         : A_F_AllocStatus
 Назначение   : Функция определения назначение является первичным пересчет
                или перевод на новое
 Автор        :  Вахромин О.Ю.       Комментарии и корректировка: ОЛВ
 Дата         :                21.10.2014 AMV     11.03.2015
 Код возврата : Возвращает статус приостановки(закрытия) назначения
******************************************************************************/
Result DBMS_SQL.Number_Table;
pAid        Number;
pCode       Number;
Code        Number;
Feature     Number;
pAlloc_Code Number;
Par_Code1   Number;
Par_Code2   Number;
BEGIN
 /*  проверка при расчете на существование
    родственного назначения  */
 /* status -  1- новое
              2- перерасчет
	          3- перевод(только для пенсии) */
/*  Трухтанов А.Н. */
   pAID:=0;
   pCODE:=0;
   CODE:=0;
   Result(0):= 1;
   Result(1):= 0;

   -- выбор кода назначения уже существующего
 begin
   for c1 in
     (select c.aid pAID,c.alloc_code pALLOC_CODE
        from W$person_Group a, allocation_role_Group b, w$allocation c,
             w$allocation_person d
       where a.cid = pCID
         and a.group_no = pGROUP_NO
         and b.code = a.role
         and b.feature = 1
         and c.cid =pCID
         and c.parent_rid is null
         and d.pid = a.pid
         and d.role = a.role
         and d.ALLOCATION_RID= c.rid
         and d.ENTERED_BY= c.entered_by
         and c.step_start =
            (Select max(step_start)
               from w$allocation
              where cid = pCID
                and aid = c.aid
                and stage = 1
                and rid = c.rid)
                and (c.alloc_status in (1,4)
                      or (c.alloc_status =
                           (Select alloc_status_old
                              from w$change_alloc_status
	                         where cid = pCID
                               and aid = c.aid
                               and alloc_status_new in(1,2,3)))))
    loop
       -- опредиляем это пенсия или пособие
        CODE:=ALLOC_CODE;
       while(code <> 0) loop
            pCODE:=code;
            select nvl(parent_code,0) into code from allocations
              where  code = pCODE;
       end loop;
       -- проверка перерасчета для пособия, + ГАСП + Капитал
       if (pcode = 2)     -- пособие
         or (pcode = 14)  -- 20.06.2014 Абрамович М.В. (+ ГАСП)
         or (pcode = 18)  -- 11.03.2015 ОЛВ +(pcode = 18)
       then
           begin
                select nvl(parent_code,0) into Par_Code1 from allocations
                        where code= ALLOC_CODE;
	            select nvl(parent_code,0) into Par_Code2 from allocations
                        where code= c1.pALLOC_CODE;
            -- найденное назначение и поданное на вход не имеют общей вершины
           exception
               when Too_Many_Rows or No_Data_Found then
               --catch(NullValue,TooManyRows,NoDatafound)
                  Par_Code1:=1;
                  Par_Code1:=2;
           end;

           if (ALLOC_CODE = c1.pALLOC_CODE) then
               if (Result(0) = 1) then
	              Result(0):= 2;
			          Result(1):= c1.pAID;
               end if;
           end if;

           if (Par_Code1 = Par_Code2) then
                  begin
                     select FEATURE into feature from allocations
                        where code in (select nvl(parent_code,0) from allocations
                        where code = ALLOC_CODE);
	              exception
                     when Too_Many_Rows or No_Data_Found then
	                 --catch(NullValue,TooManyRows,NoDatafound)
                        FEATURE:= 2;
                  end;
           end if;

           if (Result(0) = 1) then
                  if (FEATURE = 1) then
	                 Result(0):= 2;
				           Result(1):= c1.pAID;
			            end if;
           end if;
	   end if;
         -- идет обработка пенсии
         if (pcode = 1 )or( pcode = 3) or (pcode = 5) then
            if ( Result(0) = 1 ) then
               if ( ALLOC_CODE <> c1.pALLOC_CODE ) then
                  Result(0):= 3;
			            Result(1):= c1.pAID;
		            else
                  Result(0):= 2;
			            Result(1):= c1.pAID;
               end if;
            end if;
         end if;
      end loop;
   exception
      when No_Data_Found then
         return Result;
   end;
   return Result;
END A_F_AllocStatus;
/
