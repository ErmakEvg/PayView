CREATE FUNCTION       A_F_TranslaitAllocation RETURN Boolean IS
/******************************************************************************
 NAME         : A_F_Translate_Disability
 Назначение   : Перевод назначения с одного вида пенсии на другой
 Автор        : Вахромин О.Ю.                     Комментарии  : ОЛВ
 Дата         :					  			  				   03.03.2011
 Код возврата : Возвращает признак наличия незакрытого назначения
******************************************************************************/
 vCount number;
BEGIN
   SELECT COUNT(*)
     into vCount
     FROM allocation
	WHERE cid=XLPL.cid
	  AND aid=XLPL.aid
	  AND comp_part IS NULL
	  AND parent_rid IS NULL
	  AND step_start=
             ( SELECT MAX(step_start)
			     FROM allocation
				WHERE cid=XLPL.cid
				  AND aid=XLPL.aid
				  AND comp_part IS NULL
				  AND parent_rid IS NULL
				  AND Close_date is null)
	  AND Close_date is null 	 		  -- дата закрытия записи
	  AND (alloc_code=XLPL.Alloc_Code
	     OR alloc_code IN
             ( SELECT code
			     FROM allocations
				WHERE group_num=
	                       ( SELECT group_num
						       FROM allocations
							  WHERE code=XLPL.Alloc_Code)));
   return (vCount=0);
END A_F_TranslaitAllocation;
/
