CREATE FUNCTION       A_F_GetRidsWActivityBen(ARELATION_DATE in Date,
   AACTIVITY in Number,ALABOR in Number,ASTAGE in Number,
   ADISMISSAL_REASON in DBMS_SQL.Number_Table) RETURN DBMS_SQL.Number_Table IS
/* Код возврата: возращает массив RID-ов по условию для W$ACTIVITY
              с включением  ACTIVITY = 1 либо текущей, либо последней
              с PERIOD_END < WORKDATe
  (если ALABOR = -1, то ALABOR не учитывается)
Вахромин О.Ю.*/
retRIDS DBMS_SQL.Number_Table;
i number;
vsDRID number;
vsD_REASON number;
BEGIN
   i:=1;
   -- Обработка работы ACTIVITY = 1
   if AACTIVITY=1 then
      if ALABOR=-1 then
         for c1 in (select RID,NVL(DISMISSAL_REASON,-1) D_REASON from W$ACTIVITY where
            PID=XLPL.GetPID and ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and
            ACTIVITY=AACTIVITY and
            (ARELATION_DATE between NVL(PERIOD_START,ARELATION_DATE) and
               NVL(PERIOD_END,ARELATION_DATE))) loop
            if ADISMISSAL_REASON.count=0 then
               retRIDS(i):=c1.RID;
               i:=i+1;
            else
               for l in 1..ADISMISSAL_REASON.count loop
                  if c1.D_REASON=ADISMISSAL_REASON(l) then
                     retRIDS(i):=c1.RID;
                     i:=i+1;
                  end if;
               end loop;
            end if;
         end loop;
         begin
            if retRIDS.count=0 then
               select RID,NVL(DISMISSAL_REASON,-1) into vsDRID,vsD_REASON
                  from W$ACTIVITY where PID=XLPL.GetPID and
                  ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and
                  ACTIVITY=AACTIVITY and PERIOD_END=
                  (select MAX(PERIOD_END) from W$ACTIVITY where
                     PID=XLPL.GetPID and ENTERED_BY=XLPL.USER_ID and
                     STAGE=ASTAGE and ACTIVITY=AACTIVITY and
                     PERIOD_END<XLPL.WORKDATE);
               if ADISMISSAL_REASON.count=0 then
                  retRIDS(i):=vsDRID;
                  i:=i+1;
               else
                  for l in 1..ADISMISSAL_REASON.count loop
                     if vsD_REASON=ADISMISSAL_REASON(l) then
                        retRIDS(i):=vsDRID;
                        i:=i+1;
                     end if;
                  end loop;
               end if;
            end if;
         exception
            when others then
               null;
         end;
      else -- LABOR задано
         for c1 in (select RID,NVL(DISMISSAL_REASON,-1) D_REASON from W$ACTIVITY where
            PID=XLPL.GetPID and ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and
            ACTIVITY=AACTIVITY and LABOR=ALABOR and
            (ARELATION_DATE between NVL(PERIOD_START,ARELATION_DATE) and
               NVL(PERIOD_END,ARELATION_DATE))) loop
            if ADISMISSAL_REASON.count=0 then
               retRIDS(i):=c1.RID;
               i:=i+1;
            else
               for l in 1..ADISMISSAL_REASON.count loop
                  if c1.D_REASON=ADISMISSAL_REASON(l) then
                     retRIDS(i):=c1.RID;
                     i:=i+1;
                  end if;
               end loop;
            end if;
         end loop;
         begin
            if retRIDS.count=0 then
               select RID,NVL(DISMISSAL_REASON,-1) into vsDRID,vsD_REASON
                  from W$ACTIVITY where PID=XLPL.GetPID and
                  ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and
                  ACTIVITY=AACTIVITY and LABOR=ALABOR and PERIOD_END=
                  (select MAX(PERIOD_END) from W$ACTIVITY where
                     PID=XLPL.GetPID and ENTERED_BY=XLPL.USER_ID and
                     STAGE=ASTAGE and ACTIVITY=AACTIVITY and
                     PERIOD_END<XLPL.WORKDATE);
               if ADISMISSAL_REASON.count=0 then
                  retRIDS(i):=vsDRID;
                  i:=i+1;
               else
                  for l in 1..ADISMISSAL_REASON.count loop
                     if vsD_REASON=ADISMISSAL_REASON(l) then
                        retRIDS(i):=vsDRID;
                        i:=i+1;
                     end if;
                  end loop;
               end if;
            end if;
         exception
            when others then
               null;
         end;
      end if;
   end if;
   -- для обработки не работы
   if AACTIVITY>1 then
      if ALABOR=-1 then --нет учета поля LABOR
         for c1 in (select RID,NVL(DISMISSAL_REASON,-1) D_REASON from W$ACTIVITY where
            PID=XLPL.GetPID and ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and
            ACTIVITY=AACTIVITY and
            (ARELATION_DATE between NVL(PERIOD_START,ARELATION_DATE) and
               NVL(PERIOD_END,ARELATION_DATE))) loop
            if ADISMISSAL_REASON.count=0 then
               retRIDS(i):=c1.RID;
               i:=i+1;
            else
               for l in 1..ADISMISSAL_REASON.count loop
                  if c1.D_REASON=ADISMISSAL_REASON(l) then
                     retRIDS(i):=c1.RID;
                     i:=i+1;
                  end if;
               end loop;
            end if;
         end loop;
      else -- LABOR задано
         for c1 in (select RID,NVL(DISMISSAL_REASON,-1) D_REASON from W$ACTIVITY where
            PID=XLPL.GetPID and ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and
            ACTIVITY=AACTIVITY and LABOR=ALABOR and
            (ARELATION_DATE between NVL(PERIOD_START,ARELATION_DATE) and
               NVL(PERIOD_END,ARELATION_DATE))) loop
            if ADISMISSAL_REASON.count=0 then
               retRIDS(i):=c1.RID;
               i:=i+1;
            else
               for l in 1..ADISMISSAL_REASON.count loop
                  if c1.D_REASON=ADISMISSAL_REASON(l) then
                     retRIDS(i):=c1.RID;
                     i:=i+1;
                  end if;
               end loop;
            end if;
         end loop;
      end if;
   end if;
   return retRIDS;
END A_F_GetRidsWActivityBen;
/
