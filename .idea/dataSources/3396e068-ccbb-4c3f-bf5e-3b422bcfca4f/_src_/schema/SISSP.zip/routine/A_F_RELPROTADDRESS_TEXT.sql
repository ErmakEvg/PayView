CREATE FUNCTION       A_F_RelProtAddress_Text(pADDRESS_TYPE in NUMBER,ppVALUE in VARCHAR) RETURN BOOLEAN IS
/***************************************************************************************
 NAME              : A_F_RelProtAddress_Text
 Наименование      : Функция возвращает TRUE, если пенсионер проживает по указанному адресу в РБ
 Автор             : ОЛВ
 Состояние на дату : 16.05.2011
 Код возврата      : TRUE или FALSE
***************************************************************************************/
 vsDRID          NUMBER;
 vsTEXT_ADDRESS  varchar(255);
 pVALUE          varchar(10);  -- ???? сколько ????
BEGIN
 -- pADDRESS_TYPE - ТИП АДРЕСА; АДРЕС ПРОПИСКИ И/ИЛИ АДР. ПРОЖИВ. (1 - РЕГИСТР., 2 - ПРОЖИВ., 3 - ТО И  ДР.)
 -- ppVALUE
 -- TEXT_ADDRESS  - НАСЕЛЁННЫЙ ПУНКТ введенный вручную
 pVALUE:=upper('%'||ppVALUE||' %');

   -- Выбрать адрес в ОБД RID из ADDRESS
     vsDRID:=A_F_RelProtGetRIDAddress(1,pADDRESS_TYPE);
 if vsDRID<>-1 then
      begin
         SELECT TEXT_ADDRESS
		   INTO vsTEXT_ADDRESS
		   FROM ADDRESS
		  where RID=vsDRID
		    AND ADDRESS_TYPE= pADDRESS_TYPE
		    AND upper(TEXT_ADDRESS) LIKE pVALUE
		    AND PID=XLPL.GetPid
			AND ((COUNTRY is NULL) OR (COUNTRY =1)) ;
      exception
         when NO_DATA_FOUND then
            vsTEXT_ADDRESS:=NULL;
      end;
 else
      -- Выбрать адрес в РБД RID из W$ADDRESS
        vsDRID:=A_F_RelProtGetRIDAddress(0,pADDRESS_TYPE);
    if vsDRID<>-1 then
      begin
         SELECT TEXT_ADDRESS
		   INTO vsTEXT_ADDRESS
		   FROM W$ADDRESS
		  where RID=vsDRID
		    AND ADDRESS_TYPE= pADDRESS_TYPE
		    AND upper(TEXT_ADDRESS) LIKE pVALUE
		    AND PID=XLPL.GetPid
			AND ((COUNTRY is NULL) OR (COUNTRY =1)) ;
      exception
         when NO_DATA_FOUND then
            vsTEXT_ADDRESS:=NULL;
      end;
    else
        vsTEXT_ADDRESS:=NULL;
	end if;
 end if;

 if  vsTEXT_ADDRESS IS NULL then
      RETURN FALSE;
 else
      RETURN TRUE;
 end if;
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtAddress 2 xlpl.GetPid=' || xlpl.GetPid ||'  vsDRID='||vsDRID );
END A_F_RelProtAddress_Text;
/
