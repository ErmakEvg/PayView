CREATE FUNCTION       B_CHILD_NADBAVKAINV_20061201 RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_CHILD_NADBAVKAINV_20061201
 Наименование       : Проверка права и вычисление надбавок для пособий детям - инвалидам
 Автор              : ОЛВ
 Состояние на дату  : 31.03.2010
 Код возврата       : Массив, содержащий коды надбавок и соответствующие суммы надбавок
***********************************************************************************************/

 A        DBMS_SQL.NUMBER_TABLE;		-- Объявить рабочий массив
 Bonus    DBMS_SQL.NUMBER_TABLE;		-- Объявить массив результата
 max_sum  NUMBER; 						-- Объявить сумму надбавки
 max_ind  NUMBER;						-- Объявить индекс (код) надбавки
 i        NUMBER;
 j        NUMBER;

BEGIN

 A.delete;
 Bonus.delete;

 XLPL.SETGLOBALFLOAT('Nadb', 0);                    --XLPL.SETGLOBALFLOAT('Nadb', 1);

 max_sum := 0;
 max_ind := 0;

 -- Надбавка к пособию на ребенка-инвалида
 if F$CHECK502 then
 	A(502) := F$AMOUNT502;
 end if;
 -- Надбавка к пособию на детей военнослужащих срочной службы до 3 лет
  if F$CHECK504 then
 	A(504) := F$AMOUNT504;
 end if;

 -- Надбавка к пособию на ребенка до 1,5 лет, рожденного вне брака
 if F$CHECK506 then
 	A(506) := F$AMOUNT506;
 end if;
 --Надбавка к пособию на ребенка от 1,5 до 3-х лет, рожденного вне брака
 if F$CHECK507 then
 	A(507) := F$AMOUNT507;
 end if;

 -- Надбавка к пособию на детей до 3 лет одинокому лицу,усыновившему ребенка
 if F$CHECK509 then
 	A(509) := F$AMOUNT509;
 end if;
 -- Надбавка к пособию на детей до 3 лет разведенным мужчинам и женщинам
 if F$CHECK511 then
 	A(511) := F$AMOUNT511;
 end if;

   /* *
RAISE_APPLICATION_ERROR(-20801,'B_F_Nad0_20061201  '||
                                        -- '  A(502)=' ||A(502)||
                                        -- '    A(504)='||A(504)||
                                       --  '    A(506)='||A(506)||
                                       --  '    A(507)='||A(507)||
                                         '    A(509)='||A(509)--||
                                       --  '    A(511)='||A(511)
                                              );
                                              /* */
  -- При наличии права на повышение пенсии по различным основаниям, начисляется одно из повышений
   max_sum:=0;
   IF A.COUNT>0 THEN
      i:=A.First;
      WHILE i IS NOT NULL LOOP
         IF A(i)>=max_sum THEN
            max_sum:=A(i);
            max_ind:=i;
         END IF;
         i:=A.NEXT(i);
      END LOOP;
	  Bonus(max_ind):=max_sum;
/* *
RAISE_APPLICATION_ERROR(-20004,'B_F_Nad0_20061201  max_ind='||max_ind||
                               '   A(max_ind)'||A(max_ind)||
                               '   max_sum='||max_sum);
                               /* */
     Xlpl.S_PROTOCOL(S_Class(max_ind,'ALLOCATIONS') || ': ' || CHR(9) || TO_CHAR(Bonus(max_ind),'99999999.99') || CHR(10));

     XLPL.SetGlobalFloat('Nadb', 1);
   END IF;

   RETURN Bonus;

END B_CHILD_NADBAVKAINV_20061201;
/
