CREATE FUNCTION       B_F_BLIZNECY(PuskDate in date, Param6m in number ) RETURN NUMBER AS

/***************************************************************************************
// Функция: 			B_F_BLIZNECY
// Наименование: 		Функция проверки  наличия  близнецов в деле
// Автор: 				Речицкая А.В..
// Состояние на дату 	12.06.2018
// Код возврата: 		Priznak - количество близнецов в деле
//***************************************************************************************/
	--PuskDate	date;   --дата рождения текущего ребенка
	--Param6m   		--признак истечения 6 месяцев с даты возникновения права
	Priznak 	NUMBER;	--количество близнецов в деле
	i 			NUMBER; --количество детей в деле
    datetalk	date;

 BEGIN
  i:=0;
  Priznak:=0;
  datetalk := A_F_Datatalk;
  --RAISE_APPLICATION_ERROR(-20801,'B_F_BLIZNECY=' ||'.Xlpl.GETPID='||Xlpl.GETPID||'Xlpl.WorkDate = '||Xlpl.WorkDate||'datetalk = '||datetalk);

  for Rec in
  	(select p.pid as BlizPid,nvl(BIRTH_DATE, null) as dat_birth, nvl(DEATH_DATE, null) as dat_death
  	   from W$CASE_PERSON cp,W$PERSON p
   	   where
       cp.cid=XLPL.CID AND
       cp.pid=p.PID AND
       cp.stage in(1,4) AND
       cp.ROLE=56 AND
       cp.ENTERED_BY =  XLPL.USER_ID AND
       p.PID <> XLPL.GETPID AND
       p.STAGE in (1, 4) and
       p.CLOSE_DATE is null and
       cp.ENTERED_BY =  p.ENTERED_BY)

       LOOP
       i:=i+1;
	   if (REC.dat_birth is not null) AND (REC.dat_birth = PuskDate) AND (REC.dat_death is null)
	   then
        if  (XLPL.AID = 0) AND  (Param6m = 0)  			   	  	  	   	   			  	   				 -- Если превышено 6 месяцев со для возникновения права
          then Priznak:=Priznak+1;
	    end if;
	   end if;
     end loop;
  --RAISE_APPLICATION_ERROR(-20801,'B_F_BLIZNECY=' ||'.Xlpl.GETPID='||Xlpl.GETPID||'Xlpl.WorkDate = '||Xlpl.WorkDate||'Priznak = '||Priznak||'i = '||i);
	Return   Priznak;

 END B_F_BLIZNECY;
/
