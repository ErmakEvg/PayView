CREATE FUNCTION       B_F_ActvGardenStart RETURN DATE AS

/***************************************************************************************
// Функция: B_F_ActvGardenStart
// Наименование: Функция определения даты начала посещения детского сада ребенком
// Автор: Ворошилин В.
// Состояние на дату 06.11.20
// Возвращает: Дату начала посещения детского сада
//***************************************************************************************/

  ACTEND DATE;
BEGIN
  begin
    Select max(PERIOD_START) INTO ACTEND From  W$ACTIVITY
	Where PID = XLPL.GetPid
	and ACTIVITY = 2
	and LABOR = 221
	and ENTERED_BY = XLPL.User_ID
	and STAGE NOT IN(2,3);
	exception
	  when NO_DATA_FOUND then
	    ACTEND := NULL;
  end;
  if ACTEND is NULL then
    begin
	  Select max(PERIOD_START) INTO ACTEND From  ACTIVITY
	    Where PID = XLPL.GetPid
		and ACTIVITY = 2
		and LABOR = 221
		and STAGE NOT IN(2,3);
	  exception
	    when NO_DATA_FOUND then
	      ACTEND := NULL;
    end;
  end if;
  return ACTEND;
END B_F_ActvGardenStart;
/
