CREATE FUNCTION       B_F_EXIST_METRICS_PAST (aPID   in NUMBER,
                                                         aDate  in DATE,
                                                         aCode  in VARCHAR2,
                                                         PrBase in NUMBER)
RETURN BOOLEAN AS
/******************************************************************************
 Функция           : B_EXIST_METRIC_PAST
 Наименование      : Функция определяет, имелись ли у лица указанные метрики
                   : на (до) даты обращения
 Автор             : Абрамович М.В.
 Состояние на дату : 10.10.2011, 07.09.2015 (A.K.)
 Возвращает        : True, если лицо имеет метрику
/*****************************************************************************/
  aCount NUMBER;
  xCODES DBMS_SQL.number_table;
  vsCODE NUMBER;
BEGIN
  xCODES:= S_ParseFloatArray(aCode);
  -- Поиск метрики в РБД
  IF prBase = 0 THEN
    FOR I in 1 .. xCODES.Count
    LOOP
      vsCODE:= xCODES(i);
      SELECT count (*) into aCount
      FROM W$PERSON_METRIC
      WHERE PID = aPID
        and CODE = vsCODE
	    and (RECORD_START <= aDate or RECORD_START is null)
	    and (RECORD_END <= aDate or RECORD_END is null)
        and STAGE in (1,4)           -- 07.09.2015 (A.K.)
        and ENTERED_BY= XLPL.GETUID; -- 07.09.2015 (A.K.)
	  IF aCount <> 0 THEN
        RETURN TRUE;
      END IF;
    END LOOP;
  ELSE
    -- Поиск метрики в ОБД
    FOR I in 1 .. xCODES.Count
    LOOP
      vsCODE := xCODES(i);
      SELECT count (*) into aCount
      FROM PERSON_METRIC
      WHERE PID = aPID
        and CODE = vsCODE
        and (RECORD_START <= aDate or RECORD_START is null)
        and (RECORD_END <= aDate or RECORD_END is null)
        and STAGE is null;
      IF aCount <> 0 THEN
        RETURN TRUE;
      END IF;
    END LOOP;
  END IF;
  --raise_application_error(-20204,'шаг'||1);
  RETURN FALSE;
END B_F_EXIST_METRICS_PAST;
/
