CREATE FUNCTION       B_F_BENEFIT_IS(AAllocCodes IN VARCHAR2, ARECIPIENT IN BINARY_INTEGER) RETURN BOOLEAN AS
/**********************************************************************************************
 Функция            : B_F_BENEFIT_IS
 Наименование       : Проверка получения назначения без W$RELATION_PROTOCOL на основе ф-ии B_F_RELPROTISBENEFIT
 Автор              : Абрамович М.В.
 Состояние на дату  : 11.06.2014
 Код возврата       : Возращается True если на WorkDate
                      есть данные, что PID получает определенное пособие
***********************************************************************************************/
 xAllocCodes  DBMS_SQL.NUMBER_TABLE;
 i            BINARY_INTEGER;
 resFlag      NUMBER;
BEGIN
 xAllocCodes := S_ParseFloatArray(AAllocCodes);
 IF xAllocCodes.count = 0 THEN
    raise_application_error(10200, 'B_F_BENEFIT_IS: Отсуствует обязательный параметр AAllocCodes ' || CHR(10));
 END IF;
 for i in 1..xAllocCodes.count loop
    select count(*) INTO resFlag
    from ALLOCATION a,
         ALLOCATION_PERSON c,
         ID_CASE d,
         ALLOCATIONS e,
         RECIPIENT f
     where c.ALLOCATION_RID = a.RID
       and c.PID = XLPL.GetPid
       and d.CID = a.CID
       and NVL(a.stage,0) not in (2,3)
       and NVL(c.stage,0) not in (2,3)
       and d.ACCESS_DATA = 2
       and a.STEP_START <= XLPL.WorkDate
       and NVL(a.STEP_END, XLPL.WORKDATE) >= XLPL.WORKDATE
       and (    ((a.CLOSE_DATE is NULL) and (ALLOC_STATUS = 1) and (a.ALLOC_CODE = e.CODE) )
             or ((a.ALLOC_CODE = e.CODE) and (e.CLOSE_FEATURE is not NULL))
             )
       and f.CID = a.CID
       and f.STAGE is NULL
       and f.AID is NULL
       and (
                ((ARECIPIENT = 1) and (f.PID = XLPL.GetPid))  -- получатель назначения
             or ((ARECIPIENT = 0) and (f.PID <> XLPL.GetPid)) -- получатель денег назначения
             or (ARECIPIENT = -1)                             -- любой
           )
       and  xAllocCodes(i) in
                            ( select CODE
                                from ALLOCATIONS
                          start with CODE =  a.ALLOC_CODE
                    connect by prior PARENT_CODE = CODE)
       and NVL(e.stage,0) not in (2,3)
       and ROWNUM = 1;
      if  resFlag != 0 then
        return true;
      end if;
  end loop;
  return false;

END B_F_BENEFIT_IS;
/
