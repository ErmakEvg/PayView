CREATE FUNCTION       B_F_CHANGEPENSION(PuskDate in date, Param6m in number) RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: F_ChangePension
+ Наименование: определяет датs изменений назначения (пенсии)
+ Автор: Трухтанов
+ Состояние на дату 07.05.1999
==============================================================================*/

chahge_date_metric DBMS_SQL.NUMBER_TABLE;
result_array DBMS_SQL.NUMBER_TABLE;

Alloc_start date;
Alloc_end date;
Rabdate date;
datetalk date;
DateTalk1 date;

flg_insert_result boolean;
i integer;
j integer;

BEGIN
  result_array.delete;
  chahge_date_metric.delete;

  datetalk := A_F_DataTalk();
  Datetalk1 := Last_Day(S_Currdate);
--  select Last_Day(sysdate) into DateTalk1 from dual;

  for Rec in (Select nvl(ALLOCATION_START, null) as Alloc_Start,
                                          nvl(ALLOCATION_END, null) as Alloc_End
  			  				   	  	   from ALLOCATION a,
			 						        ALLOCATION_PERSON b,
			 						        CASE_PERSON c,
									        ALLOCATION_ROLE_GROUP d
			 						   where
			 						   	  a.RID = b.ALLOCATION_RID and
									         a.ALLOC_STATUS not in (3, 4) and
			 						         b.PID = XLPL.GETPID and
			 						         c.PID = b.PID and
			 						         d.CODE = c.ROLE and
									         d.FEATURE = 1 and
			 						        (c.STAGE <> 3 or c.STAGE is NULL) and
			 						   	  (a.STAGE <> 3 or a.STAGE is NULL) and
			 						        (b.STAGE <> 3 or b.STAGE is NULL) and
			 						         a.ALLOC_CODE in (select CODE
			 						                            from ALLOCATIONS
			 						                            start with CODE = 1
			 						                            connect by prior CODE = PARENT_CODE))
  LOOP

    if (Rec.Alloc_Start != null) AND (Rec.Alloc_start > PuskDate) AND
	    (Rec.Alloc_start <= DateTalk1) then
	  if  (Param6m = 1) then  			   	  	  	   	   			  	   				 -- Если превышено 6 месяцев со для возникновения права
          chahge_date_metric(chahge_date_metric.Count+1) := S_julian(S_EncodeDate(S_YearOfDate( DateTalk), S_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		  else chahge_date_metric(chahge_date_metric.Count+1) := S_julian(Rec.Alloc_start);
	  end if;
	end if;
	if (Rec.Alloc_End != null) AND (Rec.Alloc_End > PuskDate) AND
	   (Rec.Alloc_End <= DateTalk1) then
	  if (Param6m = 1) then  			   	  	  	   	   			  	   				 -- Если превышено 6 месяцев со для возникновения права
        chahge_date_metric(chahge_date_metric.Count+1) := S_julian(s_EncodeDate(s_YearOfDate( DateTalk), S_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		else chahge_date_metric(chahge_date_metric.Count+1) := s_julian(Rec.Alloc_End) + 1;
	  end if;
	end if;
  end loop;

----- избавимся от повторений -----
  for j in 1 .. chahge_date_metric.Count LOOP
    flg_insert_result := true;
    for i in 1 .. result_array.Count LOOP
	   if (chahge_date_metric(j) = result_array(i)) then flg_insert_result := false;
	   end if;
	end loop;
    if (flg_insert_result) then
	  result_array (result_array.Count + 1) := chahge_date_metric(j);
	end if;
  end loop;
  return result_array;
END B_F_CHANGEPENSION;
/
