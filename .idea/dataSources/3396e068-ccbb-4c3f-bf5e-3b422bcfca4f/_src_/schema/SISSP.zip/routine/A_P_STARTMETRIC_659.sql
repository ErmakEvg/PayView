CREATE FUNCTION       A_P_STARTMETRIC_659 RETURN DATE AS

/***************************************************************************************
//Определение даты начала действия характеристики "Пенсионер":
// если между датой окончания действия характеристики "Пенсионер" и датой
// возникновения права на пенсию по СПК прошло более 5 лет,то возвращается дата
// возникновения права на пенсию по СПК, иначе - дата начала действия характеристики "Пенсионер"
// Автор: Боровнева
// Состояние на дату 16.02.1999
// Код возврата: предположительную дата перерасчета назначения
//***************************************************************************************/
pStart date;
ACID Number;
pAlloc_Code Number;
pAid Number;
pRab_Date Date;

BEGIN
 pStart := NULL;
 ACID := XLPL.CID;
 pAlloc_Code := XLPL.ALLOC_CODE;
 pAid := XLPL.AID;
 pRab_Date := XLPL.WorkDate;

-- try
--{
  if pAid <> 0  then
     select min (step_start)
     INTO pRab_Date
     from allocation
     where cid = ACID and
           aid = pAID and
           Close_Date is NULL and
           alloc_status in(1) and
           parent_rid is null and
           comp_part is null  and
					 ALLOC_CODE = pAlloc_Code;
  end if;
--}
--catch (nodataFound,nulldate,nullvalue) {}


	if A_F_RelProtMetricStart(659) is not null then
	   if A_F_RelProtMetricEnd(659) is not null and
		    trunc(S_YearsBetween(pRab_Date,A_F_RelProtMetricEnd(659))) >= 5  then
         return  pStart;
		 else pStart := A_F_RelProtMetricStart(659);
     end if;
	end if;
	return pStart;
END A_P_STARTMETRIC_659;
/
