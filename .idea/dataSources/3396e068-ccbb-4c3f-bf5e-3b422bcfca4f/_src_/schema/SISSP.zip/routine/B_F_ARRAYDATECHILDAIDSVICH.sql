CREATE FUNCTION       B_F_ARRAYDATECHILDAIDSVICH RETURN DBMS_SQL.NUMBER_TABLE AS

/***************************************************************************************
// Функция: F_ARRAYDATECHILDAIDSVICH
// Наименование: Ограничение возраста для детей, инфицированных ВИЧ или больных СПИД
// 				 для Estimation
// Автор: Ворошилин В.
// Состояние на дату 29.11.2000
// Код возврата: Массив, состоящий из даты, кода причины, кода изменения состояния
//***************************************************************************************/

  result DBMS_SQL.NUMBER_TABLE;
  StopDt DATE;
  DtBirth DATE;
BEGIN
  result.delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CHECKROLE(56) then
	return result;
  end if;
  XLPL.REPLACEROLE('Child');
  DtBirth := A_F_RelProtBIRTHDAY;
  StopDt := S_AddYears(DtBirth, S_Const(408, XLPL.WorkDate));
  if A_F_RelProtMetric('320') then
    if StopDt > LAST_DAY(S_CURRDATE) then
      result(1) := S_Julian(StopDt);
 	  result(2) := 27;
 	  result(3) := 2;
	end if;
  end if;
  XLPL.RESTOREROLE;
  return result;
END B_F_ARRAYDATECHILDAIDSVICH;
/
