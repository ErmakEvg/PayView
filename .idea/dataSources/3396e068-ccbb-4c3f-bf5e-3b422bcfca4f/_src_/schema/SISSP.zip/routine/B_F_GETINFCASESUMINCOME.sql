CREATE FUNCTION       B_F_GETINFCASESUMINCOME RETURN DBMS_SQL.NUMBER_TABLE IS

/* --------------------------------------------------------------------
// Автор: Басинюк Я.В.
// состояние на 07.06.1999
// Код возврата: возвращает массив данных по доходам семьи согласно W$RELATION_PROTOCOL, где
//     [0] = полю 'YEAR' (преобразованому к JULIAN)
//     [1] = полю 'YEAR_WAGE'
//     [2] = полю 'AVG_MONTH_WAGE'
//     [3] = полю 'YEAR_CONTRIBUTION'
// Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
// --------------------------------------------------------------------*/

  xRetArray DBMS_SQL.Number_Table;
  vsYEAR DATE;
  vsYEAR_WAGE NUMBER;
  vsYEAR_CONTRIBUTION NUMBER;
  vsAGV_MONTH_WAGE NUMBER;
BEGIN
  xRetArray.Delete;
  if B_F_RelProtGetRIdCaseSumIncome <> -1 then
    select YEAR, AMOUNT_YEAR, CONTRIBUTION_YEAR, SSD
	into vsYEAR, vsYEAR_WAGE, vsYEAR_CONTRIBUTION, vsAGV_MONTH_WAGE
    from CASE_SUMMARY_INCOME
	where RID = B_F_RelProtGetRIdCaseSumIncome
	  and RECORD_START <= XLPL.WorkDate
	  and (RECORD_END >= XLPL.WorkDate or RECORD_END is null);
	xRetArray(xRetArray.count+1) := S_Julian(vsYEAR);
	xRetArray(xRetArray.count+1) := vsYEAR_WAGE;
	xRetArray(xRetArray.count+1) := vsAGV_MONTH_WAGE;
	xRetArray(xRetArray.count+1) := vsYEAR_CONTRIBUTION;
  else
    if B_F_RelProtGetRIdWCaseSumIncom <> -1 then
	  select YEAR, AMOUNT_YEAR, CONTRIBUTION_YEAR, SSD
	  into vsYEAR, vsYEAR_WAGE, vsYEAR_CONTRIBUTION, vsAGV_MONTH_WAGE
	  from W$CASE_SUMMARY_INCOME
	  where RID = B_F_RelProtGetRIdWCaseSumIncom
	    and RECORD_START <= XLPL.WorkDate
		and (RECORD_END >= XLPL.WorkDate or RECORD_END is null);
 	  xRetArray(xRetArray.count+1) := S_Julian(vsYEAR);
	  xRetArray(xRetArray.count+1) := vsYEAR_WAGE;
	  xRetArray(xRetArray.count+1) := vsAGV_MONTH_WAGE;
	  xRetArray(xRetArray.count+1) := vsYEAR_CONTRIBUTION;
	end if;
  end if;
  return xRetArray;
END B_F_GETINFCASESUMINCOME;
/
