CREATE FUNCTION       B_F_Arraydateestactivity (pActivity IN NUMBER) RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция                : B_F_Arraydateestactivity
 Наименование       : Формирование дат Estimation для пособий на детей старше 3 лет
 Автор                     : Ворошилин В.             Комментарии корректировка : ОЛВ
 Состояние на дату  : 16.11.2000                             -- 17.01.2013  01.07.2014 РАВ
 Код возврата          : возвращает массив дат Estimation
***********************************************************************************************/
  chahge_date_activity  DBMS_SQL.NUMBER_TABLE;
  a                               BINARY_INTEGER;
BEGIN
    chahge_date_activity.DELETE;
    a := 0;
  FOR aACTIVITY IN
            (SELECT NVL(PERIOD_START, NULL) AS activity_start,
                           NVL(PERIOD_END, NULL) AS activity_end,
                           NVL(LABOR, 0) AS pLabor
                  FROM W$ACTIVITY
               WHERE PID = Xlpl.GEtPID
                  AND ACTIVITY = pActivity
                  AND ((NVL(PERIOD_START, LAST_DAY(S_Currdate)) >= LAST_DAY(S_Currdate))
                          OR (NVL(PERIOD_END, LAST_DAY(S_Currdate)) >= LAST_DAY(S_Currdate)))
                  AND STAGE IN (1, 4)
                  AND ENTERED_BY = Xlpl.USER_ID)
  LOOP
     IF (aACTIVITY.activity_start IS NOT NULL) AND ((aACTIVITY.activity_start + 1) > LAST_DAY(S_Currdate)) THEN
          -- работа мать/опекун
          IF (pACTIVITY = 1)  AND  ((A_F_Relprotcurrentrole = 55) OR  (A_F_Relprotcurrentrole = 52)) THEN
                   --chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_start) - 1;
              IF (aACTIVITY.pLabor = 200) OR (aACTIVITY.pLabor = 201) OR (aACTIVITY.pLabor = 202) OR
                  (aACTIVITY.pLabor = 203) OR (aACTIVITY.pLabor = 204) OR (aACTIVITY.pLabor = 205) OR
                  (aACTIVITY.pLabor = 206) OR (aACTIVITY.pLabor = 207)
                  -- 17.01.2013 ОЛВ со слов РАВ
                  OR   (aACTIVITY.pLabor = 208) OR (aACTIVITY.pLabor = 214) OR (aACTIVITY.pLabor = 215)
                   OR  (aACTIVITY.pLabor = 216) OR (aACTIVITY.pLabor = 217)
                  THEN
                       null; --31.03.2014  01.07.2014 РАВ
                       /* *
                       chahge_date_activity(chahge_date_activity.COUNT + 1) := 93;
                       chahge_date_activity(chahge_date_activity.COUNT + 1) := 1; /* */
              ELSE
                    chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_start) - 1;
                    chahge_date_activity(chahge_date_activity.COUNT + 1) := 66;
                    chahge_date_activity(chahge_date_activity.COUNT + 1) := 2;
              END IF;
          END IF;
          -- работа отец/супруга опекуна
          IF (pACTIVITY = 1) AND ((A_F_Relprotcurrentrole = 56) OR (A_F_Relprotcurrentrole = 57)) THEN
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_start) - 1;
                      chahge_date_activity(chahge_date_activity.COUNT + 1) := 66;
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := 2;
          END IF;

          --учеба
             a := 0;
          IF (pACTIVITY = 2) AND ((A_F_Relprotcurrentrole = 55) OR (A_F_Relprotcurrentrole = 52) OR (A_F_Relprotcurrentrole = 56)) THEN
                  chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_start) - 1;
               IF (aACTIVITY.pLabor = 225) OR (aACTIVITY.pLabor = 228) OR (aACTIVITY.pLabor = 231) OR (aACTIVITY.pLabor = 233) THEN
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := 96;
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := 2;
                       a := 1;
               END IF;
               IF (aACTIVITY.pLabor = 226) OR (aACTIVITY.pLabor = 227) OR (aACTIVITY.pLabor = 229) OR (aACTIVITY.pLabor = 230) OR (aACTIVITY.pLabor = 232) THEN
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := 98;
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
                       a := 1;
               END IF;
               IF (aACTIVITY.pLabor = 221) THEN
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := 55;
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
                        a := 1;
               END IF;

               IF a = 0 THEN
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := 998;
                   chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
               END IF;
     END IF;

     -- учеба / получатель отец
           a := 0;
      IF (pACTIVITY = 2) AND (A_F_Relprotcurrentrole = 57) THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_start) - 1;
        IF (aACTIVITY.pLabor = 225) OR (aACTIVITY.pLabor = 228) OR (aACTIVITY.pLabor = 231) OR (aACTIVITY.pLabor = 233) THEN
            chahge_date_activity(chahge_date_activity.COUNT + 1) := 96;
            chahge_date_activity(chahge_date_activity.COUNT + 1) := 2;
          a := 1;
        END IF;
        IF a = 0 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 998;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
        END IF;
      END IF;
      a := 0;

      -- безработица
      IF (pACTIVITY = 3) AND ((A_F_Relprotcurrentrole = 55) OR (A_F_Relprotcurrentrole = 52)) THEN
        chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_start) - 1;
        IF aACTIVITY.pLabor = 241 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 302;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
          a := 1;
        END IF;
        IF aACTIVITY.pLabor = 243 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 304;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
          a := 1;
        END IF;
        IF aACTIVITY.pLabor = 242 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 306;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
          a := 1;
        END IF;
        IF a = 0 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 308;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
        END IF;
     END IF;

     -- безработица/ отец
      a := 0;
      IF (pACTIVITY = 3) AND (A_F_Relprotcurrentrole = 56) THEN
        chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_start) - 1;
        IF aACTIVITY.pLabor = 241 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 302;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 2;
          a := 1;
        END IF;
        IF aACTIVITY.pLabor = 243 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 304;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 2;
          a := 1;
        END IF;
        IF aACTIVITY.pLabor = 242 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 306;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 2;
          a := 1;
        END IF;
        IF a = 0 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 308;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
        END IF;
      END IF;
      a := 0;
      IF (pACTIVITY = 3) AND (A_F_Relprotcurrentrole = 57) THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_start) - 1;
        chahge_date_activity(chahge_date_activity.COUNT + 1) := 998;
        chahge_date_activity(chahge_date_activity.COUNT + 1) := 2;
      END IF;
    END IF;

    -- работа мать/опекун
    a := 0;
    IF (aACTIVITY.activity_end IS NOT NULL) AND ((aACTIVITY.activity_end + 1) > LAST_DAY(S_Currdate)) THEN
      IF (pACTIVITY = 1) AND ((A_F_Relprotcurrentrole = 55) OR (A_F_Relprotcurrentrole = 52)) THEN
       -- chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_end); 31.03.2014u
        IF (aACTIVITY.pLabor = 200) OR (aACTIVITY.pLabor = 201) OR (aACTIVITY.pLabor = 202) OR
           (aACTIVITY.pLabor = 203) OR (aACTIVITY.pLabor = 204) OR (aACTIVITY.pLabor = 205) OR
           (aACTIVITY.pLabor = 206) OR (aACTIVITY.pLabor = 207)
            -- 17.01.2013 ОЛВ со слов РАВ
          OR   (aACTIVITY.pLabor = 208) OR (aACTIVITY.pLabor = 214) OR (aACTIVITY.pLabor = 215)
          OR  (aACTIVITY.pLabor = 216) OR (aACTIVITY.pLabor = 217)
         THEN
          null;-- 31.03.2014 01.07.2014 РАВ
          /* chahge_date_activity(chahge_date_activity.COUNT + 1) := 94; -- 31.03.2014
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1; /* */ -- 31.03.2014
        ELSE
        chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_end);
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 95;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
        END IF;
      END IF;

      IF (pACTIVITY = 1) AND ((A_F_Relprotcurrentrole = 56) OR (A_F_Relprotcurrentrole = 57)) THEN
        chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_end);
           chahge_date_activity(chahge_date_activity.COUNT + 1) := 95;
        chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
      END IF;
      a := 0;
      IF pACTIVITY = 2 THEN
        chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_end);
        IF (aACTIVITY.pLabor = 225) OR (aACTIVITY.pLabor = 228) OR (aACTIVITY.pLabor = 231) OR (aACTIVITY.pLabor = 233) THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 97;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
          a := 1;
        END IF;
        IF (aACTIVITY.pLabor = 226) OR (aACTIVITY.pLabor = 227) OR (aACTIVITY.pLabor = 229) OR (aACTIVITY.pLabor = 230) OR (aACTIVITY.pLabor = 232) THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 99;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
          a := 1;
        END IF;
        IF (aACTIVITY.pLabor = 221) THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 56;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
          a := 1;
        END IF;

        -- 17.01.2012 ОЛВ -- Окончание академического отпуска для пособий по уходу
        IF Xlpl.ALLOC_CODE=491 THEN
            IF (aACTIVITY.pLabor = 321) THEN
               chahge_date_activity(chahge_date_activity.COUNT + 1) := 319;
               chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
               a := 1;
            END IF;
        END IF;

        IF a = 0 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 998;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
        END IF;
    END IF;

    -- безработица
      a := 0;
      IF pACTIVITY = 3 THEN
        chahge_date_activity(chahge_date_activity.COUNT + 1) := S_Julian(aACTIVITY.activity_end);
        IF aACTIVITY.pLabor = 241 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 303;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
          a := 1;
        END IF;
        IF aACTIVITY.pLabor = 243 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 305;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
          a := 1;
        END IF;
        IF aACTIVITY.pLabor = 242 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 307;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
          a := 1;
        END IF;
        IF a = 0 THEN
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 309;
          chahge_date_activity(chahge_date_activity.COUNT + 1) := 1;
        END IF;
      END IF;
    END IF;
  END LOOP;
  RETURN chahge_date_activity;
--RAISE_APPLICATION_ERROR(-20801,'B_F_Arraydateestactivity 99999  XLPL.GetPid='||Xlpl.GetPid|| '  chahge_date_activity.COUNT='||chahge_date_activity.COUNT);
END B_F_Arraydateestactivity;
/
