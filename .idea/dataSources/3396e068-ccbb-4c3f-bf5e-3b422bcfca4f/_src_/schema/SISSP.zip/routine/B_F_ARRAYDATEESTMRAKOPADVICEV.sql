CREATE FUNCTION       B_F_ARRAYDATEESTMRAKOPADVICEV(AOPINION_TYPE IN BINARY_INTEGER, AADVICE_TYPE IN BINARY_INTEGER) RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_F_ARRAYDATEESTMRAKOPADVICEV
 Наименование       : Построение массива прогнозируемых дат по инвалидности всех лиц в деле
                       для пособий ст. 3-х лет
 Автор              : ОЛВ    по Ворошилину В.  корректировка РАВ
 Состояние на дату  : 02.08.2012             13.03.2013	25.10.2013
 Код возврата       : Возвращает массив дат изменения характеристик
***********************************************************************************************/
  xDATES           DBMS_SQL.NUMBER_TABLE;
  xDRIDS           DBMS_SQL.NUMBER_TABLE;
  pPID             NUMBER;
  vsDRID           NUMBER;
  vsAOPINION_TYPE  VARCHAR2(2000);
  vsAADVICE_TYPE   VARCHAR2(2000);
  vsMin            DATE;
  vsMax            DATE;
  S_Date           DATE;
BEGIN
  xDATES.DELETE;
  xDRIDS.DELETE;
  S_Date:=S_Currdate;
 -- pEndDate := null;
 -- pminEndDate := null;
 -- все RID из W$CASE_PERSON согласно коду по W$RELATION_PROTOCOL
    xDRIDS := A_F_Relprotgetridwcaseperspid;
    --xDRIDS := A_F_Relprotgetridwcaseperspid1;
 --RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTMRAKOPADVICEV  ' ||xDRIDS(1)||' '||xDRIDS(2)||' '||xDRIDS(3)||' '||xDRIDS(4));
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTMRAKOPADVICEV   xDRIDS.COUNT=' || xDRIDS.COUNT );

 IF xDRIDS.COUNT <> 0 THEN
   FOR i IN 1..xDRIDS.COUNT LOOP
        vsDRID := xDRIDS(i);
        --RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTMRAKOPADVICEV  ' ||xDRIDS(1)||' '||xDRIDS(2)||' '||xDRIDS(3)||' '||xDRIDS(4));
        SELECT PID INTO pPID
        FROM W$CASE_PERSON
        WHERE RID=vsDRID;
    FOR MRAKOPADVICE IN (SELECT NVL(a.RECORD_START, NULL) AS vsRECORD_START,
                              NVL(a.RECORD_END, NULL) AS vsRECORD_END,
                              NVL(b.EXAMED_FROM, NULL) AS vsEXAMED_FROM,
                              NVL(a.DIS_TERM, NULL) AS vsDIS_TERM
                       FROM W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
                       WHERE a.PID = pPID
                         AND a.STAGE   IN (1,4)
                         AND b.STAGE   IN (1,4)
                         AND a.ENTERED_BY = Xlpl.User_ID
                         AND b.RID = a.MRAK_RID
                         AND b.ENTERED_BY = MRAK_ENTERED_BY
                         AND (
                               (NVL(NVL(a.RECORD_START, b.EXAMED_FROM), LAST_DAY(S_Date)+1) > LAST_DAY(S_Date))
                            OR (NVL(NVL(a.RECORD_END,a.DIS_TERM),       LAST_DAY(S_Date)+1) > LAST_DAY(S_Date))
                            )
                         AND a.OPINION_TYPE = AOPINION_TYPE
                         AND a.ADVICE_TYPE IN (11,12,13,14)) --AADVICE_TYPE)
  LOOP
  --RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTMRAKOPADVICEV   vsRECORD_START='||  CHR(10)||'    pPID  '||pPID);
    IF MRAKOPADVICE.vsRECORD_START IS NULL THEN
      vsMin := MRAKOPADVICE.vsEXAMED_FROM;
    ELSE
      vsMin := MRAKOPADVICE.vsRECORD_START;
    END IF;
  --RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTMRAKOPADVICEV   vsRECORD_START='||MRAKOPADVICE.vsRECORD_START||CHR(10)||'    pPID  '||pPID);
    IF MRAKOPADVICE.vsDIS_TERM IS NULL AND MRAKOPADVICE.vsRECORD_end IS NULL THEN
       select birth_date into vsMax from w$person where pid=ppid and stage in (1,4) AND  ENTERED_BY = Xlpl.User_ID and close_date is null;-- 25.10.2013 Речицкая АВ
       --select birth_date into vsMax from w$person where pid=ppid and stage in (1,4)  and close_date is null;  --06.03/2013 Речицкая АВ
       vsMax := S_Addyears(vsMax, S_Const(407, Xlpl.WorkDate))-1;--06.03/2013 Речицкая АВ
              -- vsMax :=vsMax
    END IF;

    IF MRAKOPADVICE.vsDIS_TERM IS NOT NULL AND MRAKOPADVICE.vsRECORD_end IS NULL THEN
       vsMax := MRAKOPADVICE.vsDIS_TERM;
    END IF;
    IF MRAKOPADVICE.vsDIS_TERM IS NULL AND MRAKOPADVICE.vsRECORD_end IS NOT NULL THEN
       vsMax := MRAKOPADVICE.vsRECORD_end;
    END IF;
    IF MRAKOPADVICE.vsDIS_TERM IS NOT NULL AND MRAKOPADVICE.vsRECORD_end IS NOT NULL THEN
       IF MRAKOPADVICE.vsRECORD_end > MRAKOPADVICE.vsDIS_TERM THEN
             vsMax := MRAKOPADVICE.vsDIS_TERM;
       ELSE
          vsMax := MRAKOPADVICE.vsRECORD_end;
       END IF;
    END IF;
    IF vsMin IS NOT NULL THEN
      IF vsMin > LAST_DAY(S_Currdate) THEN
        xDATES(xDATES.COUNT + 1) := S_Julian(vsMin) - 1;
        IF AOPINION_TYPE = 1 THEN
          xDATES(xDATES.COUNT + 1) := 314;
          xDATES(xDATES.COUNT + 1) := 1;
        ELSE
          xDATES(xDATES.COUNT + 1) := 315;
          xDATES(xDATES.COUNT + 1) := 1;
        END IF;
      END IF;
    END IF;
    IF vsMax IS NOT NULL THEN
      IF (vsMax +1) > LAST_DAY(S_Currdate) THEN
        /* OLV 17.07.2012 со слов РАВ
        Прогнозируемая дата закрытия пособия принимает следующее значение:
          - последний день месяца в котором истекает срок действия инвалидности - для ребенка;
          - дата истечения срока действия инвалидности для матери (отца или опекуна, если таковые являются получателями пособия)
        if A_F_GETROLE in (55,57,52,69) then
            null;
        else*/
        IF A_F_Getrole =56 THEN
            vsMax :=  (vsMax);
           -- vsMax :=  (vsMax)-1;  06/02/2013
            -- vsMax := LAST_DAY(vsMax);
        END IF;

        xDATES(xDATES.COUNT + 1) := S_Julian(vsMax);
        IF AOPINION_TYPE = 1 THEN
          xDATES(xDATES.COUNT + 1) := 33;  -- Истечение срока действия инвалидности
          xDATES(xDATES.COUNT + 1) := 2;
        ELSE
          xDATES(xDATES.COUNT + 1) := 58;  -- Окончание нуждаемости лица в постоянном уходе
          xDATES(xDATES.COUNT + 1) := 2;
        END IF;
      END IF;
    END IF;
  END LOOP;
  END LOOP;
    END IF;
 --RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTMRAKOPADVICEV  ' ||xDATES(1)||' '||xDATES(2)||' '||xDATES(3)||' '||xDATES(4)||pPID);
  RETURN xDATES;
END B_F_ARRAYDATEESTMRAKOPADVICEV;--_MOTHER;
/
