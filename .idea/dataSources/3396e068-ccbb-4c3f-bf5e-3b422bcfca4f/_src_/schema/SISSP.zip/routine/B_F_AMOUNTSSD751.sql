CREATE FUNCTION       B_F_AmountSSD751(ACID NUMBER) RETURN NUMBER IS
/* --------------------------------------------------------------------
// Автор: Иванова Т.С.
// состояние на 7.05.2014,12.01.2016
// Функция выбирает сумму ССД при назначении адр. помощи для массового расчета
// --------------------------------------------------------------------*/
 vsSSD NUMBER;
BEGIN
 vsSSD :=0; --12.01.2016 null;
 begin
 select distinct NVL(SSD,0) into vsSSD
  from CASE_SUMMARY_INCOME
   where CID = ACID
   and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
   and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
   and NVL(STAGE,0) not IN (2,3);
  exception  --12.01.2016
        when NO_DATA_FOUND then
          vsSSD:= 0;
  end; --12.01.2016
  /*12.01.2016 if vsSSD is  null
    then return 0;
  	else
    return vsSSD;
   end if;*/
   return vsSSD; --12.01.2016
END B_F_AmountSSD751;
/
