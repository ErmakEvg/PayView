CREATE FUNCTION       B_F_ARRAYDATEESTGARD_20020401 RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_F_ARRAYDATEESTGARD_20020401
 Наименование       : Функция построения прогнозируемых дат для пособий на детей до 3 лет
 Автор              : Ворошилин В.               Комментарии: ОЛВ
 Состояние на дату  : 03.05.2000                        23.03.2010
 Код возврата       : возвращает массив с датой наступления 1,5 года для Estimation
***********************************************************************************************/

  result_array DBMS_SQL.NUMBER_TABLE;
BEGIN
  result_array.delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CheckRole(56) then
    return result_array;
  end if;
  XLPL.REPLACEROLE('Child');

  -- 402 - Ограничение 1 возраста ребенка для пособия по уходу за ребенком в возрасте до 3 лет, посещающим детское дошкольное учреждение - в годах
  -- 513 - 2 года Ограничение 2 возраста ребенка для пособия по уходу за ребенком в возрасте до 3 лет, посещающим детское дошкольное учреждение - в годах
  -- 514 - 2,5 года Ограничение 3 возраста ребенка для пособия по уходу за ребенком в возрасте до 3 лет, посещающим детское дошкольное учреждение - в годах
  if (B_AddYearsMonths(A_F_RelProtBirthDay,S_Const(402, XLPL.WorkDate)) + 1) > LAST_DAY(S_CurrDate) then
    result_array(1) := S_Julian(B_AddYearsMonths(A_F_RelProtBirthDay,S_Const(402, XLPL.WorkDate)) + 1);
    result_array(2) := 21;
    result_array(3) := 3;
	XLPL.RESTOREROLE;
    return result_array;
  end if;

  if ((B_AddYearsMonths(A_F_RelProtBirthDay,S_Const(402, XLPL.WorkDate)) + 1) <= LAST_DAY(S_CurrDate))
     and ((B_AddYearsMonths(A_F_RelProtBirthDay,S_Const(513, XLPL.WorkDate)) + 1) > LAST_DAY(S_CurrDate)) then
    result_array(1) := S_Julian(B_AddYearsMonths(A_F_RelProtBirthDay,S_Const(513, XLPL.WorkDate)) + 1);
    result_array(2) := 21;
    result_array(3) := 3;
	XLPL.RESTOREROLE;
    return result_array;
  end if;

  if ((B_AddYearsMonths(A_F_RelProtBirthDay,S_Const(513, XLPL.WorkDate)) + 1) <= LAST_DAY(S_CurrDate))
     and ((B_AddYearsMonths(A_F_RelProtBirthDay,S_Const(514, XLPL.WorkDate)) + 1) > LAST_DAY(S_CurrDate)) then
    result_array(1) := S_Julian(B_AddYearsMonths(A_F_RelProtBirthDay,S_Const(514, XLPL.WorkDate)) + 1);
    result_array(2) := 21;
    result_array(3) := 3;
	XLPL.RESTOREROLE;
    return result_array;
  end if;
  XLPL.RESTOREROLE;
  return result_array;
END B_F_ARRAYDATEESTGARD_20020401;
/
