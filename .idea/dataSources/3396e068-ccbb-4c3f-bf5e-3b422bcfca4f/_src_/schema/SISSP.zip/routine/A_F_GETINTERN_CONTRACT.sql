CREATE FUNCTION       A_F_GetIntern_Contract(Base_ID in NUMBER)
   RETURN NUMBER AS
/**********************************************************************************************
 Функция            : A_F_GetIntern_Contract
 Наименование       : Назначение по Международному Договору
 Автор              : ОЛВ
 Состояние на дату  : 25.09.2010  01.08.2011
 Код возврата       : Код государства - 1 - РБ
***********************************************************************************************/
 vsPR_COUNTRY      NUMBER;
BEGIN
 begin
   if Base_ID=0 then
         select NVL(Country,-1) -- Country is null - запись всегда есть - означает по Закону о пенс. обесп. РБ - со слов С.А. 22.12.2010
		   into vsPR_COUNTRY
		   from W$CASE
		  where CID=XLPL.CID
		    and ENTERED_BY=XLPL.USER_ID                --and CASE_USER_ID=XLPL.USER_ID
		    and STAGE not in (2, 3);
      else
         select NVL(Country,-1)
		   into vsPR_COUNTRY
		   from CASE
		  where CID=XLPL.CID
		    and STAGE is null; -- 01.08.2011 OLV  --not in (2, 3); - не работает
      end if;

   exception
      when NO_DATA_FOUND then
         vsPR_COUNTRY:=-1;
   end;
   return vsPR_COUNTRY;
 --RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetCountry  2 vsCountry='||vsCountry);

END A_F_GetIntern_Contract;
/
