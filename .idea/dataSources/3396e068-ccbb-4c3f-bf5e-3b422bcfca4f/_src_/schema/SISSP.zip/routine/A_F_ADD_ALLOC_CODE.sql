CREATE FUNCTION       A_F_Add_Alloc_Code(pCID in Number,pAID in Number)
   RETURN DBMS_SQL.Number_Table IS
/*Возвращает код основного назначения и процент повышения пенсии за особые заслуги
Вахромин О.Ю.*/
wRESULT DBMS_SQL.Number_Table;
wAlloc_Code Number;
wAdd_Alloc_Code Number;
wIncrease_Percent Number;
BEGIN
-- Формирование ADD_ALLOC_CODE и INCREASE_PERCENT для W$ALLOCATION_PROTOCOL
-- для пенсии за особые заслуги ALLOC_CODE = 50
   wAlloc_Code:=0;
   wAdd_Alloc_Code:=0;
   wIncrease_Percent:=0;
   begin
      Select alloc_code,nvl(add_alloc_code,0),nvl(INCREASE_PERCENT,0) into
         wAlloc_Code, wAdd_Alloc_Code,wIncrease_Percent from w$allocation
          	 where  aid = pAID and Cid = pCID and
	         PARENT_RID is null and COMP_PART is null and stage =1 and Entered_by = XLPL.User_Id
			 and Step_start = (  Select max(Step_start) from w$allocation
	         where  aid =pAID and Cid = pCID and
	         PARENT_RID is null and COMP_PART is null and stage =1 and Entered_by = XLPL.User_Id) ;
   exception
      when NO_DATA_FOUND then
         wRESULT(0):=0;
   end;
   if(wAlloc_Code = 0) then
      wRESULT(0):=0;
   elsif (wAdd_Alloc_Code=0) then
      wRESULT(0):=wAlloc_Code;
   else
      wRESULT(0):=wAdd_Alloc_Code;
   end if;
   wRESULT(1):=wIncrease_Percent;
return wRESULT;
END A_F_Add_Alloc_Code;
/
