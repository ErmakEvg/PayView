CREATE FUNCTION       A_APPLICATION(ACID IN NUMBER,ACATEGORY IN NUMBER)
   RETURN NUMBER IS
/******************************************************************************
 Функция           : A_APPLICATION
 Наименование      :  Ф-я определения причины заявления по РБД
 Автор             : Иванова Тамара Степановна
 Состояние на дату : 22.05.2017 ,
                    14.06.2017 --добавлена категория
 Код возврата      : код причины обращения (справочник REQUEST),0 - нет заявления
******************************************************************************/
RET number;
BEGIN
 begin
 SELECT REQUEST_REASON INTO RET FROM W$APPLICATION ap, ID_CASE  ic
  WHERE ap.CID = ACID and ic.access_data =ACATEGORY
   and ap.stage =4 and ap.CID=ic.CID;
 RETURN  RET;
 EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN 0;
  END;

END A_APPLICATION;
/
