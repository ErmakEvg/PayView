CREATE FUNCTION       B_F_GetPaymentProcentIndiv3 RETURN NUMBER IS
--==============================================================================
-- Назначение: читает процент выплаты для пособий при массовых расчетах
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Возвращаемое значение: - % выплаты (0, если сбой при выполнении)
--==============================================================================
xCID NUMBER;
xAID NUMBER;
xWorkDate DATE;
Long_Range_Date DATE;
xResume NUMBER;
BEGIN
xCID := XLPL.CID;
xAID := XLPL.AID;
xWorkDate := XLPL.WORKDATE;
begin
  select NVL(payment_percent, 0)
  into xResume
  from ALLOCATION
  where cid = xCID
  and aid = xAID
  and parent_rid is null
  and COMP_PART is null
  and alloc_status = 1
  and (stage is null or stage <> 2)
  and NVL(step_START, xWorkDate) <= xWorkDate
  and NVL(step_END, xWorkDate) >= xWorkDate;
exception
  when NO_DATA_FOUND then
    xResume := 0;
  when OTHERS then
    xResume := 0;
end;
if xResume != 0 then
  begin
    select ESTIMATION_DATE
    into Long_Range_Date
    from PAYMENT_DATE_ESTIMATION
    where CID = xCID
    and STATUS_REASON = 21
    and CHANGE_PAYMENT_STATUS = 3
    and (STAGE is null or STAGE not in (2, 3));
  exception
    when NO_DATA_FOUND then
      Long_Range_Date := NULL;
    when OTHERS then
      Long_Range_Date := NULL;
  end;
  if Long_Range_Date is NOT NULL then
    if Long_Range_Date <= xWorkDate then
      xResume := 50;
    end if;
  end if;
end if;
RETURN xResume;
END B_F_GetPaymentProcentIndiv3;
/
