CREATE FUNCTION       B_F_GETPID_APPLICATION(pCID IN NUMBER,pENTERED_BY IN NUMBER, pBase_ID IN NUMBER) RETURN NUMBER AS
-- Возвращает PID заявителя
/*****************************************************************************
// Автор:Абрамович М.В.
// Состояние на 10.10.2018
// Код возврата: PID заявителя в деле или 0,если PID заявителя отсутствует
// *****************************************************************************/

vsPID NUMBER;
BEGIN
    BEGIN
    IF pBase_ID=0 then
     SELECT  distinct PID_APPL INTO vsPID --RBD
     FROM
      (SELECT CASE WHEN CNT_APPL = 0 THEN 0 --в заявлении нет записи
              ELSE (SELECT NVL(PID,0) PID FROM W$APPLICATION ap  --в заявлении запись есть
                    WHERE ap.CID = pCID  AND ap.STAGE not IN (2,3)
                          and ap.ENTERED_BY = pENTERED_BY AND pBase_ID=0)
             END PID_APPL
        FROM (SELECT COUNT(CID) CNT_APPL FROM W$APPLICATION ap  --кол-во записей в заявлении
                   WHERE  ap.CID = pCID  AND  ap.STAGE not IN (2,3)
                          AND ap.ENTERED_BY = pENTERED_BY AND pBase_ID=0) );
     ELSE
     SELECT  distinct PID_APPL INTO vsPID --OBD
     FROM
      (SELECT CASE WHEN CNT_APPL = 0 THEN 0 --в заявлении нет записи
              ELSE (SELECT NVL(PID,0) PID FROM APPLICATION ap  --в заявлении запись есть
                    WHERE ap.CID = pCID  AND ap.STAGE is NULL AND pBase_ID=1)
              END PID_APPL
        FROM (SELECT COUNT(CID) CNT_APPL FROM APPLICATION ap  --кол-во записей в заявлении
                   WHERE  ap.CID = pCID  AND  ap.STAGE is NULL AND pBase_ID=1) );
    END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vsPID := 0; --raise_application_error(-20801, 'FI_PROCESSINGALLOCATION: В деле '|| to_char(XLPL.CID) ||' нет получателя');
      WHEN TOO_MANY_ROWS THEN
        raise_application_error(-20801, 'FI_PROCESSINGALLOCATION: В деле '|| to_char(XLPL.CID) ||' больше одного заявителя');
      WHEN OTHERS THEN
        vsPID := 0;
    END;
RETURN vsPID;

END B_F_GETPID_APPLICATION;
/
