CREATE FUNCTION       B_F_ARRAYDATEESTCHILD18 RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: B_F_ARRAYDATEESTCHILD3
+ Наименование: Формирование дат Estimation для ребенка до 3 лет
+ Автор: Ворошилин В.
+ Состояние на дату 20/09/2002
==============================================================================*/

result_step_start DBMS_SQL.NUMBER_TABLE;
result_function DBMS_SQL.NUMBER_TABLE;
j NUMBER;

BEGIN

result_step_start.delete;

result_function.delete;
result_function := B_F_ARRAYDATEESTAGE3_N;
--result_function.delete;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ARRAYDATEESTAGE18;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;
result_function.delete;

result_function := B_F_ArrayDateEstMETRIC;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivity(2);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstAddress;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstAddressAbsent;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstBirthDeath;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;
--RAISE_APPLICATION_ERROR(-20004,'B_F_ARRAYDATEESTCHILD18 result_step_start.count='|| result_step_start.count);
return result_step_start;
END B_F_ARRAYDATEESTCHILD18;
/
