CREATE FUNCTION       B_Child16_NadbavkaT_0 RETURN DBMS_SQL.NUMBER_TABLE AS
/***************************************************************************************
 Функция: Child16_NadbavkaT
 Наименование: Проверка права и вычисление надбавок на пособие детям старше 3 лет
 Автор: Ворошилин В.
 Состояние на дату 26.09.2002
 Код возврата: массив, содержащий коды надбавок и соответствующие суммы надбавок
***************************************************************************************/

K DBMS_SQL.NUMBER_TABLE;
M DBMS_SQL.NUMBER_TABLE;

BEGIN

K.delete;
M.delete;

M := B_F_Nad1;
if M.count <> 0 then
   K := M;
end if;

if F$CHECK583 then K(583) := F$AMOUNT583; end if;

Return K;

END B_Child16_NadbavkaT_0;
/
