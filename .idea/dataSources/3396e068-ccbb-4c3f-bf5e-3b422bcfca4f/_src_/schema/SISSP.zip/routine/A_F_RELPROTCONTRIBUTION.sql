CREATE FUNCTION       A_F_RelProtContribution(Base_ID in NUMBER)
                    RETURN DBMS_SQL.Number_Table IS
/******************************************************************************
 NAME           : A_F_RelProtGetContribution
 Назначение     : Возращает из W$CONTRIBUTION согласно W$RELATION_PROTOCOL
 Автор          :  ОЛВ
 Дата           : 31.05.2010
 Код возврата   :
******************************************************************************/
 wRESULT           DBMS_SQL.Number_Table;
 vsRelation_Table  NUMBER;
 vAmount           NUMBER;
 vPercent          NUMBER;
 vPrFinance       NUMBER;

BEGIN
   if Base_ID=0 then
      vsRELATION_TABLE :=S_CodeTableSissp('W$CONTRIBUTION');
   else
      vsRELATION_TABLE :=S_CodeTableSissp('CONTRIBUTION');
   end if;

   vAmount:=0;
   vPercent:=0;
   vPrFinance:=0;
--RAISE_APPLICATION_ERROR(-20801,' P_Size_Ds   XLPL.WORKDATE='||XLPL.WORKDATE||', XLPL.GetPID='||XLPL.GetPID||', XLPL.CID='||XLPL.CID||', XLPL.USER_ID='||XLPL.USER_ID);
   begin
      if Base_ID=0 then
         select nvl(Amount,0),nvl(PERCENT,0),nvl(PR_FINANCE,0)
		   into vAmount,vPercent,vPrFinance
		   from W$RELATION_PROTOCOL b,W$CONTRIBUTION a
		  where b.CID=XLPL.CID and (AID = XLPL.AID or XLPL.AID=0)
		    and ((GROUP_NO=XLPL.GROUP_NO)or(XLPL.AID<>0 and XLPL.GROUP_NO=0))
			and ALLOC_CODE=XLPL.ALLOC_CODE
			and b.ENTERED_BY=XLPL.USER_ID and a.ENTERED_BY=XLPL.USER_ID
			and RELATION_TABLE=vsRELATION_TABLE
			and RELATION_DATE=XLPL.WorkDate and DATA_RID=a.RID
			and a.STAGE in (1,4)
			and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE) and
                                      NVL(a.RECORD_END,XLPL.WORKDATE) and
            a.PID=XLPL.GetPID;
      else
         select nvl(Amount,0),nvl(PERCENT,0),nvl(PR_FINANCE,0)
           into vAmount,vPercent,vPrFinance
           from CONTRIBUTION
          where CID=XLPL.CID
         --   and ENTERED_BY=XLPL.USER_ID
            and STAGE is null
            and (XLPL.WorkDate between NVL(RECORD_START,XLPL.WORKDATE)
                                  and NVL(RECORD_END,XLPL.WORKDATE) )
            and PID=XLPL.GetPID;
/* *
         select nvl(Amount,0),nvl(PERCENT,0),nvl(PR_FINANCE,0)
		   into vAmount,vPercent,vPrFinance
		   from W$RELATION_PROTOCOL b,CONTRIBUTION a
		  where b.CID=XLPL.CID
		    and (AID = XLPL.AID or XLPL.AID=0)
		    and ((GROUP_NO=XLPL.GROUP_NO)or(XLPL.AID<>0 and XLPL.GROUP_NO=0))
			and ALLOC_CODE=XLPL.ALLOC_CODE
			and b.ENTERED_BY=XLPL.USER_ID and a.ENTERED_BY=XLPL.USER_ID
			and RELATION_TABLE=vsRELATION_TABLE
			and RELATION_DATE=XLPL.WorkDate and DATA_RID=a.RID
			and a.STAGE in (1,4)
			and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE) and
                                      NVL(a.RECORD_END,XLPL.WORKDATE) and
            a.PID=XLPL.GetPID;
            /* */
      end if;
   exception
      when NO_DATA_FOUND then
         wRESULT(0):=0;
   end;

   wRESULT(0):=vAmount;
   wRESULT(1):=vPercent;
   wRESULT(2):=vPrFinance;

return wRESULT;
END A_F_RelProtContribution;
/
