CREATE FUNCTION       B_F_EnterCheck RETURN BOOLEAN IS
--==============================================================================
-- Назначение: проверяет, имеет ли право лицо получать пособие на момент подачи
--             заявления
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Возвращаемое значение: True - имеет право, False - не имеет права
--==============================================================================
xResume BOOLEAN;
old_WorkDate DATE;
new_WorkDate DATE;
xPIDw BOOLEAN;
xPIDb BOOLEAN;
xPIDs BOOLEAN;

BEGIN
new_WorkDate := A_F_DataTalk;
old_WorkDate := XLPL.WorkDate;
XLPL.SETWORKDATE(new_WorkDate);
xPIDw := A_F_RelProtActv('1', ''); -- работает ли
-- право получения
xPIDb := A_F_RelProtActv('1', '200, 201, 202, 203, 204, 205, 206, 207');
xPIDs := A_F_RelProtActv('2', ''); -- учится ли
XLPL.SETWORKDATE(old_WorkDate);
if (xPIDw and xPIDb) or xPIDs then
  xResume := True;
else
  xResume := False;
end if;

RETURN xResume;
END B_F_EnterCheck;
/
