CREATE FUNCTION       A_F_RelProtMetricPerson(ACODE_ROLE in NUMBER, pMetric IN NUMBER, pAge IN NUMBER, pWorkDate in DATE) RETURN BOOLEAN AS
/***************************************************************************************
 Функция           : A_F_RelProtMetricPerson
 Наименование      : Проверка наличия в деле инвалидов по закл. МРЭК pADVICE_TYPE
                                            с ролью ACODE_ROLE в возрасте до pAge
 Автор             : ОЛВ
 Состояние на дату : 02.06.2010   01.08.2011
 Код возврата      : возвращает true, если есть человек с ролью ACODE_ROLE
****************************************************************************************/

  xDRIDS        DBMS_SQL.NUMBER_TABLE;
  vsDRID        NUMBER;
  pCount        NUMBER;

BEGIN
  xDRIDS.delete;
  pCount := 0;

  -- все RID из CASE_PERSON согласно коду по W$RELATION_PROTOCOL
  xDRIDS := A_F_RelProtGetRIDCasePersonPid;

 if xDRIDS.count <> 0 then

   for i in 1..xDRIDS.count loop
	    vsDRID := xDRIDS(i);
	  select count(*) into pCount
	  from CASE_PERSON a, PERSON b, PERSON_METRIC c
	  where a.RID = vsDRID
	    AND	a.PID = b.pid
	    AND	a.PID = c.pid
		AND a.ROLE = ACODE_ROLE
		AND c.code=pMetric
		--AND a.ENTERED_BY=Xlpl.USER_ID
		and c.STAGE is null -- 01.08.2011 OLV  -- не работает AND c.STAGE not in (2, 3)
		AND S_AddYears (b.BIRTH_DATE,ROUND(pAge)) >= pWorkDate
		AND NVL(c.RECORD_START, pWorkDate) <= pWorkDate
		AND NVL(c.RECORD_END, pWorkDate) >= pWorkDate;

	    IF pCount>0 THEN
           RETURN TRUE;
        END IF;
   end loop;
 end if;

 -- все RID из W$CASE_PERSON согласно коду по W$RELATION_PROTOCOL
    xDRIDS := A_F_RelProtGetRIDWCasePersPid;
 if xDRIDS.count <> 0 then
   for i in 1..xDRIDS.count loop
	    vsDRID := xDRIDS(i);
	  select count(*) into pCount
	  from W$CASE_PERSON a, W$PERSON b, W$PERSON_METRIC c
	  where a.RID = vsDRID
	    AND	a.PID = b.pid
	    AND	a.PID = c.pid
		AND a.ROLE = ACODE_ROLE
		AND c.code=pMetric
		--AND a.ENTERED_BY=Xlpl.USER_ID
		AND c.STAGE not in (2, 3)
		AND S_AddYears (b.BIRTH_DATE,ROUND(pAge)) >= pWorkDate
		AND NVL(c.RECORD_START, pWorkDate) <= pWorkDate
		AND NVL(c.RECORD_END, pWorkDate) >= pWorkDate;

	    IF pCount>0 THEN
           RETURN TRUE;
        END IF;
   end loop;

 end if;
  RETURN FALSE;

--RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtDisPerson 1   XLPL.WorkDate='||XLPL.WorkDate);
END A_F_RelProtMetricPerson;
/
