CREATE FUNCTION       A_F_RelProtGetByRidRecord(Base_ID in NUMBER,pRECORD_CODE in NUMBER)
   RETURN NUMBER AS
/***************************************************************************************
 Функция             :  A_F_RelProtGetByRidRecord
 Наименование        :  Функция выбора расчитанного стажа
 Автор               :  Вахромин О.Ю.         Комментарии и корректировка : ОЛВ
 Состояние на дату   :  		 				  			  	     08.06.2011
 Код возврата        :  Возращает RECORD_DAYS из MANUAL_RECORD согласно W$RELATION_PROTOCOL
***************************************************************************************/
 vsRelation_Table NUMBER;
 vsRECORD_DAYS    NUMBER;
BEGIN
 /* OLV 08.06.2011 *
   if Base_ID=0 then
      vsRELATION_TABLE :=S_CodeTableSissp('W$RECORD');
   else
      vsRELATION_TABLE :=S_CodeTableSissp('RECORD');
   end if; /* */

   begin
      if Base_ID=0 then
            vsRELATION_TABLE :=S_CodeTableSissp('W$RECORD'); -- OLV перенесла 08.06.2011
         select RECORD_DAYS
		   into vsRECORD_DAYS
		   from W$RELATION_PROTOCOL b,W$RECORD a
		  where CID=XLPL.CID
		    and (AID = XLPL.AID or XLPL.AID=0)
			and ((GROUP_NO=XLPL.GROUP_NO) or (XLPL.AID<>0 and XLPL.GROUP_NO=0))
			and ALLOC_CODE=XLPL.ALLOC_CODE
			and b.ENTERED_BY=XLPL.USER_ID
			and a.ENTERED_BY=XLPL.USER_ID
			and RELATION_TABLE=vsRELATION_TABLE
			and RELATION_DATE=XLPL.WorkDate
			and DATA_RID=a.RID
			and a.STAGE in (1,4,6)
			and (XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE) and
                                       NVL(a.RECORD_END,XLPL.WORKDATE))
		    and a.PID=XLPL.GetPID and a.RECORD_CODE=pRECORD_CODE;
      else
            vsRELATION_TABLE :=S_CodeTableSissp('RECORD');  -- OLV перенесла 08.06.2011
         select RECORD_DAYS
		   into vsRECORD_DAYS
		   from W$RELATION_PROTOCOL b,RECORD a
		  where CID=XLPL.CID
		    and (AID = XLPL.AID or XLPL.AID=0)
			and ((GROUP_NO=XLPL.GROUP_NO) or (XLPL.AID<>0 and XLPL.GROUP_NO=0))
			and ALLOC_CODE=XLPL.ALLOC_CODE
			and b.ENTERED_BY=XLPL.USER_ID
			and RELATION_TABLE=vsRELATION_TABLE
			and RELATION_DATE=XLPL.WorkDate
			and DATA_RID=a.RID
			and (XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE) and
                                       NVL(a.RECORD_END,XLPL.WORKDATE))
		    and a.PID=XLPL.GetPID
			and a.RECORD_CODE=pRECORD_CODE;
      end if;
   exception
      when NO_DATA_FOUND then
         vsRECORD_DAYS := 0;
   end;
   return vsRECORD_DAYS;
END A_F_RelProtGetByRidRecord;
/
