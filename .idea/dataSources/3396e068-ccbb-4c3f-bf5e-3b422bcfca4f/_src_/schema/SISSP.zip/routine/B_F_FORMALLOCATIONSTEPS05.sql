CREATE FUNCTION       B_F_Formallocationsteps05 RETURN DBMS_SQL.NUMBER_Table IS
/**********************************************************************************************
 Функция            : B_F_FormAllocationSteps05
 Наименование       : функция определяет шаги назначения по изменнениям
                       для пособий на детей старше 3 лет
 Автор              : Ворошилин В.           Комментарии и корректировка: ОЛВ
 Состояние на дату  : 27.09.2002                 31.08.2011  01.08.2012  25.06.2013
 Код возврата       : массив даты шагов
***********************************************************************************************/
 result_step_start DBMS_SQL.NUMBER_Table;        -- массив, накапливающий даты шагов
 result_array      DBMS_SQL.NUMBER_Table;        -- массив, содержащий готовые для возврата даты шагов (без повторений)
 result_function   DBMS_SQL.NUMBER_Table;        -- массив, в который функции возвращают даты шагов
 result_rab        DBMS_SQL.NUMBER_Table;
 aP                DBMS_SQL.NUMBER_Table;
 A                    DBMS_SQL.NUMBER_Table;

 pAlloc_Code        NUMBER;                         -- код назначения
 pAID                NUMBER;                           -- идентификатор назначения
 aPID                NUMBER;                        -- идентификатор лица
 pCID                NUMBER;                           -- идентификатор дела
 Param6m            NUMBER;                           -- признак превышения 6 месяцев
 i                    NUMBER;                          -- счетчик
 j                    NUMBER;                        -- счетчик
 k                    NUMBER;                        -- счетчик
 M                    NUMBER;
 Y                    NUMBER;
 GrNo                NUMBER;
 prnew                NUMBER;
 prold                NUMBER;
 Ag                NUMBER;
 flg_insert_result BOOLEAN;                          -- признак повтора дат
 bl                BOOLEAN;
 bl1                BOOLEAN;
 prdate            DATE;
 PuskDate            DATE;                           -- рабочая дата
 d1                DATE;                           -- дата, используемая для работы
 rDate                DATE;                           -- дата, используемая для работы
 BrDt1                DATE;
 DthDt                DATE;
 DtTalk            DATE;
 Datetalk            DATE;
 d6m                DATE;
 StopDt            DATE;
 BrDt                DATE;
 WDt                DATE;
 LimitDate            DATE;
 LimitDate_Vipl     DATE;     -- OLV  25.06.2013
 Dt                DATE;
 DtBirth            DATE;

BEGIN
 DtTalk := A_F_Datatalk;
 WDt := S_Currdate;    -- select trunc(sysdate) into d from dual;
 WDt := LAST_DAY(WDt);
 i := 0;                                                     -- счетчик
 j := 0;                                                  -- счетчик
 d1 := NULL;                                              -- дата, используемая для работы
 rDate := NULL;                                          -- дата, используемая для работы
 pAlloc_Code := Xlpl.Alloc_Code;                          -- код назначения
 pAID := Xlpl.AID;                                      -- идентификатор назначения
 pCID := Xlpl.CID;                                      -- идентификатор дела
 GrNo := Xlpl.Group_No;                                  -- номер группы
 aP.DELETE;
 A.DELETE;
 i := 0;
 j := 0;
 k := 0;

--==============================================================================
-- установка рабочих признаков:
-- если ParamPervNazn = 1, то это первичное назначение, иначе назначение есть
-- если Param6m = 1, то значит дата обращения превышает на 6 мес. дату начала
--                        действия назначения, иначе дата обращения не превышает
--                     дату начала действия на 6 мес.
--==============================================================================
d1 := Xlpl.WorkDate;
IF pAID = 0 THEN                                    -- Если это первичное назначение, то
   datetalk := A_F_Datatalk;                        -- Получить дату подачи заявления (или дату, указанную вручную)
   M := S_Const(432, Xlpl.WorkDate);                -- Взять срок срок обращения за пособием (в месяцах)
   d6m := ADD_MONTHS(d1, M);                            -- и добавить к дате начального шага.
   IF d6m < datetalk THEN                             -- Если полученная дата меньше даты подачи заявления, то
         Param6m := 1;                                    -- установить, что дата обращения превышает на 6 мес. дату начала действия назначения
   ELSE                                                -- иначе
      Param6m := 0;                                    -- дата обращения не превышает на 6 мес. даты возникновения права
   END IF;
ELSE                                                   -- иначе
   Param6m := 0;                                    -- обнулить признак не превышения на 6 мес. даты возникновения права
END IF;

PuskDate := d1;                                        -- Установить дату начала формирования переломных точек

--==============================================================================
-- Ниже для всей группы и для каждого члена группы выполняются просмотр рабочих
-- таблиц и определяются даты всех происшедших в них изменений, начиная
-- с даты возникновения права (даты назначения пособий) по дату подачи заявления
-- и создается масив, состоящий из дат изменений информации (переломных точек),
-- общий по всем таблицам.
--==============================================================================

----- для всей группы -----

IF pAID <> 0 THEN
   aP := B_F_Manageallocstatus;
   IF aP.COUNT > 0 THEN
       prnew := aP(1);
       prold := aP(2);
       prdate := S_Jtod(aP(3));
      IF prdate IS NOT NULL THEN
           result_step_start(result_step_start.COUNT+1) := S_Julian(prdate);
      END IF;
   END IF;
END IF;

aP.DELETE;

aP := A_F_Arrayallocationstep(Xlpl.WorkDate);
IF aP.COUNT > 0 THEN
     FOR k IN 1..aP.COUNT LOOP                                     -- в оригинале - индекс с нуля
           IF S_Jtod(aP(k)) > PuskDate THEN
             result_step_start(result_step_start.COUNT+1) := aP(k);
         END IF;
     END LOOP;
     aP.DELETE;
END IF;

aP.DELETE;

-- пособие семье неработающей, ухаживающей или безработной матери, воспитывающей ребенка старше 3 лет
IF pAlloc_Code = 467 THEN
   result_function.DELETE;
   result_function := B_F_Dateest(pCid, PuskDate);
   IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
   END IF;

   result_function.DELETE;
   result_function := A_P_Allocstartdateother(PuskDate, Param6m);
   IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
   END IF;

   result_function.DELETE;
   result_function := B_P_Allocclosedateother(PuskDate, Param6m);
   IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
   END IF;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangessd;
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;
/* */
 -------------------------------------------------------------
 --                  Получатель в назначении                --
 -------------------------------------------------------------
        -- точки начала и конца текущего выплатного периода для ручной корректировки данных после массового расчета  -- ОЛВ   25.06.2013
	    --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		     LimitDate_Vipl:=NULL;
			d1:=A_F_ViplPeriod_Start;
 	    IF d1 IS NOT NULL THEN
            result_step_start(result_step_start.COUNT+1):= S_Julian(d1);
			d1:=LAST_DAY(A_F_ViplPeriod_Start)+1;
            result_step_start(result_step_start.COUNT+1):= S_Julian(d1);
		       LimitDate_Vipl:=d1;
  --RAISE_APPLICATION_ERROR(-20004,'A_F_Arraydatachangedeldup    d1= '||d1||CHR(10)||'  LimitDate_Vipl='|| LimitDate_Vipl||CHR(10));
        END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangeperson(PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangeaddress(PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatedeath(PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangeactivity(1, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangeactivity(2, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangeactivity(3, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangewmrak(PuskDate, -1, -1, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangeaddressab(PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(145, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

      -- Прибыл(а) на постоянное место жительства в Республику Беларусь (имеет вид на жительство)
result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(183, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(156, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(154, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(231, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(232, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

      -- Не получал(а) пособие по уходу за ребенком в возрасте до 3 лет по месту работы, учебы
result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(256, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(650, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(651, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(652, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(653, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(654, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(655, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(656, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(657, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(658, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(659, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

      -- 121 - В/с срочной службы (солдат, матрос),  кроме проходящих службу по контракту
      -- 122 - В/о (солдат, матрос), призванный на учебные, специальные или поверочные сборы
      -- 125 - В/с срочной службы (сержант, старшина, ефрейтор, старший матрос),  кроме проходящих службу по контракту
      -- 126 - В/о (сержант, старшина, ефрейтор, старший матрос), призванный на учебные, специальные или поверочные сборы
result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(121, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(122, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(125, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(126, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(463, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

      -- Осуществляет уход за престарелым, инвалидом 1 группы или ребенком - инвалидом до 18 лет
result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(258, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

      -- Осуществляет уход за ребенком в возрасте до 3-х лет 31.08.2011 ОЛВ
result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(260, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(320, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(545, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(156, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(157, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Changepension(PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Changebenefit(PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

 -------------------------------------------------------------
 --                     Ребенок в назначении                --
 -------------------------------------------------------------
 IF  Xlpl.CheckRole(56) THEN
    Xlpl.RoleDecl('Child','56');
    Xlpl.REPLACEROLE('Child');

    result_function.DELETE;
    result_function := B_F_Arraydatechangeperson(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeaddress(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    -- возвращает массив с датой наступления 1,5 года
    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivitygar(PuskDate);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivitysc;
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    -- Функция определяет дату рождения ребенка, появившегося в деле
    result_function.DELETE;
    result_function := B_F_Childbd;
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Child3age;
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatedeath(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(1, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(2, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(3, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeaddressab(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(148, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

      -- Прибыл(а) на постоянное место жительства в Республику Беларусь (имеет вид на жительство)
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(183, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(358, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(155, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(320, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

      -- Проживает в семье (приходящий контингент)
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(171, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
--Речицкая АВ  добавлено 04.04.2013
 --188 - Находится на гос. обеспечении в ГУ, обеспечивающем получение образования по дневной форме обучения
 --679 - Проживает в детском доме семейного типа
 --680 - Проживает в детской деревне (городке)
 --681 - Проживает в приемной семье
 --682 - Проживает в приемной семье
 --193 - Находится на круглосуточном пребывании в ДУ

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(188, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(679, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(680, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(681, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(682, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(193, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
-- Речицкая АВ 04.04.2013
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(354, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

      -- Ребенок, над которым установлены опека или усыновление (удочерение) местными исполнительными органами
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(257, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(355, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(156, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(157, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(545, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

/* */
    result_function.DELETE;
    result_function := B_F_Arraydatechangewmrak(PuskDate, -1, -1, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
 /* */
    Xlpl.RestoreRole;
END IF;
 -------------------------------------------------------------
 --                     Отец в назначении                   --
 -------------------------------------------------------------
IF (Xlpl.CheckRole(57) AND NOT B_F_Recipient(57)) OR
    Xlpl.CheckRole(69) THEN
    Xlpl.RoleDecl('Father','57, 69');
    Xlpl.REPLACEROLE('Father');

    result_function.DELETE;
    result_function := B_F_Arraydatechangeperson(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeaddress(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(1, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(2, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(3, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

        result_function.DELETE;
    result_function := B_F_Arraydatedeath(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeaddressab(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

      -- Прибыл(а) на постоянное место жительства в Республику Беларусь (имеет вид на жительство)
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(183, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(650, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(651, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(652, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(653, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(654, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(655, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(656, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(657, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(658, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(659, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(463, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

      -- Не получал(а) пособие по уходу за ребенком в возрасте до 3 лет по месту работы, учебы
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(256, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

      -- Осуществляет уход за престарелым, инвалидом 1 группы или ребенком - инвалидом до 18 лет
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(258, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

      -- Осуществляет уход за ребенком в возрасте до 3-х лет 31.08.2011 ОЛВ
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(260, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(320, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(545, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(121, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(122, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(125, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(126, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

        result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(156, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

        result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(157, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangewmrak(PuskDate, -1, -1, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Changepension(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Changebenefit(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    Xlpl.RestoreRole;
END IF;

----- Окончание года -----

Dt := S_Jtod(S_Const(479, Xlpl.WorkDate));
StopDt := S_Encodedate(S_Yearofdate(DtTalk), S_Monthofdate(Dt), S_Dayofdate(Dt));
IF StopDt > PuskDate AND StopDt <= WDt THEN
   result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt)+1;
END IF;

----- Наступление даты введения нового Закона -----

StopDt := S_Encodedate(2002, 04, 01);
IF StopDt > PuskDate AND StopDt <= WDt THEN
   result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
END IF;
/* */
 -------------------------------------------------------------
 --                     Ребенок в назначении                --
 -------------------------------------------------------------
 -- Ребенок- инвалид
 Xlpl.REPLACEROLE('Child');
DtBirth := S_Birthdate(0, Xlpl.GETPID, Xlpl.WorkDate);    -- дата рождения ребенка
 --01.08.2012 OLV  bl := B_F_Disability(11, XLPL.WorkDate);
 bl := B_F_Disability(14, Xlpl.WorkDate); -- 01.08.2012 OLV
Xlpl.RestoreRole;
IF bl THEN
   StopDt := S_Addyears(DtBirth, S_Const(407, Xlpl.WorkDate));
   IF StopDt > PuskDate AND StopDt <= WDt THEN
      result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
   END IF;
END IF;

 -- Ребенок нуждается в уходе -- 8 лет
Xlpl.REPLACEROLE('Child');
bl := B_F_Disability_Mrak_Opinion;
Ag := S_Age(0, Xlpl.GETPID, Xlpl.WorkDate);
Xlpl.RestoreRole;
IF bl AND Ag > S_Const(401, Xlpl.WorkDate) AND Ag <= S_Const(405, Xlpl.WorkDate) THEN
   StopDt := S_Addyears(DtBirth, S_Const(405, Xlpl.WorkDate));
   IF StopDt > PuskDate AND StopDt <= WDt THEN
      result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
   END IF;
END IF;

----- Ребенок - учащийся, студент  за свой счет -----
-- 404 - Ограничение возраста ребенка для пособия на детей в возра. ст. 3 лет для студ., уч., обуч. за свой счет - в годах -18
Xlpl.REPLACEROLE('Child');
IF (B_F_Actv_Mul(226, 227) OR B_F_Actv_Mul(229, 230) OR B_F_Actv_Mon(232))
   AND NOT B_F_Actv_Mul(222, 224) THEN
  StopDt := S_Addyears(DtBirth, S_Const(404, Xlpl.WorkDate));
   IF StopDt > PuskDate AND StopDt <= WDt THEN
      result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
   END IF;
END IF;
 --RAISE_APPLICATION_ERROR(-20801,'B_F_FormAllocationSteps05  0000  DtBirth='||DtBirth || ' S_Const(404, XLPL.WorkDate)='||S_Const(404, XLPL.WorkDate)  || ' WDt='||WDt );
Xlpl.RestoreRole;

---- Ребенок не учится -----
-- 403 - Ограничение возраста ребенка для пособия на детей в возрасте старше 3 лет - в годах - 16
-- 230 - Учащийся среднего специального учебного заведения вечерней формы обучения, с получением профессии (за счет личных средств)
Xlpl.REPLACEROLE('Child');
IF NOT( B_F_Actv_Mul(226, 227) OR B_F_Actv_Mul(229, 230) OR B_F_Actv_Mon(232))
   AND NOT B_F_Actv_Mul(222, 224) AND NOT B_F_Disability(11, Xlpl.WorkDate) THEN
   StopDt := S_Addyears(DtBirth, S_Const(403, Xlpl.WorkDate));
   IF StopDt > PuskDate AND StopDt <= WDt THEN
      result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
   END IF;
END IF;
Xlpl.RestoreRole;

     ----- Ребенок - школьник, лицеист -----
     -- 406 - Ограничение возраста ребенка для пособия на детей в возрасте старше 3 лет, обучающихся в общеобр.школе, лицее - в годах- 14
     -- 31 августа
         Xlpl.REPLACEROLE('Child');
     IF NOT(B_F_Actv_Mul(226, 227) OR B_F_Actv_Mul(229, 230) OR B_F_Actv_Mon(232))
         AND B_F_Actv_Mul(222, 224) THEN
           StopDt := S_Addyears(DtBirth, S_Const(406, Xlpl.WorkDate));
         IF StopDt > PuskDate AND StopDt <= WDt THEN
             result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
          END IF;
     END IF;
        Xlpl.RestoreRole;

 -- ИЗМЕНЕНИЕ ЗАКОНА 01.01.201  изменить константу
  ---------------------------------------------------------------------------------------------------
 IF Xlpl.WorkDate < TO_DATE('01-01-2013','DD-MM-YYYY') THEN   -- 14.01.2013 ОЛВ со слов РАВ
     ----- Ребенок - школьник, выпускник базовой школы -----
     -- 403 - Ограничение возраста ребенка для пособия на детей в возрасте старше 3 лет - в годах - 16
     -- 237 - Учащийся базового (9 или 11) класса
     -- 222 Учащийся дневной общеобразовательной школы
     -- 224 - Учащийся гимназии, лицея и др.
         Xlpl.REPLACEROLE('Child');
     IF NOT(B_F_Actv_Mul(226, 227) OR B_F_Actv_Mul(229, 230) OR B_F_Actv_Mon(232))
         AND B_F_Actv_Mul(222, 224) AND B_F_Actv_Mon(237) THEN
           StopDt := S_Addyears(DtBirth, S_Const(403, Xlpl.WorkDate));
         IF StopDt > PuskDate AND StopDt <= WDt THEN
             result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
         END IF;
     END IF;
         Xlpl.RestoreRole;

 ELSE -- 14.01.2013 ОЛВ со слов РАВ
    -- ИЗМЕНЕНИЕ ЗАКОНА 01.01.2013
    -- было 18 лет -  с 01.01.2013 изменить на 30 июня
     ----- Ребенок - школьник, лицеист -----
     -- 406 - Ограничение возраста ребенка для пособия на детей в возрасте старше 3 лет, обучающихся в общеобр.школе, лицее - в годах- 14
     -- 31 августа
         Xlpl.REPLACEROLE('Child');
     IF NOT(B_F_Actv_Mul(226, 227) OR B_F_Actv_Mul(229, 230) OR B_F_Actv_Mon(232))
         AND B_F_Actv_Mon( 223) THEN --   со слов РАВ
           StopDt := S_Addyears(DtBirth, S_Const(406, Xlpl.WorkDate));
         IF StopDt > PuskDate AND StopDt <= WDt THEN
             result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
          END IF;
     END IF;
        Xlpl.RestoreRole;

     ----- Ребенок - школьник, выпускник базовой школы -----
     -- 403 - Ограничение возраста ребенка для пособия на детей в возрасте старше 3 лет - в годах - 16
     -- 237 - Учащийся базового (9 или 11) класса
     -- 222 Учащийся дневной общеобразовательной школы
     -- 224 - Учащийся гимназии, лицея и др.
     -- было 31 июля -  с 01.01.2013 изменить на 30 июня
         Xlpl.REPLACEROLE('Child');
     IF NOT(B_F_Actv_Mul(226, 227) OR B_F_Actv_Mul(229, 230) OR B_F_Actv_Mon(232))
         AND (B_F_Actv_Mul(222,  224) OR B_F_Actv_Mon(223) ) AND B_F_Actv_Mon(237) THEN
           StopDt := S_Addyears(DtBirth, S_Const(403, Xlpl.WorkDate));
         IF StopDt > PuskDate AND StopDt <= WDt THEN
             result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
         END IF;
     END IF;
         Xlpl.RestoreRole;
 END IF;

----- Ребенок - инфицированный ВИЧ или больной СПИД -----
-- 408 - Ограничение возраста ребенка для детей, инфицированных ВИЧ - в годах
Xlpl.REPLACEROLE('Child');
IF B_F_Actv_Mon(320) THEN
   StopDt := S_Addyears(DtBirth, S_Const(408, Xlpl.WorkDate));
   IF StopDt > PuskDate AND StopDt <= WDt THEN
      result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
   END IF;
END IF;
Xlpl.RestoreRole;

----- Ребенок - инвалид, окончание действия инвалидности -----
Xlpl.REPLACEROLE('Child');
 --01.08.2012 OLV  bl := B_F_Disability(11, XLPL.WorkDate);
 bl := B_F_Disability(14, Xlpl.WorkDate); -- 01.08.2012 OLV
--01.08.2012 OLV XLPL.RestoreRole;
IF bl THEN
     StopDt := NULL;
   BEGIN
           SELECT DIS_TERM
             INTO StopDt
             FROM W$MRAK_OPINION_ADVICE
            WHERE PID = Xlpl.GetPid --01.08.2012 OLV --aPID
           AND OPINION_TYPE = 1
           AND ADVICE_TYPE = 14--11 ----01.08.2012 OLV 14
           AND ENTERED_BY = Xlpl.USER_ID
           AND STAGE NOT IN(2,3)
           AND (RECORD_START <= Xlpl.WorkDate AND NVL(DIS_TERM, Xlpl.WorkDate) >= Xlpl.WorkDate)
           AND (RECORD_END >= Xlpl.WorkDate OR RECORD_END IS NULL);
   EXCEPTION
     WHEN OTHERS THEN
          StopDt := NULL;
   END;
   IF StopDt IS NOT NULL AND StopDt > PuskDate AND StopDt <= WDt THEN
      -- 20.12.2012  Речицкая А. В. StopDt := LAST_DAY(StopDt)+1;
      StopDt :=  (StopDt)+1; --20.12.2012
      result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
   END IF;
END IF;
Xlpl.RestoreRole; --01.08.2012 OLV

----- Ребенок - нуждается в постоянном уходе, окончание действия справки -----

Xlpl.REPLACEROLE('Child');
bl := B_F_Disneed;
Xlpl.RestoreRole;
IF bl THEN
   StopDt := NULL;
   BEGIN
   SELECT RECORD_END
   INTO StopDt
   FROM W$MRAK_OPINION_ADVICE
   WHERE PID = aPID AND
            OPINION_TYPE = 2 AND
         ADVICE_TYPE = 21 AND
         ENTERED_BY = Xlpl.USER_ID AND
         STAGE NOT IN(2,3) AND
         (RECORD_START <= Xlpl.WorkDate AND NVL(RECORD_END, Xlpl.WorkDate) >= Xlpl.WorkDate) AND
         (RECORD_END >= Xlpl.WorkDate OR RECORD_END IS NULL);
   EXCEPTION
   WHEN OTHERS THEN
        StopDt := NULL;
   END;
   IF StopDt IS NOT NULL AND StopDt > PuskDate AND StopDt <= WDt THEN
      StopDt := LAST_DAY(StopDt);
      result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
   END IF;
END IF;

/* */
result_step_start := A_F_Arraydatachangedeldup(result_step_start);

---- исключить шаги, меньшие даты перерасчета (или даты возникновения права) ----
---- и исключить шаги, большие даты закрытия (или текущей даты)              ----

result_rab.DELETE;
IF prnew = 3 OR prnew = 2 THEN
   LimitDate := prdate;
--RAISE_APPLICATION_ERROR(-20801,'B_F_FormAllocationSteps05 1111   XLPL.GetPid='||XLPL.GetPid || '   prnew='||prnew||' pCID='||pCID );
ELSE
   LimitDate := B_F_Laststepaid(pAID, pCID)+1;  --01.08.2012 OLV  +1
--RAISE_APPLICATION_ERROR(-20801,'B_F_FormAllocationSteps05 2222   XLPL.GetPid='||XLPL.GetPid || '   LimitDate='||LimitDate||' pCID='||pCID );
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_FormAllocationSteps05 3333   XLPL.GetPid='||XLPL.GetPid || '   prnew='||prnew||' pCID='||pCID );

  -- конец текущего выплатного периода для ручной корректировки данных после массового расчета  -- ОЛВ   25.06.2013
  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  IF  LimitDate_Vipl IS NOT NULL  THEN
       LimitDate:= LimitDate_Vipl;
  END IF;

FOR j IN 1..result_step_start.COUNT LOOP
    rDate := S_Jtod(result_step_start(j));
    IF rDate IS NOT NULL AND rDate > Xlpl.WorkDate AND rDate <= LimitDate THEN
           result_rab(result_rab.COUNT+1) := result_step_start(j);
    END IF;
END LOOP;
result_step_start.DELETE;
FOR j IN 1..result_rab.COUNT LOOP
    result_step_start(result_step_start.COUNT+1) := result_rab(j);
END LOOP;
result_rab.DELETE;

RETURN A_F_Arraydatachangedeldup(result_step_start);

END B_F_Formallocationsteps05;
/
