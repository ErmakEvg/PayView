CREATE FUNCTION       A_F_Laborstart RETURN DATE AS
/***************************************************************************************
 Функция           :  A_F_Laborstart
 Наименование  :  Функция возвращает дату начала трудовой деятельности
 Автор               :  Кондратюк Е.В.
 Состояние на дату 25.03.2009
 Код возврата    : Дата начала трудовой деятельности
***************************************************************************************/
vLaborDate DATE;
BEGIN
   vLaborDate:=NULL;

   SELECT MIN(PERIOD_START) INTO vLaborDate
   FROM W$LABOR
   WHERE PID=Xlpl.GETPID
   AND entered_by=Xlpl.GetUID
   AND stage IN (1,4)
   AND LABOR_TYPE NOT IN
       (SELECT code
	    FROM LABOR_TYPE
		WHERE parent_code IN (10,11,14)
		);

   RETURN vLaborDate;

   /* EXCEPTION не работает из-за MIN */
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END A_F_Laborstart;
/
