CREATE FUNCTION       B_C1201 RETURN NUMBER AS
/**********************************************************************************************
 Функция            : B_C1201
 Наименование       : Функция расчета суммы пособия матери,
                      ставшей на учет до 12 недель беременности
 Автор              :  ОЛВ
 Состояние на дату  :  17.03.2010
***********************************************************************************************/
 Amount          NUMBER;
 Size_BPM        NUMBER;
 Percent         NUMBER;
 NMask           varchar2(50);

BEGIN

  /*                                Исходные данные
  /* -----------------------------------------------------------------------------------*/
  Size_BPM:=S_Const(18, XLPL.WorkDate);  -- Бюджет прожиточного минимума в среднем на душу населения
  Percent :=  S_Const(416, XLPL.WorkDate);  -- Размер пос.  - в % от БПМ в среднем на душу населения

  /* -----------------------------------------------------------------------------------*/
  /*                               Расчет размера пособия
  /* -----------------------------------------------------------------------------------*/
     Amount := S_VRound_Sum((Size_BPM * Percent/100), s_const(40,XLPL.WorkDate));
--RAISE_APPLICATION_ERROR(-20801,'B_CBC01   3 Percent=' ||Percent||'  Size_BPM='||Size_BPM||'  Amount='||Amount);

  /*                         Вывод в протокол  размера пособия
  /* -----------------------------------------------------------------------------------*/
   NMask := LPAD('9', LENGTH(TO_CHAR(Amount)), '9') || '0.99';
  Xlpl.S_Protocol('Сумма назначения (' || TO_CHAR(Size_BPM, NMask) || ' * ' ||
    TO_CHAR(Percent*0.01, '90.99') || ' ): ' || CHR(9)  || TO_CHAR(Amount,  NMask) || CHR(10));

  XLPL.Payment := 100;
  XLPL.S_protocol ('Процент выплаты назначения:                ' || TO_CHAR(XLPL.Payment) || '%' || CHR (10));

  XLPL.AMOUNT := Amount;
  --RAISE_APPLICATION_ERROR(-20801,'B_C1201    3 XLPL.Payment=' ||XLPL.Payment||'  Size_BPM='||Size_BPM||'  Amount='||Amount);
  return Amount;

END B_C1201;
/
