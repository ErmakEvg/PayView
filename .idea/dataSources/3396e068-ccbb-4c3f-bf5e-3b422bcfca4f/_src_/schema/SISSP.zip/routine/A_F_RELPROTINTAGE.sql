CREATE FUNCTION       A_F_RelProtIntAge(pNow in DATE) RETURN NUMBER IS
/*возраст человека  по данным из W$RELATION_PROTOCOL
Вахромин О.Ю.*/
BEGIN
return Trunc(S_YearsBetween(pNow,A_F_RelProtBirthday));
END A_F_RelProtIntAge;
/
