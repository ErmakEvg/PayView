CREATE FUNCTION       A_P_RECALCST_6NEAT RETURN NUMBER IS

Rec number;
BEGIN
  Rec := 0;

  IF XLPL.CheckRole(51) THEN
    Rec := A_F_RelProtRecord(6) +  trunc(A_F_RelProtRecord(7)/360) * 15 * 30 +
                  (A_F_RelProtRecord(7) - trunc(A_F_RelProtRecord(7)/360) *360 ) +
                   trunc((A_F_RelProtRecord(3) + A_F_RelProtRecord(68))/360) * 9 * 30;
  end if;
  Return Rec;
END A_P_RECALCST_6NEAT;
/
