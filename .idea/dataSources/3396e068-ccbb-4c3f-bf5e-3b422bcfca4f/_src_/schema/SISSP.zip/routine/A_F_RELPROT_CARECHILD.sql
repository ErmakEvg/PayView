CREATE FUNCTION       A_F_RelProt_CareChild(aRole_Code in NUMBER,N_Age in NUMBER)
                                                               RETURN BOOLEAN IS
/******************************************************************************
 NAME         : A_F_RelProt_CareChild
 Назначение   : Функция проверки на наличие в деле ребенка
 Автор        :  Боровнева         Комментарии и корректировка: ОЛВ
 Дата         :                                   16.02.2015  16.02.2015
 Код возврата : True если хотя бы один PID не равный PID-у по умолчанию
                с ролью AROLE имеет возраст меньше N_Age лет
    Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
******************************************************************************/
 xDRIDS       DBMS_SQL.Number_Table;
 vsDRID       NUMBER;
 vsDRID1      NUMBER;
 vsPID        NUMBER;
 vsBIRTH_DATE Date;
 flRet        BOOLEAN;
BEGIN
 flRet := false;
 xDRIDS := A_F_RelProtGetRIDCasePNotPID(); -- ОБД
    for l in 1..xDRIDS.count loop
	     vsDRID := xDRIDS(l);
       for c1 in (select PID as pPID
                    from CASE_PERSON
  	               where   RID = vsDRID
                     and  ROLE = AROLE_CODE) loop
          vsPID := c1.pPID;
          vsDRID1 := A_F_RelProtGetRIDPID (1,vsPID);
          if vsDRID1 <> -1 then
            select BIRTH_DATE  into vsBIRTH_DATE
              from PERSON
             where RID = vsDRID1;
		        if S_AddYears ( vsBIRTH_DATE,trunc(N_Age)) > XLPL.WorkDate then
                    flRet := true;
                end if;
          end if;
        end loop;
        if flRet then return flRet;
        end if;
    end loop;

 xDRIDS := A_F_RelProtGetRIDWCasePNotPID (); -- РБД
    for l in 1..xDRIDS.count LOOP
          vsDRID := xDRIDS(l);
  	    for c1 in (select PID as pPID
                     from W$CASE_PERSON
  	                where   RID = vsDRID
                      and ENTERED_BY = XLPL.USER_ID
                      and  ROLE = AROLE_CODE) loop
            vsPID := c1.pPID;
            vsDRID1 := A_F_RelProtGetRIDPID (0,vsPID);
          if vsDRID1 <> -1 then
            select BIRTH_DATE  into vsBIRTH_DATE
              from W$PERSON
             where RID = vsDRID1
               and ENTERED_BY = XLPL.USER_ID;  -- 16.02.2015 OLV по наводке РАВ
		        if S_AddYears ( vsBIRTH_DATE,trunc(N_Age)) > XLPL.WorkDate then
                    flRet := true;
                end if;
          end if;
        end loop;
        if flRet then
           return flRet;
        end if;
    end loop;
 return flRet;
END A_F_RelProt_CareChild;
/
