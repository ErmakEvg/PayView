CREATE FUNCTION       B_F_CountMONTHS_751(aAllocCode IN NUMBER,
                                                     aTestDate  IN DATE)
RETURN NUMBER IS
/******************************************************************************
 Функция           : B_F_CountMONTHS_751
 Назначение        : Функция считает количество месяцев назначения ежемесячного
                   : социального пособия у выбранного лица в течении 12 месяцев
                   : начиная с требуемой даты
 Основание         :
 Автор             : АМВ
 Входные параметры : aAllocCode
                   : aTestDate
 Состояние на дату : 12.09.2014, 17.09.2014, 07.10.2015
 Возвращаемое      :
      значение     : количество месяцев
*******************************************************************************/
  xResume        NUMBER;
  xPID           NUMBER;
  xMONTHS_CALC   NUMBER;
  vMinStartAlloc DATE;
BEGIN
  xResume:= NULL;
  vMinStartAlloc:= NULL; --07.10.2015 AMV
  xPID:= XLPL.GETPID;
  -- Анализ по сроку обращения за ГАСП (новый период >= 12 месяцев
  -- c минимальной даты обращения в течение года )
  --
  Select MIN(ALLOCATION_START) INTO vMinStartAlloc
  From ALLOCATION --Было ли 751 за последние 12 месяцев от 1 числа месяца обращения
  Where CID IN
        ( Select distinct a.CID
          From ALLOCATION a, ALLOCATION_PERSON b
          Where a.RID = b.ALLOCATION_RID
            and (b.ROLE= 65) and a.ALLOC_CODE = aAllocCode
            and (a.ALLOC_STATUS = 1 or a.ALLOC_STATUS = 3)
            and ((a.ALLOCATION_START>= ADD_MONTHS(aTestDate, -12))
            and  (a.ALLOCATION_START< aTestDate))
            and b.PID = xPID
            and NVL(a.STAGE, 0) NOT IN (2,3)
            and NVL(b.STAGE, 0) NOT IN (2,3) );
  --07.10.2015 IF (aTestDate- vMinStartAlloc)>= 0 THEN
  IF vMinStartAlloc is NULL THEN
    RETURN xResume;
  END IF;
  -- Анализ по сроку обращения за ГАСП (новый период < 12 месяцев
  -- c минимальной даты обращения в течение года ), т.е сколько
  -- месяцев осталось до 6
  --
  Select SUM(tp.COUNT_MONTHS) into xResume
  From
    ( Select Max(p.COUNT_MONTHS) OVER (PARTITION BY CID) COUNT_MONTHS
      From PARAM_ADDR_HELP p
      Where p.CID IN
        ( Select distinct a.CID
          From ALLOCATION a, ALLOCATION_PERSON b
          Where a.RID = b.ALLOCATION_RID
            and (b.ROLE= 65) and a.ALLOC_CODE = aAllocCode
            and (a.ALLOC_STATUS = 1 or a.ALLOC_STATUS = 3)
            and ((a.ALLOCATION_START> ADD_MONTHS(aTestDate, -12))
            and  (a.ALLOCATION_START< aTestDate))
            and b.PID = xPID
            and NVL(a.STAGE, 0) NOT IN (2,3)
            and NVL(b.STAGE, 0) NOT IN (2,3)
        )
        and NVL(p.STAGE, 0) NOT IN (2,3)
    ) tp;
  --RAISE_APPLICATION_ERROR(-20801,'Xlpl.AID=  '||XLPL.AID);
  -- Режим редактирования дела, взятого из ОБД ( XLPL.AID > 0 )
  --
  if Xlpl.AID <> 0 then
    Select  COUNT(t.AID) into xMONTHS_CALC
    From ALLOCATION a, ALLOCATION_PERSON b, CALC_AMOUNT t
    Where a.ALLOC_CODE = aAllocCode
      and a.RID = b.ALLOCATION_RID
      and a.RID= t.ALLOCATION_RID
      and (a.ALLOC_STATUS = 1 or a.ALLOC_STATUS = 3)
      and a.CID = t.CID
      and b.PID = xPID
      and (b.ROLE= 65)
      and ((a.ALLOCATION_START> ADD_MONTHS(aTestDate,-12)) AND (a.ALLOCATION_START<aTestDate))
      and NVL(a.STAGE, 0) NOT IN (2,3)
      and NVL(b.STAGE, 0) NOT IN (2,3)
      and NVL(t.STAGE, 0) NOT IN (2,3);
   --RAISE_APPLICATION_ERROR(-20801,'xMONTHS_CALC=  '||xMONTHS_CALC);
    if xMONTHS_CALC < xResume  then
      xResume:= xMONTHS_CALC;
    end if;
  end if;
  RETURN xResume;
END B_F_CountMONTHS_751;
/
