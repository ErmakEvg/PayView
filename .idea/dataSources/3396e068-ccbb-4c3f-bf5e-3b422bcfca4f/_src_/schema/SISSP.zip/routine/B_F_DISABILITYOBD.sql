CREATE FUNCTION       B_F_DISABILITYOBD (ADIS_GROUP IN BINARY_INTEGER) RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_DISABILITYOBD
// Наименование: Функция возвращает True если человек инвалид
// Автор: Ворошилин В.
// Состояние на дату 05.02.1999
// Код возврата: True - если есть требуемая характеристика, False - если ее нет
//***************************************************************************************/

  CN_DISABILITY NUMBER;
BEGIN
  select count(*) INTO CN_DISABILITY from MRAK_OPINION_ADVICE
    where PID = XLPL.GetPid
	  and (STAGE not in (2,3) or STAGE is null)
	  and RECORD_START <= XLPL.WorkDate
	  and (RECORD_END >= XLPL.WorkDate or RECORD_END is null or DIS_TERM >= XLPL.WorkDate or DIS_TERM is null)
	  and OPINION_TYPE = 1 and ADVICE_TYPE = ADIS_GROUP ;
  return CN_DISABILITY != 0;
END B_F_DISABILITYOBD;
/
