CREATE FUNCTION       A_F_RelatedTable(ACODE in number) RETURN NUMBER IS
/* Код возврата: код связанной таблицы
Вахромин О.Ю.*/
vsCODE number;
vsTABLE_NAME VarChar2(255);
BEGIN
   select NAME_TABLE into vsTABLE_NAME from SISSP_TABLES where CODE=ACODE;
   select CODE into vsCODE from SISSP_TABLES where
      (NAME_TABLE=SUBSTR(vsTABLE_NAME,3) and SUBSTR(vsTABLE_NAME,1,2)='W$') or
	  (NAME_TABLE='W$'||vsTABLE_NAME);
   return vsCODE;
END A_F_RelatedTable;
/
