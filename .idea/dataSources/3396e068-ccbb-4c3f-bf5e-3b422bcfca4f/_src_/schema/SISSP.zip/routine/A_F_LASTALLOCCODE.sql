CREATE FUNCTION       A_F_LASTALLOCCODE RETURN NUMBER AS
/***************************************************************************************
 Функция            : A_F_LASTALLOCCODE
 Наименование       :  Определение типа ИК(старого) инвалидам вследствие ЧАЭС
                       при  переводе с социальной пенсии по ЧАЭС
                       на пенсию по инвалидности по ЧАЭС или при ее перерасчете
 Автор              :                    Комментарии и корректировка: ОЛВ
 Состояние на дату  :                                                 08.11.2010
 Код возврата       : тип ИК - 3 расчитан по закону ЧАЭС, в противном случае - 0
***************************************************************************************/
  vsOld_Type_Ratio NUMBER;
  vsAlloc_Code NUMBER;
BEGIN
 begin -- OLV  08.11.2010

  SELECT Alloc_Code INTO vsAlloc_Code
  FROM allocation
  WHERE cid = XLPL.CID
	and aid = XLPL.AID
	and comp_part is NULL
	and parent_rid is NULL
	and ALLOC_STATUS = 1
	and step_start = (SELECT MAX(step_start) FROM allocation
	                  WHERE cid = XLPL.CID
	 			        and aid = XLPL.AID
						and comp_part is NULL
						and parent_rid is NULL
						and Close_date is null)
	and Close_date is null;
  if vsAlloc_Code <> 0 then
    if (vsAlloc_Code = 361) OR (vsAlloc_Code = 362) OR (vsAlloc_Code = 363) then
      -- Социальная пенсия (инв. 1,2,3 группы вследствие катастрофы на ЧАЭС)
      vsOld_Type_Ratio := 3;
    else
      if (vsAlloc_Code = 331) OR (vsAlloc_Code = 332) OR (vsAlloc_Code = 333) then
        -- Пенсия по инвалидности (инв. 1,2,3 группы вследствие катастрофы на ЧАЭС)
        begin
          SELECT Ratio_By INTO vsOld_Type_Ratio
		  from W$PERSON_EXTRA
		  where PID = XLPL.GETPID
		    and stage = 2
			and Entered_by = XLPL.User_ID;
          if vsOld_Type_Ratio <> 3 then
            vsOld_Type_Ratio := 0;
          end if;
        EXCEPTION
          WHEN NO_DATA_FOUND then
            vsOld_Type_Ratio := 0;
          WHEN OTHERS then
            vsOld_Type_Ratio := 0;
        end;
      end if;
    end if;
  end if;
 /* -- OLV  08.11.2010 */
 EXCEPTION
     WHEN NO_DATA_FOUND then
          vsOld_Type_Ratio := 0;
     WHEN OTHERS then
          vsOld_Type_Ratio := 0;
 end;
--RAISE_APPLICATION_ERROR(-20801,'A_F_LASTALLOCCODE ----- :');
 /* */
  RETURN vsOld_Type_Ratio;
end A_F_LASTALLOCCODE;
/
