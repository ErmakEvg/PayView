CREATE FUNCTION       A_F_RelProtGetRASCH(Base_ID in NUMBER)
   RETURN NUMBER AS
/**********************************************************************************************
 Функция            : A_F_RelProtGetRASCH
 Наименование       :  Метод расчета pr_RASCH из W$CASE для Межд.дог.с РФ
 Автор              : ОЛВ
 Состояние на дату  : 25.09.2010  01.08.2011
 Код возврата       : Метод расчета - 1 - по пропорции
***********************************************************************************************/
 vsRelation_Table number;
 vsPR_METHOD      NUMBER;
BEGIN
 begin
   if Base_ID=0 then
         select NVL(METHOD,0)
		   into vsPR_METHOD
		   from W$CASE
		  where CID=XLPL.CID
		    and STAGE not in (2, 3)
            and METHOD is not null
			and COUNTRY>1; --=2;
      else
         select NVL(METHOD,0)
		   into vsPR_METHOD
		   from CASE
		  where CID=XLPL.CID
		    and STAGE is null -- 01.08.2011 OLV  -- не работает and STAGE not in (2, 3)
            and METHOD is not null
			and COUNTRY>1; --=2;
      end if;

   exception
      when NO_DATA_FOUND then
         vsPR_METHOD:=-1;
 --RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetCountry  2 vsCountry='||vsCountry);
   end;
   return vsPR_METHOD;

/* W$APPLICATION *
 vsRelation_Table number;
 vsPR_RASCH        NUMBER;
BEGIN
 begin
   if Base_ID=0 then
         select PR_RASCH
		   into vsPR_RASCH
		   from W$APPLICATION a
		  where a.CID=XLPL.CID
			--and ENTERED_BY=XLPL.USER_ID
		    and STAGE not in (2, 3)
            and PR_RASCH is not null;
	 --RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetCountry  1 vsCountry='||vsCountry);
      else
         select PR_RASCH
		   into vsPR_RASCH
		   from APPLICATION a
		  where a.CID=XLPL.CID
			--and ENTERED_BY=XLPL.USER_ID
		    and STAGE not in (2, 3)
            and PR_RASCH is not null;
      end if;

   exception
      when NO_DATA_FOUND then
         vsPR_RASCH:=-1;
 --RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetCountry  2 vsCountry='||vsCountry);
   end;
   return vsPR_RASCH;
/* */
END A_F_RelProtGetRASCH;
/
