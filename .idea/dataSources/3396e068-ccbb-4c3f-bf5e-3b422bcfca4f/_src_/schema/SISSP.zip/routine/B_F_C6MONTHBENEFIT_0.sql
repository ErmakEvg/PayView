CREATE FUNCTION       B_F_C6MonthBenefit_0 (dt IN DATE) RETURN DATE AS

/***************************************************************************************
// Функция: B_F_C6MonthBenefit_0
// Наименование: Функция котроля шести месяцев для пособий
// Автор: Гуз Е.
// Состояние на дату 01.02.1999
// Код возврата: дата наступления права
//***************************************************************************************/

  k_StartDate DATE;

BEGIN

  k_StartDate := ADD_MONTHS(dt, S_CONST(432, XLPL.WorkDate));
  if k_StartDate > XLPL.WorkDate then
    return dt;
  else
    return S_EncodeDate(S_YearOfDate(XLPL.WorkDate), S_MonthOfDate(XLPL.WorkDate), 1);
  end if;

END B_F_C6MonthBenefit_0;
/
