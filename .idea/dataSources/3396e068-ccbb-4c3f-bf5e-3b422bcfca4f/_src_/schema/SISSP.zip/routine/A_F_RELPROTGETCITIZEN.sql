CREATE FUNCTION       A_F_RelProtGetCITIZEN(Base_ID in NUMBER)
   RETURN NUMBER AS
/**********************************************************************************************
 Функция            : A_F_RelProtGetCITIZEN
 Наименование       : Функция определения гражданства  IZ_CITIZEN из W$PERSON
 Автор              : ОЛВ
 Состояние на дату  : 16.12.2010  01.08.2011
 Код возврата       : Код гражданства : 1 - РБ, 2 - РФ
***********************************************************************************************/
 vsCITIZEN     NUMBER;
BEGIN
 begin
   if Base_ID=0 then
         select NVL(IS_CITIZEN,-1)
		   into vsCITIZEN
		   from W$PERSON
		  where PID = XLPL.GetPid
		    and STAGE not in (2, 3)
			and ENTERED_BY=XLPL.USER_ID -- ???
	        and XLPL.WorkDate between
                 NVL(RECORD_START,XLPL.WorkDate) and NVL(RECORD_END,XLPL.WorkDate);
      else
         select NVL(IS_CITIZEN,-1)
		   into vsCITIZEN
		   from PERSON
		  where PID = XLPL.GetPid
		    and STAGE is null -- 01.08.2011 OLV  -- не работает and STAGE not in (2, 3)
	        and XLPL.WorkDate between
                 NVL(RECORD_START,XLPL.WorkDate) and NVL(RECORD_END,XLPL.WorkDate);
      end if;

   exception
      when NO_DATA_FOUND then
         vsCITIZEN:=-1;
 --RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetCountry  2 vsCountry='||vsCountry);
   end;
   return vsCITIZEN;
END A_F_RelProtGetCITIZEN;
/
