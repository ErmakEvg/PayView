CREATE FUNCTION       B_F_ARRAYDATEESTMETRICPOG RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_ARRAYDATEESTMETRICPOG
+ Автор: Ворошилин В.
+ Состояние на дату 30.11.2000
==============================================================================*/

  result DBMS_SQL.NUMBER_TABLE;
  StopDt DATE;
  DeathDt DATE;
BEGIN
  result.delete;
  XLPL.RoleDecl('Death', '71');
  if not XLPL.CHECKROLE(71) then
	return result;
  else
    XLPL.REPLACEROLE('Death');
	DeathDt := A_F_RelProtDEATHDate;
    XLPL.RESTOREROLE;
  end if;
  XLPL.RoleDecl('Rec', '70');
  if not XLPL.CHECKROLE(70) then
	return result;
  else
    XLPL.REPLACEROLE('Rec');
	StopDt := B_F_MetricWithOutStart(145);
    XLPL.RESTOREROLE;
  end if;
  if (StopDt is not NULL) and (DeathDt < StopDt) and (LAST_DAY(S_CurrDate) < StopDt) then
    result(1) := S_Julian(LAST_DAY(StopDt));
 	result(2) := 34;
 	result(3) := 2;
  end if;
   return result;
END B_F_ARRAYDATEESTMETRICPOG;
/
