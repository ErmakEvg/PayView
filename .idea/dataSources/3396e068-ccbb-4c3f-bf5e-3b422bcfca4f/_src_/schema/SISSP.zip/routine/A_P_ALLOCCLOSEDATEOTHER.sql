CREATE FUNCTION       A_P_ALLOCCLOSEDATEOTHER(PuskDate in date,Param6m in number) RETURN DBMS_SQL.number_table IS
/*==============================================================================
+ Функция: P_ALLOCCLOSEDATEOTHER
+ Наименование: Функция возвращает дату закрытия - приотановки других назначений,
+ 				находящихся в деле
+ Автор: Трухтанов
+ Состояние на дату 11.12.2000
==============================================================================*/
chahge_date_aRecord DBMS_SQL.number_TABLE;
aRecord_start date;
i integer;
DateTalk date;
DateTalk1 date;

BEGIN
  DateTalk := A_F_DataTalk();
  DateTalk1 := Last_Day(S_CurrDate);
--  select Last_Day(sysdate) into DateTalk1 from dual;

  for Record_start in (select nvl(Step_start,XLPL.WORKDATE) as dat
		                      from Allocation
							  where cid = XLPL.Cid and aid <> XLPL.Aid and
	                          alloc_status = 3) LOOP
	aRecord_start := Record_start.dat;
	if (aRecord_start is not null) AND (aRecord_start > PuskDate) AND (aRecord_start <= DateTalk1) then
	  if  (Param6m = 1) AND (XLPL.AID = 0)
	    then 			   	  	  	   	   			  	   				 -- Если превышено 6 месяцев со для возникновения права
          chahge_date_aRecord(chahge_date_aRecord.Count+1) := S_JULIAN(S_EncodeDate(S_YearOfDate(DateTalk), S_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		else
		  chahge_date_aRecord(chahge_date_aRecord.Count+1) := S_JULIAN(aRecord_start);
	   end if;
	end if;
  end loop;
  return A_F_ArrayDataChangeDelDup(chahge_date_aRecord);

END A_P_ALLOCCLOSEDATEOTHER;
/
