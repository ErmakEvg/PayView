CREATE FUNCTION       B_F_AmountLimit_AddrHelp3 return BOOLEAN is
/***************************************************************************************
// Функция: B_F_AmountLimit_AddrHelp3
// Наименование: Функция, определяющая контроль на предельную сумму, которую можно назначить
// по единовременному социальному пособию 752
// Автор: Абрамович М.В.
// Состояние на дату 26.04.2011 10.04.2012,05.07.2018
// Код возврата: True - Amount меньше  установленной суммы, False - Amount больше
//               установленной суммы
//**************************************************************************************/
Am NUMBER;
BEGIN
 --05.07.2018 select SUMMA INTO Am
 select SUMMA_PERSON INTO Am ----05.07.2018
 from W$PARAM_ADDR_HELP a
 where cid = Xlpl.CID
       and entered_by = Xlpl.GETUID
       and  STAGE not in (2,3);
  -- Если Amount не превышает % установленной суммы , то
 -- RAISE_APPLICATION_ERROR(-20801,'B_F_AmountLimit_AddrHelp3  S_CONST_48='||S_CONST(48, XLPL.WorkDate));
 -- if (Am <= (S_CONST(18, XLPL.WorkDate)*S_CONST(48, XLPL.WorkDate)/100)) then
  if (Am <= (S_CONST(1, XLPL.WorkDate)*S_CONST(48, XLPL.WorkDate)/100)) then --10.04.12
    Return True;  -- возвратить "Amount меньше  установленной суммы"
  else
    Return False;  -- иначе - "Amount больше установленной суммы"
  end if;
end B_F_AmountLimit_AddrHelp3;
/
