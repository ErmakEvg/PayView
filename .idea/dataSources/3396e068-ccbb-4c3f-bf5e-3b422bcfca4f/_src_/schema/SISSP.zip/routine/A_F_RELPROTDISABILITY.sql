CREATE FUNCTION       A_F_Relprotdisability(aOPINION_TYPE IN NUMBER,
   aADVICE_TYPE IN VARCHAR2) RETURN BOOLEAN IS
/*********************************************************************************************************
 Функция                :  A_F_Relprotdisability
 Наименование       :  Функция определяет наличие инвалидности по коду
 					   		     согласно W$RELATION_PROTOCOL
 Автор                    :  Вахромин О.Ю.                 Комментарии и корректирвка: ОЛВ
 Состояние на дату :   		 		                                      08.01.2013
 Параметры            :  OPINION_TYPE = -1 тип инвалидности не имеет значение
     							 AADVICE_TYPE = "x,x1 .. xn" или "" если не имеет значения
     							 Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
     							 при AADVICE_TYPE = "" проверяется наличие только OPINION_TYPE
 Код возврата         :   true, если человек есть указанная рекомендация МРЕК по коду
**********************************************************************************************************/
 DRIDS                  DBMS_SQL.NUMBER_TABLE;
 xADVICE_TYPE    DBMS_SQL.NUMBER_TABLE;
 vt 			 		     NUMBER;
 WorkDate              DATE;
BEGIN
   WorkDate:=Xlpl.WorkDate;
   xADVICE_TYPE:=S_Parsefloatarray(aADVICE_TYPE);

 -- ОБД
   DRIDS:=A_F_Relprotgetridmrakopadvice(1,AOPINION_TYPE);
 IF (DRIDS.COUNT>0) AND (xADVICE_TYPE.COUNT=0) THEN
      RETURN TRUE;
 END IF;
 IF DRIDS.COUNT<>0 THEN
      FOR i IN 1..DRIDS.COUNT LOOP
         FOR l IN 1..xADVICE_TYPE.COUNT LOOP
            SELECT COUNT(*) INTO vt
			   FROM MRAK_OPINION_ADVICE a,MRAK_OPINION b
			WHERE a.RID=DRIDS(i)
			      AND a.ADVICE_TYPE=xADVICE_TYPE(l)
				  AND b.RID=a.MRAK_RID
                   AND NVL (b.RECORD_END,Xlpl.WorkDate) >= Xlpl.WorkDate -- OLV 29.03.2012
				  AND NVL(NVL(a.RECORD_START,b.EXAMED_FROM),WorkDate)<=WorkDate
				  AND NVL(NVL(a.RECORD_END,a.DIS_TERM),WorkDate)>=WorkDate;
            IF vt>0 THEN
               RETURN TRUE;
            END IF;
         END LOOP;
      END LOOP;
 END IF;

 -- РБД
   DRIDS:=A_F_Relprotgetridmrakopadvice(0,AOPINION_TYPE);
--RAISE_APPLICATION_ERROR(-20801,'A_F_Relprotdisability  2'||'   GetPid='||Xlpl.GetPid ||'   XLPL.WorkDate='||Xlpl.WorkDate ||'   DRIDS.COUNT='||DRIDS.COUNT );
 IF (DRIDS.COUNT>0) AND (xADVICE_TYPE.COUNT=0) THEN
      RETURN TRUE;
 END IF;
 IF DRIDS.COUNT<>0 THEN
      FOR i IN 1..DRIDS.COUNT LOOP
         FOR l IN 1..xADVICE_TYPE.COUNT LOOP
            SELECT COUNT(*) INTO vt
			   FROM W$MRAK_OPINION_ADVICE a,W$MRAK_OPINION b
			WHERE a.RID=DRIDS(i)
			      AND a.ADVICE_TYPE=xADVICE_TYPE(l)
				  AND a.ENTERED_BY=Xlpl.USER_ID
				  AND b.RID=a.MRAK_RID
				  AND b.ENTERED_BY=MRAK_ENTERED_BY
                  AND NVL (b.RECORD_END,Xlpl.WorkDate) >= Xlpl.WorkDate -- OLV 08.01.2013
				  AND NVL(NVL(a.RECORD_START,b.EXAMED_FROM),WorkDate)<=WorkDate
				  AND NVL(NVL(a.RECORD_END,a.DIS_TERM),WorkDate)>=WorkDate;
            IF vt>0 THEN
 --  RAISE_APPLICATION_ERROR(-20801,'A_F_Relprotdisability  2'||'   GetPid='||Xlpl.GetPid ||'   XLPL.WorkDate='||Xlpl.WorkDate ||'   DRIDS.COUNT='||DRIDS.COUNT );
               RETURN TRUE;
            END IF;
         END LOOP;
      END LOOP;
 END IF;
   RETURN FALSE;
 END A_F_Relprotdisability;
/
