CREATE FUNCTION       A_F_RelProtGetRidPID(Base_ID in Number,pPID in NUMBER) RETURN NUMBER AS
/***************************************************************************************
 Функция             :  A_F_RelProtGetRidPID
 Наименование        :  Функция озращает RID из (W$)PERSON согласно W$RELATION_PROTOCOL
 Автор               :  Вахромин О.Ю.   Комментарии и корректировка : ОЛВ
 Состояние на дату   :                              09.06.2014
 Код возврата        :  озращает RID из W$PERSON (PERSON) для заданного PID
***************************************************************************************/
 vsRelation_Table number;
 vsDRid           NUMBER;
BEGIN
   vsDRid:=-1;
  /* * if Base_ID=0 then
      vsRelation_Table:=S_CodeTableSissp('W$PERSON');
   else
      vsRelation_Table:=S_CodeTableSissp('PERSON');
   end if; /* */
   BEGIN
      if Base_ID=0 then
           vsRelation_Table:=S_CodeTableSissp('W$PERSON');
         select DATA_RID into vsDRID from W$RELATION_PROTOCOL b,W$PERSON a
          where CID=XLPL.Cid
            and (Aid=XLPL.Aid or XLPL.Aid=0)
            and (GROUP_NO=XLPL.Group_No or (XLPL.Aid<>0 and XLPL.Group_No=0))
            and ALLOC_CODE=XLPL.Alloc_Code
            and RELATION_TABLE=vsRelation_Table
            and RELATION_DATE=XLPL.WorkDate
            and b.ENTERED_BY=XLPL.User_ID
            and a.ENTERED_BY=XLPL.USER_ID -- 09.06.2014 ОЛВ
            and DATA_RID=a.RID
            and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WorkDate)
                                  and NVL(a.RECORD_END,XLPL.WorkDate) and a.PID=pPid;
      else
           vsRelation_Table:=S_CodeTableSissp('PERSON');
         select DATA_RID into vsDRID from W$RELATION_PROTOCOL b,PERSON a
          where CID=XLPL.Cid and (Aid=XLPL.Aid or XLPL.Aid=0)
            and (GROUP_NO=XLPL.Group_No or (XLPL.Aid<>0 and XLPL.Group_No=0))
            and ALLOC_CODE=XLPL.Alloc_Code
            and RELATION_TABLE=vsRelation_Table
            and RELATION_DATE=XLPL.WorkDate
            and b.ENTERED_BY=XLPL.User_ID
            and DATA_RID=a.RID
            and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WorkDate)
                                  and NVL(a.RECORD_END,XLPL.WorkDate) and a.PID=pPid;
      end if;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         vsDRid:=-1;
   END;
   RETURN vsDRid;
END A_F_RelProtGetRidPID;
/
