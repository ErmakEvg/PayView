CREATE FUNCTION       B_F_CheckContribut return NUMBER is
/**********************************************************************************************
 Функция            : B_F_CheckContribut
 Наименование       : Функция определяет сумму выплаченных пособий в деле
 				      за предыдущий год, если выплаты были, или предположительную
 				      сумму, если выплат не было
 Автор              : Ворошилин В.  Перевод на PLS/QL Сманцер Ю.А.   Комментарии: ОЛВ
 Состояние на дату  : 17.05.2002                       16.07.2002           14.06.2010
 Код возврата       :
***********************************************************************************************/
  SumBenefit    number;   	  -- накопление суммы
  ResBenefit    number; 	  -- накопление результата
  APERIOD_START date;
  APERIOD_END   date;
  aday          number;
  amonth        number;
  ayear         number;
  DateBenefit   date;
  SaveDate      date;
  j             number;

begin

  ResBenefit := 0;
  APERIOD_START := S_Encodedate(S_YearOfDate(S_AddYears(XLPL.WorkDate, -1)), 1, 1);
  APERIOD_END := S_Encodedate(S_YearOfDate(S_AddYears(XLPL.WorkDate, -1)), 12, 31);

  if (XLPL.AID <> 0) then
    if (XLPL.WorkDate >= S_Encodedate(2002,4,1)) and
	  (XLPL.WorkDate < S_Encodedate(2002,12,31)) and
      (B_F_StartDateAllocation is not null) and
	  (B_F_StartDateAllocation < S_Encodedate(2002,4,1)) then
--      ResBenefit := B_F_RelProtAmountToPayContrib();
      ResBenefit := B_F_RelProtCalcContrib;
	  return ResBenefit;
    end if;
  else
    if XLPL.WorkDate >= S_Encodedate(2002,4,1) and
	  XLPL.WorkDate < S_Encodedate(2002,12,31) then
--  	  ResBenefit := B_F_RelProtAmountToPayContrib();
      ResBenefit := B_F_RelProtCalcContrib;
	  return ResBenefit;
    end if;
  end if;

  -- Определить выплаченные суммы пособий до 3 лет и старше 3 лет с надбавками и индексацией по делу за указанный период
  -- (без единовременных пособий, без пособий по уходу за ребенком-инвалидом и без пособий больным СПИД)
  ResBenefit := B_Amount_Last_Year(APERIOD_START, APERIOD_END);

  if (ResBenefit = 0) then
    aday := 1;
    amonth := 1;
    ayear := S_YearOfDate(S_AddYears(XLPL.WorkDate, -1));

    for c1 in (select b.BIRTH_DATE as BDate
			   from W$CASE_PERSON a, W$PERSON b
			   where a.CID = XLPL.CID
			     and a.ROLE = 56 -- ребенок
				 and a.STAGE NOT IN(2,3)
				 and a.ENTERED_BY = XLPL.User_ID
				 and b.PID = a.PID
				 and b.STAGE NOT IN(2,3)
				 and b.ENTERED_BY = XLPL.User_ID) loop

	  -- 401 - Ограничение возраста ребенка для пособия по уходу за ребенком в возрасте до 3 лет - в годах
	  -- 457 - Индексация государственных пособий семьям, воспитывающим детей, в процентах
	  -- 489 - Число месяцев в году, учит. при пров. превыш. суммой взн. в ФСЗ
	         -- установл. месяч. разм. пос. на реб. ст. 3 лет, умноженного на указанное число месяцев - 12
      if (S_YearsBetween(XLPL.WorkDate, c1.BDate) <= S_Const(401, XLPL.WorkDate)) then

		-- сумма взносов для семьи
		if (B_F_RelProtAmountToPayContrib() > 0) then
		  j := trunc(S_Const(489, XLPL.WorkDate));

          SaveDate := XLPL.WorkDate;

         -- Размер пособия на детей в возрасте старше 3 лет - в % от БПМ  498 - 30
		  for amonth in 1..j loop
  			XLPL.WorkDate := S_EncodeDate(ayear, amonth, aday);
    		SumBenefit := B_CU300()*(1 + S_Const(457, XLPL.WorkDate)/100);
			ResBenefit := ResBenefit + SumBenefit;
		  end loop;

          XLPL.WorkDate := SaveDate;
		else
		  j := trunc(S_Const(489, XLPL.WorkDate));

          SaveDate := XLPL.WorkDate;

		  -- Размер пособия по уходу за ребенком в возрасте до 3 лет для неработающих матерей - в % от БПМ  494 - 35%
		  for amonth in 1..j loop
  			XLPL.WorkDate := S_EncodeDate(ayear, amonth, aday);
    		SumBenefit := B_CU306()*(1 + S_Const(457, XLPL.WorkDate)/100);
			ResBenefit := ResBenefit + SumBenefit;
 		  end loop;

          XLPL.WorkDate := SaveDate;
        end if;

      else
		j := trunc(S_Const(489, XLPL.WorkDate));

        SaveDate := XLPL.WorkDate;

         -- Размер пособия на детей в возрасте старше 3 лет - в % от БПМ  498 - 30%
		for amonth in 1..j loop
  		  XLPL.WorkDate := S_EncodeDate(ayear, amonth, aday);
    	  SumBenefit := B_CO300()*(1 + S_Const(457, XLPL.WorkDate)/100);
		  ResBenefit := ResBenefit + SumBenefit;
		end loop;

        XLPL.WorkDate := SaveDate;
	  end if;

	end loop;


  end if;

  return ResBenefit;

/*==============================================================================
+ Функция: F_CHECKCONTRIBUT
+ Наименование: Функция определяет сумму выплаченных пособий в деле
+ 				за предыдущий год, если выплаты были, или предположительную
+ 				сумму, если выплат не было
+ Автор: Ворошилин. В.
+ Состояние на дату 17.05.2002
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 16.07.2002
==============================================================================*
  SumBenefit number;   	  -- накопление суммы
  ResBenefit number; 	  -- накопление результата
  APERIOD_START date;
  APERIOD_END date;
  aday number;
  amonth number;
  ayear number;
  DateBenefit date;
  SaveDate date;
  j number;
begin

  ResBenefit := 0;
  APERIOD_START := S_Encodedate(S_YearOfDate(S_AddYears(XLPL.WorkDate, -1)), 1, 1);
  APERIOD_END := S_Encodedate(S_YearOfDate(S_AddYears(XLPL.WorkDate, -1)), 12, 31);

  if (XLPL.AID <> 0) then
    if (XLPL.WorkDate >= S_Encodedate(2002,4,1)) and
	  (XLPL.WorkDate < S_Encodedate(2002,12,31)) and
      (B_F_StartDateAllocation is not null) and
	  (B_F_StartDateAllocation < S_Encodedate(2002,4,1)) then
--      ResBenefit := B_F_RelProtAmountToPayContrib();
      ResBenefit := B_F_RelProtCalcContrib;
	  return ResBenefit;
    end if;
  else
    if XLPL.WorkDate >= S_Encodedate(2002,4,1) and
	  XLPL.WorkDate < S_Encodedate(2002,12,31) then
--  	  ResBenefit := B_F_RelProtAmountToPayContrib();
      ResBenefit := B_F_RelProtCalcContrib;
	  return ResBenefit;
    end if;
  end if;

  ResBenefit := B_Amount_Last_Year(APERIOD_START, APERIOD_END);

  if (ResBenefit = 0) then
    aday := 1;
    amonth := 1;
    ayear := S_YearOfDate(S_AddYears(XLPL.WorkDate, -1));

    for c1 in (select b.BIRTH_DATE as BDate
			   from W$CASE_PERSON a, W$PERSON b
			   where a.CID = XLPL.CID
			     and a.ROLE = 56
				 and a.STAGE NOT IN(2,3)
				 and a.ENTERED_BY = XLPL.User_ID
				 and b.PID = a.PID
				 and b.STAGE NOT IN(2,3)
				 and b.ENTERED_BY = XLPL.User_ID) loop

      if (S_YearsBetween(XLPL.WorkDate, c1.BDate) <= S_Const(401, XLPL.WorkDate)) then
		if (B_F_RelProtAmountToPayContrib() > 0) then
		  j := trunc(S_Const(489, XLPL.WorkDate));

          SaveDate := XLPL.WorkDate;

		  for amonth in 1..j loop
  			XLPL.WorkDate := S_EncodeDate(ayear, amonth, aday);
    		SumBenefit := B_CU300()*(1 + S_Const(457, XLPL.WorkDate)/100);
			ResBenefit := ResBenefit + SumBenefit;
		  end loop;

          XLPL.WorkDate := SaveDate;
		else
		  j := trunc(S_Const(489, XLPL.WorkDate));

          SaveDate := XLPL.WorkDate;

		  for amonth in 1..j loop
  			XLPL.WorkDate := S_EncodeDate(ayear, amonth, aday);
    		SumBenefit := B_CU306()*(1 + S_Const(457, XLPL.WorkDate)/100);
			ResBenefit := ResBenefit + SumBenefit;
 		  end loop;

          XLPL.WorkDate := SaveDate;
        end if;
      else
		j := trunc(S_Const(489, XLPL.WorkDate));

        SaveDate := XLPL.WorkDate;

		for amonth in 1..j loop
  		  XLPL.WorkDate := S_EncodeDate(ayear, amonth, aday);
    	  SumBenefit := B_CO300()*(1 + S_Const(457, XLPL.WorkDate)/100);
		  ResBenefit := ResBenefit + SumBenefit;
		end loop;

        XLPL.WorkDate := SaveDate;
	  end if;
	end loop;
  end if;

  return ResBenefit;
  /* */
end;
/
