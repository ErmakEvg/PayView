CREATE FUNCTION       A_F_CheckCloseAlloc(aAID in NUMBER, aCID in NUMBER)
                                                               RETURN BOOLEAN IS
--==============================================================================
-- Назначение: проверяет, состояние назначения на рабочую дату
-- Автор: ???????       переписал Раковчук М.П.
--------------------------------------------------------------------------------
-- Входные праметры:
---------------------
-- aAID  - AID назначения
-- aCID  - идентификатор дела
--------------------------------------------------------------------------------
-- Возвращаемое значение: True - назначение закрыто или приостановлено
--                        False - назначение действует
--==============================================================================
xCount NUMBER;
xWorkDate DATE;
xResume BOOLEAN;
BEGIN
xWorkDate := XLPL.WORKDATE;
select count (*)
into xCount
from W$ALLOCATION
where CID = aCID
and AID = aAID
and PARENT_RID is NULL
and (ALLOC_STATUS <> 1 or (AMOUNT = 0 and PAYMENT_PERCENT = 0))
and STEP_START <= xWorkDate
and (STEP_END >= xWorkDate or STEP_END is NULL)
and STAGE in (4, 1);
if xCount > 0 then
  xResume := True;
else
  select count (*)
  into xCount
  from ALLOCATION
  where CID = aCID
  and AID = aAID
  and PARENT_RID is NULL
  and (ALLOC_STATUS <> 1 or (AMOUNT = 0 and PAYMENT_PERCENT = 0))
  and STEP_START <= xWorkDate
  and (STEP_END >= xWorkDate or STEP_END is NULL)
  and (STAGE = 1 or STAGE is NULL);
  if xCount > 0 then
    xResume := True;
  else
    xResume := False;
  end if;
end if;
RETURN xResume;
END A_F_CheckCloseAlloc;
/
