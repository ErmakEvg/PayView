CREATE FUNCTION       A_F_RelProtMale RETURN Boolean IS
/*TRUE если PID муж. по W$RELATION_PROTOCOL
Вахромин О.Ю.*/
BEGIN
   return A_F_RelProtGender()=1;
END A_F_RelProtMale;
/
