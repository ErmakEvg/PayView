CREATE FUNCTION       B_F_ARRAYDATEESTMETRIC RETURN DBMS_SQL.NUMBER_TABLE AS
/*******************************************************************************
 Функция            : B_F_ARRAYDATEESTMETRIC
 Наименование       : Построение массива дат изменения характеристик
                      для одной характеристики с CODE = pCode для Estimation
 Автор              : Ворошилин В.     Комментарии и корректировка: ОЛВ		РАВ
 Состояние на дату  : 17.11.2000     30.08.2011  24.08.2015	11.05.2017
 Код возврата       : Возвращает массив дат изменения характеристик
********************************************************************************/
 chahge_date_metric DBMS_SQL.NUMBER_TABLE;
 a                  BINARY_INTEGER;
BEGIN
  /* массив дат изменения характеристик для одной характеристики с CODE = pCode для Estimation
  STATUS_REASON       - ПРИЧИНА ИЗМЕНЕНИЯ СОСТОЯНИЯ НАЗНАЧЕНИЯ; СПРАВОЧНИК ALLOC_STATUS_CHANGE_REASON
  CHAHGE_ALLOC_STATUS - ПРОГНОЗИРУЕМОЕ ДЕЙСТВИЕ ПО ИЗМЕНЕНИЮ СОСТОЯНИЯ НАЗНАЧЕНИЯ из REF_CHAHGE_ALLOC_STATUS:
                                                                                          1 - приостановить, 2 - закрыть/**/
  chahge_date_metric.Delete;
  a := 0;
 for METRIC in (select nvl(RECORD_START, NULL) as metric_start, nvl(RECORD_END, NULL) as metric_end, CODE
                 from W$PERSON_METRIC
                 where PID = XLPL.GetPid
                   and STAGE in (1, 4)
                   and ((NVL(RECORD_START, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate)) or (NVL(RECORD_END, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate)))
                   and ENTERED_BY = XLPL.User_ID)
 loop
    --                               RECORD_START as metric_start
    -----------------------------------------------------------------------------------------------
   if (METRIC.metric_start is not NULL) and (METRIC.metric_start > LAST_DAY(S_CurrDate)) then

      -- 121 - В/с срочной службы (солдат, матрос),  кроме проходящих службу по контракту
      -- 122 - В/о (солдат, матрос), призванный на учебные, специальные или поверочные сборы
      -- 125 - В/с срочной службы (сержант, старшина, ефрейтор, старший матрос),  кроме проходящих службу по контракту
      -- 126 - В/о (сержант, старшина, ефрейтор, старший матрос), призванный на учебные, специальные или поверочные сборы
      if (METRIC.Code = 121) or (METRIC.Code = 122) or (METRIC.Code = 125) or (METRIC.Code = 126) then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start);
        chahge_date_metric(chahge_date_metric.count + 1) := 87;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 145 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(LAST_DAY(METRIC.metric_start));
        chahge_date_metric(chahge_date_metric.count + 1) := 35;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 148 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start);
        chahge_date_metric(chahge_date_metric.count + 1) := 76;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 154 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(LAST_DAY(METRIC.metric_start));
        chahge_date_metric(chahge_date_metric.count + 1) := 45;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 155 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 998;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 156 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 21;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 157 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 21;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      -- Проживает в семье (приходящий контингент)
      if METRIC.Code = 171 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 73;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      -- Прибыл(а) на постоянное место жительства в Республику Беларусь (имеет вид на жительство)
      if METRIC.Code = 183 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 998;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      -- Не получал(а) пособие по уходу за ребенком в возрасте до 3 лет по месту работы, учебы
      if METRIC.Code = 256 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 317;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      -- Ребенок, над которым установлены опека или усыновление (удочерение) местными исполнительными органами
      if METRIC.Code = 257 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 998;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      -- Осуществляет уход за престарелым, инвалидом 1 группы или ребенком - инвалидом до 18 лет
      if METRIC.Code = 258 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 84;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      -- Осуществляет уход за ребенком в возрасте до 3-х лет 30.08.2011 ОЛВ
      if METRIC.Code = 260 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start); --24.08.2015 OLV - Зачем эта прогнозируемая дата?
        chahge_date_metric(chahge_date_metric.count + 1) := 85; -- пока - так - Завершение ухода за престарелым, инвалидом 1 группы или ребенком - инвалидом до 18 лет
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 320 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 86;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 358 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 87;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 545 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 89;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;

      if (METRIC.Code = 650) or (METRIC.Code = 651) or (METRIC.Code = 652) or (METRIC.Code = 653) or (METRIC.Code = 654) or
         (METRIC.Code = 655) or (METRIC.Code = 656) or (METRIC.Code = 657) or (METRIC.Code = 658) or (METRIC.Code = 659) then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 91;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if a = 0 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_start)-1;
        chahge_date_metric(chahge_date_metric.count + 1) := 998;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
      end if;
    end if;

    --                                 RECORD_END as metric_end
    -----------------------------------------------------------------------------------------------
    a := 0;
    if (METRIC.metric_end is not NULL) and ((METRIC.metric_end +1) > LAST_DAY(S_CurrDate)) then

      if (METRIC.Code = 121) or (METRIC.Code = 122) or (METRIC.Code = 125) or (METRIC.Code = 126) then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(LAST_DAY(METRIC.metric_end));
        chahge_date_metric(chahge_date_metric.count + 1) := 88;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 145 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 75;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 148 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(LAST_DAY(METRIC.metric_end));
        chahge_date_metric(chahge_date_metric.count + 1) := 37;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 154 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 77;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 155 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 998;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 156 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 316;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 157 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 316;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 171 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(LAST_DAY(METRIC.metric_end));
        chahge_date_metric(chahge_date_metric.count + 1) := 67;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 183 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 82;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      -- Не получал(а) пособие по уходу за ребенком в возрасте до 3 лет по месту работы, учебы
      if METRIC.Code = 256 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(LAST_DAY(METRIC.metric_end));
        chahge_date_metric(chahge_date_metric.count + 1) := 318;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      -- Ребенок, над которым установлены опека или усыновление (удочерение) местными исполнительными органами
      if METRIC.Code = 257 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 83; -- не нашла в справочнике ALLOC_STATUS_CHANGE_REASON
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 258 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 85; -- Завершение ухода за престарелым, инвалидом 1 группы или ребенком - инвалидом до 18 лет
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      -- Осуществляет уход за ребенком в возрасте до 3-х лет 30.08.2011 ОЛВ
      if METRIC.Code = 260 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 85; -- пока - так - Завершение ухода за престарелым, инвалидом 1 группы или ребенком - инвалидом до 18 лет
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 320 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(LAST_DAY(METRIC.metric_end));
        chahge_date_metric(chahge_date_metric.count + 1) := 70;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 358 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 88;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 545 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 90;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      --Речицкая А. В. 11.05.2017  удостоверение ЧАЭС
      if METRIC.Code = 547 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(LAST_DAY(METRIC.metric_end));
        chahge_date_metric(chahge_date_metric.count + 1) := 90;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if (METRIC.Code = 650) or (METRIC.Code = 651) or (METRIC.Code = 652) or (METRIC.Code = 653) or (METRIC.Code = 654) or
         (METRIC.Code = 655) or (METRIC.Code = 656) or (METRIC.Code = 657) or (METRIC.Code = 658) or (METRIC.Code = 659) then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(LAST_DAY(METRIC.metric_end));
        chahge_date_metric(chahge_date_metric.count + 1) := 92;
        chahge_date_metric(chahge_date_metric.count + 1) := 2;
        a := 1;
      end if;
      if METRIC.Code = 709 then  -- 30.10.2017 ОЛВ -- Пенсионер отказался от получения пенсии по заявлению
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 32;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if METRIC.Code = 760 then  -- 30.10.2017 ОЛВ  -- Отказано в получении пенсии
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 32;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
        a := 1;
      end if;
      if a = 0 then
        chahge_date_metric(chahge_date_metric.count + 1) := S_Julian(METRIC.metric_end);
        chahge_date_metric(chahge_date_metric.count + 1) := 998;
        chahge_date_metric(chahge_date_metric.count + 1) := 1;
      end if;
    end if;
  end LOOP;
  return chahge_date_metric;
end B_F_ARRAYDATEESTMETRIC;
/
