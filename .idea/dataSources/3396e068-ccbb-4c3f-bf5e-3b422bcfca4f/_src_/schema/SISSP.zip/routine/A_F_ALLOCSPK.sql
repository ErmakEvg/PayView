CREATE FUNCTION       A_F_AllocSPK(aAlloc_Code IN NUMBER) RETURN boolean IS
/***************************************************************************************
 Функция           :  A_F_AllocInv
 Наименование      :  Ф-я проверки является ли назначение пенсией по СПК
 Автор             : ОЛВ
 Состояние на дату : 24.02.2011
 Код возврата      : True - назначение - пенсия по инвалидности
***************************************************************************************/
 count_D        NUMBER;
 AllocSPK       BOOLEAN;
BEGIN
 -- 190 - Пенсия по случаю потери кормильца
    AllocSPK:= False;
 select count(*)
   into count_D
   from ALLOCATIONS
  where code = aAlloc_Code
    and parent_code =190
	and end_date is null;

 IF count_D=1   then
    AllocSPK:= True;
 END IF;
  RETURN AllocSPK;

END A_F_AllocSPK;
/
