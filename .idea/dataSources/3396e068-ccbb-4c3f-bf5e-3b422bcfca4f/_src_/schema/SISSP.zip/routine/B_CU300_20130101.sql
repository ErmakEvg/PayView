CREATE FUNCTION       B_Cu300_20130101 RETURN NUMBER AS
/*******************************************************************************
 Функция           :  B_Cu300_20130101
 Наименование      : Функция расчета суммы пособия по уходу за ребенком до 3 лет
 Основание         :  Зак. РБ от               N  .
 Автор             : Речицкая А.В.        Корректировка: ОЛВ
 Состояние на дату :                                20.05.2013  17.10.2014
 Код возврата      : число с плавающей точкой с суммой пособия
********************************************************************************/
 Amount          NUMBER;
 Size_RSZP    NUMBER;
 Percent          NUMBER;
 NMask           VARCHAR2(50);

BEGIN
    Xlpl.RoleDecl('Child','56');
    Xlpl.REPLACEROLE('Child');
 -- 20.05.2013 OLV
 IF A_F_Relprotdisability(1, '14') OR B_F_Relprotmetricben('320') THEN   -- реб.-инв.
       Percent:=   S_Const(451, Xlpl.WorkDate); --45%
 ELSE
    IF B_F_Relprotmetricben('359') THEN -- 17.10.2014 OLV --IF A_F_Relprotmetric('359')  THEN
       Percent:=   S_Const(436, Xlpl.WorkDate);  -- 40%  -- Ребенок второй или последующий
    ELSE
       Percent:=   S_Const(415, Xlpl.WorkDate); -- 35 %
    END IF;
 END IF;
   Xlpl.RestoreRole;
      Size_RSZP :=S_Const(240, Xlpl.WorkDate);  -- Средняя заработная плата рабочих и служащих
      Amount :=  S_Vround_Sum((Size_RSZP * Percent*0.01), S_Const(40,Xlpl.WorkDate));

 IF Xlpl.INDIV = 0 THEN      -- Индивидуальный расчет -- Вывод в протокол  размера пособия
   Xlpl.S_PROTOCOL(' ');
   Xlpl.S_PROTOCOL('                       Исчисление размера пособия' || CHR(10));
   Xlpl.S_Protocol('------------------------------------------------------------------------------------------- '|| CHR(10));
   NMask := LPAD('9', LENGTH(TO_CHAR(Amount)), '9') || '0.99';
     Xlpl.S_protocol ('Сумма основного назначения ( '||Percent||'% от '||Size_RSZP||'  ): '
                                           || CHR(9)|| TO_CHAR(Amount, NMask) || CHR (10));
 END IF;

  RETURN Amount;
 --RAISE_APPLICATION_ERROR(-20801,'B_CU300_20130101 1 1  XLPL.GetPid=' ||XLPL.GetPid|| '  XLPL.Payment='||XLPL.Payment || '  Amount='||Amount );
/* 20.05.2013 OLV *
 IF   (A_F_Relprotage < S_Const(401, Xlpl.WorkDate))
            AND ( A_F_Relprotdisability(1, '14') OR B_F_Relprotmetricben('320') OR A_F_Relprotdisabilityreason(-1, '', '4') ) -- реб.-инв.
            AND  B_F_Relprotmetricben('171')  THEN            -- Проживает в семье (приходящий контингент)

 IF A_F_Relprotmetric('359')
    THEN
      IF   (A_F_Relprotage < S_Const(401, Xlpl.WorkDate))  AND ( A_F_Relprotdisability(1, '14') OR B_F_Relprotmetricben('320') OR A_F_Relprotdisabilityreason(-1, '', '4') )
            AND  B_F_Relprotmetricben('171')  THEN
                            Amount :=  S_Vround_Sum((S_Const(240, Xlpl.WorkDate) * S_Const(451, Xlpl.WorkDate)/100), S_Const(40,Xlpl.WorkDate));
                            Percent:=   S_Const(451, Xlpl.WorkDate);
                            --RAISE_APPLICATION_ERROR(-20801,'B_CU300_20130101  5    XLPL.GetPid=' ||XLPL.GetPid||' Amount= '|| Amount||' Percent'|| Percent);
                            ELSE
                            Amount :=  S_Vround_Sum((S_Const(240, Xlpl.WorkDate) * S_Const(436, Xlpl.WorkDate)/100), S_Const(40,Xlpl.WorkDate));
                            Percent:=   S_Const(436, Xlpl.WorkDate);
                            --RAISE_APPLICATION_ERROR(-20801,'B_CU300_20130101  5    XLPL.GetPid=' ||XLPL.GetPid||' Amount= '|| Amount||'Percent||Percent);
                            END IF;
        ELSE
                           IF   (A_F_Relprotage < S_Const(401, Xlpl.WorkDate))
                            AND ( A_F_Relprotdisability(1, '14') OR B_F_Relprotmetricben('320') OR A_F_Relprotdisabilityreason(-1, '', '4') )
                            AND  B_F_Relprotmetricben('171')  THEN
                            Amount :=  S_Vround_Sum((S_Const(240, Xlpl.WorkDate) * S_Const(451, Xlpl.WorkDate)/100), S_Const(40,Xlpl.WorkDate));
                            Percent:=   S_Const(451, Xlpl.WorkDate);
                            --RAISE_APPLICATION_ERROR(-20801,'B_CU300_20130101  5    XLPL.GetPid=' ||XLPL.GetPid||' Amount= '|| Amount||' Percent='|| Percent);
                            ELSE
                            Amount :=  S_Vround_Sum((S_Const(240, Xlpl.WorkDate) * S_Const(415, Xlpl.WorkDate)/100), S_Const(40,Xlpl.WorkDate));
                            Percent:=   S_Const(415, Xlpl.WorkDate);
                            --RAISE_APPLICATION_ERROR(-20801,'B_CU300_20130101  5    XLPL.GetPid=' ||XLPL.GetPid||' Amount= '|| Amount||' Percent='|| Percent);
                            END IF;
 END IF;/* */
END B_Cu300_20130101;
/
