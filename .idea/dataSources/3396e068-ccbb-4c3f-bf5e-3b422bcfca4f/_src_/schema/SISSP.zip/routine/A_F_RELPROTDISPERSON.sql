CREATE FUNCTION       A_F_RelProtDisPerson(ACODE_ROLE in NUMBER, pADVICE_TYPE IN NUMBER, pAge IN NUMBER, pWorkDate in DATE) RETURN BOOLEAN AS
/***************************************************************************************
 Функция           : A_F_RelProtDisPerson
 Наименование      : Проверка наличия в деле инвалидов по закл. МРЭК pADVICE_TYPE
                                            с ролью ACODE_ROLE в возрасте до pAge
 Автор             : ОЛВ
 Состояние на дату : 02.06.2010
 Код возврата      : возвращает true, если есть человек с ролью ACODE_ROLE
****************************************************************************************/

  xDRIDS        DBMS_SQL.NUMBER_TABLE;
  vsDRID        NUMBER;
  pCount        NUMBER;

BEGIN

  xDRIDS.delete;
  pCount := 0;
  -- все RID из CASE_PERSON согласно коду по W$RELATION_PROTOCOL
  xDRIDS := A_F_RelProtGetRIDCasePersonPid;

 if xDRIDS.count <> 0 then

   for i in 1..xDRIDS.count loop
	    vsDRID := xDRIDS(i);
	  select count(*) into pCount
	  from CASE_PERSON a, PERSON b, MRAK_OPINION_ADVICE c, MRAK_OPINION d
	  where a.RID = vsDRID
	    AND	a.PID = b.pid
	    AND	a.PID = c.pid
	    AND	a.PID = d.pid
		AND a.ROLE = ACODE_ROLE
		AND c.ADVICE_TYPE=pADVICE_TYPE
		--AND a.ENTERED_BY=Xlpl.USER_ID
		AND S_AddYears (b.BIRTH_DATE,ROUND(pAge)) >= pWorkDate
		AND  NVL(NVL(c.RECORD_START,d.EXAMED_FROM),pWorkDate)<=pWorkDate
		AND  NVL(NVL(c.RECORD_END,c.DIS_TERM),pWorkDate)>=pWorkDate;

	    IF pCount>0 THEN
           RETURN TRUE;
        END IF;
   end loop;
 end if;

 -- все RID из W$CASE_PERSON согласно коду по W$RELATION_PROTOCOL
    xDRIDS := A_F_RelProtGetRIDWCasePersPid;
 if xDRIDS.count <> 0 then
   for i in 1..xDRIDS.count loop
	    vsDRID := xDRIDS(i);
	  select count(*) into pCount
	  from W$CASE_PERSON a, W$PERSON b, W$MRAK_OPINION_ADVICE c, W$MRAK_OPINION d
	  where a.RID = vsDRID
	    AND	a.PID = b.pid
	    AND	a.PID = c.pid
	    AND	a.PID = d.pid
		AND a.ROLE = ACODE_ROLE
		AND c.ADVICE_TYPE=pADVICE_TYPE
		--AND a.ENTERED_BY=Xlpl.USER_ID
		AND S_AddYears (b.BIRTH_DATE,ROUND(pAge)) >= pWorkDate
		AND  NVL(NVL(c.RECORD_START,d.EXAMED_FROM),pWorkDate)<=pWorkDate
		AND  NVL(NVL(c.RECORD_END,c.DIS_TERM),pWorkDate)>=pWorkDate;
	    IF pCount>0 THEN
           RETURN TRUE;
        END IF;
   end loop;

 end if;
--RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtDisPerson 2   XLPL.WorkDate='||XLPL.WorkDate||CHR(10)||'    ST  '||ST);
  RETURN FALSE;

END A_F_RelProtDisPerson;
/
