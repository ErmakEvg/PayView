CREATE FUNCTION       A_F_RELPROTDISABILITYSTART(AOPINION_TYPE in NUMBER, AADVICE_TYPE in VARCHAR2) return date is
/*******************************************************************************
 Функция             :  A_F_RELPROTDISABILITYSTART
 Наименование        :  возвращает минимальную дату начала действия инвалидности
 Автор               :  Боровнева            Комментарии и корректировка: ОЛВ
 Состояние на дату   :  01.06.1999			 					 18.02.2011
 Код возврата        :  возвращает минимальную дату начала действия инвалидности
                        по коду согласно W$RELATION_PROTOCOL
   Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
   AOPINION_TYPE - одно значение (при -1 - игнорируется)
   при AADVICE_TYPE = "" будет игнорироваться, иначе интерпритируется как список параметров
********************************************************************************/
 DRIDS                DBMS_SQL.NUMBER_TABLE;
 xADVICE_TYPE         DBMS_SQL.NUMBER_TABLE;
 VSDRID               NUMBER;
 vsADVICE_TYPE        Number;
 Dis_Start_Rab        Number;
 Disability_Start_Min date;
 pRecord_Start        date;
 pExamed_From         date;
begin

  Disability_Start_Min := NULL;
  pRecord_Start := NULL;
  pExamed_From := NULL;
  xADVICE_TYPE := S_ParseFloatArray (AADVICE_TYPE);

 -- RID из W$RELATION_PROTOCOL для MRAK_OPINION_ADVICE
  ------------------------------------------------------
  DRIDS := A_F_RelProtGetRIDMrakOpAdvice (1,AOPINION_TYPE);

 --Выбрать минимальную дату начала действия инвалидности
 -------------------------------------------------------
 IF DRIDS.count <> 0 then
    for i in 1..DRIDS.count LOOP
        vsDRID := DRIDS(i);
	   SELECT nvl(a.Record_Start,NULL), nvl(b.EXAMED_FROM,NULL)
         INTO pRecord_Start, pExamed_From
	     FROM MRAK_OPINION_ADVICE a, MRAK_OPINION b
	    WHERE a.RID = vsDRID
          AND b.RID = MRAK_RID;

	    IF(pRecord_Start is not null) and (pExamed_From is not null) then
             Dis_Start_Rab := Least(s_julian(pRecord_Start), S_julian(pExamed_From));
	    ELSE
		  IF (pRecord_Start is NULL) and (pExamed_From is not null) then
                Dis_Start_Rab := S_julian(pExamed_From);
	      ELSE
		    IF(pRecord_Start is not null) and (pExamed_From is null) then
                    Dis_Start_Rab := s_julian(pRecord_Start);
            END IF;
          END IF;
      END IF;

	  IF Disability_Start_Min is not null then
         Disability_Start_Min := s_jtod(Least(s_julian(Disability_Start_Min), Dis_Start_Rab));
	  ELSE
	     Disability_Start_Min := s_jtod(Dis_Start_Rab);
      END IF;
    END LOOP;
 END IF;

  -- RID из W$RELATION_PROTOCOL для W$MRAK_OPINION_ADVICE
  ------------------------------------------------------
  DRIDS := A_F_RelProtGetRIDMrakOpAdvice (0,AOPINION_TYPE);

 --Выбрать минимальную дату начала действия инвалидности
 -------------------------------------------------------
  IF DRIDS.count <> 0 then
    for i in 1..DRIDS.count LOOP
      vsDRID := DRIDS(i);
	    SELECT nvl(a.Record_Start,NULL), nvl(b.EXAMED_FROM,NULL)
	      INTO pRecord_Start, pExamed_From
          FROM W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
	     WHERE a.RID = vsDRID
           AND b.RID = a.MRAK_RID
           AND a.entered_by = XLPL.USER_ID
           AND b.entered_by = XLPL.USER_ID;

	    IF (pRecord_Start is not null) and (pExamed_From is not null)  then
	            Dis_Start_Rab := Least(s_julian(pRecord_Start), s_julian(pExamed_From));
	    ELSE
		     IF(pRecord_Start is  null) and (pExamed_From is not null) then
               Dis_Start_Rab := s_julian(pExamed_From);
	         ELSE
			    IF(pRecord_Start is not null) and (pExamed_From is  null) then
                   Dis_Start_Rab := s_julian(pRecord_Start);
                END IF;
           END IF;
      END IF;
	    IF(Disability_Start_Min is not null) then
           Disability_Start_Min := s_jtod(least(s_julian(Disability_Start_Min), Dis_Start_Rab));
        ELSE
		   Disability_Start_Min := s_jtod(Dis_Start_Rab);
        END IF;
    END LOOP;
  END IF;
  return Disability_Start_Min ;

end A_F_RELPROTDISABILITYSTART;
/
