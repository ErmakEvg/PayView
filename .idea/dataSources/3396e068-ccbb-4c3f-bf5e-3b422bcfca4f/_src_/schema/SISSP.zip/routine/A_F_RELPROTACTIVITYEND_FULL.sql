CREATE FUNCTION       A_F_RelProtActivityEnd_FULL(aActivity in NUMBER, aLabor in VARCHAR2, aDismiss_Reason in VARCHAR2)
                                                   RETURN DATE IS
/***************************************************************************************
 Функция            : A_F_RelProtActvEnd
 Наименование       : Функция определения даты окончания ACTIVITY
                    :  без проверки условия даты окончания
 Автор              : АМВ
 Состояние на дату  : 22.07.2014,02.10.2014,17.12.2015,07.07.2016
 Код возврата       : датa окончания ACTIVITY
****************************************************************************************/

 DRIDS       DBMS_SQL.NUMBER_TABLE;
 vsDRID      number;
 pPERIOD_End date default  null;
 mPERIOD_End date default  null;
 i integer;
BEGIN
  --     1 - ОБД
  ----------------------
    DRIDS := A_F_RelProtGetRIDActivity(1);
  if (DRIDS.count <> 0) then
    for i in 1 .. DRIDS.count LOOP
        vsDRID := DRIDS(i);
      BEGIN
	    select PERIOD_END into pPERIOD_End
		  from ACTIVITY
	     where RID = vsDRID
	       and ACTIVITY = aActivity
		   --07.07.2016 and (case when aLabor is null then 0 else TO_NUMBER(aLabor) end = NVL(LABOR,0)) ---02.10.2014,17.12.2015 NVL
		   --07.07.2016 and (case when aDismiss_Reason is null then 0 else TO_NUMBER(aDismiss_Reason) end = NVL(DISMISSAL_REASON,0)) --02.10.2014,17.12.2015 NVL
           and ( (LABOR = TO_NUMBER(aLabor)) or (aLabor is NULL) ) --07.07.2016
           and ( (DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason)) or (aDismiss_Reason is NULL) ) --07.07.2016
           and PERIOD_END is not null
		   and (( (PERIOD_Start is null) or (XLPL.WorkDate>= PERIOD_Start)));
             if (mPERIOD_End is null) or (mPERIOD_End < pPERIOD_End) then
                mPERIOD_End:= pPERIOD_End;
             end if;
      exception
        when No_Data_Found then
           null;
      END;

	end loop;
  end if;
  --     0 - РБД
  ----------------------
    DRIDS := A_F_RelProtGetRIDActivity(0);
  if (DRIDS.count <> 0) then
    for i in 1 .. DRIDS.count LOOP
        vsDRID := DRIDS(i);
      BEGIN
      -- if vsDRID = 7240000169651  and aLabor = NULL then
      --  RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtActivityEnd_FULL'
      --         ||chr(10)||'vsDRID='||vsDRID
      --        ||chr(10)||'aLabor='||aLabor
      --          );
      -- end if;
	    select PERIOD_END into pPERIOD_End
		  from W$ACTIVITY
	     where RID = vsDRID
	       and ACTIVITY = aActivity
           /** 07.07.2016
           and (case when aLabor is null then 0 else TO_NUMBER(aLabor)  end = NVL(LABOR,0)) ---02.10.2014,17.12.2015 NVL
		   and (case when aDismiss_Reason is null then 0 else TO_NUMBER(aDismiss_Reason) end = NVL(DISMISSAL_REASON,0)) --02.10.2014,17.12.2015 NVL
           /**/
           and ( (LABOR = TO_NUMBER(aLabor)) or (aLabor is NULL) ) --07.07.2016
           and ( (DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason)) or (aDismiss_Reason is NULL) ) --07.07.2016
           and PERIOD_END is not null
		   and (( (PERIOD_Start is null) or (XLPL.WorkDate>= PERIOD_Start)) )
		   and entered_by = XLPL.User_ID ;

             if (mPERIOD_End is null) or (mPERIOD_End < pPERIOD_End) then
                mPERIOD_End:= pPERIOD_End;
             end if;
      exception
        when No_Data_Found then
           null;
      END;

	end loop;
  end if;

RETURN mPERIOD_End;

END A_F_RelProtActivityEnd_FULL;
/
