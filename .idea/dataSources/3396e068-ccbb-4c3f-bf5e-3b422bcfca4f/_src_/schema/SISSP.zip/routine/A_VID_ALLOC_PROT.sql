CREATE FUNCTION A_VID_ALLOC_PROT (rcid IN NUMBER,rentered_by IN NUMBER)RETURN varchar2 IS
-- функция выбора вида назначения для протоколов решения и исчисления
--Якимова С.А. 27.01.2011
--  Закон, по которому назначаем
--- Если в заявлении pr_rasch=1, значит Россия, по пропорции
--- если есть Литовский стаж, то Литва
--- остальное из Аllocation -notes

vid_nazn varchar2(1000);
pr_rasch number;
stag_litva number;
rpid number;
begin
vid_nazn:=' ';
pr_rasch:=0;
stag_litva:=0;
-- определяем pid
rpid:=0;
select pid into rpid from  W$CASE_PERSON where CID=RCID and stage in (1,4);
---признак расчета для Росии
-- есть ли заявление
select count(*) into pr_rasch FROM  W$APPLICATION
WHERE    cid=RCID and
       entered_by = REntered_by and
       STAGE IN (4);
if pr_rasch>0 then
SELECT pr_rasch into pr_rasch
FROM  W$APPLICATION
WHERE    cid=RCID and
       entered_by = REntered_by and
       STAGE IN (4);
	if pr_rasch=1 then

	   SELECT distinct DECODE_ALLOCATION (a.ALLOC_CODE)||' По нормам Договора с РФ' into vid_nazn
        FROM W$ALLOCATION a, ALLOCATIONS f
        WHERE a.CID =RCID AND
        a.ALLOC_CODE = f.CODE AND
        f.OTHER_PAYMENTS IS NULL AND
        a.STAGE IN (4) AND
        a.PARENT_RID IS NULL AND
        a.COMP_PART IS NULL AND
        a.STEP_END IS NULL AND
        a.ALLOC_STATUS in (1,2) AND
        a.ENTERED_BY =RENTERED_BY;
		 return vid_nazn;
     end if;

	 end if;

	---- проверяем Литву
	select count(*) into stag_litva FROM  W$MANUAL_RECORD
    WHERE    RECORD_CODE=82 and PID=RPID and
       entered_by = REntered_by and
       STAGE IN (1,4);
	  if stag_litva>0 then
	 SELECT distinct DECODE_ALLOCATION (a.ALLOC_CODE)||' По нормам Договора с Литвой' into vid_nazn
        FROM W$ALLOCATION a, ALLOCATIONS f
        WHERE a.CID =RCID AND
        a.ALLOC_CODE = f.CODE AND
        f.OTHER_PAYMENTS IS NULL AND
        a.STAGE IN (4) AND
        a.PARENT_RID IS NULL AND
        a.COMP_PART IS NULL AND
        a.STEP_END IS NULL AND
        a.ALLOC_STATUS in (1,2) AND
        a.ENTERED_BY =RENTERED_BY;

	  else
	  ---закон о занятости
	  pr_rasch:=0;
      SELECT count(*) into pr_rasch FROM W$ALLOCATION a
        WHERE a.CID =RCID AND
        a.STAGE IN (4) AND
        a.PARENT_RID IS NULL AND
        a.COMP_PART IS NULL AND
        a.STEP_END IS NULL AND
        a.ALLOC_STATUS in (1,2) AND
        a.ENTERED_BY =RENTERED_BY and a.FEATURE=1;
		if pr_rasch=0 then

	   SELECT distinct DECODE_ALLOCATION (a.ALLOC_CODE)||' '|| f.NOTES vID_ALLOC into vid_nazn
       FROM W$ALLOCATION a, ALLOCATIONS f
      WHERE a.CID =RCID AND
      a.ALLOC_CODE = f.CODE AND
      f.OTHER_PAYMENTS IS NULL AND
      a.STAGE IN (4) AND
       a.PARENT_RID IS NULL AND
       a.COMP_PART IS NULL AND
       a.STEP_END IS NULL AND
       a.ALLOC_STATUS in (1,2) AND
       a.ENTERED_BY =RENTERED_BY;
        else
		 SELECT distinct DECODE_ALLOCATION (a.ALLOC_CODE)||' '|| s.value vID_ALLOC into vid_nazn
       FROM W$ALLOCATION a, ALLOCATIONS f,ref_Alloc_feature s
      WHERE a.CID =RCID AND
      a.ALLOC_CODE = f.CODE AND
      f.OTHER_PAYMENTS IS NULL AND
      a.STAGE IN (4) AND
       a.PARENT_RID IS NULL AND
       a.COMP_PART IS NULL AND
       a.STEP_END IS NULL AND
       a.ALLOC_STATUS in (1,2) AND
       a.ENTERED_BY =RENTERED_BY
	   and s.code=a.FEATURE and a.FEATURE=1;
	   end if;
	  	end if;

		return vid_nazn;
exception when no_data_found
   then return NULL;
end;
/
