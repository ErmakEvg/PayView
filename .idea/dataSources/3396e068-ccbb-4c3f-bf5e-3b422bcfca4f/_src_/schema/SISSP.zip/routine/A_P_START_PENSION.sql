CREATE FUNCTION       A_P_Start_Pension RETURN DATE AS
/*******************************************************************************
 Функция           : A_P_Start_Pension
 Наименование      : Функция определения даты начала получения пенсии
                      ( получал другую пенсию кроме выплаты alloc_code = 40)
 Автор             : Боровнева        Комментарии и корректировка: ОЛВ
 Состояние на дату : 16.02.1999               30.05.2016
 Код возврата      : предположительная дата перерасчета назначения
********************************************************************************/
 Start_Pension DATE;
 End_Pension  DATE;
 ACID              NUMBER;
 pAlloc_Code   NUMBER;
 pAid               NUMBER;
 pRab_Date     DATE;

BEGIN
 /* если между датой окончания получения пенсии
   и датой возникновения права на пенсию по СПК прошло более 5 лет,
   то возвращается дата возникновения права на пенсию по СПК,
  иначе - дата начала получения пенсии/**/
 Start_Pension := NULL;
 End_Pension := NULL;
 ACID := Xlpl.CID;
 pAlloc_Code := Xlpl.ALLOC_CODE;
 pAid := Xlpl.AID;
 pRab_Date := Xlpl.WorkDate;

  IF pAid <> 0  THEN    -- есть старое назначение
     SELECT MIN (step_start)
          INTO pRab_Date
        FROM ALLOCATION
     WHERE cid = ACID
           AND aid = pAID
           AND STAGE IS NULL  --Close_Date IS NULL
           AND alloc_status =1
           AND parent_rid IS NULL
           AND comp_part IS NULL
           AND ALLOC_CODE = pAlloc_Code;
  END IF;

  SELECT MAX(a.step_start)
       INTO End_Pension
     FROM ALLOCATION a, ALLOCATION_PERSON b, ALLOCATIONS c, ALLOCATION_ROLE_GROUP d, ID_CASE f
  WHERE  d.CODE = b.ROLE
        AND f.ACCESS_DATA = 1
        AND  f.CID = a.CID
        AND  f.CID<> ACID
        AND  NVL(d.FEATURE,0) = 1
        AND d.PARENT_CODE = c.ROLE_GROUP
        AND  c.CODE = a.ALLOC_CODE
        AND a.ALLOC_CODE <>40
        AND a.PARENT_RID IS NULL
        AND  a.COMP_PART IS NULL
        AND a.STAGE IS NULL
        AND  a.STEP_START <= pRab_Date --AND a.STEP_START = a.allocation_start
        AND  a.ALLOC_STATUS IN (2,3)       -- status -  2- перерасчет    3- перевод(только для пенсии)
        AND b.ALLOCATION_RID = a.RID
        AND  b.PID = Xlpl.GETPID
        AND b.STAGE IS NULL
        AND a.allocation_start =
            ( SELECT MAX(k.ALLOCATION_START)
                 FROM ALLOCATION k, ALLOCATION_PERSON g, ALLOCATIONS z, ALLOCATION_ROLE_GROUP h, ID_CASE r
              WHERE  h.CODE = g.ROLE
                    AND r.ACCESS_DATA = 1
                    AND r.CID = k.CID
                    AND   NVL(h.FEATURE,0) = 1
                    AND h.PARENT_CODE = z.ROLE_GROUP
                    AND  z.CODE = k.ALLOC_CODE
                    AND k.ALLOC_CODE <>40
                    AND k.PARENT_RID IS NULL
                   AND k.COMP_PART IS NULL
                   AND k.STAGE IS NULL
                   AND k.STEP_START <= Xlpl.WORKDATE
                   AND k.STEP_START = k.allocation_start
                   AND k.ALLOC_STATUS = 1
                   AND g.ALLOCATION_RID = k.RID
                   AND g.PID = Xlpl.GETPID
                   AND g.STAGE IS NULL );
  IF TRUNC(S_Yearsbetween(pRab_Date,End_Pension)) >= 5  THEN
          RETURN Start_Pension;
  END IF;

  SELECT MAX(a.allocation_start)
       INTO Start_Pension
     FROM ALLOCATION a, ALLOCATION_PERSON b, ALLOCATIONS c, ALLOCATION_ROLE_GROUP d, ID_CASE f
     , CASE ca --30.05.2016 OLV
  WHERE  d.CODE = b.ROLE
         AND f.ACCESS_DATA = 1
         AND f.CID = a.CID
         AND  f.CID<> ACID
        AND  NVL(d.FEATURE,0) = 1
        AND d.PARENT_CODE = c.ROLE_GROUP
        AND  c.CODE = a.ALLOC_CODE
        AND a.ALLOC_CODE <>40
        AND a.PARENT_RID IS NULL
        AND a.COMP_PART IS NULL
        AND a.STAGE IS NULL
        AND  a.STEP_START <= pRab_Date
        --30.05.2016 OLV--AND a.STEP_START = a.allocation_start
        AND ca.cid=a.cid
        AND ca.stage is null
        AND ( --30.05.2016 OLV
             (a.STEP_START = a.allocation_start)
          or ((ca.pr_konvert IS NOT NULL) and (a.STEP_START> a.allocation_start))
        )
        AND  a.ALLOC_STATUS = 1
        AND b.ALLOCATION_RID = a.RID
       AND  b.PID = Xlpl.GETPID
       AND b.STAGE IS NULL ;
   RETURN     Start_Pension;
   /** if Xlpl.GETPID= --xlpl.cid=30601016738 then
      RAISE_APPLICATION_ERROR(-20004,'1 A_P_Start_Pension  A_F_ALLOCSTARTCONVERT=' ||pRab_Date||'   dateSt='||dateSt
      ||'   Xlpl.GETPID='|| Xlpl.GETPID||'   xlpl.cid='||xlpl.cid);
      -- не видит, что пенсионер--or (xlpl.cid=30601016738)
     end if;/**/
END A_P_Start_Pension;
/
