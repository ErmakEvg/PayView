CREATE FUNCTION       B_F_DISABILITY_MRAK_OPINION RETURN BOOLEAN IS
/***************************************************************************************
// Функция: F_Disability_MRAK_Opinion
// Наименование: Функция определения наличия у лица заключения МРЭК
// Автор: Холодова
// Состояние на дату 05.04.1999
// Код возврата: True - заключение имеется, False - заключение не имеется
//***************************************************************************************/
CN_MRAK number default 0;
BEGIN
  Select COUNT(*) into CN_MRAK
                    From W$MRAK_OPINION_ADVICE
                    Where PID = XLPL.GETPID and
					      OPINION_TYPE = 2 and
					      STAGE NOT IN(2,3) and
					      CLOSE_DATE IS NULL and
                          ENTERED_BY = XLPL.USER_ID and
                         (RECORD_START <= XLPL.WorkDate and NVL(DIS_TERM, XLPL.WorkDate) >= XLPL.WorkDate);
  if CN_MRAK = 0
    then Return false;
	else Return true;
  end if;

END B_F_DISABILITY_MRAK_OPINION;
/
