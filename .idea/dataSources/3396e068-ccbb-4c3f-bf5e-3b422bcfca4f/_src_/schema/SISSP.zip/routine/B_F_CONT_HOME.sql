CREATE FUNCTION       B_F_Cont_Home(AORGANISATION_TYPE in NUMBER) return BOOLEAN is
/*==============================================================================
почти безымянный оригинал:
Функция определяет, принадлежит ли адрес ДИ, ИТУ
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 12.07.2002
==============================================================================*/
  vsCOUNT number;
begin
  begin
    SELECT CODE into vsCOUNT from org_types
    where code in
	  (SELECT min(t.code)
	   FROM ORG_TYPES t
       CONNECT BY PRIOR t.parent_code = t.code
       START WITH code = (select org_type from organizations
                          where code = (select distinct a.code_establishment from W$address a --РАВ 03.02.2017 distinct
						                where a.pid = XLPL.GetPID
	                                      and a.STAGE in (1, 4, 6)
						                  and a.ENTERED_BY = XLPL.User_ID
                                          and  NVL(a.RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
                                          and  NVL(a.RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate)));
  exception
 	when NO_DATA_FOUND then
	  return FALSE;
  end;

  if (vsCOUNT = AORGANISATION_TYPE) then
    return TRUE;
  else
    return FALSE;
  end if;
end;
/
