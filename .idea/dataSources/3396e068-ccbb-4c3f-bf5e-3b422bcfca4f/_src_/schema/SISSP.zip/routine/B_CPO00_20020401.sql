CREATE FUNCTION       B_CPO00_20020401 RETURN NUMBER AS

/***************************************************************************************
 Функция: B_CPO00_20020401
 Наименование: Функция расчета размера надбавки к пособию одинокой матери
 Автор: Ворошилин В.
 Состояние на дату 05.02.1999
 Код возврата: число с плавающей точкой с суммой надбавки
***************************************************************************************/

  BDate DATE;
  Dtt DATE;

BEGIN
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CHECKROLE(56) then
	return 0;
  end if;
  XLPL.REPLACEROLE('Child');
  -- 424 - Размер надбавки к пособию одинокой матери - в процентах от установленного размера пособия
  -- 499 - Размер надбавки к пособию одинокой матери на ребенка до 1,5 лет - в процентах от установленного размера пособия
  BDate := A_F_RelProtBIRTHDAY;
  Dtt :=  B_AddYearsMonths(BDate, S_Const(409, XLPL.WorkDate));
  if (XLPL.WorkDate < Dtt) then
    XLPL.RESTOREROLE;
    return (XLPL.GetGlobalFloat('Amount1') * S_Const(499, XLPL.WorkDate) / 100);
  else
    XLPL.RESTOREROLE;
    return (XLPL.GetGlobalFloat('Amount1') * S_Const(424, XLPL.WorkDate) / 100);
  end if;

  /* */
END B_CPO00_20020401;
/
