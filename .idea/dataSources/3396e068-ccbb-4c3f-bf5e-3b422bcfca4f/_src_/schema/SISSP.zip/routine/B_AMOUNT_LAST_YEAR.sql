CREATE FUNCTION       B_Amount_Last_Year(APERIOD_START in date, APERIOD_END in date) return NUMBER is
/*---------------------------------------------------------------------------
// Amount_Last_Year
// Функция определяет выплаченные суммы пособий до 3 лет и старше 3 лет
// с надбавками и индексацией по делу за указанный период
// (без единовременных пособий, без пособий по уходу за ребенком-инвалидом и
// без пособий больным СПИД)
//-------------------------------------------------------------------------*/
  AAmount number := 0;
begin
  SELECT ROUND(NVL(SUM(e.PERIOD_AMOUNT * (LEAST(NVL(APERIOD_END,PERIOD_END), PERIOD_END) -
    GREATEST (NVL(APERIOD_START, PERIOD_START), PERIOD_START) + 1)/
	(PERIOD_END - PERIOD_START + 1)),0)  * 100) * 0.01 into AAmount
  FROM CALC_AMOUNT e, RESULT_PAYMENT f
  WHERE e.MONTH_AMOUNT > 0
    and e.STAGE IS NULL
	AND (e.ALLOC_CODE between 421 and 489 OR e.ALLOC_CODE between 501 and 529)
	AND (((((PERIOD_START >= NVL(APERIOD_START, PERIOD_START))
	AND (PERIOD_START <= NVL(APERIOD_END, PERIOD_END)))
	OR ((PERIOD_END <= NVL(APERIOD_END, PERIOD_END))
	AND (PERIOD_END >= NVL(APERIOD_START, PERIOD_START)))))
	OR ((PERIOD_START <= APERIOD_START)AND(PERIOD_END >= APERIOD_END)))
	AND f.STAGE IS NULL AND f.RID = e.RESULT_PAYMENT_RID AND e.CID = XLPL.CID;

  return AAmount;
end;
/
