CREATE FUNCTION       A_Sroc (pr IN CHAR,rcid IN NUMBER,rentered_by IN NUMBER)RETURN char IS
-- функция выбора срока действия назначения для протоколов решения
--Якимова С.А. 03.11.2010
stroka varchar2(100);
kol number;
begin
kol:=0;
-- срок назначения НАЗНАЧИТЬ
if pr= '1' then
	 SELECT  COUNT(*) into kol from W$ALLOC_DATE_ESTIMATION D where
			 D.CID =rcid  and D.STAGE =4 and D.ENTERED_BY=rENTERED_BY and   D.CHANGE_ALLOC_STATUS in (1,2)
			 AND d.STAGE in (1,4)
			 AND D.PARENT_AID IS NULL and d.STATUS_REASON not in (103,109)
			 AND D.ALLOC_CODE=(SELECT distinct a.ALLOC_CODE
			 FROM W$ALLOCATION a
			 WHERE a.CID =rCID AND a.STAGE =4
			 and    a.COMP_PART is null and
			 a.PARENT_RID IS NULL AND
			 a.STEP_END IS   NULL and
			 a.ALLOC_STATUS =1 AND
			 a.ENTERED_BY =rENTERED_BY);

IF KOL=0 THEN Stroka:='    на срок: пожизненно';
else
SELECT distinct '    на срок: '||  to_char(min(D.ESTIMATION_DATE),'DD.MM.YYYY')  into stroka from W$ALLOC_DATE_ESTIMATION D where
			 D.CID =rcid  and D.STAGE =4 and D.ENTERED_BY=rENTERED_BY and   D.CHANGE_ALLOC_STATUS in (1,2)
			 AND d.STAGE in (1,4)
			 AND D.PARENT_AID IS NULL and d.STATUS_REASON not in (103,109)
			 AND D.ALLOC_CODE=(SELECT distinct a.ALLOC_CODE
			 FROM W$ALLOCATION a
			 WHERE a.CID =rCID AND a.STAGE =4
			 and    a.COMP_PART is null and
			 a.PARENT_RID IS NULL AND
			 a.STEP_END IS   NULL and
			 a.ALLOC_STATUS =1 AND
			 a.ENTERED_BY =rENTERED_BY);
end if;
-- назначение не первое - срок первичного назначения
else
/*
  SELECT  COUNT(*) into kol   from W$ALLOC_DATE_ESTIMATION D  where
   D.CID =rcid  and D.STAGE =2 and D.ENTERED_BY=rENTERED_BY and   D.CHANGE_ALLOC_STATUS=1 AND D.PARENT_AID IS NULL
and d.STATUS_REASON not in (103,109)
AND D.ALLOC_CODE=(SELECT distinct a.ALLOC_CODE
FROM W$ALLOCATION a
WHERE a.CID =rCID
 AND   a.COMP_PART  is null and
a.PARENT_RID IS NULL AND
a.STEP_END IS  not NULL and a.amount <>0
AND a.ENTERED_BY =rENTERED_BY
AND a.step_start=(select distinct b.step_start from W$ALLOCATION b
WHERE b.CID =rCID AND   COMP_PART IS NULL
AND PARENT_RID IS NULL
AND STEP_END IS NOT NULL
 AND b.amount <>0 and  b.ALLOC_STATUS=1  and
b.ENTERED_BY =rENTERED_BY));

  IF KOL=0 THEN Stroka:='    на срок: пожизненно';
  else

	 select  '    на срок: ' || to_char(min(D.ESTIMATION_DATE), 'dd.mm.yyyy') into stroka from W$ALLOC_DATE_ESTIMATION D  where
   D.CID =rcid  and D.STAGE =2 and D.ENTERED_BY=rENTERED_BY and   D.CHANGE_ALLOC_STATUS=1 AND D.PARENT_AID IS NULL
and d.STATUS_REASON not in (103,109)
AND D.ALLOC_CODE=(SELECT distinct a.ALLOC_CODE
FROM W$ALLOCATION a WHERE a.CID =rCID
AND   a.COMP_PART  is null and
a.PARENT_RID IS NULL AND
a.STEP_END IS  not NULL and a.amount <>0
AND a.ENTERED_BY =rENTERED_BY
AND a.step_start=(select distinct b.step_start from W$ALLOCATION b
WHERE b.CID =rCID AND   COMP_PART IS NULL
AND PARENT_RID IS NULL
AND STEP_END IS NOT NULL
 AND b.amount <>0 and  b.ALLOC_STATUS=1  and
b.ENTERED_BY =rENTERED_BY));
end if;
*/
 Stroka:='';
end if;
RETURN stroka;
END;
/
