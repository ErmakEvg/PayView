CREATE FUNCTION       A_F_RelProtDeathDate RETURN DATE IS
/*возвращает дату смерти человека согласно W$RELATION_PROTOCOL
Вахромин О.Ю.*/
vsDRID NUMBER;
vDeathDate DATE;
BEGIN
   vDeathDate:=NULL;
   vsDRID:=A_F_RelProtGetRIDPerson(1);

   --RAISE_APPLICATION_ERROR(-20801,' A_F_RelProtDeathDate  XLPL.GetPid='||XLPL.GetPid );

   if vsDRID<>-1 then
      begin
         select DEATH_DATE into vDeathDate from PERSON where RID=vsDRID and
            DEATH_DATE<=XLPL.Workdate;
      exception
         when OTHERS then
            vDeathDate:=NULL;
      end;
   else
      vsDRID:=A_F_RelProtGetRIDPerson (0);
   --RAISE_APPLICATION_ERROR(-20801,' A_F_RelProtDeathDate  XLPL.GetPid='||XLPL.GetPid );
      if vsDRID<>-1 then
         begin
            select DEATH_DATE into vDeathDate from W$PERSON where RID=vsDRID and
               ENTERED_BY=XLPL.User_ID and DEATH_DATE<=XLPL.Workdate;
         exception
            when OTHERS then
               vDeathDate:=NULL;
         end;
      else
         RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtDeathDate:'||chr(10)||
            'Нет DATA_RID в W$RELATION_PROTOCOL для данных CID='||to_char(XLPL.CID));
      end if;
   end if;
   return vDeathDate;
END A_F_RelProtDeathDate;
/
