CREATE FUNCTION       A_F_CHECKAIDESTIMATION(AALLOC_CODE in number) RETURN boolean IS
/* Проверяет наличие прогнозируемых дат изменения назначений в деле*/
cnt1 number;
vsCID varchar2(20);
vsAID number;
araids DBMS_SQL.NUMBER_TABLE;
i number;
wAID number;

BEGIN
  i := 0;
  vsCID := XLPL.CID;
  vsAID := XLPL.AID;
  FOR C1 IN(select distinct(nvl(AID, -1)) as aid from W$ALLOCATION
	 where CID = vsCID and
	       ENTERED_BY = XLPL.USER_ID and
		   STAGE in (1,4) and
		   ALLOC_CODE = AALLOC_CODE and
		   STEP_START <= XLPL.WORKDATE and
		   NVL(STEP_END, XLPL.WORKDATE) >= XLPL.WORKDATE) LOOP
    araids(araids.Count + 1) := C1.AID;
  end loop;

  if araids.Count > 0 then
    for i IN 1 .. araids.Count LOOP
	  if vsAID <> araids(i) then
		wAID := araids(i);
		select count (*) into cnt1 from W$ALLOC_DATE_ESTIMATION
	        where CID = vsCID and
			  	  ENTERED_BY = XLPL.USER_ID and
			  	  STAGE in (1,4) and
			  	  ALLOC_CODE = AALLOC_CODE and
				  AID = wAID and
			  	  ESTIMATION_DATE <= XLPL.WORKDATE;
		if cnt1 > 0 then
		  return true;
	    end if;
	  end if;
	end loop;
  end if;
  return false;
END A_F_CHECKAIDESTIMATION;
/
