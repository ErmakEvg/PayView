CREATE FUNCTION       B_F_AgeCheck RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_AgeCheck
// состояние на 10.02.2002
// Наименование: Функция проверки возраста лица на дату подачи заявления
//***************************************************************************************/

  Dt DATE;
  BDate DATE;
BEGIN
  BDate := B_F_RelProtBIRTHDAYNULL;
  if BDate is NULL then
    return false;
  end if;
  Dt :=  A_F_DataTalk;
  if S_Age(XLPL.Base_ID, XLPL.GetPid, Dt) <= S_Const(401, Dt) then
    return true;
  else
    return false;
  end if;
END B_F_AgeCheck;
/
