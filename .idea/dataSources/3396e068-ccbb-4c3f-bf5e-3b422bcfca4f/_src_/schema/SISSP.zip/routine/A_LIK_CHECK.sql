CREATE FUNCTION       A_LIK_CHECK(LIK IN VARCHAR2) RETURN VARCHAR2 IS
/******************************************************************************
 Функция           :  A_LIK_CHECK
 Наименование      :  Ф-я проверки идентификационного номера
 Автор             : Мушаликов А. Л.
 Состояние на дату : 20.04.2016
 Код возврата      : признак проверки
*******************************************************************************/
i number;
koef number; --весовой коэффициент
summ number;  --контрольная сумма
s1 char;

BEGIN

  summ := 0;

  -- количество символов
   if  length(LIK) <> 14 then RETURN  'Ошибка в идентификационном номере. Неверная длина';
   end if;

   -- пол и век рождения
   s1 := substr(LIK, 1, 1);
    if  s1 not in ('1','2','3','4','5','6','7') then  RETURN  'Ошибка в идентификационном номере. Ошибочный символ в позиции 1.';
    end if;

  -- дата рождения
  for i  IN 2..7
  LOOP
     if  substr(LIK, i, 1) not in ('1','2','3','4','5','6','7','8','9','0') then
        if s1 <> '7' then
             RETURN 'Ошибка в идентификационном номере. Ошибочный символ в дате рождения (позиции 2-7).';
        else
             RETURN 'Ошибка в идентификационном номере. Ошибочный символ в позициях 2-7.';
        end if;
     end if;

    END LOOP;

    -- код области

       if  ((substr(LIK, 8, 1) not in ('A', 'B', 'C', 'H', 'K', 'E', 'M')) and (s1 <> '7'))  then  RETURN 'Ошибка в идентификационном номере. Ошибочный символ в коде области (позиция 8).';
       elsif ((substr(LIK, 8, 1) <> 'A') and (s1 = '7 ')) then RETURN 'Ошибка в идентификационном номере. Ошибочный символ в позиции 8.';
       end if;


    --порядковый номер гражданина, родившегося в данный день и получавшего паспорт в данной области
  for i  IN 9..11  LOOP
     if  ((substr(LIK, i, 1) not in ('1','2','3','4','5','6','7','8','9','0', 'A', 'B', 'C', 'D', 'E', 'F')) and  (s1 <> '7'))  then
          RETURN   'Ошибка в идентификационном номере. Ошибочный символ в порядковом номере (позиции 9-11).';
     elsif ((substr(LIK, i, 1) not in ('1','2','3','4','5','6','7','8','9','0')) and (s1 = '7 ')) then RETURN 'Ошибка в идентификационном номере. Ошибочный символ в позициях 9-11.';
     end if;
  END LOOP;

   --признак гражданства
  if  ((substr(LIK, 12,  2) not in ('PB', 'GB', 'VF', 'VA')) and  (s1 <> '7')) then
           RETURN  'Ошибка в идентификационном номере. Ошибочный символ в признаке гражданства (позиция 12-13).';
  elsif ((substr(LIK, 12,  2) <> 'PB') and (s1 = '7 ')) then
           RETURN 'Ошибка в идентификационном номере. Ошибочный символ в позиции 12-13.';
  end if;


  -- контрольная сумма
  if  substr(LIK, 14, 1) not in ('1','2','3','4','5','6','7','8','9','0') then  RETURN  'Ошибка в идентификационном номере. Ошибочный символ в контрольной сумме (позиция 14).';
  end if;

    for i  IN 1..13  LOOP

    koef := 7; -- для 1, 4, 7, 10, 13 символов

         if i in (1, 4, 7, 10, 13) then
          BEGIN
               if  (ASCII(substr(LIK, i, 1)) >= ASCII('A')) and  (ASCII(substr(LIK, i, 1)) <= ASCII('Z')) then
                    summ := summ + (ASCII(substr(LIK, i, 1)) - 55) * koef;
                elsif   (ASCII(substr(LIK, i, 1)) >= ASCII('0')) and  (ASCII(substr(LIK, i, 1)) <= ASCII('9')) then
                    summ := summ + to_number(substr(LIK, i, 1)) * koef;
                end if;
         END;
        end if;

    koef := 3; -- для 2, 5, 8, 11 символов

        if i in (2, 5, 8, 11) then
          BEGIN
               if  (ASCII(substr(LIK, i, 1)) >= ASCII('A')) and  (ASCII(substr(LIK, i, 1)) <= ASCII('Z')) then
                    summ := summ + (ASCII(substr(LIK, i, 1)) - 55) * koef;
                elsif   (ASCII(substr(LIK, i, 1)) >= ASCII('0')) and  (ASCII(substr(LIK, i, 1)) <= ASCII('9')) then
                    summ := summ + to_number(substr(LIK, i, 1)) * koef;
                end if;
         END;
        end if;

     koef := 1; -- для 3, 6, 9, 12 символов

        if i in (3, 6, 9, 12) then
          BEGIN
               if  (ASCII(substr(LIK, i, 1)) >= ASCII('A')) and  (ASCII(substr(LIK, i, 1)) <= ASCII('Z')) then
                    summ := summ + (ASCII(substr(LIK, i, 1)) - 55);
                elsif   (ASCII(substr(LIK, i, 1)) >= ASCII('0')) and  (ASCII(substr(LIK, i, 1)) <= ASCII('9')) then
                    summ := summ + to_number(substr(LIK, i, 1));
                end if;
         END;
        end if;
     END LOOP;

   if (to_number(substr(LIK, 14, 1))) <> (summ mod 10) then RETURN 'Ошибка в идентификационном номере. Ошибочный символ в контрольной сумме (позиция 14).';
   end if;

RETURN 0;
END A_LIK_CHECK;
/
