CREATE FUNCTION       A_F_Relprotratio RETURN NUMBER AS
/*Возращает 'ИНДИВИДУАЛЬНЫЙ КОЭФФИЦИЕНТ ЗАРАБОТКА'  человека согласно W$RELATION_PROTOCOL
из W$PERSON_EXTRA или PERSON_EXTRA
Автор: Боровнева Н.В.*/
vsDRID NUMBER;
vsRATIO NUMBER;
BEGIN

vsRATIO := -1;

vsDRID := A_F_Relprotgetridpersonextra(1);

BEGIN


  IF vsDRID <> -1 THEN
     SELECT INDIVIDUAL_RATIO INTO vsRATIO FROM PERSON_EXTRA WHERE RID = vsDRID;
  ELSE
    BEGIN

      vsDRID := A_F_Relprotgetridpersonextra(0);


      IF vsDRID <> -1  THEN SELECT INDIVIDUAL_RATIO INTO vsRATIO FROM W$PERSON_EXTRA
                                WHERE RID = vsDRID AND ENTERED_BY = Xlpl.USER_ID;
      END IF;
    END;
  END IF;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      vsRATIO:=-1;
END;
 IF vsRATIO=-1 THEN vsRATIO:=0; END IF;   -- OLV 14122008
RETURN vsRATIO;
END A_F_Relprotratio;
/
