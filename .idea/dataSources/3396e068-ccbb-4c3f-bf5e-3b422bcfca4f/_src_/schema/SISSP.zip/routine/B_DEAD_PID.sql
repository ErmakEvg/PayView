CREATE FUNCTION       B_DEAD_PID(ACID  NUMBER) RETURN  NUMBER AS
/*******************************************************************************
 Наименование :  B_DEAD_PID
 Описание     :  Функция возвращает PID УМЕРШЕГО ДЛЯ ПОЛУЧЕНИЯ НЕВЫПЛАЧЕННЫХ
                 СУММ (ПЕНСИИ ИЛИ ПОСОБИЯ) НАСЛЕДНИКАМ
 Параметр      : ACID - идентификатор дела
 Автор         :  Иванова Т.С.
 Состояние на дату   13.09.2018
 Код возврата  : PID или 0, если не нашли
********************************************************************************/
  PPID       NUMBER;
  PCATEGORY  NUMBER;
  countpid NUMBER;
 BEGIN
 SELECT ACCESS_DATA INTO PCATEGORY FROM ID_CASE WHERE CID=ACID ;-- выбор категории дела
 --поиск PID  в зависимости от категории дела
  IF PCATEGORY=2 THEN -- пособие
   select count(CP.pid) into countpid from  CASE_PERSON CP,CASE C,RECIPIENT R
        WHERE C.CID=ACID  AND Cp.CID=ACID  AND R.CID=ACID
         AND C.STAGE IS NULL AND R.STAGE IS NULL AND CP.STAGE IS NULL
         AND C.CASE_STATUS=3 -- дело закрыто
         AND CP.ROLE IN (52,55,57,59,77,94,96)
         and cp.pid=r.pid;--роли в пособиях для получателей
   IF countpid<>1 then PPID:=0; ELSE
     SELECT  PID into PPID  FROM PERSON P
      WHERE P.PID IN
      (SELECT CP.PID FROM  CASE_PERSON CP,CASE C,RECIPIENT R
        WHERE C.CID=ACID  AND Cp.CID=ACID  AND R.CID=ACID
         AND C.STAGE IS NULL AND R.STAGE IS NULL AND CP.STAGE IS NULL
         AND C.CASE_STATUS=3 -- дело закрыто
         AND CP.ROLE IN (52,55,57,59,77,94,96)--роли в пособиях для получателей
         and cp.pid=r.pid
       )
      AND P.STAGE IS NULL
      AND P.DEATH_DATE IS NOT NULL;--есть дата смерти
      end if;
      RETURN PPID;
     end if;
    IF  PCATEGORY=1 THEN -- пенсия
      SELECT  PID into PPID FROM PERSON P -- PID пенсионера
       WHERE P.PID IN
       (SELECT AP.PID from allocation a, allocation_person ap
         WHERE a.CID=ACID  AND a.rid=ap.allocation_rid
          AND A.ALLOC_STATUS=3 -- назначение закрыто
          AND A.STAGE IS NULL  AND Ap.STAGE is null  AND A.step_end IS NULL
          AND A.parent_rid IS NULL AND A.comp_part IS NULL --выбираем только основное назначение
          AND ap.ROLE IN (51,53)-- роли для пенсионера
        )
       AND P.STAGE IS NULL
       AND P.DEATH_DATE IS NOT NULL ;-- есть дата смерти
       RETURN PPID;
     end if;

 EXCEPTION
      WHEN NO_DATA_FOUND THEN
      PPID:=0; RETURN PPID;
  END;
/
