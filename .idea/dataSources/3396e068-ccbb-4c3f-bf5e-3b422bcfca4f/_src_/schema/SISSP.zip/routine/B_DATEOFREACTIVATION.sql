CREATE FUNCTION       B_DateOfReactivation(aCID in NUMBER, aAlloc_Code in NUMBER, aAID in NUMBER) RETURN DATE IS
/*******************************************************************************
 NAME          : B_DateOfReactivation
 Назначение    : Интерфейсная функция определения даты возобновления назначения
 Автор         : Ворошилин В.    Комментарии и корректировка:  ОЛВ
 Дата          : 27.10.1999                         24.02.2011 19.05.2015
 Код возврата  : дата возобновления назначения
********************************************************************************/
 Date_talk           DATE;
 Date_Alloc_Restore  DATE;
BEGIN
 -- Выбираем дату обращения за назначением
 -----------------------------------------
 BEGIN
    SELECT CHECK_DATE
	  into  Date_talk
	  from  W$CASE_CHECKS
	 where CID = aCID
	   and ENTERED_BY = XLPL.USER_ID;
 exception
    when No_Data_Found then
	     Date_talk:= NULL;
 end;
 if Date_talk is  NULL then
	return Date_talk;
 end if;


 -- Выбираем дату начала шага приостановленного или закрытого назначения
 -----------------------------------------------------------------------
 BEGIN
    SELECT step_start
	  into Date_Alloc_Restore
      from W$ALLOCATION
	 where cid = Acid
	   and aid = Aaid
	   and alloc_code = aAlloc_Code
	   and parent_rid is null
	   and alloc_status in (2, 3)
       and stage in (1,4) -- 19.05.2015 OLV
	   and step_start <= Date_talk
	   and (step_end >= Date_talk or step_end is null);
 exception
    when No_Data_Found then
	  Date_Alloc_Restore := NULL;
 end;

 -- Выбираем дату возобновления назначения для пенсий по инвалидности и СПК и Досрочной выплаты семейного капитала
 Date_Alloc_Restore:=P_DATEALLOC_RESTORE(aCID, aAlloc_Code, aAID, Date_Alloc_Restore, Date_talk);
 -- Предварительная дата для проверки права
 return Date_Alloc_Restore;

--raise_application_error(-20004,'B_DateOfReactivation 4    '||CHR(10)||'  Date_talk='||Date_talk||'   Date_FromInv='||Date_FromInv||'   Date_Alloc_Restor='||Date_Alloc_Restore);
END B_DateOfReactivation;
/
