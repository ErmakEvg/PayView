CREATE FUNCTION       A_F_ArrivedCase_Date RETURN Date IS
/******************************************************************************
 NAME         : A_F_AllocPrib
 Назначение   : Функция получения даты первоначального назначения прибывшего дела
 Автор        : ОЛВ
 Дата         :	20.01.2011
 Код возврата : Дата первоначального назначения прибывшего дела
******************************************************************************/
 DATE_PN      Date;  -- дата первоначального назначения

BEGIN
   BEGIN
     select DATE_PERV_NAZN
	   into DATE_PN
	   from W$APPLICATION
	  where CID=XLPL.CID
	    and STAGE in (2, 4)
        and PR_PRIB is not null;

   EXCEPTION
     when NO_DATA_FOUND or TOO_MANY_ROWS then
              DATE_PN:=XLPL.WorkDate;
   END;
 return DATE_PN;
END A_F_ArrivedCase_Date;
/
