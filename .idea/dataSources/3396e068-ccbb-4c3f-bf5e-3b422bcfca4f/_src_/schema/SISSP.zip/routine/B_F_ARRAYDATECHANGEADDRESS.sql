CREATE FUNCTION       B_F_ARRAYDATECHANGEADDRESS(PuskDate in date, Param6m in number ) RETURN DBMS_SQL.NUMBER_TABLE IS

/*==============================================================================
+ Функция: F_ArrayDateChangePERSON
+ Наименование: Функция возвращает массив дат изменения общей информации о лице
+ Автор: Трухтанов
+ Состояние на дату 25.08.1999
==============================================================================*/
chahge_date_aRecord DBMS_SQL.NUMBER_TABLE;
DateTalk date;
DateTalk1 date;

BEGIN

  DateTalk := A_F_DataTalk();
    DateTalk1 := Last_Day(S_CurrDate);
--  select Last_Day(sysdate) into DateTalk1 from dual;

  for Rec in (select nvl(RECORD_START, null) as dat_start, nvl(RECORD_END, null) as dat_end
  	   from W$ADDRESS
   	   where PID = XLPL.GETPID AND
       (RECORD_START > PuskDate OR RECORD_END > PuskDate OR (RECORD_START > PuskDate and RECORD_END is NULL)) AND
       STAGE in (1, 4) and
       ENTERED_BY =  XLPL.USER_ID) LOOP

	if (REC.dat_start is not null) AND
	   (REC.dat_start > PuskDate) AND
	   (REC.dat_start <= DateTalk1) then
      if  (Param6m = 1) AND (XLPL.AID = 0)  			   	  	  	   	   			  	   				 -- Если превышено 6 месяцев со для возникновения права
          then chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), s_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		  else chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(Rec.Dat_start);
	  end if;
	end if;
	if (REC.dat_end is not null) AND
	   (REC.dat_end > PuskDate) AND
	   (REC.dat_end <= DateTalk1) then
      if  (Param6m = 1) AND (XLPL.AID = 0)  			   	  	  	   	   			  	   				 -- Если превышено 6 месяцев со для возникновения права
          then chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), s_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		  else chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(Rec.dat_start);
	  end if;
	end if;
  end loop;
return A_F_ArrayDataChangeDelDup(chahge_date_aRecord);
END B_F_ARRAYDATECHANGEADDRESS;
/
