CREATE FUNCTION       B_DATEOFDEATHACTIVATION (aCID in NUMBER, aAID in NUMBER) RETURN DATE IS
/***************************************************************************************
 Назначение: B_DATEOFDEATHACTIVATION
 Наименование: Функция определения даты закрытия пенсии для умершего лица
 Автор: Ворошилин В.
 Состояние на дату 20.03.2001
 Коды возврата: дата закрытия пенсии
***************************************************************************************/
pp DATE;
wDate DATE;
BEGIN
pp := NULL;
xlpl.cid:=acid;
begin
    SELECT CHECK_DATE
	into  wDate
	from  W$CASE_CHECKS
	where CID = aCID and
	      ENTERED_BY = XLPL.USER_ID;
exception
    when OTHERS then
		 wDate := NULL;
         end;
if wDate is not NULL then
   begin
    SELECT p.DEATH_DATE
	into pp
	FROM  W$ALLOCATION a,
          W$PERSON p,
    	  W$ALLOCATION_PERSON c,
    	  ALLOCATION_ROLE_GROUP g,
    	  REF_ALLOCATION_ROLE e
	WHERE a.CID = aCID AND
		  a.AID = aAID and
       	  a.PARENT_RID IS NULL AND
    	  a.COMP_PART IS NULL AND
		  a.STEP_START <= wDate AND
		 (a.STEP_END >= wDate OR a.STEP_END IS NULL) AND
    	  c.ALLOCATION_RID = a.RID AND
    	  a.STAGE in (1, 4) AND
    	  c.STAGE = a.STAGE AND
		  p.STAGE in (1, 4) AND
    	  c.ROLE = g.CODE AND
    	  g.FEATURE = 1 AND
    	  c.PID = p.PID AND
    	  a.ENTERED_BY = XLPL.User_Id AND
    	  p.ENTERED_BY = a.ENTERED_BY AND
    	  c.ENTERED_BY = a.ENTERED_BY AND
    	  e.CODE = c.ROLE;
exception
    when OTHERS then
		 pp := NULL;
end;
end if;

if B_F_Category = 1 and pp is not NULL then
   return Last_Day(pp)+1;
else
   return pp;
end if;

return pp;

END B_DATEOFDEATHACTIVATION;
/
