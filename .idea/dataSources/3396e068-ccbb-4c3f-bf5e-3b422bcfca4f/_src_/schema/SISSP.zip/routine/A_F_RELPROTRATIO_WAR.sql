CREATE FUNCTION       A_F_Relprotratio_War RETURN NUMBER AS
/***************************************************************************************
 Функция            : A_F_Relprotratio_War
 Наименование       : Функция возращает ИНДИВИДУАЛЬНЫЙ КОЭФФИЦИЕНТ ЗАРАБОТКА по З. о в/с
 					  согласно W$RELATION_PROTOCOL
                      из W$PERSON_EXTRA или PERSON_EXTRA
 Автор              : ОЛВ                                  На основ. Боровнева
 Состояние на дату  : 03.08.2011
 Код возврата       : число с плавающей точкой
***************************************************************************************/
 vsDRID   NUMBER;
 vsRATIO  NUMBER;
BEGIN

 vsRATIO := 0;

/*  -- заготовка для получения альтернативного коэфф. по З. о в/сл */

 -- RID из W$RELATION_PROTOCOL для PERSON_EXTRA
 ------------------------------------------------------
 vsDRID := A_F_Relprotgetridpersonextra(1);

 BEGIN
   IF vsDRID <> -1 THEN
      SELECT NVL(INDIVIDUAL_RATIO_WAR,0) INTO vsRATIO FROM PERSON_EXTRA
	   WHERE RID = vsDRID;
   ELSE
     BEGIN
 	 	 -- RID из W$RELATION_PROTOCOL для W$PERSON_EXTRA
 	 	 ------------------------------------------------------
         vsDRID := A_F_Relprotgetridpersonextra(0);
       IF vsDRID <> -1  THEN
	      SELECT NVL(INDIVIDUAL_RATIO_WAR,0) INTO vsRATIO FROM W$PERSON_EXTRA
           WHERE RID = vsDRID AND ENTERED_BY = Xlpl.USER_ID;
       END IF;
     END;
   END IF;
 EXCEPTION
   WHEN NO_DATA_FOUND THEN
      vsRATIO:=0;
 END;
 /* */
 RETURN vsRATIO;
END A_F_Relprotratio_War;
/
