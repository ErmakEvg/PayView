CREATE FUNCTION       A_F_ViplPeriod_Start  RETURN DATE IS
/**********************************************************************************************
 Функция                 : P_ViplPeriod_Start
 Наименование        : Функция получения даты  начала выплатного периода
 Автор                     : ОЛВ
 Состояние на дату  : 26.06.2013
 Код возврата          : Возвращает дату конца выплатного периода
***********************************************************************************************/
  Metric_Start DATE;
  Metric_End DATE;
BEGIN
   BEGIN
        SELECT NVL(RECORD_START, NULL),  NVL(RECORD_END, NULL)
	         INTO Metric_Start, Metric_End
           FROM W$PERSON_METRIC
        WHERE PID = Xlpl.GetPid
	          AND code=740 	-- 740 - Требуется ручная корректировка суммы назначения за текущий выплатной период
	    	  AND STAGE IN (1, 4)
		      AND ((NVL(RECORD_START, LAST_DAY(SYSDATE)) > LAST_DAY(SYSDATE)) AND (NVL(RECORD_END, LAST_DAY(SYSDATE)) >= LAST_DAY(SYSDATE)))
		      AND ((NVL(RECORD_START, LAST_DAY(SYSDATE)) < LAST_DAY( LAST_DAY(SYSDATE)+1)) AND (NVL(RECORD_END, LAST_DAY(SYSDATE)) < LAST_DAY( LAST_DAY(SYSDATE)+1)))
		      AND ENTERED_BY = Xlpl.User_ID;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         Metric_End:= NULL;
   END;

  IF Metric_End IS NULL THEN
     Metric_Start :=NULL;
  END IF;
    RETURN Metric_Start;
		--		   RAISE_APPLICATION_ERROR(-20801,'A_F_ViplPeriod_Start'||'  Metric_Start='||Metric_Start||'   XLPL.WorkDate='||  Xlpl.WorkDate);
END A_F_ViplPeriod_Start;
/
