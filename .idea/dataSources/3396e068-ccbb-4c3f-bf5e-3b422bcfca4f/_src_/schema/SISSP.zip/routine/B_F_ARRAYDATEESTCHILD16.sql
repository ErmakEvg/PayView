CREATE FUNCTION       B_F_Arraydateestchild16 RETURN DBMS_SQL.NUMBER_TABLE IS
/**********************************************************************************************
 Функция            : B_F_ARRAYDATEESTCHILD16
 Наименование       : Формирование дат Estimation для пособий на детей старше 3 лет
 Автор              : Ворошилин В.                  Корректировка и кмментарии : ОЛВ
 Состояние на дату  : 01.10.2002                                   20.03.2012  16.01.2013
 Код возврата       : возвращает массив дат Estimation
***********************************************************************************************/
 result_step_start    DBMS_SQL.NUMBER_TABLE;
 result_function      DBMS_SQL.NUMBER_TABLE;
 j                          NUMBER;
BEGIN
result_step_start.DELETE;
-- Массив из даты окончания года для пособий старше 3 лет
result_function.DELETE;
result_function := B_F_Arraydateestending;
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;

 result_function.DELETE;
 result_function := B_F_Arraydateestchilduxod;
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16   XLPL.GetPid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'**'||S_Jtod(result_step_start(1)));

-- Ограничение возраста для детей, обучающихся за собственный счет
result_function.DELETE;
result_function := B_F_Arraydateestchildovn;
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16   XLPL.GetPid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'**'||S_Jtod(result_step_start(1)));
result_function.DELETE;
result_function := B_F_Arraydateestchildinv;
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16   XLPL.GetPid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'**'||S_Jtod(result_step_start(1)));
result_function.DELETE;
result_function := B_F_Arraydateestchildaids;
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16   XLPL.GetPid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'**'||S_Jtod(result_step_start(1)));
result_function.DELETE;
result_function := B_F_Arraydateestchildnlearn;  -- Ограничение возраста для детей, нигде не обучающихся 18 лет
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16 Pid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'**'||S_Jtod(result_step_start(1)));
result_function.DELETE;
result_function := B_F_Arraydateestmetric;
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16   XLPL.GetPid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'**'||S_Jtod(result_step_start(1)));
result_function.DELETE;
result_function := B_F_Arraydateestactivity(2);
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16   XLPL.GetPid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'**'||S_Jtod(result_step_start(1)));


  -- Для детей инвалидов без предъявления дополнительных условий по учебе  - РАВ
  -- не было реализовано раньше, а в законе было
  IF  NOT  ( A_F_Relprotdisability(1, '14') AND A_F_Relprotdisabilityreason(-1, '', '4')) OR B_F_Relprotmetricben('320')  THEN  --ОЛВ 16.01.2012
result_function.DELETE;
result_function := B_F_Arraydateestactivityschool;  --возвращает массив дат окончания учебного года для учащихся
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
  END IF;

--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16   XLPL.GetPid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'**'||S_Jtod(result_step_start(1)));
result_function.DELETE;
result_function := B_F_Arraydateestmrakopadvice(1, 14);
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16 Pid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'*'||S_Jtod(result_step_start(1))||'**'||S_Jtod(result_step_start(4)));
result_function.DELETE;
result_function := B_F_Arraydateestmrakopadvice(2, 21);
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16 Pid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'*'||S_Jtod(result_step_start(1))||'**'||S_Jtod(result_step_start(4)));
result_function.DELETE;
result_function := B_F_Arraydateestaddress;
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16 Pid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'*'||S_Jtod(result_step_start(1))||'**'||S_Jtod(result_step_start(4)));
result_function.DELETE;
result_function := B_F_Arraydateestaddressabsent;
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16 Pid='||XLPL.GetPid ||' result_function(1)='||S_Jtod(result_function(1))||'*'||S_Jtod(result_step_start(1))||'**'||S_Jtod(result_step_start(4)));
result_function.DELETE;
result_function := B_F_Arraydateestbirthdeath;
IF result_function.COUNT > 0 THEN
     FOR j IN 1 .. result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT + 1) := result_function(j);
     END LOOP;
END IF;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTCHILD16 Pid='||XLPL.GetPid ||' result_step_start.count='||result_step_start.count||'*'||S_Jtod(result_step_start(1))||'**'||S_Jtod(result_step_start(4)));
RETURN result_step_start;

END B_F_Arraydateestchild16;
/
