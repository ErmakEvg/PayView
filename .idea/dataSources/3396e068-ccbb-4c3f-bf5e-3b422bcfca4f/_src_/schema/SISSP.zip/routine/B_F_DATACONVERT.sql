CREATE FUNCTION       B_F_DATACONVERT(ADATA IN DATE) RETURN DATE AS

/****************************************************************************
// Автор: Басинюк Я.В.
// Состояние на 31.05.1999
// Код возврата: дата или NEVER если ADATA = F_CMinData
// ****************************************************************************/

BEGIN
  IF ADATA = A_F_CMINDATE THEN
    RETURN NULL;
  ELSE
    RETURN ADATA;
  END IF;
END B_F_DATACONVERT;
/
