CREATE FUNCTION       B_F_ARRAYDATECHANGEADDRESSAB(PuskDate IN DATE, Param6m IN NUMBER) RETURN DBMS_SQL.NUMBER_TABLE IS
/**********************************************************************************************
 Функция            : B_F_ARRAYDATECHANGEADDRESSAB
 Наименование       : Функция возвращает массив дат изменения адреса проживания/прописки
 Автор              : Трухтанов                   Корректировка: ОЛВ
 Состояние на дату  : 25.08.1999                                29.04.2011  15.11.2011
 Код возврата       : массив дат изменения адреса проживания/прописки
***********************************************************************************************/
 chahge_date_aRecord  DBMS_SQL.NUMBER_TABLE;
 aRID                 NUMBER;
 DateTalk             DATE;
 DateTalk1            DATE;

BEGIN
  -- получение даты обращения за назначением
  DateTalk := A_F_DataTalk();
  DateTalk1 := LAST_DAY(S_CurrDate);
--  select Last_Day(sysdate) into DateTalk1 from dual;

  FOR Rec IN (
  	  		 SELECT NVL(PERIOD_START, NULL) AS aRecord_start, NVL(PERIOD_END, NULL) AS aRecord_end
		 	 FROM W$ABSENCE_PERSON
             WHERE PID = XLPL.GETPID AND
			       ADDRESS_RID = (SELECT RID
  		 	 				       FROM W$ADDRESS
             				      WHERE PID = XLPL.GETPID
								    AND ADDRESS_TYPE IN (2,3) -- 29.04.2011 ОЛВ - если разные адр.прож. и рег. - была ошибка
								    AND STAGE IN (1, 4)       -- 15.11.2011 ОЛВ
                                    AND ENTERED_BY = XLPL.USER_ID)
					AND STAGE IN (1, 4)
					AND ENTERED_BY = XLPL.USER_ID  ) LOOP

	 IF (Rec.aRecord_start IS NOT NULL) AND (Rec.aRecord_start > PuskDate) AND (REc.aRecord_start <= DateTalk1) THEN
	    IF  (XLPL.AID = 0) AND (Param6m = 1) THEN
           -- Если превышено 6 месяцев со для возникновения права - то выбрать начало месяца подачи заявления
	       chahge_date_aRecord(chahge_date_aRecord.COUNT + 1) := s_julian(S_EncodeDate(S_YearOfDate(DateTalk), S_MonthOfDate(DateTalk), 1));

		 ELSE
		   chahge_date_aRecord(chahge_date_aRecord.COUNT + 1) := s_julian(REC.aRecord_start);
	     END IF;
	 END IF;
	 IF (Rec.aRecord_end IS NOT NULL) AND (Rec.aRecord_end > PuskDate) AND (Rec.aRecord_end <= DateTalk1) THEN
	    IF  (XLPL.AID = 0) AND (Param6m = 1) THEN
           -- Если превышено 6 месяцев со для возникновения права - то выбрать начало месяца подачи заявления
           chahge_date_aRecord(chahge_date_aRecord.COUNT + 1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), S_MonthOfDate(DateTalk), 1));
		  ELSE
		   chahge_date_aRecord(chahge_date_aRecord.COUNT + 1) := s_julian(rec.aRecord_end) + 1;
	    END IF;
     END IF;
  END LOOP;
RETURN A_F_ArrayDataChangeDelDup(chahge_date_aRecord);
END B_F_ARRAYDATECHANGEADDRESSAB;
/
