CREATE FUNCTION       A_F_RelProtAddress_Name(pADDRESS_TYPE in NUMBER,pLEVEL_CODE in NUMBER,pPARENT_CODE in VARCHAR, ppVALUE in VARCHAR) RETURN BOOLEAN IS
/***************************************************************************************
 NAME              : A_F_RelProtAddress
 Наименование      : Функция возвращает TRUE, если пенсионер проживает по указанному коду
 Автор             : ОЛВ
 Состояние на дату : 14.05.2011
 Код возврата      : TRUE или FALSE
***************************************************************************************/
 vsDRID     NUMBER;
 vsSite     NUMBER;
 pVALUE     varchar(10); -- ???? сколько ????
 pSITE      NUMBER;
BEGIN
 -- pADDRESS_TYPE - ТИП АДРЕСА; АДРЕС ПРОПИСКИ И/ИЛИ АДР. ПРОЖИВ. (1 - РЕГИСТР., 2 - ПРОЖИВ., 3 - ТО И  ДР.)
 -- ppVALUE       - наименование населенного пункта - города
 -- pSITE         - НАСЕЛЁННЫЙ ПУНКТ; СПРАВОЧНИК STATE_DIVISION
 pVALUE:=upper('%'||ppVALUE||'%'); --

   -- Выбрать адрес в ОБД RID из ADDRESS
     vsDRID:=A_F_RelProtGetRIDAddress(1,pADDRESS_TYPE);
 if vsDRID<>-1 then
      begin
         select SITE
		   into vsSITE
		   from ADDRESS
		  where RID=vsDRID
		    and ADDRESS_TYPE= pADDRESS_TYPE
			and SITE =
			   (SELECT CODE FROM STATE_DIVISION
			     WHERE upper(VALUE) LIKE pVALUE
				   AND (LEVEL_CODE=pLEVEL_CODE)
				   AND (  ((pPARENT_CODE=0) AND (PARENT_CODE is NULL))
				        OR ((pPARENT_CODE<>0) AND (PARENT_CODE =pPARENT_CODE)) )  );
      exception
         when NO_DATA_FOUND then
            vsSITE:=0;
      end;
 else
      -- Выбрать адрес в РБД RID из W$ADDRESS
        vsDRID:=A_F_RelProtGetRIDAddress(0,pADDRESS_TYPE);
    if vsDRID<>-1 then
      begin
         select SITE
		   into vsSITE
		   from W$ADDRESS
		  where RID=vsDRID
		    and ADDRESS_TYPE= pADDRESS_TYPE
			and SITE =
			   (SELECT CODE FROM STATE_DIVISION
			     WHERE upper(VALUE) LIKE pVALUE
				   AND (LEVEL_CODE=pLEVEL_CODE)
				   AND (  ((pPARENT_CODE=0) AND (PARENT_CODE is NULL))
				        OR ((pPARENT_CODE<>0) AND (PARENT_CODE =pPARENT_CODE)) )  );
	  exception
         when NO_DATA_FOUND then
            vsSITE:=0;
      end;
    else
       vsSITE:=0;
	end if;
 end if;
	   --   RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtAddress 11 vsSITE=' || vsSITE ||'  pVALUE='||pVALUE);

 if vsSITE=0 then
    RETURN FALSE;
 else
    RETURN TRUE;
 end if;
	      -- RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtAddress 11 pSITE=' || pSITE ||'  pVALUE='||pVALUE);
          --  RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtAddress 0   pSITE=' || pSITE ||'    xlpl.GetPid=' || xlpl.GetPid ||'  vsDRID='||vsDRID );
END A_F_RelProtAddress_Name;
/
