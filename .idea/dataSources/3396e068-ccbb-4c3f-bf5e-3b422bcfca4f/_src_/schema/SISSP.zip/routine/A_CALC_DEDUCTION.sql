CREATE FUNCTION       A_Calc_Deduction(ACID IN NUMBER,AAID IN NUMBER,pDate_Dop IN DATE, pAlloc_Code IN NUMBER)
   RETURN NUMBER IS
/******************************************************************************
 Функция           :  A_Calc_Deduction
 Наименование      :  Ф-я определения суммы удержания
 Автор             : ОЛВ
 Состояние на дату : 23.10.2013   18.06.2014   12.11.2014
 Код возврата      : сумма назначения
*******************************************************************************/
 Summa_DEDUCTION   NUMBER;
 pStart            DATE;
 pEnd              DATE;
BEGIN
    --Получить дату первого и последнего дня месяца
    pStart:=LAST_DAY(ADD_MONTHS(pDate_Dop,-1))+1;
    pEnd:=ADD_MONTHS(pStart, 1)-1;
    Summa_DEDUCTION := 0;
 BEGIN
   IF (Xlpl.INDIV <>2) THEN -- не массовый расчет --
     SELECT sum(a.amount_recipient) INTO Summa_DEDUCTION
       FROM W$DEDUCTION_CALC_AMOUNT a, W$RESULT_PAYMENT b, ALLOCATIONS al -- ,ALLOCATIONS al --18.06.2014 ОЛВ
      WHERE a.cid=ACID
        AND a.base_aid=AAID
        AND (a.aid=b.aid OR b.aid=0)
        AND a.stage IN (1,4)
        AND a.ENTERED_BY=Xlpl.USER_ID
        AND (a.Alloc_Code_Alloc=pAlloc_Code OR pAlloc_Code=0)
        AND al.code =  a.Alloc_Code--10.07--_Alloc -- 18.06.2014 ОЛВ
        and al.DEDUC_FLAG in (1,2)  --12.11.2014 OLV +2 АМВ -- 18.06.2014 ОЛВ со слов ЯТЛ
        AND b.rid=a.result_payment_rid
        AND (((pStart BETWEEN a.period_start AND a.period_end)
        AND (pEnd BETWEEN a.period_start AND a.period_end))
            OR (a.period_start BETWEEN pStart AND pEnd) OR (a.period_end BETWEEN pStart AND pEnd));
    ELSE
     SELECT SUM(a.amount_recipient) INTO Summa_DEDUCTION  -- SUM(nvl(a.amount_recipient,0)) INTO Summa_DEDUCTION
       FROM DEDUCTION_CALC_AMOUNT a, RESULT_PAYMENT b, ALLOCATIONS al -- ,ALLOCATIONS al --18.06.2014 ОЛВ
      WHERE a.cid=ACID
        AND a.base_aid=AAID
        AND (a.aid=b.aid OR b.aid=0)
        AND a.stage IS NULL
        AND (a.Alloc_Code_Alloc=pAlloc_Code OR pAlloc_Code=0)
        AND al.code =  a.Alloc_Code--10.07--_Alloc -- 18.06.2014 ОЛВ
        and al.DEDUC_FLAG in (1,2)  --12.11.2014 OLV +2 АМВ  -- 18.06.2014 ОЛВ со слов ЯТЛ
        AND b.rid=a.result_payment_rid
        AND (((pStart BETWEEN a.period_start AND a.period_end)
        AND (pEnd BETWEEN a.period_start AND a.period_end))
            OR (a.period_start BETWEEN pStart AND pEnd) OR (a.period_end BETWEEN pStart AND pEnd));
    END IF;
 EXCEPTION
        WHEN NO_DATA_FOUND THEN
            Summa_DEDUCTION := 0;
 END;
 /* */
 if Summa_DEDUCTION is null then
    Summa_DEDUCTION:=0;
 end if;/* */
RETURN  Summa_DEDUCTION;

--RAISE_APPLICATION_ERROR(-20801,'A_Calc_Deduction 2  Summa_DEDUCTION='||Summa_DEDUCTION||'  XLPL.Alloc_Code='|| XLPL.Alloc_Code);
END A_Calc_Deduction;
/
