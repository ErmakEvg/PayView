CREATE FUNCTION       B_F_Actv_Mul (S_LABOR IN NUMBER, E_LABOR IN NUMBER) RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_Actv_Mul
// Наименование: Функция определения факта работы, учебы, безработицы лица по интервалу кодов
// Автор: Гуз Е.
// Состояние на дату 28.01.1999
// Возвращает: True - если лицо активно, False - если лицо не активно
//***************************************************************************************/

  CN_ACTIVITY NUMBER;
BEGIN
  Select COUNT(*) INTO CN_ACTIVITY From W$ACTIVITY
  Where PID = XLPL.GetPid
    and (LABOR BETWEEN S_LABOR AND E_LABOR)
	and ENTERED_BY = XLPL.User_ID
	and STAGE NOT IN(2,3)
	and PERIOD_START <= XLPL.WorkDate
	and (PERIOD_END >= XLPL.WorkDate or PERIOD_END is null) ;
  return CN_ACTIVITY != 0;
END B_F_Actv_Mul;
/
