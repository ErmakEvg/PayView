CREATE FUNCTION       A_F_RelProtAge RETURN NUMBER IS
/*возраст человека  по данным из W$RELATION_PROTOCOL
Вахромин О.Ю.*/
BEGIN
   return S_YearsBetween(XLPL.WorkDate,A_F_RelProtBirthday());
END A_F_RelProtAge;
/
