CREATE FUNCTION       B_F_ActvEnd_DISMISSAL(ACID IN float) RETURN  date as r date;
/* Определение max дату увольнения лица по причине ликвидации предприятия, сокращения и др.*/
BEGIN
  r:= null;
  begin
  select max(PERIOD_END) into r
      from W$ACTIVITY
      where  ACTIVITY in (1, 2) and stage in (1,4)
      --and ENTERED_BY = XLPL.USER_ID
     -- and LABOR is NULL
      and DISMISSAL_REASON in (2,3,4,5,12)
      and PID in (Select PID from W$Case_person Where CID=ACID) ;

  exception
      when NO_DATA_FOUND then
       r:= null;
  end;
return r;
END B_F_ActvEnd_DISMISSAL;
/
