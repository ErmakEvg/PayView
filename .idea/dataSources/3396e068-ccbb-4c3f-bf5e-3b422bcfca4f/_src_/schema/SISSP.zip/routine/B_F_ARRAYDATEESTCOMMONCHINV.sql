CREATE FUNCTION       B_F_ARRAYDATEESTCOMMONCHINV RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: B_F_ARRAYDATEESTCOMMONCHINV
+ Наименование: Формирование дат Estimation для ребенка-инвалида
+ Автор: Ворошилин В.
+ Состояние на дату 20/09/2002	14.03.2017 РАВ
==============================================================================*/

result_step_start DBMS_SQL.NUMBER_TABLE;
result_function DBMS_SQL.NUMBER_TABLE;
j NUMBER;

BEGIN

result_step_start.delete;
result_function.delete;
result_function := B_F_ArrayDateEstUXCHINV;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMETRICUX;
--result_function := B_F_ArrayDateEstMETRIC; 14.03.2017 РАВ увеличение пенсионного возраста
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMETRIC;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivity(1);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivity(2);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivity(3);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;
--17.11.2014 РАВ  по Закону "О государственных пособиях семьям, воспитывающим детей" от 01.01.2013
-- инвалидность получателя не влияет на срок окончания действия пособия
if (xlpl.alloc_code=491)  then null; --добавлено 09.11.2016  Речицкая АВ
else
result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdvice(1, 11);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdvice(1, 12);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdvice(1, 13);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdvice(1, 14);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdvice(1, 15);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdvice(2, 21);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;
 end if;		--09.11.2016 РАВ  по Закону "О государственных пособиях семьям, воспитывающим детей"01.01.2013

result_function.delete;
result_function := B_F_ArrayDateEstAddress;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstAddressAbsent;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstBirthDeath;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

return result_step_start;

END B_F_ARRAYDATEESTCOMMONCHINV;
/
