CREATE FUNCTION       B_F_Arraydateestmrakopadvice(AOPINION_TYPE IN BINARY_INTEGER, AADVICE_TYPE IN BINARY_INTEGER) RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_F_ARRAYDATEESTMRAKOPADVICE
 Наименование       : Построение массива прогнозируемых дат для пособий ст. 3-х лет
 Автор              : Ворошилин В.                  Комментарии:ОЛВ
 Состояние на дату  : 17.11.2000                                   17.07.2012  19.11.2012
 Код возврата       : Возвращает массив дат изменения характеристик
***********************************************************************************************/
  xDATES           DBMS_SQL.NUMBER_TABLE;
  vsAOPINION_TYPE  VARCHAR2(2000);
  vsAADVICE_TYPE   VARCHAR2(2000);
  vsMin            DATE;
  vsMax            DATE;
BEGIN
  xDATES.DELETE;
  /*
  if AOPINION_TYPE = - 1 then
    vsAOPINION_TYPE := '';
  else
    vsAOPINION_TYPE := TO_CHAR(AOPINION_TYPE);
  end if;
  if AADVICE_TYPE = - 1 then
    vsAADVICE_TYPE := '';
  else
    vsAADVICE_TYPE := TO_CHAR(AADVICE_TYPE);
  end if;
  */
  xDATES.DELETE;
  FOR MRAKOPADVICE IN (SELECT NVL(a.RECORD_START, NULL) AS vsRECORD_START,
                              NVL(a.DIS_TERM, NULL) AS vsDIS_TERM,
                              NVL(a.RECORD_END, NULL) AS vsRECORD_END,
                              NVL(b.EXAMED_FROM, NULL) AS vsEXAMED_FROM
                       FROM W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
                       WHERE a.PID = Xlpl.GetPid
                         AND a.STAGE NOT IN (2,3)
                         AND a.ENTERED_BY = Xlpl.User_ID
                         AND b.RID = a.MRAK_RID
                         AND b.ENTERED_BY = MRAK_ENTERED_BY
                  AND NVL (b.RECORD_END,LAST_DAY(S_Currdate)) >= LAST_DAY(S_Currdate)-- OLV 18.05.2015
                         AND ((NVL(NVL(a.RECORD_START, b.EXAMED_FROM), LAST_DAY(S_Currdate)) > LAST_DAY(S_Currdate))
                             OR (NVL(NVL(a.RECORD_END,a.DIS_TERM), LAST_DAY(S_Currdate)) > LAST_DAY(S_Currdate)))
                         AND a.OPINION_TYPE = AOPINION_TYPE
                         AND a.ADVICE_TYPE = AADVICE_TYPE)
  LOOP
    IF MRAKOPADVICE.vsRECORD_START IS NULL THEN
      vsMin := MRAKOPADVICE.vsEXAMED_FROM;
    ELSE
      vsMin := MRAKOPADVICE.vsRECORD_START;
    END IF;

    IF MRAKOPADVICE.vsDIS_TERM IS NULL AND MRAKOPADVICE.vsRECORD_end IS NULL THEN
       vsMax := NULL;
    END IF;
   --------****!!!
   IF MRAKOPADVICE.vsDIS_TERM IS NOT NULL AND MRAKOPADVICE.vsRECORD_end IS NULL THEN
       vsMax := MRAKOPADVICE.vsDIS_TERM;
   END IF;
   ---------
    IF MRAKOPADVICE.vsDIS_TERM IS NULL AND MRAKOPADVICE.vsRECORD_end IS NOT NULL THEN
       vsMax := MRAKOPADVICE.vsRECORD_end;
    END IF;
    IF MRAKOPADVICE.vsDIS_TERM IS NOT NULL AND MRAKOPADVICE.vsRECORD_end IS NOT NULL THEN
       IF MRAKOPADVICE.vsRECORD_end > MRAKOPADVICE.vsDIS_TERM THEN
             vsMax := MRAKOPADVICE.vsDIS_TERM;
       ELSE
          vsMax := MRAKOPADVICE.vsRECORD_end;
       END IF;
    END IF;

--if XLPL.GetPid =6100001489  then
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTMRAKOPADVICE  XLPL.GetPid='||XLPL.GetPid || ' vsMax='||vsMax ||'   vsMin='||vsMin);
--end if;
--RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTMRAKOPADVICE  XLPL.GetPid='||XLPL.GetPid);--||'result_function(7)= '||S_JToD(result_function(1))

    IF vsMin IS NOT NULL THEN
      IF vsMin > LAST_DAY(S_Currdate) THEN
        xDATES(xDATES.COUNT + 1) := S_Julian(vsMin) - 1;
        IF AOPINION_TYPE = 1 THEN
          xDATES(xDATES.COUNT + 1) := 314;
          xDATES(xDATES.COUNT + 1) := 1;
        ELSE
          xDATES(xDATES.COUNT + 1) := 315;
          xDATES(xDATES.COUNT + 1) := 1;
        END IF;
      END IF;
    END IF;

    IF vsMax IS NOT NULL THEN
      IF (vsMax +1) > LAST_DAY(S_Currdate) THEN
        xDATES(xDATES.COUNT + 1) := S_Julian(vsMax);
        IF AOPINION_TYPE = 1 THEN
          xDATES(xDATES.COUNT + 1) := 33;  -- Истечение срока действия инвалидности
          xDATES(xDATES.COUNT + 1) := 2;
        ELSE
          xDATES(xDATES.COUNT + 1) := 58;  -- Окончание нуждаемости лица в постоянном уходе
          xDATES(xDATES.COUNT + 1) := 2;
        END IF;
      END IF;
    END IF;
  END LOOP;
  RETURN xDATES;
END B_F_Arraydateestmrakopadvice;--_MOTHER;
/
