CREATE FUNCTION       B_CHILD_NADBAVKAAIDS RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_CHILD_NADBAVKAAIDS
 Наименование       : переключатель по датам
                     Проверка права и вычисление надбавок для пособий детям в возрасте до 18 лет,
                      инфицированных вирусом иммунодефицита человека
                     или больных СПИД
 Автор              : Ворошилин В.               Коректировка: ОЛВ
 Состояние на дату  : 05.02.1999                            31.03.2010
 Код возврата       : число с плавающей точкой с суммой
***********************************************************************************************/

BEGIN
   if XLPL.WorkDate < to_date('01-07-2002','DD-MM-YYYY') then
      return B_CHILD_NADBAVKAAIDS_0;
   else
       return B_CHILD_NADBAVKAAIDS_20020701;
     /* ОЛВ 31.03.2010 *
     if XLPL.WorkDate < to_date('01-12-2006','DD-MM-YYYY') then
        return B_CHILD_NADBAVKAAIDS_20020701;
     else
       if XLPL.WorkDate < to_date('01-01-2008','DD-MM-YYYY') then
        return B_CHILD_NADBAVKAAIDS_20061201;
       else
         return B_CHILD_NADBAVKAAIDS_20080101;
       end if;

     end if;
     /* */
   end if;

END B_CHILD_NADBAVKAAIDS;
/
