CREATE FUNCTION       A_P_RecordStr_VL RETURN NUMBER AS
/******************************************************************************
   NAME         : A_P_RecordStr
   Назначение   : Функция определения требуемого страхового стажа для пенсий за выслугу лет
   Автор        : ОЛВ
   Дата         : 18.12.2015   06.12.2016
   Код возврата : Требуемый страховой стаж
******************************************************************************/
 St_Str        NUMBER;
 date_recalc   DATE;
BEGIN
         St_Str :=1;   -- наличие страхового стажа
  IF (Xlpl.CONVER_T = 1) THEN   --  Для прибывших и конвертированных дел
         IF A_F_Allocstartconvert() >= S_Encodedate(2016,1,1) THEN
              St_Str:=5580;  -- 15 лет 6 месяцев
         END IF;
  ELSE                         --  Для новых дел и перерасчета
      IF XLPL.AID<>0 THEN -- перерасчет
          IF A_P_Start_Allocation = Xlpl.WorkDate then -- перевод на новое
                 date_recalc:=A_F_Datatalk();-- дата обращения за назначением
            IF (Xlpl.WorkDate >= TO_DATE('01-01-2017','DD-MM-YYYY'))
                   AND (date_recalc >=  TO_DATE('01-01-2017','DD-MM-YYYY')) THEN
                    St_Str:=5760;  -- 16 лет
            ELSE
               IF (Xlpl.WorkDate >= TO_DATE('01-01-2016','DD-MM-YYYY'))
                   AND (date_recalc >=  TO_DATE('01-01-2016','DD-MM-YYYY')) THEN
                    St_Str:=5580;  -- 15 лет 6 месяцев
               END IF;
            END IF;
          ELSE
            IF A_P_Start_Allocation >= S_Encodedate(2017,01,01) THEN
                    St_Str:=5760;  -- 16 лет
            ELSE
              IF A_P_Start_Allocation >= S_Encodedate(2016,01,01) THEN
                    St_Str:=5580;  -- 15 лет 6 месяцев
              END IF;
            END IF;
          END IF;
      ELSE
            date_recalc:=A_F_Datatalk();-- дата обращения за назначением
          IF (Xlpl.WorkDate >= TO_DATE('01-01-2017','DD-MM-YYYY'))
                AND (date_recalc >=  TO_DATE('01-01-2017','DD-MM-YYYY')) THEN
                    St_Str:=5760;  -- 16 лет
          ELSE
            IF (Xlpl.WorkDate >= TO_DATE('01-01-2016','DD-MM-YYYY'))
                AND (date_recalc >=  TO_DATE('01-01-2016','DD-MM-YYYY')) THEN
                    St_Str:=5580;  -- 15 лет 6 месяцев
            END IF;
          END IF;
      END IF;
  END IF;
  RETURN St_Str;
/* *if xlpl.cid=71401001601 then
 RAISE_APPLICATION_ERROR(-20801,'A_P_RecordStr:   33333  St_Str='||St_Str);
end if; /**/
END A_P_RecordStr_VL;
/
