CREATE FUNCTION       A_F_Arrdatachangewmrakopadvpen(pStartDate IN DATE,
   pOPINION_TYPE IN NUMBER,pADVICE_TYPE IN NUMBER) RETURN DBMS_SQL.Number_Table IS
/***********************************************************************************************
 Функция          : A_F_Arrdatachangewmrakopadvpen
 Наименование : Функция создания массива дат по W$MRAK_OPINION ADVICE
 Автор              : Вахромин О.Ю.
 Состояние на дату
 Код возврата: число с плавающей точкой с суммой пенсии
**********************************************************************************************/

xDATES                  DBMS_SQL.Number_Table;
vsRECORD_START  DATE;
vsRECORD_END      DATE;
vsEXAMED_FROM   DATE;
vsDIS_TERM            DATE;
vsMin                       DATE;
vsMax                      DATE;
vsAOPINION_TYPE  VARCHAR2(2000);
vsAADVICE_TYPE   VARCHAR2(2000);

BEGIN

   xDATES.DELETE;

   IF pOPINION_TYPE=-1 THEN
      vsAOPINION_TYPE:='';
   ELSE
      vsAOPINION_TYPE:=TO_CHAR(pOPINION_TYPE);
   END IF;

   IF pADVICE_TYPE=-1 THEN
      vsAADVICE_TYPE:='';
   ELSE
      vsAADVICE_TYPE:=TO_CHAR(pADVICE_TYPE);
   END IF;

   FOR c1 IN
              ( SELECT a.RECORD_START vsRECORD_START,
                              a.RECORD_END     vsRECORD_END,
                              b.EXAMED_FROM  vsEXAMED_FROM,
                              a.DIS_TERM           vsDIS_TERM
                  FROM W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
               WHERE a.PID=Xlpl.GetPID
                     AND a.STAGE NOT IN (2,3)
                     AND a.ENTERED_BY=Xlpl.USER_ID
                     AND b.RID=MRAK_RID
                     AND b.ENTERED_BY=MRAK_ENTERED_BY
                     AND ( (NVL(NVL(a.RECORD_START, b.EXAMED_FROM),pStartDate)>pStartDate)
                              OR  (NVL (NVL(a.RECORD_END,a.DIS_TERM),pStartDate)>pStartDate ) )
                     AND a.OPINION_TYPE=vsAOPINION_TYPE
                     AND a.ADVICE_TYPE=vsAADVICE_TYPE
	       ORDER BY b.EXAMED_FROM)
   LOOP
      vsRECORD_START:=c1.vsRECORD_START;
      vsRECORD_END:=c1.vsRECORD_END;
      vsEXAMED_FROM:=c1.vsEXAMED_FROM;
      vsDIS_TERM:=c1.vsDIS_TERM;

      IF vsRECORD_START IS NULL THEN
         vsMin:=vsEXAMED_FROM;
      ELSE
         vsMin:=vsRECORD_START;
      END IF;

      IF (vsDIS_TERM IS NULL)AND(vsRECORD_END IS NULL) THEN
         vsMax:=NULL;
      ELSIF vsDIS_TERM IS NULL THEN
         vsMax:=vsRECORD_END;
	  ELSIF vsRECORD_END IS NULL THEN
         vsMax:=vsDIS_TERM;
      ELSE
         vsMax:=vsRECORD_END;
      END IF;

      IF (vsMin IS NOT NULL)OR(vsMax IS NOT NULL) THEN
         xDATES(xDATES.COUNT+1):=S_Julian(vsMin);
	     xDATES(xDATES.COUNT+1):=S_Julian(vsMax);
	  END IF;

   END LOOP;

   RETURN xDATES;
END A_F_Arrdatachangewmrakopadvpen;
/
