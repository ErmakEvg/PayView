CREATE FUNCTION       A_F_ArrivedCase RETURN BOOLEAN IS
/******************************************************************************
 NAME         : A_F_AllocPrib
 Назначение   : Функция получения признака - прибывшее дело
 Автор        : ОЛВ
 Дата         :	20.01.2011    22.05.2017
 Код возврата : Признак прибывшего дела
******************************************************************************/
 vsPR_Prib NUMBER;
BEGIN
 BEGIN
   select NVL(PR_PRIB,0)
	 into vsPR_Prib
	 from W$APPLICATION
	where CID=XLPL.CID
	  and STAGE in (1,4)
      and PR_PRIB is not null;

	 if vsPR_Prib=1 then
       return True;
     end if;
 EXCEPTION
   when NO_DATA_FOUND then
      return False;
 END;
      return False;
END A_F_ArrivedCase;
/
