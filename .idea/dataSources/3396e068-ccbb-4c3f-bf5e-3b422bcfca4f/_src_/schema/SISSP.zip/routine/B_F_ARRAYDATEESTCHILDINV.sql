CREATE FUNCTION       B_F_Arraydateestchildinv RETURN DBMS_SQL.NUMBER_TABLE AS
/***************************************************************************************
 Функция: F_ARRAYDATEESTCHILDINV
 Наименование: Ограничение возраста для детей - инвалидов старше 3 лет для Estimation
 Автор: Ворошилин В.
 Состояние на дату 29.11.2000    23.10.2012
 Код возврата: Массив, состоящий из даты, кода причины, кода изменения состояния
***************************************************************************************/
  result DBMS_SQL.NUMBER_TABLE;
  StopDt DATE;
  StopDtEnd DATE;
BEGIN
  result.DELETE;
  IF Xlpl.CheckRole(56) THEN
   Xlpl.RoleDecl('Child','56');   									-- Ребенок в назначении
  ELSE
   RETURN result;
  END IF;
  Xlpl.REPLACEROLE('Child');
  StopDt := S_Addyears(A_F_Relprotbirthday, S_Const(407, Xlpl.WorkDate));
  StopDtEnd := S_Encodedate(S_Yearofdate(Xlpl.WorkDate), S_Monthofdate(S_Jtod(S_Const(479, Xlpl.WorkDate))), S_Dayofdate(S_Jtod(S_Const(479, Xlpl.WorkDate))));
  IF A_F_Relprotdisability(1, '14') THEN
    IF (StopDt <= StopDtEnd) AND (StopDt > LAST_DAY(S_Currdate)) THEN
    -- срок действия пособия перед днем достижения 18 лет - разъяснение Коваль СИ
    ---Речицкая А. В. 23.10.2012 -- result(1) := S_Julian(StopDt);
 	  result(1) := S_Julian(StopDt)-1; --Речицкая А. В. 23.10.2012 инвалидность установить "по"
 	  result(2) := 28;
 	  result(3) := 2;
	END IF;
  END IF;
  Xlpl.RESTOREROLE;
  RETURN result;
END B_F_Arraydateestchildinv;
/
