CREATE FUNCTION       A_F_RELPROTDISABILITYEIGHTEEN RETURN BOOLEAN AS

/* --------------------------------------------------------------------
// Автор: Басинюк Я.В.
// состояние на 14.05.1999
// Код возврата: возвращает True, если учеловека инвалид до 18 лет
//               по коду согласно W$RELATION_PROTOCOL
// --------------------------------------------------------------------*/

  DRIDS DBMS_SQL.NUMBER_TABLE;
  vsMinDate DATE;
  vsDate DATE;
  vsNullDate DATE;
BEGIN
  DRIDS.delete;
  vsMinDate := NULL;
  vsDate := NULL;
  vsNullDate := A_F_CMinDate;
  DRIDS := A_F_RelProtGetRIDMrakOpAdvice(1, -1);
  if DRIDS.count <> 0 then
    for i in 1..DRIDS.count loop
      select NVL(NVL(a.RECORD_START,b.EXAMED_FROM), vsNullDate)  into vsDate
      from MRAK_OPINION_ADVICE a, MRAK_OPINION b
	  where a.RID = DRIDS(i)
	    and b.RID = MRAK_RID;
	  vsDate := B_F_DataConvert(vsDate);
	  if (vsDate is not NULL) then
	    if (vsMinDate is NULL) then
		  vsMinDate := vsDate;
	    else
		  if (vsMinDate > vsDate) then
		    vsMinDate := vsDate;
		  end if;
	    end if;
	  end if;
    end loop;
  end if;
  DRIDS := A_F_RelProtGetRIDMrakOpAdvice(0, -1);
  if DRIDS.count <> 0 then
    for i in 1..DRIDS.count loop
      select NVL(NVL(a.RECORD_START,b.EXAMED_FROM), vsNullDate) into vsDate
      from W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
	  where a.RID = DRIDS(i)
	    and a.ENTERED_BY = XLPL.USER_ID
		and b.RID = MRAK_RID
		and b.ENTERED_BY = MRAK_ENTERED_BY;
	  vsDate := B_F_DataConvert(vsDate);
	  if (vsDate is not NULL) then
	    if (vsMinDate is NULL) then
		  vsMinDate := vsDate;
	    else
		  if (vsMinDate > vsDate) then
		    vsMinDate := vsDate;
		  end if;
		end if;
	  end if;
    end loop;
  end if;
  if (vsMinDate is not NULL) then
    if S_YearsBetween(A_F_RelProtBirthday, vsMinDate) < S_CONST(214, XLPL.WorkDate) then
	  return true;
	end if;
  end if;
  return false;
END A_F_RELPROTDISABILITYEIGHTEEN;
/
