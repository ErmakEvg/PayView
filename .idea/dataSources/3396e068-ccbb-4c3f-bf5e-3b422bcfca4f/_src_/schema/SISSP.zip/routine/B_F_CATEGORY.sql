CREATE FUNCTION       B_F_CATEGORY RETURN NUMBER AS

/***************************************************************************************
// Функция: B_F_CATEGORY
// Наименование: Получение категории дела
// Автор: Ворошилин В.
// Состояние на дату 05.02.1999
// Код возврата: категория дела
//***************************************************************************************/

  aCategory NUMBER;
BEGIN
  select ACCESS_DATA INTO aCategory from ID_CASE where CID = XLPL.CID and (ENTERED_BY = XLPL.User_ID or ENTERED_BY is null);
  return aCategory;
  exception
    when No_Data_Found then
	  return 0;
END B_F_CATEGORY;
/
