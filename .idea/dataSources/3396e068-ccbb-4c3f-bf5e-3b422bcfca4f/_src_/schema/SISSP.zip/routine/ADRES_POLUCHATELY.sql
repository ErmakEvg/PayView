CREATE FUNCTION       adres_poluchately(cid# VARCHAR2, entered_by# VARCHAR2) RETURN VARCHAR2 IS text VARCHAR2(2000);
BEGIN
SELECT DISTINCT
oblast.value||' '||oblastr.value||' '||raion.value||' '||raionr.value||' '||derevnia.value ||' '||site.value  ||' '|| street.value||house.value ||house_x.value ||appt.value
INTO text
FROM
(SELECT NVL(( SELECT sd.value
FROM ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = (SELECT sd.parent_code
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =(SELECT sd.parent_code
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =ad.site))),' ') value FROM dual) oblast,
(SELECT NVL(( SELECT rsd.catshortname
FROM
ADDRESS  ad,
PERSON  p,
RECIPIENT  r,
STATE_DIVISION  sd,
REF_ST_DIVISION_LEVELS rsd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = (SELECT sd.parent_code
FROM
ADDRESS  ad,
PERSON  p,
RECIPIENT  r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =(SELECT sd.parent_code
FROM
 ADDRESS  ad,
 PERSON  p,
 RECIPIENT  r,
STATE_DIVISION  sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =ad.site))
AND  rsd.code = sd.level_code),' ') value FROM dual) oblastr,
(SELECT NVL(( SELECT sd.value
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = (SELECT sd.parent_code
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =ad.site)),' ') value FROM dual) raion,
(SELECT NVL(( SELECT rsd.catshortname
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd,
REF_ST_DIVISION_LEVELS rsd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = (SELECT sd.parent_code
FROM
W$ADDRESS ad,
W$PERSON p,
W$RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =ad.site)
AND  rsd.code = sd.level_code),' ') value FROM dual) raionr,
(SELECT NVL(( SELECT rsd.catshortname
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd,
REF_ST_DIVISION_LEVELS rsd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site
AND  rsd.code = sd.level_code),' ') value FROM dual) derevnia,
(SELECT NVL(( SELECT sd.value
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site),' ') value FROM dual) site,
(SELECT NVL(( SELECT ' ул. '||sd.value
FROM
ADDRESS ad,PERSON p,RECIPIENT r,STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid = p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.street),' ') value FROM dual) street,
(SELECT NVL(( SELECT ' д. '||ad.house
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND p.rid = r.person_rid
AND  ad.pid =  p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site),' ') value FROM dual) house,
(SELECT NVL(( SELECT ' корп. '||ad.house_x
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid =  p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site),' ') value FROM dual) house_x,
(SELECT NVL(( SELECT ' кв. '||ad.appt
FROM
ADDRESS ad,
PERSON p,
RECIPIENT r,
STATE_DIVISION sd
WHERE
r.cid = cid#
AND  r.entered_by = entered_by#
AND  p.rid = r.person_rid
AND  ad.pid =  p.pid
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site),' ') value FROM dual) appt;
RETURN TEXT;
END;
/
