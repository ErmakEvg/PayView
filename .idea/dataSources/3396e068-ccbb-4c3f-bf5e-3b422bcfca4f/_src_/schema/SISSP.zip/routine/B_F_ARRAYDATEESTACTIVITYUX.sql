CREATE FUNCTION       B_F_ArrayDateEstACTIVITYUX (pActivity in BINARY_INTEGER) RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_ArrayDateEstACTIVITYUX
+ Наименование: возвращает массив дат изменения "работ лица" по Estimation
+ Автор: Ворошилин В.
+ Состояние на дату 16.11.2000
==============================================================================*/

  b DBMS_SQL.NUMBER_TABLE;
  a BINARY_INTEGER;
BEGIN
  b.Delete;
  a := 0;
  for ACTIVITYUX in (select nvl(PERIOD_START, NULL) as activity_start,
                            nvl(PERIOD_END, NULL) as activity_end,
							nvl(LABOR, 0) as pLabor
  					 from w$ACTIVITY
                  	 where PID = XLPL.GetPID
					   and ACTIVITY = pActivity
					   and (NVL(PERIOD_START, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate) or NVL(PERIOD_END, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate))
					   and STAGE in (1, 4)
					   and ENTERED_BY = XLPL.USER_ID)
  loop
  if (ACTIVITYUX.activity_start is not NULL) and ((ACTIVITYUX.activity_start + 1) > LAST_DAY(S_CurrDate)) then
    if (pActivity = 1) and ((A_F_RELPROTCURRENTROLE = 55) or (A_F_RELPROTCURRENTROLE = 52)) then
	  b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_start)) - 1;
	  if (ACTIVITYUX.pLabor = 200) or (ACTIVITYUX.pLabor = 201) or (ACTIVITYUX.pLabor = 202) or
	     (ACTIVITYUX.pLabor = 203) or (ACTIVITYUX.pLabor = 204) or (ACTIVITYUX.pLabor = 205) or
		 (ACTIVITYUX.pLabor = 206) or (ACTIVITYUX.pLabor = 207) then
		b(b.count + 1) := 93;
		b(b.count + 1) := 1;
	  else
	    b(b.count + 1) := 66;
		b(b.count + 1) := 2;
 	  end if;
	  if (pActivity = 1) and ((A_F_RELPROTCURRENTROLE = 56) or (A_F_RELPROTCURRENTROLE = 57)) then
		b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_start)) - 1;
		b(b.count + 1) := 66;
		b(b.count + 1) := 2;
	  end if;
	  a := 0;
      if (pActivity = 2) and ((A_F_RELPROTCURRENTROLE = 55) or (A_F_RELPROTCURRENTROLE = 52) or (A_F_RELPROTCURRENTROLE = 56)) then
		b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_start)) - 1;
		if (ACTIVITYUX.pLabor = 225) or (ACTIVITYUX.pLabor = 228) or (ACTIVITYUX.pLabor = 231) or (ACTIVITYUX.pLabor = 233) then
		  b(b.count + 1) := 96;
		  b(b.count + 1) := 2;
		  a := 1;
		end if;
		if (ACTIVITYUX.pLabor = 226) or (ACTIVITYUX.pLabor = 227) or (ACTIVITYUX.pLabor = 229) or
		   (ACTIVITYUX.pLabor = 230) or (ACTIVITYUX.pLabor = 232) then
		  b(b.count + 1) := 98;
		  b(b.count + 1) := 1;
		  a := 1;
		end if;
		if (a = 0) then
		  b(b.count + 1) := 998;
		  b(b.count + 1) := 1;
		end if;
      end if;
	  a := 0;
	  if (pActivity = 2) and (A_F_RELPROTCURRENTROLE = 57) then
		b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_start))-1;
		if (ACTIVITYUX.pLabor = 225) or (ACTIVITYUX.pLabor = 228) or (ACTIVITYUX.pLabor = 231) or (ACTIVITYUX.pLabor = 233) then
		  b(b.count + 1) := 96;
		  b(b.count + 1) := 2;
		  a := 1;
		end if;
		if (a = 0) then
		  b(b.count + 1) := 998;
		  b(b.count + 1) := 1;
		end if;
	  end if;
	  a := 0;
	  if (pActivity = 3) and ((A_F_RELPROTCURRENTROLE = 55) or (A_F_RELPROTCURRENTROLE = 52)) then
		b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_start))-1;
		if (ACTIVITYUX.pLabor = 241) then
		  b(b.count + 1) := 302;
		  b(b.count + 1) := 1;
		  a := 1;
		end if;
		if (ACTIVITYUX.pLabor = 243) then
		  b(b.count + 1) := 304;
		  b(b.count + 1) := 1;
		  a := 1;
		end if;
		if (ACTIVITYUX.pLabor = 242) then
		  b(b.count + 1) := 306;
		  b(b.count + 1) := 1;
		  a := 1;
		end if;
		if (a = 0) then
		  b(b.count + 1) := 308;
		  b(b.count + 1) := 1;
		  a := 1;
		end if;
	  end if;
	  a := 0;
	  if (pActivity = 3) and (A_F_RELPROTCURRENTROLE = 56) then
		b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_start))-1;
		if (ACTIVITYUX.pLabor = 241) then
		  b(b.count + 1) := 302;
		  b(b.count + 1) := 2;
		  a := 1;
		end if;
		if (ACTIVITYUX.pLabor = 243) then
		  b(b.count + 1) := 304;
		  b(b.count + 1) := 2;
		  a := 1;
		end if;
		if (ACTIVITYUX.pLabor = 242) then
		  b(b.count + 1) := 306;
		  b(b.count + 1) := 2;
		  a := 1;
		end if;
		if (a = 0) then
		  b(b.count + 1) := 308;
		  b(b.count + 1) := 1;
		  a := 1;
		end if;
	  end if;
	  a := 0;
	  if (pActivity = 3) and (A_F_RELPROTCURRENTROLE = 57) then
	    b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_start))-1;
		b(b.count + 1) := 998;
		b(b.count + 1) := 1;
	  end if;
	end if;
  end if;
	a := 0;

----------------------------------------------------------------------------------------------------------------------------------------

    if (ACTIVITYUX.activity_end is not NULL) and ((ACTIVITYUX.activity_end+1) > LAST_DAY(S_CurrDate)) then
	  if (pActivity = 1) and ((A_F_RELPROTCURRENTROLE = 55 or A_F_RELPROTCURRENTROLE = 52)) then
		b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_end));
		if (ACTIVITYUX.pLabor = 200) or (ACTIVITYUX.pLabor = 201) or (ACTIVITYUX.pLabor = 202) or
		   (ACTIVITYUX.pLabor = 203) or (ACTIVITYUX.pLabor = 204) or (ACTIVITYUX.pLabor = 205) or
		   (ACTIVITYUX.pLabor = 206) or (ACTIVITYUX.pLabor = 207) or (ACTIVITYUX.pLabor = 200) then
		  b(b.count + 1) := 94;
		  b(b.count + 1) := 1;
	    else
	      b(b.count + 1) := 95;
		  b(b.count + 1) := 1;
		end if;
	  end if;
	  if (pActivity = 1) and ((A_F_RELPROTCURRENTROLE = 56) or (A_F_RELPROTCURRENTROLE = 57)) then
		b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_end));
		b(b.count + 1) := 95;
		b(b.count + 1) := 1;
	  end if;
	  a := 0;
	  if (pActivity = 2) then
		 b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_end));
		 if (ACTIVITYUX.pLabor = 225) or (ACTIVITYUX.pLabor = 228) or (ACTIVITYUX.pLabor = 231) or (ACTIVITYUX.pLabor = 233) then
	       b(b.count + 1) := 97;
	       b(b.count + 1) := 1;
	       a := 1;
	     end if;
		 if (ACTIVITYUX.pLabor = 226) or (ACTIVITYUX.pLabor = 227) or (ACTIVITYUX.pLabor = 229) or
		    (ACTIVITYUX.pLabor = 230) or (ACTIVITYUX.pLabor = 232) then
		   b(b.count + 1) := 99;
		   b(b.count + 1) := 1;
		   a := 1;
		 end if;
		 if (a = 0) then
		   b(b.count + 1) := 998;
		   b(b.count + 1) := 1;
		 end if;
	   end if;
	   a := 0;
	   if (pActivity = 3) then
		 b(b.count + 1) := S_Julian(LAST_DAY(ACTIVITYUX.activity_end));
		 if (ACTIVITYUX.pLabor = 241) then
		   b(b.count + 1) := 303;
		   b(b.count + 1) := 1;
		   a := 1;
		 end if;
		 if (ACTIVITYUX.pLabor = 243) then
		   b(b.count + 1) := 305;
		   b(b.count + 1) := 1;
		   a := 1;
		 end if;
		 if (ACTIVITYUX.pLabor = 242) then
		   b(b.count + 1) := 307;
		   b(b.count + 1) := 1;
		   a := 1;
		 end if;
		 if (a = 0) then
		   b(b.count + 1) := 309;
		   b(b.count + 1) := 1;
		 end if;
	   end if;
     end if;
  end loop;
  return b;
END B_F_ArrayDateEstACTIVITYUX;
/
