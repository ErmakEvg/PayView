CREATE FUNCTION       A_F_RelProtActivityEnd(aActivity in NUMBER, aLabor in VARCHAR2, aDismiss_Reason in VARCHAR2)
                                                   RETURN DATE IS
/***************************************************************************************
 Функция            : A_F_RelProtActvEnd
 Наименование       : Функция определения даты окончания ACTIVITY
 Автор              : ОЛВ
 Состояние на дату  : 09.03.2010
 Код возврата       : датa окончания ACTIVITY
****************************************************************************************/

 DRIDS       DBMS_SQL.NUMBER_TABLE;
 vsDRID      number;
 pPERIOD_End date default  null;
 mPERIOD_End date default  null;
 i integer;

BEGIN

  --     1 - ОБД
  ----------------------
    DRIDS := A_F_RelProtGetRIDActivity(1);
  if (DRIDS.count <> 0) then

    for i in 1 .. DRIDS.count LOOP
        vsDRID := DRIDS(i);
      BEGIN
	    select PERIOD_END into pPERIOD_End
		  from ACTIVITY
	     where RID = vsDRID
	       and ACTIVITY = aActivity
           and PERIOD_END is not null
		   --and ((XLPL.WorkDate>= PERIOD_Start) AND (XLPL.WorkDate<= PERIOD_END))-- OLV 29.06.2010 со слов Я.С.А.
		   and (( (PERIOD_Start is null) or (XLPL.WorkDate>= PERIOD_Start)) AND (XLPL.WorkDate<= PERIOD_END)) -- OLV 29.06.2010

		   and entered_by = XLPL.User_ID ;

             if (mPERIOD_End is null) or (mPERIOD_End < pPERIOD_End) then
                mPERIOD_End:= pPERIOD_End;
             end if;
      exception
        when No_Data_Found then
           null;
      END;

	end loop;
  end if;

  --     0 - РБД
  ----------------------
    DRIDS := A_F_RelProtGetRIDActivity(0);
  if (DRIDS.count <> 0) then

    for i in 1 .. DRIDS.count LOOP
        vsDRID := DRIDS(i);
      BEGIN
	    select PERIOD_END into pPERIOD_End
		  from W$ACTIVITY
	     where RID = vsDRID
	       and ACTIVITY = aActivity
           and PERIOD_END is not null
		   --and ((XLPL.WorkDate>= PERIOD_Start) AND (XLPL.WorkDate<= PERIOD_END)) -- OLV 29.06.2010 со слов Я.С.А.
		   and (( (PERIOD_Start is null) or (XLPL.WorkDate>= PERIOD_Start)) AND (XLPL.WorkDate<= PERIOD_END)) -- OLV 29.06.2010
		   and entered_by = XLPL.User_ID ;
             if (mPERIOD_End is null) or (mPERIOD_End < pPERIOD_End) then
                mPERIOD_End:= pPERIOD_End;
             end if;
      exception
        when No_Data_Found then
           null;
      END;

	end loop;
  end if;

RETURN mPERIOD_End;
   /* *
             RAISE_APPLICATION_ERROR(-20801,' A_F_RelProtActivityEnd 000'|| CHR(10)|| ' vsDRID='||vsDRID
                                                                         || CHR(10)|| ' PERIOD_Start='||pPERIOD_Start
                                                                         || CHR(10)|| ' PERIOD_END='||pPERIOD_END
                                                                         || CHR(10)|| ' XLPL.WorkDate='||XLPL.WorkDate
                                                                             );
  /* */
END A_F_RelProtActivityEnd;
/
