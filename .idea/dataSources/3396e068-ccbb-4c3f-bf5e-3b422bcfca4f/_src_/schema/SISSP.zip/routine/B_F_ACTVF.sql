CREATE FUNCTION       B_F_Actvf RETURN DBMS_SQL.NUMBER_TABLE AS

/***************************************************************************************
// Функция: B_F_Actv
// Наименование: Функция определяет, кем работало лицо (без привязки к дате)
// Автор: Ворошилин В.
// Состояние на дату 05.05.1999
// Возвращает: массив, где первый член - код вида деятельности, второй - код типа
// 			   деятельности (конкретизация)
//***************************************************************************************/

  a DBMS_SQL.NUMBER_TABLE;
BEGIN
  a.Delete;
  for curActvf in (Select ACTIVITY, nvl(LABOR, 0) as aLABOR,
                          nvl(PERIOD_START, NULL) as ACTSTART,
						  nvl(PERIOD_END, NULL) as ACTEND
                   From W$ACTIVITY
				   Where  PID = XLPL.GetPid
				     and  ENTERED_BY = XLPL.User_ID
					-- and  ACTIVITY in (1,2)
					 and  ACTIVITY in (1,2,3)
					 and  STAGE NOT IN(2,3)
				   ORDER BY PERIOD_START)
  LOOP
	a(a.count+1) := curActvf.ACTIVITY;
	a(a.count+1) := curActvf.aLABOR;
	a(a.count+1) := S_Julian(curActvf.ACTSTART);
	a(a.count+1) := S_Julian(curActvf.ACTEND) + 1;
  end LOOP;
  RETURN a;
END B_F_Actvf;
/
