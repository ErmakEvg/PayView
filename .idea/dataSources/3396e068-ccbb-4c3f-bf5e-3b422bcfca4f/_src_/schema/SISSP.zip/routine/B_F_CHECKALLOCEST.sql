CREATE FUNCTION       B_F_CHECKALLOCEST (aAID IN NUMBER, aCID IN VARCHAR2) RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_CHECKALLOCEST
+ Наименование: Возвращает дату, статус и код причины завершения назначения для Estimation
+ Автор: Ворошилин В.
+ Состояние на дату 17/11/2000
==============================================================================*/

  aData DBMS_SQL.NUMBER_TABLE;
BEGIN
  aData.delete;
  for CHECKALLOCEST in (select nvl(Estimation_Date, NULL) as Dt, STATUS_REASON, CHANGE_ALLOC_STATUS
                        from W$ALLOC_DATE_ESTIMATION
						where CID = aCID
						  and AID = aAID
						  and STAGE in (1, 4)
						  and ENTERED_BY = XLPL.User_ID)
  loop
    if CHECKALLOCEST.Dt is not NULL then
	  aData(aData.count + 1) := S_Julian(CHECKALLOCEST.Dt);
	  aData(aData.count + 1) := CHECKALLOCEST.STATUS_REASON;
	  aData(aData.count + 1) := CHECKALLOCEST.CHANGE_ALLOC_STATUS;
    end if;
  end loop;
  return aData;
END B_F_CHECKALLOCEST;
/
