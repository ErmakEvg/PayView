CREATE FUNCTION       before_payment_mat_help return number
is
--Иванова Т.С.24.07.2013
aperiod date;
acount number;
/* запускается перед выплатой мат. помощи за текущий месяц (4 выплатной период).
Если возвращает 0, то ничего на выплату мат. помощи нет.
Если возвращает больше 0, то надо запустить программу Выплата,а
 затем -  after_payment_mat_help */
begin
select max(period) into APERIOD  from accounting_period
   where sign_close_period is null or sign_close_period=1;
select count(cid) into acount  from RESULT_PAYMENT
 where PERIOD_RID IS  NULL
 AND PAYROLL_NO IS NULL
 and payment_flag is null
 and stage=5
 and  (TRUNC(entry_date,'mm')=TRUNC(APERIOD ,'mm')) AND (TRUNC(entry_date,'YYYY') =TRUNC(APERIOD ,'YYYY'))
 and  ACCESS_DATA=6;
if  acount>0 then
 for c1 in (select rid,cid ,close_date,aid from RESULT_PAYMENT
  where PERIOD_RID IS  NULL
   AND PAYROLL_NO IS NULL
   AND ACCESS_DATA = 6 and stage=5
   AND  (TRUNC(entry_date,'mm')=TRUNC(APERIOD ,'mm')) AND (TRUNC(entry_date,'YYYY') =TRUNC(APERIOD ,'YYYY')))
  loop
   update calc_amount set stage=null,close_date=null
    where RESULT_PAYMENT_RID=C1.RID and ALLOC_CODE=745 ;
   update allocation set stage=null,close_date=null
    where cid=c1.cid  and aid=c1.aid
    and stage=5
    AND  TRUNC(STEP_START,'mm')=TRUNC(APERIOD ,'mm') AND TRUNC(STEP_START,'YYYY') =TRUNC(APERIOD ,'YYYY');
   update assistance set stage=null,close_date=null
    where  stage=5 AND  TRUNC(CLOSE_date,'mm')=TRUNC(APERIOD ,'mm') AND TRUNC(CLOSE_date,'YYYY') =TRUNC(APERIOD ,'YYYY');
   update result_payment set stage=null,close_date=null where rid=c1.rid;
  end loop;
 commit;
end if;
return acount ;
end before_payment_mat_help;
/
