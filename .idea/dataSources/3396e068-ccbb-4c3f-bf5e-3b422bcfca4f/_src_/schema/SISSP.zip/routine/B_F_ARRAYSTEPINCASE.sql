CREATE FUNCTION       B_F_ARRAYSTEPINCASE RETURN DBMS_SQL.NUMBER_TABLE IS
/*/////////////////////////////////////////////////////////////////////
// Боровнева
// Возвращает массив шагов основного назначения, связанного с пособием
// по 30 ст
///////////////////////////////////////////////////////////////////////*/
EXPECT_START_DATE date;
Step_Date DBMS_SQL.NUMBER_TABLE;
Rab1 DBMS_SQL.NUMBER_TABLE;

pFeature number default  0;  -- признак основной роли

BEGIN
  select nvl(feature,0) into pFeature from w$CASE_PERSON a, allocation_role_group b,W$Case c where
	               parent_code = c.Role_Group and code = role and
			       a.pid= XLPL.GETPID and a.cid=  XLPL.CID and a.stage not in(2,3)
				   and c.cid=  XLPL.CID and c.stage not in(2,3);

  if(pFeature !=1) then -- неосновная роль в деле
    for c1 in ( select distinct AID as pAID
                from  allocation_role_Group b, W$allocation c,  W$Allocation_person d, allocations a
                where d.pid <> XLPL.GETPID   and d.role = b.code
	            and a.code =c.alloc_Code  and  a.role_group = b.parent_code and a.close_feature is Null
	            and b.feature = 1   and  c.Alloc_Code   <> XLPL.Alloc_Code
	            and  c.parent_rid  is null   and c.comp_part is null
	            and c.cid = XLPL.Cid   and c.rid  = d.allocation_rid  and c.stage  not in (2,3) )
    LOOP
	--/Step_Date =Step_Date + F_ArrayStepAid(pAID,pCID);
	  Rab1.delete;
	  if (Step_Date.Count = 0)
	    then Step_Date :=  B_F_ArrayStepAid(XLPL.AID, XLPL.CID);
		else
		  Rab1 := B_F_ArrayStepAid(XLPL.AID,XLPL.CID);
		  for i in 1 .. Rab1.count  loop
			Step_Date(Step_Date.count+1) := Rab1(i);
          end loop;
	  end if;
    end loop;
  else
    for c2 in  ( select distinct AID as pAID
                 from  allocation_role_Group b, W$allocation c,  W$Allocation_person d, allocations a
                 where d.pid = XLPL.GETPID   and d.role = b.code
	              and a.code =c.alloc_Code  and  a.role_group = b.parent_code and a.close_feature is Null
	              and b.feature = 1   and  c.Alloc_Code   <> XLPL.Alloc_Code
				  and  c.parent_rid  is null   and c.comp_part is null
	              and c.cid = XLPL.Cid  and c.rid  = d.allocation_rid  and c.stage  not in (2,3) )
    LOOP
--//	Step_Date = F_ArrayStepAid(pAID,$CID.string);
  	  Rab1.delete;
	  if (Step_Date.count = 0)
	  then Step_Date :=  B_F_ArrayStepAid(XLPL.AID, XLPL.CID);
	  else
		Rab1 := B_F_ArrayStepAid(XLPL.AID,XLPL.CID);
		for i IN 1 .. Rab1.count
		loop
		  Step_Date(Step_Date.count+1) := Rab1(i);
        end loop;
	  end if;
    end loop;
  end if;
  return Step_Date ;

END B_F_ARRAYSTEPINCASE;
/
