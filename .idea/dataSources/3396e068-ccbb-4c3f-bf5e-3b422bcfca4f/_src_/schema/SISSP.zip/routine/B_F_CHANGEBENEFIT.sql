CREATE FUNCTION       B_F_CHANGEBENEFIT(puskdate in date, Param6m in number) RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: F_ChangeBenefit
+ Наименование: определяет даты изменений назначений пособий
+ Автор: Трухтанов
+ Состояние на дату 24.06.1999
==============================================================================*/

chahge_date_metric DBMS_SQL.NUMBER_TABLE;
result_array DBMS_SQL.NUMBER_TABLE;
--Alloc_start date;
--Alloc_end date;
--Rabdate date;
flg_insert_result boolean;
datetalk date;
datetalk1 date;
i integer;
j integer;

BEGIN
  result_array.delete;
  chahge_date_metric.delete;

  datetalk := A_F_DataTalk();
  datetalk1 := Last_Day(S_CurrDate);

  for REC in (
  Select nvl(ALLOCATION_START, null) as Alloc_Start,
        nvl(ALLOCATION_END, null) as Alloc_End
  			  		from ALLOCATION a,
			 		     ALLOCATION_PERSON b,
			 		     CASE_PERSON c,
					     RECIPIENT d
			 		where
			 			   a.RID = b.ALLOCATION_RID and
						   a.ALLOC_STATUS = 1 and
			 		      b.PID = XLPL.GETPID and
			 		      c.PID = b.PID and
					      d.CID = c.CID and
					      d.PID = b.PID and
			 		     (c.STAGE <> 3 or c.STAGE is NULL) and
			 			  (a.STAGE <> 3 or a.STAGE is NULL) and
			 		     (b.STAGE <> 3 or b.STAGE is NULL) and
					     (d.STAGE <> 3 or d.STAGE is NULL) and
			 		      a.ALLOC_CODE in (select CODE
			 		                         from ALLOCATIONS
			 		                         start with CODE = 2
			 		                         connect by prior CODE = PARENT_CODE))
  LOOP
    if (REC.Alloc_Start != null) AND (REC.Alloc_start > PuskDate) AND
	   (REC.Alloc_start <= DateTalk1) then
	  if  (Param6m = 1)  			   	  	  	   	   			  	   				 -- Если превышено 6 месяцев со для возникновения права
        then chahge_date_metric(chahge_date_metric.count+1) := s_julian(s_EncodeDate(s_YearOfDate( DateTalk), S_MonthOfDate( DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		else chahge_date_metric(chahge_date_metric.count+1) := s_julian(REC.Alloc_start);
	  end if;
	end if;
	if (REC.Alloc_End != null) AND (REC.Alloc_End > PuskDate) AND
	   (REC.Alloc_End <= DateTalk1) then
	  if  (Param6m = 1)  			   	  	  	   	   			  	   			-- Если превышено 6 месяцев со для возникновения права
        then chahge_date_metric(chahge_date_metric.count+1) := s_julian(s_EncodeDate(s_YearOfDate( DateTalk), S_MonthOfDate( DateTalk), 1)); -- то выбрать начало месяца подачи заявления
		else chahge_date_metric(chahge_date_metric.count+1) := s_julian(REC.Alloc_End) + 1;
	  end if;
	end if;
  end loop;

----- избавимся от повторений -----
  for j in 1 .. chahge_date_metric.count
  loop
    flg_insert_result := true;
    for i in 1 .. result_array.count
	loop
	  if (chahge_date_metric(j) = result_array(i)) then
	    flg_insert_result := false;
	  end if;
      if (flg_insert_result) then
	    result_array (result_array.Count + 1) := chahge_date_metric(j);
      end if;
	end loop;
  end loop;
return result_array;
END B_F_CHANGEBENEFIT;
/
