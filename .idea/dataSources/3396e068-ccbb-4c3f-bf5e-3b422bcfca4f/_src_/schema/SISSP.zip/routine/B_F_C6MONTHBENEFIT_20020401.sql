CREATE FUNCTION       B_F_C6MonthBenefit_20020401 (dt IN DATE) RETURN DATE AS

/***************************************************************************************
// Функция: B_F_C6MonthBenefit_20020401
// Наименование: Функция котроля шести месяцев для пособий
// Автор: Гуз Е.
// Состояние на дату 01.02.1999
// Код возврата: дата наступления права
//***************************************************************************************/

  k_StartDate DATE;
BEGIN
  k_StartDate := ADD_MONTHS(dt, S_CONST(432, XLPL.WorkDate));
  if k_StartDate > XLPL.WorkDate then
    return dt;
  else
    return XLPL.WorkDate;
  end if;
END B_F_C6MonthBenefit_20020401;
/
