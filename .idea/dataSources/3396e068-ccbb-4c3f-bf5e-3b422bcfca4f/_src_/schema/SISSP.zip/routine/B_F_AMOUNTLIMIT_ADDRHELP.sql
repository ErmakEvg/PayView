CREATE FUNCTION       B_F_AmountLimit_AddrHelp return BOOLEAN is
/***************************************************************************************
// Функция: B_F_AmountLimit_AddrHelp
// Наименование: Функция, определяющая контроль на предельную сумму, при которой
//               допускается получение адресной социальной помощи 751
// Автор: Абрамович М.В.
// Состояние на дату 29.12.2011, 25.06.2014,14.07.2016(Denom),05.09.2016 AMV
//                   30.09.2016
// Код возврата: True - ССД меньше  установленной суммы, False - ССД больше
//               установленной суммы или ССД не вводилось вообще
//**************************************************************************************/
BPM_Now number; --БПМ на дату назначения  29.12.2011
--13.07.2016 BPM_Old number; --БПМ за прошлый квартал
Factor  number;
Crit_Need number; --Критерий нуждаемости
  SDD         NUMBER;
  SDD_Factor  NUMBER;
  CNT_RBD     NUMBER;
  CNT_OBD     NUMBER;
  Fl_BZ_RBD   NUMBER;
  Start_SDD   Date;
  DateWork    Date;
  DateTalk    Date;
  FL_RETURN   NUMBER; --для возврата XLPL.WorkDate --30.09.2016
begin
 DateTalk := A_F_DATATALK; --дата обращения  05.09.2016 AMV
 FL_RETURN:=0; --не меняли XLPL.WorkDate 30.09.2016
  if ((XLPL.NStep_Check<>0) AND (XLPL.INDIV<>2) --при отказе теряется XLPL.WorkDate
       AND ((EXTRACT(YEAR FROM DateTalk)<>EXTRACT(YEAR FROM XLPL.WorkDate))
       OR (EXTRACT(MONTH FROM DateTalk)<>EXTRACT(MONTH FROM XLPL.WorkDate)))
      ) then --05.09.2016 AMV
       --if  ((XLPL.CID =61514003039) AND (XLPL.NStep_Check<>0) ) then
       -- RAISE_APPLICATION_ERROR(-20801,'B_F_AmountLimit_AddrHelp    XLPL.WorkDate='||XLPL.WorkDate||'   BPM_Now='
        -- ||BPM_Now||'  SDD_Factor='||SDD_Factor||'   DateTalk='
        -- ||DateTalk||'  XLPL.INDIV='||XLPL.INDIV||'  XLPL.NStep_Check='||XLPL.NStep_Check);
      -- end if;
   DateWork:=XLPL.WorkDate; --по кнопке "отказ" XLPL.WorkDate не дата обращения и при нескольких шагах в назначении
   XLPL.WorkDate:=DateTalk;
   FL_RETURN:=1; --меняем XLPL.WorkDate 30.09.2016
  end if; --05.09.2016 AMV

 BPM_Now:=S_CONST(18, XLPL.WorkDate);
 Crit_Need:= BPM_Now;
 --13.07.2016 BPM_Old:=S_CONST(18, ADD_MONTHS(XLPL.WorkDate,-3));
 --13.07.2016 if BPM_Now < BPM_Old then Crit_Need:=BPM_Old; end if;
 -- Получение коэф.Factor из T_PARAM_ADDRHELP
 --***25.06.2014
  if XLPL.INDIV= 2 then  --INDIV=2 - массовый расчет
	begin
      select VALUE_FACTOR INTO Factor
	  from PARAM_ADDR_HELP a
	  where a.CID = XLPL.CID
       and (a.STAGE not in (2,3) or a.STAGE is null);
	  exception
        when NO_DATA_FOUND then
          Factor:= 1;
	  end;
  else
	begin
	  select VALUE_FACTOR INTO Factor
	  from W$PARAM_ADDR_HELP a
	  where a.CID = XLPL.CID
	    and a.STAGE not in (2,3);
      exception
        when NO_DATA_FOUND then
	      Factor:= 1;
	  end;
  end if;

  ------!!!!DENOM14.07.2016
  IF XLPL.INDIV= 2 then  --INDIV=2 - массовый расчет --its 20.08.2014
   SDD :=0;
   Start_SDD:=NULL;
   begin
     select distinct NVL(SSD,0),RECORD_START into SDD,Start_SDD
     from CASE_SUMMARY_INCOME
     where CID = XLPL.CID
     and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
     and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
     and NVL(STAGE,0) not IN (2,3);
   exception  --12.01.2016
        when NO_DATA_FOUND then
          SDD:=0;
   end;
 ELSE
  --**есть ли данные в РБД
     begin --22.03.2016
       select NVL(COUNT(SSD),0) INTO CNT_RBD --22.03.2016
       from w$CASE_SUMMARY_INCOME s
       where s.CID = XLPL.CID
              and NVL(s.RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
              and( (NVL(s.RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or( s.RECORD_END is null))
              and s.ENTERED_BY =XLPL.User_ID and NVL(s.STAGE,0) not IN (2,3);
      exception
        when NO_DATA_FOUND then
          CNT_RBD:= 0;
    end;
     if CNT_RBD = 0 then --находим по ОБД если нет в РБД
       begin
        select NVL(COUNT(SSD),0) INTO CNT_OBD --21.03.2016 NVL
                 from CASE_SUMMARY_INCOME
                 where CID = XLPL.CID
                      and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
                      and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
                      and NVL(STAGE,0) not IN (2,3);
       exception
        when NO_DATA_FOUND then
          CNT_OBD:= 0;
       end;
     end if;
  SDD:=0;
  Start_SDD:=null;
   if  ((CNT_RBD <> 0) OR (CNT_RBD <> 0)) then
      if CNT_RBD <> 0 then Fl_BZ_RBD:=1;
        else Fl_BZ_RBD:=0;
      end if; --есть SDD в РБД
     select distinct SSD,RECORD_START into SDD,Start_SDD
     from
        ( select  SSD,RECORD_START  --выборка по РБД --22.03.2016
         from w$CASE_SUMMARY_INCOME
         where CID = XLPL.CID
               and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
               and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
               and ENTERED_BY = XLPL.User_ID  and NVL(STAGE,0) not IN (2,3)
               and Fl_BZ_RBD=1
          union
         select  SSD,RECORD_START   --выборка по ОБД --22.03.2016
         from CASE_SUMMARY_INCOME
         where CID = XLPL.CID
               and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
               and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
               and NVL(STAGE,0) not IN (2,3)
               and Fl_BZ_RBD=0 );
  end if; --**

  END IF;
     --RAISE_APPLICATION_ERROR(-20851,'Отладка B_COAddrHelp751: SDD = ' || SDD);--masha
  if SDD<>0 then
     SDD_Factor:= SDD/Factor;
     SDD_Factor:=B_F_ModernSum (SDD_Factor,Start_SDD,XLPL.WorkDate);
  else
    SDD_Factor:= 0;
  end if;
--         if  ((XLPL.CID =61514003039) AND (XLPL.NStep_Check<>0) ) then
--        RAISE_APPLICATION_ERROR(-20801,'B_F_AmountLimit_AddrHelp    XLPL.WorkDate='||XLPL.WorkDate||'   BPM_Now='
 --        ||BPM_Now||'  SDD_Factor='||SDD_Factor||'   DateTalk='
 --        ||DateTalk||'  XLPL.INDIV='||XLPL.INDIV||'  XLPL.NStep_Check='||XLPL.NStep_Check);
 --       end if;
  ------!!!DENOM14.07.2016
 ----***
  -- Если ССД меньше  установленной суммы, то
  --25.06.2014 if (B_F_Denom(B_F_RelProtAmountSSD()/Xlpl.Factor_Correct_SDD) < Crit_Need) then
  --14.07.2016if (B_F_Denom(B_F_RelProtAmountSSD()/Factor) < Crit_Need) then
 /*30.09.2016  if ((XLPL.NStep_Check<>0) AND (XLPL.INDIV<>2)  --05.09.2016 AMV при отказе теряется XLPL.WorkDate
      AND ((EXTRACT(YEAR FROM DateTalk)<>EXTRACT(YEAR FROM XLPL.WorkDate))
       OR (EXTRACT(MONTH FROM DateTalk)<>EXTRACT(MONTH FROM XLPL.WorkDate)))
      ) then --05.09.2016 AMV */
  if FL_RETURN = 1 then    --30.09.2016
   XLPL.WorkDate:=DateWork;
   FL_RETURN:=0;
  end if;
  if SDD_Factor < Crit_Need then
    Return True;  -- возвратить "СДД меньше или равно установленной суммы"
  else
    Xlpl.Fl_Refuse_Family:=1;
    Return False;  -- иначе - "СДД больше установленной суммы"
  end if;
       -- if  ((XLPL.CID =40914005231) AND (XLPL.NStep_Check<>0) ) then
       -- RAISE_APPLICATION_ERROR(-20801,'B_F_AmountLimit_AddrHelp    XLPL.WorkDate='||XLPL.WorkDate||'   BPM_Now='
       --  ||BPM_Now||'  SDD_Factor='||SDD_Factor||'   XLPL.AID='
       --  ||XLPL.AID||'  XLPL.INDIV'||XLPL.INDIV||'  XLPL.NStep_Check='||XLPL.NStep_Check);
       -- end if;
end B_F_AmountLimit_AddrHelp;
/
