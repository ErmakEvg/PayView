CREATE FUNCTION       B_F_FormAllocationSteps04 RETURN DBMS_SQL.NUMBER_Table IS
/*==============================================================================
+ Функция: B_F_FormAllocationSteps04
+ Наименование: функция определяет шаги назначения по изменнениям для погибших
+ Автор: Ворошилин В.
+ Состояние на дату 18.10.2002
==============================================================================*/

pAID NUMBER;			   						   -- идентификатор назначения
pCID NUMBER;		   							   -- идентификатор дела
Param6m NUMBER;					   				   -- признак превышения 6 месяцев
j NUMBER;						   			   	   -- счетчик
prnew NUMBER;
prold NUMBER;
prdate DATE;
PuskDate DATE;					   				   -- рабочая дата
d1 DATE;				   					  	   -- дата, используемая для работы
rDate DATE;				   				   		   -- дата, используемая для работы
LimitDate DATE;
result_step_start DBMS_SQL.NUMBER_Table;		   -- массив, накапливающий даты шагов
result_array DBMS_SQL.NUMBER_Table;				   -- массив, содержащий готовые для возврата даты шагов (без повторений)
result_function DBMS_SQL.NUMBER_Table;			   -- массив, в который функции возвращают даты шагов
result_rab DBMS_SQL.NUMBER_Table;
aP DBMS_SQL.NUMBER_Table;

BEGIN

j := 0;
aP.delete;
pAID := XLPL.AID;
pCID := XLPL.CID;

--==============================================================================
-- установка рабочих признаков:
-- если ParamPervNazn = 1, то это первичное назначение, иначе назначение есть
-- если Param6m = 1, то значит дата обращения превышает на 6 мес. дату начала
-- 				  	 действия назначения, иначе дата обращения не превышает
--					 дату начала действия на 6 мес.
--==============================================================================

d1 := XLPL.WorkDate;
Param6m := 0;									-- обнулить признак не превышения на 6 мес. даты возникновения права
PuskDate := d1;									-- Установить дату начала формирования переломных точек

----- для всей группы -----

if pAID <> 0 then
   aP := B_F_ManageAllocStatus;
   if aP.count > 0 then
 	  prnew := aP(1);
 	  prold := aP(2);
 	  prdate := S_JTod(aP(3));
	  if prdate is not NULL then
	  	 result_step_start(result_step_start.count+1) := S_julian(prdate);
	  end if;
   end if;

   aP.delete;
   aP := A_F_ArrayAllocationStep(XLPL.WorkDate);
   if aP.count > 0 then
	 for k in 1..aP.Count loop						   		  -- в оригинале - индекс с нуля
	  	 if S_jtod(aP(k)) > PuskDate then
		 	result_step_start(result_step_start.count+1) := aP(k);
		 end if;
	 end loop;
	 aP.delete;
   end if;
end if;

if  XLPL.CheckRole(60) then
    XLPL.RoleDecl('Death','60');
else
    result_array.delete;
	return result_array;
end if;

XLPL.REPLACEROLE('Death');
result_function.delete;
result_function := B_F_ArrayDateChangePERSON(PuskDate, Param6m);
if result_function.count > 0 then
	 for j in 1..result_function.count loop
	 	 result_step_start(result_step_start.count+1) := result_function(j);
	 end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateChangeADDRESS(PuskDate, Param6m);
if result_function.count > 0 then
	 for j in 1..result_function.count loop
	 	 result_step_start(result_step_start.count+1) := result_function(j);
	 end loop;
end if;

result_function.delete;
result_function := B_F_ChangePension(PuskDate, Param6m);
if result_function.count > 0 then
	 for j in 1..result_function.count loop
	 	 result_step_start(result_step_start.count+1) := result_function(j);
	 end loop;
end if;

XLPL.RestoreRole;

result_rab.delete;
if prnew = 3 or prnew = 2 then
   LimitDate := prdate;
else
   LimitDate := B_F_LastStepAID(pAID, pCID);
end if;
for j in 1..result_step_start.count loop
	rDate := S_jtod(result_step_start(j));
	if rDate is not NULL and rDate > XLPL.WorkDate and rDate <= LimitDate then
	       result_rab(result_rab.count+1) := result_step_start(j);
	end if;
end loop;
result_step_start.delete;
for j in 1..result_rab.count loop
	result_step_start(result_step_start.count+1) := result_rab(j);
end loop;
result_rab.delete;

if result_step_start.count > 0 then
   XLPL.SETGLOBALFLOAT('Bullit', 1);
end if;

return A_F_ArrayDataChangeDelDup(result_step_start);

END B_F_FormAllocationSteps04;
/
