CREATE FUNCTION       A_F_RelProtActvDisMiss(AACTIVITY in VarChar2,ALABOR in VarChar2,
   ADISMISS_REASON in VarChar2) RETURN BOOLEAN IS
/*возвращает увольнялся ли человек согласно W$RELATION_PROTOCOL
Вахромин О.Ю.*/
xDRIDS DBMS_SQL.Number_Table;
xLABOR DBMS_SQL.Number_Table;
xD_REASON DBMS_SQL.Number_Table;
xACTIVITY DBMS_SQL.Number_Table;
c1 integer;
vsb integer;
vcount NUMBER;
BEGIN
   xACTIVITY:=S_ParseFloatArray(AACTIVITY);
   xLABOR:=S_ParseFloatArray(ALABOR);
   xD_REASON:=S_ParseFloatArray(ADISMISS_REASON);
   xDRIDS:=A_F_RelProtGetRIDActivity(1);
   if xLabor.count=0 then --Задан ACTIVITY и список связанный LABOR
      if xDRIDS.count<>0 then
         for i in 1..xDRIDS.count loop
            for ss1 in (select DISMISSAL_REASON from ACTIVITY where RID=xDRIDS(i) and
			   ACTIVITY=AACTIVITY and DISMISSAL_REASON is not NULL and
               PERIOD_END<=XLPL.WORKDATE) loop
			   if ADISMISS_REASON='' then
                  return true;
               else
                  if S_NumInSet(ss1.DISMISSAL_REASON,ADISMISS_REASON) then
                     return true;
                  end if;
               end if;
            end loop;
         end loop;
      else
         for i in 1..xDRIDS.count loop
	        for m in 1..xLABOR.count loop
               for ss1 in (select DISMISSAL_REASON from ACTIVITY where
                  RID=xDRIDS(i) and ACTIVITY=AACTIVITY and LABOR=xLABOR(m) and
			      DISMISSAL_REASON is not NULL and PERIOD_END<=XLPL.WORKDATE) loop
			      if ADISMISS_REASON='' then
                     return true;
	              else
                     if S_NumInSet(ss1.DISMISSAL_REASON,ADISMISS_REASON) then
                        return true;
                     end if;
                  end if;
               end loop;
            end loop;
         end loop;
      end if;
   end if;
   xDRIDS:=A_F_RelProtGetRIDActivity(0);
   if xLabor.count=0 then --Задан ACTIVITY и список связанный LABOR
      if xDRIDS.count<>0 then
         for i in 1..xDRIDS.count loop
            for k in 1..xACTIVITY.count loop
               for ss1 in (select DISMISSAL_REASON from w$ACTIVITY where RID=xDRIDS(i) and
	              ACTIVITY=xACTIVITY(k) and ENTERED_BY=XLPL.USER_ID and
                  DISMISSAL_REASON is not NULL and
                  PERIOD_END<=XLPL.WORKDATE) loop
                  if ADISMISS_REASON='' then
                     return true;
                  else
                     if S_NumInSet(ss1.DISMISSAL_REASON,ADISMISS_REASON) then
                        return true;
                     end if;
                  end if;
               end loop;
            end loop;
         end loop;
      else
         for i in 1..xDRIDS.count loop
            for k in 1..xACTIVITY.count loop
               for m in 1..xLABOR.count loop
                  for ss1 in (select DISMISSAL_REASON from w$ACTIVITY where
                     RID=xDRIDS(i) and ACTIVITY=xACTIVITY(k) and LABOR=xLABOR(m) and
                     ENTERED_BY=XLPL.USER_ID and
                     DISMISSAL_REASON is not NULL and PERIOD_END<=XLPL.WORKDATE) loop
                     if ADISMISS_REASON='' then
                        return true;
                     else
                        if S_NumInSet(ss1.DISMISSAL_REASON,ADISMISS_REASON) then
                           return true;
                        end if;
                     end if;
                  end loop;
               end loop;
            end loop;
         end loop;
      end if;
   end if;
   return false;
END A_F_RelProtActvDisMiss;
/
