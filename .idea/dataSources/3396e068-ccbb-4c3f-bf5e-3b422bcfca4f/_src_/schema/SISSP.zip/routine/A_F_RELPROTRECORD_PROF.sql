CREATE FUNCTION       A_F_Relprotrecord_Prof (pCODE IN NUMBER) RETURN NUMBER IS
/***************************************************************************************
 Функция                 : A_F_Relprotrecord_Prof
 Наименование        : Возвращает стаж  согласно кода
 Автор                      : ОЛВ
 Состояние на дату   : 10.12.2009   17.05.2013
 Код возврата           :
***************************************************************************************/
BEGIN
  IF (Xlpl.INDIV <>2) THEN -- не массовый расчет -- 17.05.2013 OLV
     RETURN A_F_Relprotgetbyridrecordprof(0,pCODE); -- Выбрать в РБД
 ELSE
     RETURN A_F_Relprotgetbyridrecordprof(1,pCODE); -- Выбрать в ОБД
 END IF;
  -- 17.05.2013 OLV --RETURN A_F_Relprotgetbyridrecordprof(0,pCODE)+A_F_Relprotgetbyridrecordprof(1,pCODE);
END A_F_Relprotrecord_Prof;
/
