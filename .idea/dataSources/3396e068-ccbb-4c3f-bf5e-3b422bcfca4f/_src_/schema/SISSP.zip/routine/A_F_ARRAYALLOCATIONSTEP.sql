CREATE FUNCTION       A_F_ArrayAllocationStep(RecDat in date)
   RETURN DBMS_SQL.Number_Table IS
/*Масcив шагов по старому назначению
Вахромин О.Ю.*/
AllocStep DBMS_SQL.Number_Table;
BEGIN
   AllocStep.delete;
   for c1 in (Select Step_Start from ALLOCATION Where
      Cid=XLPL.Cid and Aid=XLPL.Aid and Close_Date Is Null And
      Step_Start>RecDat and PARENT_RID is NULL and
      Comp_Part is NULL and stage is null and Step_Start is not NULL) loop
      AllocStep(AllocStep.count+1):=s_julian(c1.Step_Start);
   end loop;
   return AllocStep;
END A_F_ArrayAllocationStep;
/
