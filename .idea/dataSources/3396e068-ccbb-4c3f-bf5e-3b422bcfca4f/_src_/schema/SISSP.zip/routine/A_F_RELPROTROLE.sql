CREATE FUNCTION       A_F_RelProtRole(aRole_Codes in VARCHAR)
                                                               RETURN BOOLEAN IS
--==============================================================================
-- Назначение: возвращает TRUE, если в CASE_PERSON's согласно W$RELATION_PROTOCOL
--             есть хотя бы одна запись ролью из списка aRole_Codes
--          Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
--------------------------------------------------------------------------------
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Входные праметры:
---------------------
--  aRelation - список кодов отношения
--==============================================================================

xResume BOOLEAN;
xRID DBMS_SQL.Number_Table;
xRole DBMS_SQL.Number_Table;
curr_Role NUMBER;
curr_RID NUMBER;
i NUMBER;
k NUMBER;
l NUMBER;
m NUMBER;
xCount NUMBER;
xUser NUMBER;

BEGIN
xResume := False;
xUser := XLPL.USER_ID;
xRole.Delete;
xRole := S_ParseFloatArray(aRole_Codes);
xRID.Delete;
xRID := A_F_RelProtGetRIDCasePerson;
k := xRole.Count;
m := xRID.Count;
if m <> 0 then
  FOR i IN 1..k LOOP
    if xResume = True then
	  EXIT;
	end if;
    curr_Role := xRole(i);
    FOR l IN 1..m LOOP
      curr_RID := xRID(l);
      select count(*) into xCount
	  from CASE_PERSON
	  where RID = curr_RID
	  and ROLE = curr_Role;
	  if xCount > 0 then
	    xResume := True;
		EXIT;
	  end if;
    END LOOP;
  END LOOP;
end if;
if xResume = False then
  xRID.Delete;
  xRID := A_F_RelProtGetRIDWCasePerson;
  m := xRID.Count;
  if m <> 0 then
    FOR i IN 1..k LOOP
      if xResume = True then
	    EXIT;
	  end if;
      curr_Role := xRole(i);
      FOR l IN 1..m LOOP
        curr_RID := xRID(l);
		select count(*) into xCount
		from W$CASE_PERSON
	    where RID = curr_RID
		and ENTERED_BY = xUser
		and ROLE = curr_Role;
	    if xCount > 0 then
	      xResume := True;
		  EXIT;
	    end if;
      END LOOP;
    END LOOP;
  end if;
end if;
RETURN xResume;
END A_F_RelProtRole;
/
