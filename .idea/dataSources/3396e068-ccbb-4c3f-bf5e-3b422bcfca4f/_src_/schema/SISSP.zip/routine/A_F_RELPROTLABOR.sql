CREATE FUNCTION       A_F_RelProtLabor(AACTIVITY in VarChar2,ALABOR in VarChar2)
   RETURN NUMBER IS
/***************************************************************************************
 Функция             :  A_F_RelProtLabor
 Наименование        :  Функция выполняет УТОЧНЕНИЕ ХАРАКТЕРА РАБОТЫ (СПРАВОЧНИК LABOR_TYPE)
 Автор               :  ОЛВ                  на основ. Вахромин О.Ю.
 Состояние на дату   :  05.05.1999		 			  				 18.02.2011
***************************************************************************************/
 xDRIDS    DBMS_SQL.Number_Table;
 xLABOR    DBMS_SQL.Number_Table;
 xACTIVITY DBMS_SQL.Number_Table;
 vACTIVITY NUMBER;
 vLABOR    NUMBER;
BEGIN

  vACTIVITY:=0;
  xACTIVITY:=S_ParseFloatArray(AACTIVITY);
  xLABOR:=S_ParseFloatArray(ALABOR);
  xDRIDS:=A_F_RelProtGetRIDActivity(0);
 for i in 1..xDRIDS.count loop
	  if (xLABOR.count=0) then -- нет кодов нижнего уровня
         for m in 1..xACTIVITY.count loop
            for ss1 in ( select LABOR
			               from w$ACTIVITY
						  where RID=xDRIDS(i)
						    and ACTIVITY=xACTIVITY(m)
							and XLPL.Workdate between nvl(PERIOD_START,XLPL.Workdate) and nvl(PERIOD_END,XLPL.Workdate))
			loop
               if ss1.LABOR is not null then -->0 then
			      vACTIVITY:=ss1.LABOR;
--RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtLabor    3   ss1.LABOR='||ss1.LABOR||'   vACTIVITY='||vACTIVITY);
             --     return vACTIVITY;
               end if;
            end loop;
         end loop;
	  else -- есть кода нижнего уровня
         for m in 1..xACTIVITY.count loop
            for l in 1..xLABOR.count loop
               select LABOR into vLABOR
			     from w$ACTIVITY
				where RID=xDRIDS(i)
			      and ACTIVITY=xACTIVITY(m)
				  and LABOR=xLABOR(l)
				  and XLPL.Workdate between nvl(PERIOD_START,XLPL.Workdate) and nvl(PERIOD_END,XLPL.Workdate);
               if vLABOR>0 then
			      vACTIVITY:=vLABOR;
               end if;
            end loop;
         end loop;
      end if;
   end loop;
--RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtLabor    3   xDRIDS.count='||xDRIDS.count||'   vACTIVITY='||vACTIVITY);
  return vACTIVITY;
END A_F_RelProtLabor;
/
