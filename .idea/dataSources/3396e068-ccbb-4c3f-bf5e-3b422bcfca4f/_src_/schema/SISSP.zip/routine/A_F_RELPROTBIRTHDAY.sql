CREATE FUNCTION       A_F_RelProtBirthday RETURN DATE IS
/*Возращает дату рождения по W$RELATION_PROTOCOL
Вахромин О.Ю.*/
vsDRID NUMBER;
vBirthDay DATE;
BEGIN
   vBirthDay:=NULL;
   vsDRID:=A_F_RelProtGetRIDPerson(1);
   if vsDRID<>-1 then
      select BIRTH_DATE into vBirthDay from PERSON where RID=vsDRID;
      return vBirthDay;
   else
      vsDRID:=A_F_RelProtGetRIDPerson(0);
      if vsDRID<>-1 then
         select BIRTH_DATE into vBirthDay from W$PERSON where RID=vsDRID and
            ENTERED_BY=XLPL.User_ID;
         return vBirthDay;
      else
         RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtBirthday:'||chr(10)||
            'Нет DATA_RID в W$RELATION_PROTOCOL для данных CID='||to_char(XLPL.CID));
      end if;
   end if;
END A_F_RelProtBirthday;
/
