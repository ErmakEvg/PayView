CREATE FUNCTION       B_F_GetMinDelAllWAbsent return DATE is
/**********************************************************************************************
 Функция           : B_F_GetMinDelAllWAbsent
 Наименование      : функция определяет дата STEP_START из ALLOCATION
 Автор             : Ворошилин В.  Перевод на PLS/QL: Сманцер Ю.А.        Корректировка: ОЛВ
 Состояние на дату : 26.07.2000                15.07.2002                           20.08.2011
 Код возврата      : дата STEP_START из ALLOCATION для записей со STAGE = 3 из W$ABSENCE_PERSON
 	 			   	 по всем PID -ам из CASE_PERSON
***********************************************************************************************/
 vsBNo       number;
 vsDate      date := null;
 vsMinDate   date := null;
 alloc_date  date;
begin
  vsBNo := S_CodeTableSISSP('W$ABSENCE_PERSON');

  for c1 in (select RID as vsRID
               from W$ABSENCE_PERSON   -- ВРЕМЯ ОТСУТСТВИЯ ЛИЦА В ДИ, ЗОНЕ ЗАГРЯЗНЕНИЯ
              WHERE PID =  XLPL.GetPID
			     AND ADDRESS_RID = (SELECT RID
  		 	                          FROM W$ADDRESS
                                     WHERE PID = XLPL.GetPID
								       AND STAGE IN (1, 4)
									   AND ADDRESS_TYPE IN (2, 3) -- 18.08.2011 OLV  -- заплатка (если 2 записи - ошибка)
									   AND ENTERED_BY = XLPL.User_ID)
			   AND STAGE = 3  -- не понимаю -   ????
			   AND ENTERED_BY = XLPL.User_ID) loop

    vsDate := B_F_GetMinDateByRelRid(XLPL.CID, XLPL.AID, vsBNo, c1.vsRID);

    if (vsMinDate is null) then
	  vsMinDate := vsDate;
	else
	  if (vsMinDate < vsDate) then
	    vsMinDate := vsDate;
	  end if;
	end if;
  end loop;

  alloc_date := B_F_StartDateAllocation();

  if (not (vsMinDate is null)) and (vsMinDate > alloc_date) then
    return vsMinDate;
  else
    return null;
  end if;
end;
/
