CREATE FUNCTION       A_P_SIZEMINPENS RETURN NUMBER AS
/*******************************************************************************
 Функция           : A_P_SIZEMINPENS
 Наименование      : Ветвление по датам ф-ии
                     исчисления размера пенсии в минимальном размере
 Автор             : Вахромин О.Ю.         Коментарии и корректировка : ОЛВ
 Состояние на дату :                                            17.03.2016
 Код возврата      : пенсия в минимальном размере
********************************************************************************/
BEGIN
 IF XLPL.WorkDate>=to_date('01-07-2016','DD-MM-YYYY') then
    return A_P_SIZEMINPENS_20160701; -- Деноминация /10000
 ELSE
    if XLPL.WorkDate<to_date('01-01-2000','DD-MM-YYYY') then
      return A_P_SIZEMINPENS_0;
    else
      return A_P_SIZEMINPENS_20000101;
    end if;
 END IF;
END A_P_SIZEMINPENS;
/
