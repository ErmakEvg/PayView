CREATE FUNCTION       B_F_Arraydatechangemetricmon(pCode NUMBER, PuskDate DATE, Param6m NUMBER)
RETURN DBMS_SQL.NUMBER_TABLE IS
/**********************************************************************************************
 Функция            : B_F_ARRAYDATECHANGEMETRICMON
 Наименование       : функция возращает массив дат изменеия характеристик для одной
 					  характеристики с CODE = pCode
 Автор              : Трухтанов             Комментарии и корректировка: ОЛВ	РАВ
 Состояние на дату  : 03.05.1999           19.03.2012							24.09.2013
 Код возврата       : массив даты шагов
***********************************************************************************************/
 chahge_date_metric   DBMS_SQL.NUMBER_TABLE;
 metric_start 		  DATE;
 metric_end 		  DATE;
 Rabdate 			  DATE;
 datetalk 			  DATE;
 DateTalk1 			  DATE;
BEGIN
  chahge_date_metric.DELETE;
  datetalk := A_F_Datatalk;
  DateTalk1 := LAST_DAY(S_Currdate);
  --  select Last_Day(sysdate) into DateTalk1 from dual;
--RAISE_APPLICATION_ERROR(-20801,' B_F_Arraydatechangemetricmon   2' ||CHR(10) ||'    datetalk ='||datetalk  ||CHR(10) ||'     DateTalk1 ='||DateTalk1  );

  FOR rec IN (
      SELECT NVL(RECORD_START, NULL) AS metric_start, NVL(RECORD_END, NULL) AS metric_end
  	  FROM   W$PERSON_METRIC
      WHERE  PID = Xlpl.GETPID
            AND CODE = pCode
		    AND STAGE IN (1, 4)
         -- AND  (RECORD_START > PuskDate OR RECORD_START IS NULL)
         --  AND (RECORD_END <= PuskDate OR RECORD_END IS NULL)
		 --  AND  (RECORD_START > PuskDate OR RECORD_END > PuskDate)
		 AND    ENTERED_BY = Xlpl.USER_ID
			 )
  LOOP

    IF rec.metric_start IS NOT NULL AND rec.metric_start > PuskDate AND rec.metric_start <= DateTalk1 THEN
    		IF  (Xlpl.AID = 0) AND (Param6m = 1) THEN		-- Если превышено 6 месяцев со дня возникновения права
          		chahge_date_metric(chahge_date_metric.COUNT+1) := S_Julian(S_Encodedate(S_Yearofdate(DateTalk), S_Monthofdate(DateTalk), 1));
		  	ELSE
		     -- 145 - Находится в браке (в повторном браке)
		  	 -- 154 - Проживает, ведет хозяйство и воспитывает ребенка совместно с отцом ребенка
		  	 -- 259 - Ребенок посещает детское дошкольное учреждение - ОЛВ 19.03.2012
		  	  IF (pCode = 145) OR (pCode = 154) OR (pCode = 259) THEN
		         -- Нужно с первого числа месяца  следующего за месяцем оформления
      	  	     chahge_date_metric(chahge_date_metric.COUNT+1) := S_Julian(LAST_DAY(rec.metric_start) + 1);
			  ELSE
              -- RAISE_APPLICATION_ERROR(-20801,' B_F_Arraydatechangemetricmon ++  2' ||CHR(10) ||'    datetalk ='||datetalk  ||CHR(10) ||'     DateTalk1 ='||DateTalk1  );

		  	     if (Xlpl.AID = 0) then chahge_date_metric(chahge_date_metric.COUNT+1) := S_Julian(rec.metric_start);
                 else chahge_date_metric(chahge_date_metric.COUNT+1) := S_Julian(LAST_DAY(rec.metric_start)+1);
                 end if;
			  END IF;
		  END IF;
	END IF;

    IF rec.metric_end IS NOT NULL AND rec.metric_end >= PuskDate AND rec.metric_end <= DateTalk1 THEN --корректировка 24.09.2013 РАВ (было =)
	--IF rec.metric_end IS NOT NULL AND rec.metric_end > PuskDate AND rec.metric_end <= DateTalk1 THEN
		  IF (Xlpl.AID = 0) AND (Param6m = 1 ) THEN -- Если превышено 6 месяцев со дня возникновения права
             chahge_date_metric(chahge_date_metric.COUNT+1) := S_Julian(S_Encodedate(S_Yearofdate(DateTalk), S_Monthofdate(DateTalk), 1));
		  ELSE
	 	  	  IF pCode = 148 OR
		      	 pCode = 171 OR
			 	 pCode = 320 OR
		     	 pCode = 121 OR
			 	 pCode = 122 OR
			 	 pCode = 125 OR
			 	 pCode = 126 THEN
		         -- Нужно с первого числа месяца  следующего за месяцем оформления
	 	  	 	 chahge_date_metric(chahge_date_metric.COUNT+1) := S_Julian(LAST_DAY(rec.metric_end) + 1);
			   ELSE
			      if (Xlpl.AID = 0) then chahge_date_metric(chahge_date_metric.COUNT+1) := S_Julian(rec.metric_end) + 1;
                  else chahge_date_metric(chahge_date_metric.COUNT+1) := S_Julian(LAST_DAY(rec.metric_start)+1); end if;
		       END IF;
	      END IF;
	END IF;
  END LOOP;
 RETURN A_F_Arraydatachangedeldup(chahge_date_metric);

END B_F_Arraydatechangemetricmon;
/
