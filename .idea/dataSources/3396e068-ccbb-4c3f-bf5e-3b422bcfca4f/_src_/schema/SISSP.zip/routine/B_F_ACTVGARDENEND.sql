CREATE FUNCTION       B_F_ActvGardenEnd RETURN DATE AS

/***************************************************************************************
// Функция: B_F_ActvGardenEnd
// Наименование: Функция определения даты окончания посещения детского сада ребенком
// Автор: Ворошилин В.
// Состояние на дату 06.11.20
// Возвращает: Дату окончания посещения детского сада
//***************************************************************************************/

  ACTEND DATE;
BEGIN
  begin
    Select max(PERIOD_END) INTO ACTEND From  W$ACTIVITY
	Where PID = XLPL.GetPid
	and ACTIVITY = 2
	and LABOR = 221
	and ENTERED_BY = XLPL.User_ID
	and STAGE NOT IN(2,3);
	exception
	  when NO_DATA_FOUND then
	    ACTEND := NULL;
  end;
  if ACTEND is NULL then
    begin
	  Select max(PERIOD_END) INTO ACTEND From  ACTIVITY
	    Where PID = XLPL.GetPid
		and ACTIVITY = 2
		and LABOR = 221
		and STAGE NOT IN(2,3);
	  exception
	    when NO_DATA_FOUND then
	      ACTEND := NULL;
    end;
  end if;
  return ACTEND;
END B_F_ActvGardenEnd;
/
