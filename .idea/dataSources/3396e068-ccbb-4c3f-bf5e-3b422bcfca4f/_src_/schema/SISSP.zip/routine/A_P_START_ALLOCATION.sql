CREATE FUNCTION       A_P_Start_Allocation RETURN DATE AS
/*******************************************************************************
 Функция           : A_P_Start_Allocation
 Наименование      : Функция определения даты начала действия назначения
 Автор             : ОЛВ
 Состояние на дату : 03.10.2011   10.07.2014    03.02.2017
 Код возврата      : предположительная дата действия назначения
********************************************************************************/
 Start_Allocation DATE;
BEGIN
  Start_Allocation := Xlpl.WorkDate;
 IF Xlpl.AID <> 0  THEN -- перерасчет
   BEGIN
     SELECT allocation_start
       INTO Start_Allocation
       FROM ALLOCATION
      WHERE cid = Xlpl.CID
        AND aid = Xlpl.AID
        AND close_Date IS NULL
        AND alloc_status = 1
        AND parent_rid IS NULL
        AND comp_part IS NULL
        AND step_start =
              ( SELECT min(a.step_start) -- считать, что был пенсионером, если относится к одной группе- если будут проблемы - буду думать
                  FROM ALLOCATION a, ALLOCATIONS al, ALLOCATIONS an
                 WHERE a.cid = Xlpl.CID
                   AND a.aid = Xlpl.AID
                   AND a.Close_Date IS NULL
                   AND a.alloc_status = 1
                   AND a.parent_rid IS NULL
                   AND a.comp_part IS NULL
                AND a.alloc_code = al.code
                AND Xlpl.ALLOC_CODE = an.code
                AND ((al.parent_code=an.parent_code)
                or (al.code=50)    -- 03.02.2017 -- OLV
                or (Xlpl.ALLOC_CODE=50))
                );
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
          Start_Allocation := Xlpl.WorkDate;
     WHEN TOO_MANY_ROWS THEN
          RAISE_APPLICATION_ERROR(-20801,'A_P_Start_Allocation:  Cуществует некорректная запись в ALLOCATION');
   END;
 END IF;
    RETURN Start_Allocation;
END A_P_Start_Allocation;
/
