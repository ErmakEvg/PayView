CREATE FUNCTION       A_F_RELPROTDISREASON_VSL
(
AOPINION_TYPE in number,
AADVICE_TYPE in varchar2,
AADIS_REASON in varchar2,
ASTART_DATE in date
)
 RETURN boolean IS
/* --------------------------------------------------------------------
// Автор: Трухтанов.
// состояние на 01.06.1999
// Код возврата: возвращает True, если учеловека есть указанная причина инвалидности
//               по коду согласно W$RELATION_PROTOCOL
//
//     Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
//     AOPINION_TYPE - одно значение (при -1 - игнорируется)
//     при AADVICE_TYPE = "" будет игнорироваться, иначе интерпритируется как список параметров
// -------------------------------------------------------------------*/

DRIDS DBMS_SQL.number_table;
vsDRID number;
xADVICE_TYPE DBMS_SQL.number_table;
--vsADVICE_TYPE number;
xDIS_REASON  DBMS_SQL.number_table;
--vsDIS_REASON number;
i integer;
l integer;
BEGIN

  if (AADIS_REASON = '') then
    return false;
--    raise APPLICATION_ERROR('F_RelProtDisabilityReason: не указан обязательный параметр ADIS_REASION');
  end if;
  xADVICE_TYPE := S_ParseFloatArray (AADVICE_TYPE);
  xDis_REASON  := S_ParseFloatArray (AADIS_REASON);

  DRIDS := A_F_RelProtGetRIDMrakOpAdvice (1, AOPINION_TYPE);
  if (DRIDS.count > 0)
  then
    for i in DRIDS.First .. DRIDS.Last
	LOOP
	  if DRIDS.exists(i) then
        vsDRID := DRIDS(i);
--		vsADVICE_TYPE, vsDIS_REASON
	      for c1 in(
	        select ADVICE_TYPE as vsADVICE_TYPE, DIS_REASON as vsDIS_REASON from MRAK_OPINION_ADVICE a, MRAK_OPINION b
	        where
		    a.RID = vsDRID and
		    b.RID = MRAK_RID and
		    NVL (NVL(a.RECORD_START,b.EXAMED_FROM), ASTART_DATE) <=  ASTART_DATE and
		    NVL (NVL(a.RECORD_END,a.DIS_TERM),ASTART_DATE) >= ASTART_DATE)
		  loop
 	        if xADVICE_TYPE.count = 0 -- не заданы коды нижнего уровня
	        then
	          for l in xDIS_REASON.FIRST .. xDIS_REASON.LAST
		      LOOP
		        if xDIS_REASON.exists(i) then
	              if (trunc(xDIS_REASON(l)) = c1.vsDIS_REASON)
			      then
			        return true;
			      end if;
		        end if;
		      end loop;
	        else
	        for m in xADVICE_TYPE.FIRST .. xADVICE_TYPE.LAST
		    LOOP
  	          for l in xDIS_REASON.FIRST .. xDIS_REASON.LAST
		      LOOP
	            if ((trunc(xDIS_REASON(l)) = c1.vsDIS_REASON) AND (trunc(xADVICE_TYPE(m)) = c1.vsADVICE_TYPE))
			    then
			      return true;
			    end if;
		      end loop;
		    end loop;
		  end if;
	    end loop;
      end if;
	end loop;
  end if;

  DRIDS := A_F_RelProtGetRIDMrakOpAdvice (0, AOPINION_TYPE);

  if DRIDS.count > 0
  then
    for i in DRIDS.FIRST .. DRIDS.LAST
	LOOP
      vsDRID := DRIDS(i);
--	  (vsADVICE_TYPE, vsDIS_REASON)
	  for c2 IN(
	    select ADVICE_TYPE as vsADVICE_TYPE, DIS_REASON as vsDIS_REASON from W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
	         where
		     a.RID = vsDRID and
		     a.ENTERED_BY = XLPL.USER_ID and
		     b.RID = MRAK_RID and
		     b.ENTERED_BY = MRAK_ENTERED_BY and
		     NVL (NVL(a.RECORD_START,b.EXAMED_FROM), ASTART_DATE) <= ASTART_DATE and
		     NVL (NVL(a.RECORD_END,a.DIS_TERM), ASTART_DATE) >= ASTART_DATE)
	  LOOP
	    if xADVICE_TYPE.count = 0   then -- // не заданы коды нижнего уровня
	       for l in xDIS_REASON.FIRST .. xDIS_REASON.LAST   LOOP
	          if trunc(xDIS_REASON(l)) = c2.vsDIS_REASON 	then
			           return true;
			      end if;
		     end loop;
	    else
	      for m in xADVICE_TYPE.FIRST .. xADVICE_TYPE.LAST  LOOP
		       if xADVICE_TYPE.exists(m)   then
		          for l in xDIS_REASON.FIRST .. xDIS_REASON.LAST   LOOP
			           if  xDIS_REASON.exists(l) then
			             if (trunc(xDIS_REASON(l)) = c2.vsDIS_REASON) AND (trunc(xADVICE_TYPE(m)) = c2.vsADVICE_TYPE)  then
				              return true;
				           end if;
			           end if;
			        end loop;
		       end if;
		    end loop;
		  end if;
	  end loop;
	end loop;
  end if;
  return false;
END A_F_RELPROTDISREASON_VSL;
/
