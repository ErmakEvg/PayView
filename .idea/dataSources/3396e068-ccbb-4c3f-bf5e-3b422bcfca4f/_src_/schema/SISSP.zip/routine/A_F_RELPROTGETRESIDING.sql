CREATE FUNCTION       A_F_RelprotGetRESIDING(Base_ID in NUMBER) RETURN NUMBER AS
/*******************************************************************************
 NAME              : A_F_Relprotgetrid_RESIDING
 Назначение        : Возращает из PERSON_RESIDING_FEATURE
                                согласно W$RELATION_PROTOCOL
 Автор             : ОЛВ
 Состояние на дату : 25.03.2013    01.11.2016
 Код возврата      : RID из PERSON_RESIDING_FEATURE  01.11.2016
********************************************************************************/
 vPrice         NUMBER;
 xWorkDate      DATE;
BEGIN
 begin
   vPrice:=0;
   xWorkDate := ADD_MONTHS(Xlpl.WorkDate, -1);
   IF xWorkDate<A_P_Start_Alloc THEN xWorkDate:=A_P_Start_Alloc; END IF; -- 01.11.2016 OLV
   if Base_ID=0 then
         select NVL(Price,-1)
           into vPrice
           from W$PERSON_RESIDING_FEATURE
          where PID = XLPL.GetPid
            and STAGE not in (2, 3)
            and ENTERED_BY=XLPL.USER_ID -- ???
            and xWorkDate between
                 NVL(PERIOD_START,xWorkDate) and NVL(PERIOD_END,xWorkDate);
      else
         select NVL(Price,-1)
           into vPrice
           from PERSON_RESIDING_FEATURE
          where PID = XLPL.GetPid
            and STAGE is null
            and xWorkDate between
                 NVL(PERIOD_START,xWorkDate) and NVL(PERIOD_END,xWorkDate);
      end if;

   exception
      when NO_DATA_FOUND then
         vPrice:=-1;
   end;
   return vPrice;
END A_F_RelprotGetRESIDING;
/
