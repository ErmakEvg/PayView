CREATE FUNCTION       A_F_RELPROTCOUNTPERSON(ACODE_ROLE in NUMBER,pWorkDate in DATE) RETURN BINARY_INTEGER AS
/***************************************************************************************
 Функция           :  A_F_RELPROTCOUNTPERSON
 Наименование      : Получение количества членов семьи,состоящих на иждивении у кормильца
 Автор             : Боровнева             Корректировка ОЛВ 18.11.2009 pWorkDate in Date
 Состояние на дату : 17.05.1999
 Код возврата      : количество человек проходящих по делу с ролью ACODE_ROLE
              Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
****************************************************************************************/

  xDRIDS        DBMS_SQL.NUMBER_TABLE;
  vsDRID        NUMBER;
  pCount        NUMBER;
  Count_Person  BINARY_INTEGER;

BEGIN

  xDRIDS.delete;
  pCount := 0;
  Count_Person := 0;

  -- RID из CASE_PERSON согласно коду по W$RELATION_PROTOCOL
  xDRIDS := A_F_RelProtGetRIDCasePersonPid;

  if xDRIDS.count <> 0 then

    for i in 1..xDRIDS.count loop
	  vsDRID := xDRIDS(i);

	  select count(*) into pCount
	  from CASE_PERSON a, PERSON b
	  where a.RID = vsDRID
	    and	a.PID = b.pid
		and b.stage is null
		and b.BIRTH_DATE <= pWorkDate --XLPL.WorkDate ОЛВ 18.11.2009
		and a.ROLE = ACODE_ROLE;

	  Count_Person := Count_Person + TRUNC(pCount);
    end loop;

  end if;

  -- RID из W$CASE_PERSON согласно коду по W$RELATION_PROTOCOL
  xDRIDS := A_F_RelProtGetRIDWCasePersPid;

  if xDRIDS.count <> 0 then

    for i in 1..xDRIDS.count loop
	  vsDRID := xDRIDS(i);

	  select count(*) into pCount
	  from W$CASE_PERSON a, W$PERSON b
	  where a.RID = vsDRID
		and a.ENTERED_BY = XLPL.USER_ID
		and a.PID = b.pid
		and b.ENTERED_BY = XLPL.USER_ID
		and b.stage in (1,4)
		and b.BIRTH_DATE <= pWorkDate --XLPL.WorkDate ОЛВ 18.11.2009
		and a.ROLE = ACODE_ROLE;

	  Count_Person := Count_Person + TRUNC(pCount);
	end loop;

  end if;

  return Count_Person;

END A_F_RELPROTCOUNTPERSON;
/
