CREATE FUNCTION       A_F_RelProtGender RETURN NUMBER IS
/*Вернуть пол PID-а по W$RELATION_PROTOCOL
Вахромин О.Ю.*/
vsDRid number;
vSex number;
BEGIN
   vsDRid:=A_F_RelProtGetRIDPerson(1);
   if (vsDRid<>-1) then
      select SEX into vSex from PERSON where RID=vsDRid;
   else
      vsDRID:=A_F_RelProtGetRIDPerson(0);
      if (vsDRID<>-1) then
         select SEX into vSex from w$PERSON where RID=vsDRid
		   and ENTERED_BY = XLPL.USER_ID; -- elena 16.05.2011
      else
         RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtGender:'||chr(10)||
            'Нет DATA_RID в W$RELATION_PROTOCOL для данных CID='||to_char(XLPL.CID));
      end if;
   end if;
   return vSex;
END A_F_RelProtGender;
/
