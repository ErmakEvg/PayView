CREATE FUNCTION       B_F_GetMinDateByRelRid(ACID in varchar2, AAID in number,
  ARELATION_TABLE in number, ARID in number) return DATE is
/* ---------------------------------------------------------------------------------------
// F_GetMinDateByRelRid
// Автор Басинюк Я.В.
// состояние на 5.05.99
// возращает дату Step_start для указаной таблицы и ее RID а
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 15.07.2002
// --------------------------------------------------------------------------------------*/

  vsMaxEDate date := null;
  vsMinDate date := null;
  vsDate date := null;
begin
  begin
	for c1 in (select RID as vsAllocRid,
	                  NVL(STEP_START, ALLOCATION_START) vsDate,
					  ENTRY_DATE as vsEDate
	           from ALLOCATION
		       where CID = ACID
			     and AID = AAID) loop
	  vsDate := c1.vsDate;

	  if (not vsDate is null) then
    	if (B_F_IsRIDinDATARID (ARELATION_TABLE, c1.vsAllocRid, ARID)) then

          if (vsMaxEDate is null) then
		    vsMaxEDate := c1.vsEDate;
		  end if;

		  if (vsMinDate is null) then
		    vsMinDate := vsDate;
		  end if;

          if ((c1.vsEDate > vsMaxEDate) or
		    ((vsMinDate > vsDate) and (c1.vsEDate = vsMaxEDate))) then
		    vsMaxEDate := c1.vsEDate;
			 vsMinDate := vsDate;
		  end if;
        end if;
	  end if;
	end loop;

    return vsDate;
  exception
    when NO_DATA_FOUND then
      RAISE_APPLICATION_ERROR(-20801, 'В таблице ALLOCATION не задан RID для CID: и AID:');
    return null;
  end;
end;
/
