CREATE FUNCTION       A_F_RelProtSt_Pov (Rec IN NUMBER) RETURN NUMBER IS
/***************************************************************************************
 Функция           :  A_F_RelProtSp_Pov
 Наименование      :  функция расчета Общий стаж для увеличения размера пенсии
 Автор             :  Вахромин О.Ю.    Корректировка : ОЛВ  17.12.2009  -- Rec IN NUMBER
***************************************************************************************/
 NSt      number;

BEGIN
/* */
   if A_F_RelProtGender=1 then
      NSt:=S_CONST(109,XLPL.WorkDate);   -- Стаж работы для назначения полной пенсии по возрасту (мужчины)
   else -- end if;    if vGender=2 then
      NSt:=S_CONST(110,XLPL.WorkDate);   -- Стаж работы для назначения полной пенсии по возрасту (женщины)
   end if;
/* */
   /* OLV 17.12.2009 */
   if (Rec-NSt>0) then    -- Общий стаж > Стажа работы для назначения полной пенсии по возрасту
      return trunc((Rec-NSt)/360);
   else
      return 0;
   end if;
   /* */

/* OLV 17.12.2009  было так *
   if (A_F_RelProtRecord(1)-St>0) then
      return trunc((A_F_RelProtRecord(1)-St)/360);
   else
      return 0;
   end if;
/* */

END A_F_RelProtSt_Pov;
/
