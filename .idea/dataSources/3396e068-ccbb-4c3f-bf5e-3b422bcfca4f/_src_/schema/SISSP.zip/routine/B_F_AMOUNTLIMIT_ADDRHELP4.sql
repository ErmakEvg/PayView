CREATE FUNCTION       B_F_AmountLimit_AddrHelp4 RETURN BOOLEAN AS
/*******************************************************************************
 Функция          : B_F_AmountLimit_AddrHelp4
 Наименование     : Функция, определяющая контроль на предельную сумму, которую
                  : можно назначить по госудпрственной адресной социальной
                  : помощи для возмещения затрат на приобретение подгузников
                  : (код назначения 754)
 Автор            : Ярошик А.К.
 Состояние на дату: 11.07.2017, 01.11.2017
 Код возврата     : True - Amount меньше установленной суммы,
                  : False - Amount больше установленной суммы
*******************************************************************************/
  LimitSum  Number;
BEGIN
  Select distinct SUMMA INTO LimitSum
  From W$PARAM_ADDR_HELP
  Where CID = Xlpl.CID
    and ENTERED_BY = Xlpl.GETUID
    and STAGE IN (1, 4);
  -- 01.11.2017 A.K. IF (LimitSum <= (S_CONST(1, XLPL.WorkDate)* S_CONST(55, XLPL.WorkDate)/100)) THEN
  IF LimitSum <= S_CONST(2, XLPL.WorkDate) THEN   -- 01.11.2017 A.K.
    RETURN True;  -- возвратить "Amount меньше  установленной суммы"
  ELSE
    RETURN False; -- иначе - "Amount больше установленной суммы"
  END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN False;
END B_F_AmountLimit_AddrHelp4;
/
