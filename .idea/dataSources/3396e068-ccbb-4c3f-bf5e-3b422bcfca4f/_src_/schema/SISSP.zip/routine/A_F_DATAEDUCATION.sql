CREATE FUNCTION       A_F_DataEducation(aPID in NUMBER, aDate_Alloc_Restore IN DATE) RETURN Date IS
/***************************************************************************************
 Функция             : A_F_DataEducation
 Наименование        : Функция получения даты начала периода обучения у иждивенца
 Автор               : ОЛВ
 Состояние на дату   : 18.03.2011
 Код возврата        : Дата начала обучения
***************************************************************************************/
 Start_Education   date;
BEGIN
  Start_Education := NULL;

 BEGIN
          FOR c2  IN
            (  SELECT Period_Start AS pStart_Date,Period_End AS pEnd_Date
		        FROM W$ACTIVITY
                WHERE PID = aPID
                      AND ACTIVITY = 2
                      AND ENTERED_BY = Xlpl.USER_ID
                      AND stage IN (1,4)
				      AND Period_START =
                           (  SELECT MIN(Period_START)
				              FROM W$ACTIVITY
                              WHERE PID = aPID
                                   AND  ACTIVITY = 2
                                   AND ENTERED_BY = Xlpl.USER_ID
                                   AND stage IN (1,4))
              )
              LOOP
		          IF c2.pStart_Date > aDate_Alloc_Restore THEN
                    Start_Education := c2.pStart_Date;
                 END IF;
              END LOOP;

 EXCEPTION
      WHEN NO_DATA_FOUND THEN
            Start_Education := NULL;
 END;

   return Start_Education;
END A_F_DataEducation;
/
