CREATE FUNCTION       A_F_Relprotgetrid_RESIDING RETURN NUMBER AS
/***********************************************************************************************
 NAME                   : A_F_Relprotgetrid_RESIDING
 Назначение           : Возращает из PERSON_RESIDING_FEATURE
                                согласно W$RELATION_PROTOCOL
 Автор                    : ОЛВ
 Состояние на дату : 25.03.2013
 Код возврата         : RID из PERSON_RESIDING_FEATURE
************************************************************************************************/
 vsDRID NUMBER;
 xWorkDate               DATE;
BEGIN
   xWorkDate := ADD_MONTHS(Xlpl.WorkDate, -1);
  BEGIN
  vsDRID := -1;
  IF Xlpl.AID = 0 THEN
    SELECT DATA_RID INTO vsDRID
	FROM W$RELATION_PROTOCOL b, PERSON_RESIDING_FEATURE a
	WHERE b.CID = Xlpl.CID
	  AND GROUP_NO = Xlpl.GROUP_NO
	  AND ALLOC_CODE = Xlpl.ALLOC_CODE
	  AND RELATION_TABLE =  S_Codetablesissp('PERSON_RESIDING_FEATURE')
	  AND RELATION_DATE = Xlpl.WorkDate
	  AND b.ENTERED_BY = Xlpl.User_ID
	  AND DATA_RID = a.RID
	  AND NVL(a.PERIOD_START, xWorkDate) <= xWorkDate
	  AND NVL(a.PERIOD_END, xWorkDate) >= xWorkDate
	  AND a.pID = Xlpl.GetPid;
  ELSE
    SELECT DATA_RID INTO vsDRID
	FROM W$RELATION_PROTOCOL b, PERSON_RESIDING_FEATURE a
	WHERE b.CID = Xlpl.CID
	  AND AID = Xlpl.AID
	  AND ((GROUP_NO = Xlpl.Group_NO) OR (Xlpl.Group_NO = 0))
	  AND ALLOC_CODE = Xlpl.ALLOC_CODE
	  AND b.ENTERED_BY = Xlpl.User_ID
	  AND RELATION_TABLE = S_Codetablesissp('PERSON_RESIDING_FEATURE')
	  AND RELATION_DATE = Xlpl.WorkDate
	  AND DATA_RID = a.RID
	  AND NVL(a.PERIOD_START, xWorkDate) <=xWorkDate
	  AND NVL(a.PERIOD_END, xWorkDate) >=xWorkDate
	  AND a.pID = Xlpl.GetPid;
  END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
	  vsDRID := -1;
  END;
  RETURN vsDRID;
END A_F_Relprotgetrid_RESIDING;
/
