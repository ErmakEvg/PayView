CREATE FUNCTION       B_Child3_Nadbavka_0 RETURN DBMS_SQL.NUMBER_TABLE AS
/***************************************************************************************
// Функция: Child3_Nadbavka
// Наименование: Проверка права и вычисление надбавок на пособие детям до 3 лет
// Автор: Ворошилин В.
// Состояние на дату 09.03.1999
// Код возврата: массив, содержащий коды надбавок и соответствующие суммы надбавок
/***************************************************************************************/

K DBMS_SQL.NUMBER_TABLE;
M DBMS_SQL.NUMBER_TABLE;

BEGIN

K.delete;
M.delete;

XLPL.SETGLOBALFLOAT('Nadb1', 0);
M := B_F_Nad0();
XLPL.SETGLOBALFLOAT('Nadb1', 1);
if M.count <> 0 then
   K := M;
end if;

-- Сумма увеличения пособия по Закону о ЧАЭС для детей до 3 лет для зон
-- радиоактивного загрязнения 2 - 5:
if F$CHECK581 then K(581) := F$AMOUNT581;
else
-- Сумма фиксированной доплаты по ст. 33:
if F$CHECK583 then K(583) := F$AMOUNT583; end if;
end if;

Return K;

END B_Child3_Nadbavka_0;
/
