CREATE FUNCTION       B_F_CheckEstimationDate return BOOLEAN is
/**********************************************************************************************
 Функция            :  B_F_CheckEstimationDate
 Наименование       : Функция определяет, превышает ли дата завершения назначения текущую дату
                        для автоматически выполняемых действующих назначений
 Автор              : Перевод на PLS/QL Сманцер Ю.А.   Комментарии и корректировка: ОЛВ
 Состояние на дату  : 16.07.2002                                  18.05.2010  05.03.2014
 Код возврата       : True - если , False  - если
***********************************************************************************************/
  Dt       date;
  StopDt   date := null;
  datatalk date;
  BDate    date;
  aGN      number;

begin
 -- Ребенок в назначени
  if not XLPL.CheckRole(56) then
    return false;
  else
    XLPL.RoleDecl('Child','56');
  end if;

 -- дата родения
 XLPL.REPLACEROLE('Child');
   BDate := A_F_RelProtBIRTHDAY;
 XLPL.RestoreRole;

 -- дата обращения за назначением
 datatalk := A_F_datatalk();

  begin
    select group_num into aGN from ALLOCATIONS
	where code = XLPL.ALLOC_CODE;
  exception
    when NO_DATA_FOUND then
	  aGN := 0;
  end;

  -------------------------------------------------------------------------------
  --                  Определить окончание действия назначений
  -------------------------------------------------------------------------------
  -- Ограничение возраста ребенка для пособия по уходу за ребенком в возрасте до 3 лет - в годах
  if (aGN = 5) then         -- группа пособий на реб. до 3-х лет
    StopDt := S_AddYears(BDate, trunc(S_Const(401, XLPL.WorkDate)));
  end if;

  -- 479 - Дата окончания действия пособий на детей старше 3 лет (31.12) - в числовом виде дата 31.12.1997
  if (aGN = 6) then         -- группа пособий на реб. старше 3-х лет
    Dt := S_Jtod(trunc(S_Const(479, XLPL.WorkDate)));
	StopDt := S_EncodeDate(S_YearOfDate(DataTalk), S_MonthOfDate(Dt), S_DayOfDate(Dt));
	StopDt := StopDt + 1;
  end if;

  -- Ограничение возраста ребенка для пособия одинокой матери, воспит. реб.в воз. до полутора лет, - в годах
  -- действовало до '01-04-2002'
  if (XLPL.ALLOC_CODE = 496) then
    StopDt := B_AddYearsMonths(BDate, S_Const(409, XLPL.WorkDate));
  end if;

  -- Ограничение возраста ребенка в годах для детей-инвалидов - в годах
  if (XLPL.ALLOC_CODE = 491) then
    StopDt := S_AddYears(BDate, trunc(S_Const(407, XLPL.WorkDate)));
  end if;

  -- Ограничение возраста ребенка для детей, инфицированных ВИЧ - в годах
  if (XLPL.ALLOC_CODE = 493) then
    StopDt := S_AddYears(BDate, trunc(S_Const(408, XLPL.WorkDate)));
  end if;
  --XLPL.RestoreRole;

  -------------------------------------------------------------------------------
  --   Выбрать прогнозируемую дату изменения состояния действующего назначения
  -------------------------------------------------------------------------------
  begin
	select Estimation_Date into Dt from ALLOC_DATE_ESTIMATION
	where CID = XLPL.CID
	  and AID = XLPL.AID
	  and ALLOC_CODE = XLPL.ALLOC_CODE
	 -- 5.03.2014 ОЛВ -- and (STAGE not in (2) or STAGE is null)
      and (STAGE not in (2,3) or STAGE is null)
	  and ENTERED_BY = XLPL.User_ID;
  exception
    when NO_DATA_FOUND then
	  dt := null;
  end;

  -- текущая дата не превышает прогнозируемую даты
  if not (Dt is null) then
    if (XLPL.WorkDate < Dt) then
	  return True;
	end if;
  end if;

  -- текущая дата не превышает дату окончания действия назначения
  if (Dt is null) then
    if (XLPL.WorkDate < StopDt) then
	  return True;
    end if;
  end if;

  return False;

end;
/
