CREATE FUNCTION       B_F_ARRAYDATEESTCOMMONUX RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: B_F_ARRAYDATEESTCOMMONUX
+ Наименование: Формирование дат Estimation пособия по уходу
+ Автор: Ворошилин В.  корректировка Речицкая А. В.
+ Состояние на дату 20/09/2002		16.03.2017
==============================================================================*/

result_step_start DBMS_SQL.NUMBER_TABLE;
result_function DBMS_SQL.NUMBER_TABLE;
j NUMBER;

BEGIN

result_step_start.delete;

result_function.delete;
result_function := B_F_ArrayDateEstMETRIC ;
--result_function := B_F_ArrayDateEstMETRICUX; 16.03.2017
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivityUX(1);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivityUX(2);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstActivityUX(3);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdviceUX(1, 11);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdviceUX(1, 12);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdviceUX(1, 13);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdviceUX(1, 14);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdviceUX(1, 15);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMrakOpAdviceUX(2, 21);
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstAddress;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstAddressAbsent;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstBirthDeathUX;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

return result_step_start;

END B_F_ARRAYDATEESTCOMMONUX;
/
