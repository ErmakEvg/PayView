CREATE FUNCTION       B_F_INV_PID_ADDRH_SOC (aOPINION_TYPE IN NUMBER,aADVICE_TYPE IN VARCHAR2,
                                                      aPID in NUMBER, aDate in DATE)
RETURN BOOLEAN AS
/******************************************************************************
 Функция           : B_F_INV_PID_ADDRH_SOC
 Наименование      : Функция определяет наличие инвалидности у конкретного лица
                   : по конкретному коду инвалидности
 Параметры         : aOPINION_TYPE = -1 тип  не имеет значение
                   : aADVICE_TYPE = "x,x1 .. xn" или "" если не имеет значения
                   : при aADVICE_TYPE = "" проверяется наличие только OPINION_TYPE
                   : aPID - идентификатор лица
                   : aDate -дата на которую идет проверка
 Автор             : Абрамович М.В.
 Состояние на дату : 01.07.2017
 Возвращает        : True если лицо имеет указанные хар-ки
*******************************************************************************/
  aCount NUMBER;
  vCID   NUMBER;
  xADVICE_TYPE    DBMS_SQL.NUMBER_TABLE;
  err_num Number;
  err_msg VARCHAR2(500);
BEGIN
  vCID := Xlpl.CID;
  xADVICE_TYPE:=S_Parsefloatarray(aADVICE_TYPE);
   if xADVICE_TYPE.COUNT=0 then --выбираем только по OPINION_TYPE
    select count (*) into aCount
    from  W$MRAK_OPN_ADVICE wa, W$MRAK_OPN wo
    where wa.PID = aPID
         AND wa.PID = wo.PID
         AND wa.MRAK_RID = wo.RID
         AND wa.CID = vCID  AND wa.CID = wo.CID
         AND wo.ENTERED_BY = XLPL.User_ID
         AND wo.ENTERED_BY = wa.ENTERED_BY
         AND (wo.STAGE in (1,4,6) or wo.STAGE is null)
         AND (wa.STAGE in (1,4,6) or wa.STAGE is null)
         AND ((wa.OPINION_TYPE=aOPINION_TYPE) or (aOPINION_TYPE=-1))
         AND (wo.RECORD_END >= aDate or NVL(wo.RECORD_END, aDate)>= aDate )
         AND NVL(wa.RECORD_START,aDate) <=  aDate
         AND (wa.RECORD_END >= aDate or NVL(NVL(wa.RECORD_END, wa.DIS_TERM), aDate)>= aDate or
               wa.DIS_TERM >= aDate or NVL(NVL(wa.DIS_TERM, wa.RECORD_END), aDate)>= aDate);
     else
       FOR l IN 1..xADVICE_TYPE.COUNT LOOP
        select count (*) into aCount
        from  W$MRAK_OPN_ADVICE wa, W$MRAK_OPN wo
        where wa.PID = aPID
         AND wa.PID = wo.PID
         AND wa.MRAK_RID = wo.RID
         AND wa.CID = vCID  AND wa.CID = wo.CID
         AND wo.ENTERED_BY = XLPL.User_ID
         AND wo.ENTERED_BY = wa.ENTERED_BY
         AND (wo.STAGE in (1,4,6) or wo.STAGE is null)
         AND (wa.STAGE in (1,4,6) or wa.STAGE is null)
         AND ((wa.OPINION_TYPE=aOPINION_TYPE) or (aOPINION_TYPE=-1))
         AND ( wa.ADVICE_TYPE = xADVICE_TYPE(l))
         AND (wo.RECORD_END >= aDate or NVL(wo.RECORD_END, aDate)>= aDate )
         AND NVL(wa.RECORD_START,aDate) <=  aDate
         AND (wa.RECORD_END >= aDate or NVL(NVL(wa.RECORD_END, wa.DIS_TERM), aDate)>= aDate or
             wa.DIS_TERM >= aDate or NVL(NVL(wa.DIS_TERM, wa.RECORD_END), aDate)>= aDate);

         if aCount <> 0 then
          return true;
         end if;
        END LOOP;
     end if;

  --ОБД
   if xADVICE_TYPE.COUNT=0 then --выбираем только по OPINION_TYPE
     select count (*) into aCount
     from  MRAK_OPN_ADVICE ta, MRAK_OPN tm
     where ta.PID = aPID and   ta.PID = tm.PID
         AND SUBSTR(to_char(ta.CID),4,2) = SUBSTR(to_char(vCID),4,2)  --по категории в ОБД
         AND ta.CID = tm.CID and    ta.MRAK_RID = tm.RID
         AND (tm.RECORD_END >= aDate or NVL(tm.RECORD_END, aDate)>= aDate )
         AND ta.STAGE is null and tm.STAGE is null
         AND ((ta.OPINION_TYPE=aOPINION_TYPE) or (aOPINION_TYPE=-1))
         AND NVL(ta.RECORD_START,aDate) <=  aDate
         AND (ta.RECORD_END >= aDate or NVL(NVL(ta.RECORD_END, ta.DIS_TERM), aDate)>= aDate or
         ta.DIS_TERM >= aDate or NVL(NVL(ta.DIS_TERM, ta.RECORD_END), aDate)>= aDate);
   else
     FOR l IN 1..xADVICE_TYPE.COUNT LOOP
     select count (*) into aCount
     from  MRAK_OPN_ADVICE ta, MRAK_OPN tm
     where ta.PID = aPID and   ta.PID = tm.PID
         AND SUBSTR(to_char(ta.CID),4,2) = SUBSTR(to_char(vCID),4,2)  --по категории в ОБД
         AND ta.CID = tm.CID and    ta.MRAK_RID = tm.RID
         AND (tm.RECORD_END >= aDate or NVL(tm.RECORD_END, aDate)>= aDate )
         AND ta.STAGE is null and tm.STAGE is null
         AND ((ta.OPINION_TYPE=aOPINION_TYPE) or (aOPINION_TYPE=-1))
         AND (ta.ADVICE_TYPE = xADVICE_TYPE(l))
         AND NVL(ta.RECORD_START,aDate) <=  aDate
         AND (ta.RECORD_END >= aDate or NVL(NVL(ta.RECORD_END, ta.DIS_TERM), aDate)>= aDate or
         ta.DIS_TERM >= aDate or NVL(NVL(ta.DIS_TERM, ta.RECORD_END), aDate)>= aDate);
       if aCount <> 0 then
          return true;
       end if;
     END LOOP;
   end if;

  if aCount <> 0 then
    return true;
  else
    return false;
  end if;
     --if vCID=31814006721 then
     --raise_application_error(-20801,'Отладка B_SSD_INV_PID_AddrHelp  aCount='||aCount||' aDate='||aDate);
     --end if;
  EXCEPTION WHEN OTHERS THEN
   err_num := SQLCODE;
   err_msg := SUBSTR(SQLERRM, 1, 500);
   raise_application_error(-20001, 'B_F_INV_PID_ADDRH_SOC error - '|| err_num || ':' ||err_msg);

END B_F_INV_PID_ADDRH_SOC;
/
