CREATE FUNCTION       A_F_RelProtActivityEnd_OneP(aActivity in NUMBER)  RETURN DATE IS
/***************************************************************************************
 Функция            : A_F_RelProtActivityEnd_OneP
 Наименование       : Функция определения даты окончания ACTIVITY
 Автор              : АМВ
 Состояние на дату  : 22.07.2010
 Код возврата       : датa окончания ACTIVITY
****************************************************************************************/

 DRIDS       DBMS_SQL.NUMBER_TABLE;
 vsDRID      number;
 pPERIOD_End date default  null;
 mPERIOD_End date default  null;
 i integer;

BEGIN

  --     1 - ОБД
  ----------------------
    DRIDS := A_F_RelProtGetRIDActivity(1);
  if (DRIDS.count <> 0) then

    for i in 1 .. DRIDS.count LOOP
        vsDRID := DRIDS(i);
      BEGIN
	    select PERIOD_END into pPERIOD_End
		  from ACTIVITY
	     where RID = vsDRID
	       and ACTIVITY = aActivity
           and PERIOD_END is not null
		   and (XLPL.WorkDate>= PERIOD_Start)
		   and entered_by = XLPL.User_ID ;

             if (mPERIOD_End is null) or (mPERIOD_End < pPERIOD_End) then
                mPERIOD_End:= pPERIOD_End;
             end if;
      exception
        when No_Data_Found then
           null;
      END;

	end loop;
  end if;

  --     0 - РБД
  ----------------------
    DRIDS := A_F_RelProtGetRIDActivity(0);
  if (DRIDS.count <> 0) then

    for i in 1 .. DRIDS.count LOOP
        vsDRID := DRIDS(i);
      BEGIN
	    select PERIOD_END into pPERIOD_End
		  from W$ACTIVITY
	     where RID = vsDRID
	       and ACTIVITY = aActivity
           and PERIOD_END is not null
		   and (XLPL.WorkDate>= PERIOD_Start)
		   and entered_by = XLPL.User_ID ;
             if (mPERIOD_End is null) or (mPERIOD_End < pPERIOD_End) then
                mPERIOD_End:= pPERIOD_End;
             end if;
      exception
        when No_Data_Found then
           null;
      END;

	end loop;
  end if;

RETURN mPERIOD_End;

END A_F_RelProtActivityEnd_OneP;
/
