CREATE FUNCTION       B_F_ARRAYDATECHANGESSD RETURN DBMS_SQL.NUMBER_TABLE IS
/***************************************************************************************
// Функция: F_ARRAYDATECHANGESSD
// Наименование: Функция определяет дату SSD
// Автор: Ворошилин В.
// Состояние на дату 20.01.2000
// Возвращает: массив
//***************************************************************************************/


A DBMS_SQL.NUMBER_TABLE;
ACTSTART date default null;
BDay date;
StartDateBD date;
Dt date;
Dt1 date;
DateTalk date;

BEGIN
  A.delete;
  if (not XLPL.CheckRole(56))
    then Return A;
    else XLPL.ROLEDECL('Child','56');
  end if;

  BDay := S_BIRTHDATE(0,XLPL.GETPID, XLPL.WorkDate);
  StartDateBD := Add_Months(BDay,S_Const(401,XLPL.WorkDate)*12)+1;
  Dt := S_DateConst(478,XLPL.WorkDate);
  Dt := s_EncodeDate(S_YearOfDate(XLPL.WorkDate), S_MonthOfDate(Dt), S_DayOfDate(Dt));
  Dt1 := S_EncodeDate(S_YearOfDate(XLPL.WorkDate)-1, S_MonthOfDate(Dt), S_DayOfDate(Dt));
  if (StartDateBD >= Dt) AND (StartDateBD <= XLPL.WorkDate)
    then Dt := StartDateBD;
  end if;
  DateTalk := Last_Day(S_currdate);

  for REC in (
		 		Select RECORD_START as ACTSTART
                From   W$CASE_SUMMARY_INCOME
                Where   CID = XLPL.CID and
                        YEAR < Dt and
                        YEAR >= Dt1 and
                        ENTERED_BY = XLPL.USER_ID and
                        STAGE NOT IN(2,3)
			   )
  LOOP
	if (ACTSTART <= DateTalk) then A(A.Count+1) := s_julian(ACTSTART);
	end if;
  end loop;
Return A;

END B_F_ARRAYDATECHANGESSD;
/
