CREATE FUNCTION       B_F_CountMONTHS_PERIOD_751(aAllocCode IN NUMBER,
                                 aTestDate  IN DATE)
RETURN   DBMS_SQL.NUMBER_TABLE IS
/******************************************************************************
 Функция           : B_F_CountMONTHS_PERIOD_751
 Назначение        : Функция считает количество месяцев назначения ежемесячного
                   : социального пособия у выбранного лица в течении действующего периода
                   : назначения (период предоставления ГАСП в виде ежемесячного социального пособия
                   :  определяется годом с месяца обращения)
 Основание         :
 Автор             : АМВ
 Входные параметры : aAllocCode
                   : aTestDate - начало месяца даты обращения
 Состояние на дату : 03.12.2015, 05.02.2016, 31.05.2016,15.06.2016,,30.06.2016(NVL)
                   : 18.07.2016,29.07.2016,05.09.2016,09.09.2016,11.01.2017
                   : 04.05.2017,13.06.2017
 Возвращаемое      :
      значение     : количество месяцев  назначенных ранее в текущем периоде
*******************************************************************************/
  xPID           NUMBER;
  vCount  NUMBER;
  xMONTHS_CALC   NUMBER;
  vMinStartAlloc DATE;
  vStartPeriod    DATE;
  vEndPeriod      DATE;
  vCntMonthsPeriod NUMBER; --кол-во назначенных месяцев в интервале
  vArray_Period   DBMS_SQL.Number_Table; --массив периодов назначения
  --31.05.2016
  vStartPeriod_Fam    DATE;
  vEndPeriod_Fam      DATE;
  vCntMonthsPeriod_Fam NUMBER;
  vCntMonthsPeriod_Rec NUMBER;
  vRID_PARAM           NUMBER;
  xPID_Recip           NUMBER;
  vFl_RecPeriod        NUMBER; --05.09.2016
  vFl_FOUND_RecPeriod  NUMBER; --05.09.2016
  /*
   vArray_Periods[0] - начало перида
   vArray_Periods[1] - конец периода
   vCountMonths[2]  - кол-во месяцев назначения в периоде
  */
  vStartPeriod_Rec    DATE;--6
  vEndPeriod_Rec      DATE;--6
BEGIN
  vMinStartAlloc:= NULL;
  vStartPeriod:=NULL;
  vEndPeriod:=NULL;
  vCntMonthsPeriod:=0; --30.06.2016
  vCntMonthsPeriod_Rec:=NULL;
  vArray_Period.delete;
  xPID:= XLPL.GETPID;
  vStartPeriod_Rec:= NULL;--6
  vEndPeriod_Rec:= NULL; --6

  --31.05.2016 в W$PARAM_ADDR_HELP необходимо записать интервал исчисления получателя по делу
  --Находим был ли уже зафиксирован интервал для этой семьи в W$PARAM_ADDR_HELP по получателю
      vStartPeriod_Fam:=NULL;  --Для сохранения интервала по семье (нового или уже действующего)
      vEndPeriod_Fam:=NULL;
      vCntMonthsPeriod_Fam:=0;--30.06.2016
       --проверяем, занесен  ли уже по семье интервал по получателю
      Select p.RID,p.TSSR_START, p.TSSR_END, p.AMOUNT_UNITS
             INTO vRID_PARAM, vStartPeriod_Fam, vEndPeriod_Fam,  vCntMonthsPeriod_Fam
      From W$PARAM_ADDR_HELP p
      WHERE p.CID=XLPL.CID and p.ENTERED_BY = XLPL.User_ID and NVL(p.STAGE,0) not in (2,3);

     if ((vStartPeriod_Fam is NULL) AND (vEndPeriod_Fam is NULL) ) then --нет еще интервалов по семье в W$PARAM_ADDR_HELP
        -- Ищем получателя по делу и формируем интервал
         begin
          select pid INTO xPID_Recip from W$RECIPIENT r
          where r.cid=XLPL.CID AND r.ENTERED_BY = XLPL.User_ID AND NVL(r.STAGE,0) not IN(2,3)
                AND r.BASE_AID is NULL; --15.06.2016
         exception
           when NO_DATA_FOUND  Then  --нет получателя
             xPID_Recip:=xPID;
         end;
        -- Ищем первое обращение по получателю для дальнейшего построения периодов
         vFl_RecPeriod:=0;
          begin
           Select MIN(a.ALLOCATION_START)  INTO vMinStartAlloc
           From ALLOCATION a, ALLOCATION_PERSON b
           Where a.ALLOC_CODE = aAllocCode
            and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
            and b.PID = (select pid from W$RECIPIENT r where r.cid=XLPL.CID AND
                         NVL(r.STAGE,0) not IN(2,3) and r.base_aid is null) --15.06.2016
            and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76)) --05.02.2016
            and NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3);
           exception  --05.09.2016
           when NO_DATA_FOUND  Then  --не обращалcz получатель семьи за 751 назн. ранее
             vFl_FOUND_RecPeriod:=0; --не обращались ранее получатель
             vMinStartAlloc:=NULL; --не обращались ранее
          end;
         if vMinStartAlloc is NULL then vFl_FOUND_RecPeriod:=0;
            else vFl_FOUND_RecPeriod:=1;
         end if; --06.09.2016
           if ((vMinStartAlloc is NULL) or (vFl_RecPeriod=0)) then  --не было назначений раньше по получателю
                vStartPeriod_Rec:=aTestDate;  --Для сохранения интервала по получателю(первого обращения получателя)
                vEndPeriod_Rec:=ADD_MONTHS(aTestDate,12)-1;
           end if;
         --получатель обращался ранее за ГАСП
         --находим последний интервал по получателю (считаем что это интервал семьи)
         while vMinStartAlloc is not NULL --были обращения получателя
          loop
           vStartPeriod := vMinStartAlloc;
           vEndPeriod:=  ADD_MONTHS(vMinStartAlloc,12)-1; --поледнее число  месяца
          --выбираем кол-во месяцев в этом периоде по PARAM_ADDR_HELP
           vCntMonthsPeriod:=0; --09.09.2016
           begin
            Select NVL(SUM(CNT_MONTHS),0) into vCntMonthsPeriod --30.06.2016
             FROM
              (Select al.CID,
                     CASE when al.ALLOC_STATUS=3 then -- назначение закрыто считаем кол-во месяцев по CALC_AMOUNT
                       (Select  COUNT(DISTINCT(TRUNC(ca.PERIOD_START,'MM')))
                        From   CALC_AMOUNT ca
                        Where  ca.CID = al.CID and ca.AID = al.AID
                                and ca.STAGE Is Null and ca.CLOSE_DATE Is Null
                                and ((ca.PERIOD_START>= vStartPeriod) and (ca.PERIOD_END< vEndPeriod))
                                and  ca.MONTH_AMOUNT<>0 and PAYMENT_FLAG is NULL ) --13.06.2017 and PAYMENT_FLAG is NULL
                      when al.ALLOC_STATUS=4 then 0 --11.01.2017
                      ELSE --назначение действует
                       (Select  Max(p.COUNT_MONTHS) From PARAM_ADDR_HELP p --кол-во месяцев из PARAM_ADDR_HELP
                        Where p.CID = al.CID and NVL(p.STAGE, 0)<>3 )
                      END CNT_MONTHS
                FROM
                (Select distinct a.CID,a.AID, A.ALLOC_STATUS, a.STEP_START --назначение по персоне и  статус назначение
                 From ALLOCATION a, ALLOCATION_PERSON b
                 Where a.RID = b.ALLOCATION_RID and b.ROLE= 65 and a.ALLOC_CODE = aAllocCode
                   and b.PID = xPID_Recip and a.STAGE Is Null and b.STAGE Is Null --xPID_Recip
                   and a.STEP_START = (Select max(aa.STEP_START)
                                       From   ALLOCATION_PERSON bb, ALLOCATION aa
                                       Where  bb.PID = xPID_Recip and (bb.ROLE= 65)
                                            and bb.ALLOCATION_RID = aa.RID and aa.ALLOC_CODE = aAllocCode
                                            and aa.PARENT_RID Is Null and aa.COMP_PART Is Null
                                            and aa.STAGE Is Null and aa.CLOSE_DATE Is Null
                                            and bb.STAGE Is Null and bb.CLOSE_DATE Is Null
                                            and a.cid=aa.cid
                                            and ((aa.ALLOCATION_START>= vStartPeriod) and (aa.ALLOCATION_START< vEndPeriod))
                                        )
                 and ((a.ALLOCATION_START>= vStartPeriod) and (a.ALLOCATION_START<vEndPeriod))
                ) al);
           EXCEPTION
            when NO_DATA_FOUND  Then  --не обращалить за 751 назн. ранее
            vCntMonthsPeriod:=0;
           end;
          --04.05.2017 у получателя может быть отказ, и в этом периоде назначения у него нет кол-ва месяцев
          -- проверяем по другим членам семьи
           if vCntMonthsPeriod=0 then --по получателю кол-во месяцев 0
            begin
             Select NVL(SUM(CNT_MONTHS),0) INTO vCntMonthsPeriod --30.06.2016
             FROM
              (Select al.CID,
                       (Select  Max(p.COUNT_MONTHS) From PARAM_ADDR_HELP p --кол-во месяцев из PARAM_ADDR_HELP
                        Where p.CID = al.CID and NVL(p.STAGE, 0)<>3 ) CNT_MONTHS
                FROM
                (Select  distinct a.CID --назначение по персоне и  статус назначение
                 From ALLOCATION a, ALLOCATION_PERSON b
                 Where a.RID = b.ALLOCATION_RID and b.ROLE =65 and a.ALLOC_CODE = aAllocCode
                   and b.PID <> xPID_Recip and a.STAGE Is Null and b.STAGE Is Null --xPID_Recip
                   and a.STEP_START = (Select max(aa.STEP_START)
                                       From   ALLOCATION_PERSON bb, ALLOCATION aa
                                       Where  bb.PID = xPID_Recip and (bb.ROLE =76) --получатель как член семьи может быть отказ ему
                                            and bb.ALLOCATION_RID = aa.RID and aa.ALLOC_CODE = aAllocCode
                                            and aa.PARENT_RID Is Null and aa.COMP_PART Is Null
                                            and aa.STAGE Is Null and aa.CLOSE_DATE Is Null
                                            and bb.STAGE Is Null and bb.CLOSE_DATE Is Null
                                            and a.cid=aa.cid
                                            and ((aa.ALLOCATION_START>= vStartPeriod) and (aa.ALLOCATION_START<vEndPeriod))
                                        )
                 and ((a.ALLOCATION_START>= vStartPeriod) and (a.ALLOCATION_START<vEndPeriod))
                ) al);
            EXCEPTION
            when NO_DATA_FOUND  Then  --не обращалить за 751 назн. ранее
            vCntMonthsPeriod:=0;
            end;

           end if; --по получателю кол-во месяцев 0

             if vCntMonthsPeriod=0 then --пропущен период нужно строить новое начало периодов
                                        --или новый интервал
                  if aTestDate<=vEndPeriod then--новый интервал --18.07.2016
                    vStartPeriod_Rec:=vStartPeriod;  --
                    vEndPeriod_Rec:=vEndPeriod;--
                    vMinStartAlloc:=NULL;
                  else
                   --пропущен период нужно строить новое начало периодов  --18.07.2016

                    vCount:=0;
                    Select COUNT(*)  INTO vCount --ищем новое обращение после пропуска
                    From ALLOCATION a, ALLOCATION_PERSON b --формируем уже другой период по получателю
                    Where a.ALLOC_CODE = aAllocCode
                      and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
                      and b.PID = (select pid from W$RECIPIENT r where r.cid=XLPL.CID AND
                                 NVL(r.STAGE,0) not IN(2,3) and r.base_aid is null) --15.06.2016
                      and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76)) --05.02.2016
                      and NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3)
                      and a.ALLOCATION_START>vEndPeriod;
                    if vCount<>0 then --ГАСП был плосле пропущеного периода
                    begin
                     Select MIN(a.ALLOCATION_START)  INTO vMinStartAlloc --ищем новое обращение после пропуска
                     From ALLOCATION a, ALLOCATION_PERSON b --формируем уже другой период по получателю
                     Where a.ALLOC_CODE = aAllocCode
                      and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
                      and b.PID = (select pid from W$RECIPIENT r where r.cid=XLPL.CID AND
                                 NVL(r.STAGE,0) not IN(2,3) and r.base_aid is null) --15.06.2016
                      and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76)) --05.02.2016
                      and NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3)
                      and a.ALLOCATION_START>vEndPeriod;
                    EXCEPTION --09.09.2016
                     when NO_DATA_FOUND  Then  --не обращалcz получатель за 751 назн. после пропущеного периода
                     --начинаем новый период назначения для семьи
                     vStartPeriod_Rec:=aTestDate;  --Для сохранения интервала по получателю(формируем уже другой интервал)
                     vEndPeriod_Rec:=ADD_MONTHS(aTestDate,12)-1;
                     vCntMonthsPeriod_Rec:=NULL;--
                     vMinStartAlloc:=NULL; --09.09.2016
                     END;
                    else --vCount=0  --пропустил период и не обращался -новый период с месяца даты обращения
                     vStartPeriod_Rec:=aTestDate;  --Для сохранения интервала по получателю(формируем уже другой интервал)
                     vEndPeriod_Rec:=ADD_MONTHS(aTestDate,12)-1;
                     vCntMonthsPeriod_Rec:=NULL;--
                     vMinStartAlloc:=NULL; --09.09.2016
                    end if;
                  end if;
             else --vCntMonthsPeriod<>0 --получали ГАСП
               if aTestDate>vEndPeriod then --начало месяца текущего обращения > взятого периода
                vMinStartAlloc:=vEndPeriod+1;  -- строим след. период
                --13.06.2017 ищем следующее обращение за уже проверенным интервалом
                    vCount:=0;
                    Select COUNT(*)  INTO vCount --ищем следующие обращение после проверенного интервала
                    From ALLOCATION a, ALLOCATION_PERSON b --формируем уже другой период по получателю
                    Where a.ALLOC_CODE = aAllocCode
                      and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
                      and b.PID = (select pid from W$RECIPIENT r where r.cid=XLPL.CID AND
                                 NVL(r.STAGE,0) not IN(2,3) and r.base_aid is null) --15.06.2016
                      and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76)) --05.02.2016
                      and NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3)
                      and a.ALLOCATION_START>vEndPeriod;
                    if vCount<>0 then --обращались еще после предыдущего интервала
                    begin              --строим реальный интервал с даты следующего  обращения
                     Select MIN(a.ALLOCATION_START)  INTO vMinStartAlloc --ищем новое обращение после предыдущего интервала
                     From ALLOCATION a, ALLOCATION_PERSON b --формируем уже другой период по получателю
                     Where a.ALLOC_CODE = aAllocCode
                      and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
                      and b.PID = (select pid from W$RECIPIENT r where r.cid=XLPL.CID AND
                                 NVL(r.STAGE,0) not IN(2,3) and r.base_aid is null)
                      and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76))
                      and NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3)
                      and a.ALLOCATION_START>vEndPeriod;
                    EXCEPTION
                     when NO_DATA_FOUND  Then  --не обращалcz получатель за 751 назн. после предыдущего периода
                     --начинаем новый период назначения для семьи
                     vStartPeriod_Rec:=aTestDate;  --Для сохранения интервала по получателю(формируем уже другой интервал)
                     vEndPeriod_Rec:=ADD_MONTHS(aTestDate,12)-1;
                     vCntMonthsPeriod_Rec:=NULL;--
                     vMinStartAlloc:=NULL; --09.09.2016
                     END;
                    else --vCount=0  не обращался -новый период с месяца даты обращения
                     vStartPeriod_Rec:=aTestDate;  --Для сохранения интервала по получателю(формируем уже другой интервал)
                     vEndPeriod_Rec:=ADD_MONTHS(aTestDate,12)-1;
                     vCntMonthsPeriod_Rec:=NULL;--
                     vMinStartAlloc:=NULL;
                    end if;
                --13.06.2017
               else --начало месяца текущего обращения < окончания построенного периода -
                --запоминаем следующий полученный период

                   vStartPeriod_Rec:=vStartPeriod;  --
                   vEndPeriod_Rec:=vEndPeriod;--
                   vCntMonthsPeriod_Rec:=vCntMonthsPeriod;--могут быть в этом периоде уже месяцы
                   vMinStartAlloc:=NULL;
                end if;
               end if;
                --end if;
            end loop;

      if ((vStartPeriod_Rec is not NULL) AND (vEndPeriod_Rec is not NULL)) then
       begin
             UPDATE W$PARAM_ADDR_HELP p    --записываем  интервал семьи по даннм получателя
             SET p.TSSR_START=vStartPeriod_Rec,p.TSSR_END=vEndPeriod_Rec,
                 p.AMOUNT_UNITS=vCntMonthsPeriod_Rec
             WHERE p.cid=XLPL.CID AND p.ENTERED_BY = XLPL.User_ID AND NVL(p.STAGE,0) not IN(2,3);
        exception  --05.09.2016
               when OTHERS  Then  --не обращалить за 751 назн. ранее
               NULL;
        end;
      end if;
      end if; --по получателю период назначения

  --31.05.2016 *****************ПЕРСОНА
   --поиск по персоне проверки права
  -- Ищем первое обращение для дальнейшего построения периодов по персоне
  vMinStartAlloc:=NULL;
  begin
   Select MIN(a.ALLOCATION_START)  INTO vMinStartAlloc
   From ALLOCATION a, ALLOCATION_PERSON b
   Where a.ALLOC_CODE = aAllocCode
       and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
       --05.02.2016 and b.PID = xPID and a.RID = b.ALLOCATION_RID and (b.ROLE= 65) --часто не утверждают отказ
       and b.PID = xPID and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76)) --05.02.2016
       and NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3);
   EXCEPTION
    when NO_DATA_FOUND  Then  --не обращалить за 751 назн. ранее
         vArray_Period.DELETE;
         RETURN vArray_Period;
  end;
  if vMinStartAlloc is not NULL then --обращались уже за 751 назн-ием,нужно построить периоды

     while vMinStartAlloc is not NULL loop
       vStartPeriod := vMinStartAlloc;
       vEndPeriod:=  ADD_MONTHS(vMinStartAlloc,12)-1; --поледнее число  месяца
       --выбираем кол-во месяцев в этом периоде по PARAM_ADDR_HELP
       vCntMonthsPeriod:=0; --09.09.2016
       begin
          Select NVL(SUM(CNT_MONTHS),0) into vCntMonthsPeriod --30.06.2016
            FROM
              (Select al.CID,
                     CASE when al.ALLOC_STATUS=3 then -- назначение закрыто считаем кол-во месяцев по CALC_AMOUNT
                       (Select  COUNT(DISTINCT(TRUNC(ca.PERIOD_START,'MM')))
                        From   CALC_AMOUNT ca
                        Where  ca.CID = al.CID and ca.AID = al.AID
                                and ca.STAGE Is Null and ca.CLOSE_DATE Is Null
                                and ((ca.PERIOD_START>= vStartPeriod) and (ca.PERIOD_END< vEndPeriod))
                                and  ca.MONTH_AMOUNT<>0 and PAYMENT_FLAG is NULL ) --13.06.2017 and PAYMENT_FLAG is NULL
                       when al.ALLOC_STATUS=4 then 0 --11.01.2017   отказ
                      ELSE --назначение действует
                       (Select  Max(p.COUNT_MONTHS) From PARAM_ADDR_HELP p --кол-во месяцев из PARAM_ADDR_HELP
                        Where p.CID = al.CID and NVL(p.STAGE, 0)<>3 )
                      END CNT_MONTHS
               FROM
               (Select  a.CID,a.AID, A.ALLOC_STATUS, a.STEP_START --назначение по персоне и  статус назначение
                From ALLOCATION a, ALLOCATION_PERSON b
                Where a.RID = b.ALLOCATION_RID and b.ROLE= 65 and a.ALLOC_CODE = aAllocCode
                 and b.PID = xPID and a.STAGE Is Null and b.STAGE Is Null
                 and a.STEP_START = (Select max(aa.STEP_START)
                                     From   ALLOCATION_PERSON bb, ALLOCATION aa
                                     Where  bb.PID = xPID  and (bb.ROLE= 65)
                                            and bb.ALLOCATION_RID = aa.RID and aa.ALLOC_CODE = aAllocCode
                                            and aa.PARENT_RID Is Null and aa.COMP_PART Is Null
                                            and aa.STAGE Is Null and aa.CLOSE_DATE Is Null
                                            and bb.STAGE Is Null and bb.CLOSE_DATE Is Null
                                            and a.cid=aa.cid
                                            and ((aa.ALLOCATION_START>= vStartPeriod) and (aa.ALLOCATION_START< vEndPeriod))
                                        )
                 and ((a.ALLOCATION_START>= vStartPeriod) and (a.ALLOCATION_START<vEndPeriod))
                ) al);

          EXCEPTION
            when NO_DATA_FOUND  Then  --не обращалить за 751 назн. ранее
            vCntMonthsPeriod:=0;
          end;
           --04.05.2017 по персоне  может быть отказ, и в этом периоде назначения у него нет кол-ва месяцев
          -- проверяем по другим членам семьи
           if vCntMonthsPeriod=0 then --по персоне кол-во месяцев 0
            begin
             Select NVL(SUM(CNT_MONTHS),0) INTO vCntMonthsPeriod --30.06.2016
             FROM
              (Select al.CID,
                       (Select  Max(p.COUNT_MONTHS) From PARAM_ADDR_HELP p --кол-во месяцев из PARAM_ADDR_HELP
                        Where p.CID = al.CID and NVL(p.STAGE, 0)<>3 ) CNT_MONTHS
                FROM
                (Select  distinct a.CID --назначение по персоне и  статус назначение
                 From ALLOCATION a, ALLOCATION_PERSON b
                 Where a.RID = b.ALLOCATION_RID and b.ROLE =65 and a.ALLOC_CODE = aAllocCode
                   and b.PID <> xPID and a.STAGE Is Null and b.STAGE Is Null --xPID_Recip
                   and a.STEP_START = (Select max(aa.STEP_START)
                                       From   ALLOCATION_PERSON bb, ALLOCATION aa
                                       Where  bb.PID = xPID and (bb.ROLE =76) --персона как член семьи может быть отказ ему
                                            and bb.ALLOCATION_RID = aa.RID and aa.ALLOC_CODE = aAllocCode
                                            and aa.PARENT_RID Is Null and aa.COMP_PART Is Null
                                            and aa.STAGE Is Null and aa.CLOSE_DATE Is Null
                                            and bb.STAGE Is Null and bb.CLOSE_DATE Is Null
                                            and a.cid=aa.cid
                                            and ((aa.ALLOCATION_START>= vStartPeriod) and (aa.ALLOCATION_START<vEndPeriod))
                                        )
                 and ((a.ALLOCATION_START>= vStartPeriod) and (a.ALLOCATION_START<vEndPeriod))
                ) al);
            EXCEPTION
            when NO_DATA_FOUND  Then  --не обращалить за 751 назн. ранее
            vCntMonthsPeriod:=0;
            end;
           end if; --по персоне кол-во месяцев 0

          if vCntMonthsPeriod=0 then --пропущен период или навый интервал нужно строить новое начало периодов
             if aTestDate>vEndPeriod then --начало месяца текущего обращения > взятого периода(пропущен период)
                -- vMinStartAlloc:=vEndPeriod+1;  -- строим след. период для проверки
                  vcount:=0;
                  Select count(*)  INTO vcount --ищем новое обращение после пропуска
                  From ALLOCATION a, ALLOCATION_PERSON b
                  Where a.ALLOC_CODE = aAllocCode
                    and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
                    and b.PID = xPID
                    and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76)) --05.02.2016
                    and a.STAGE IS NULL--NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3)
                    and b.STAGE IS NULL
                    and a.ALLOCATION_START>vEndPeriod;
               if vcount>0 then
                 BEGIN --09.09.2016
                  Select MIN(a.ALLOCATION_START)  INTO vMinStartAlloc --ищем новое обращение после пропуска
                  From ALLOCATION a, ALLOCATION_PERSON b
                  Where a.ALLOC_CODE = aAllocCode
                    and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
                    and b.PID = xPID
                    and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76)) --05.02.2016
                    and a.STAGE IS NULL--NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3)
                    and b.STAGE IS NULL
                    and a.ALLOCATION_START>vEndPeriod;
                 EXCEPTION
                  when OTHERS Then--NO_DATA_FOUND  Then  --не обращалить за 751 назн. после пропущеного периода
                   vMinStartAlloc:=NULL; --нужно вернуть формируемый новый период
                   vArray_Period.Delete;
                  RETURN vArray_Period; --09.09.2016
                 END;
               ELSE
                   vMinStartAlloc:=NULL; --нужно вернуть формируемый новый период
                   vArray_Period.Delete;
                  RETURN vArray_Period; --09.09.2016
               end if;
             else --начало месяца текущего обращения < окончания построенного периода -
                vMinStartAlloc:=NULL;
                vArray_Period.Delete;
                RETURN vArray_Period; --не получал в этом периоде (очередной период)
               end if; --
          else --vCntMonthsPeriod<>0 получал в выбранном периоде
               if (aTestDate>vEndPeriod) then --начало месяца текущего обращения > взятого периода
                vMinStartAlloc:=vEndPeriod+1; -- строим след. период исчисления назначения
                --13.06.2017 ищем следующее обращение за уже проверенным интервалом
                    vCount:=0;
                    Select COUNT(*)  INTO vCount --ищем следующие обращение после проверенного интервала
                    From ALLOCATION a, ALLOCATION_PERSON b --формируем уже другой период по получателю
                    Where a.ALLOC_CODE = aAllocCode
                      and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
                      and b.PID = (select pid from W$RECIPIENT r where r.cid=XLPL.CID AND
                                 NVL(r.STAGE,0) not IN(2,3) and r.base_aid is null) --15.06.2016
                      and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76)) --05.02.2016
                      and NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3)
                      and a.ALLOCATION_START>vEndPeriod;
                    if vCount<>0 then --обращались еще после предыдущего интервала
                    begin              --строим реальный интервал с даты следующего  обращения
                     Select MIN(a.ALLOCATION_START)  INTO vMinStartAlloc --ищем новое обращение после предыдущего интервала
                     From ALLOCATION a, ALLOCATION_PERSON b --формируем уже другой период по получателю
                     Where a.ALLOC_CODE = aAllocCode
                      and ((a.ALLOC_STATUS = 1) or (a.ALLOC_STATUS = 2) or (a.ALLOC_STATUS = 3))
                      and b.PID = (select pid from W$RECIPIENT r where r.cid=XLPL.CID AND
                                 NVL(r.STAGE,0) not IN(2,3) and r.base_aid is null)
                      and a.RID = b.ALLOCATION_RID and (b.ROLE IN (65,76))
                      and NVL(a.STAGE, 0) NOT IN (2,3) and NVL(b.STAGE, 0) NOT IN (2,3)
                      and a.ALLOCATION_START>vEndPeriod;
                    EXCEPTION
                     when NO_DATA_FOUND  Then  --не обращалcz получатель за 751 назн. после предыдущего периода
                     --начинаем новый период назначения для семьи
                     vStartPeriod_Rec:=aTestDate;  --Для сохранения интервала по получателю(формируем уже другой интервал)
                     vEndPeriod_Rec:=ADD_MONTHS(aTestDate,12)-1;
                     vCntMonthsPeriod_Rec:=NULL;--
                     vMinStartAlloc:=NULL; --09.09.2016
                     END;
                    else --vCount=0  не обращался -новый период с месяца даты обращения
                     vStartPeriod_Rec:=aTestDate;  --Для сохранения интервала по получателю(формируем уже другой интервал)
                     vEndPeriod_Rec:=ADD_MONTHS(aTestDate,12)-1;
                     vCntMonthsPeriod_Rec:=NULL;--
                     vMinStartAlloc:=NULL;
                    end if;
                --13.06.2017
                else --начало месяца текущего обращения < окончания построенного периода -
                   vArray_Period(1):= S_Julian(vStartPeriod);
                   vArray_Period(2):= S_Julian(vEndPeriod);
                   vArray_Period(3):= vCntMonthsPeriod;
                  --31.05.2016
               --Находим был ли уже зафиксирован интервал для этой семьи в W$PARAM_ADDR_HELP
                   vStartPeriod_Fam:=NULL;
                   vEndPeriod_Fam:=NULL;
                   vCntMonthsPeriod_Fam:=NULL;
                 begin
                   Select p.RID,p.TSSR_START, p.TSSR_END, p.AMOUNT_UNITS
                      INTO vRID_PARAM, vStartPeriod_Fam, vEndPeriod_Fam,  vCntMonthsPeriod_Fam
                   From W$PARAM_ADDR_HELP p
                   WHERE p.CID=XLPL.CID AND p.ENTERED_BY = XLPL.User_ID
                         and NVL(p.STAGE,0) not in (2,3);
                 EXCEPTION
                  when NO_DATA_FOUND  then
                   vStartPeriod_Fam:=NULL;
                   vEndPeriod_Fam:=NULL;
                   vCntMonthsPeriod_Fam:=NULL;
                 end;
                 if ((vStartPeriod_Fam is not NULL) AND (vEndPeriod_Fam is not NULL)) then
                      --есть уже интервал по семье
                       if ((vStartPeriod<vStartPeriod_Fam) and (vEndPeriod<vEndPeriod_Fam) ) then --29.07.2016 интервал новый для семьи
                           --29.07.2016 AND (vCntMonthsPeriod  is not NULL)) then--интервал новый для семьи
                       --было назначение потом родился ребенок и опять назначение и при третьем обращении его период будет другой - берем как у других
                        vArray_Period(1):= S_Julian(vStartPeriod_FAM);
                        vArray_Period(2):= S_Julian(vEndPeriod_FAM);
                        vArray_Period(3):= vCntMonthsPeriod_FAM;
                       end IF;

                 end if;
                   vMinStartAlloc:=NULL; --31.05.2016
               end if;
          end if;

     end loop;

     if ((vStartPeriod_Fam is NULL) AND (vEndPeriod_Fam is NULL)) then --нет  интервала??? -  член семьи
           begin  --11.01.2017
             UPDATE W$PARAM_ADDR_HELP p
             SET p.TSSR_START=S_JToD(vArray_Period(1)),p.TSSR_END=S_JToD(vArray_Period(2)), p.AMOUNT_UNITS=vArray_Period(3)
             WHERE p.RID=vRID_PARAM;
            exception  --11.01.2017
               when OTHERS  Then
               NULL;
           end;   --11.01.2017
     end if;

     RETURN vArray_Period;
  else
   RETURN vArray_Period; --нет vMinStartAlloc
  end if;

 /* if  ((XLPL.CID =72514011041)AND (vMinStartAlloc=to_date('01-май-2015'))) then --AND (xPID=7220036589)) then
     RAISE_APPLICATION_ERROR(-20801,'ОТЛАДКА АГАТ B_F_CountMONTHS_PERIOD_751 FF11'||chr(10)||'PID= '||xPID||' xPID_Recip='||xPID_Recip||
      'aTestDate='||aTestDate||' vStartPeriod='||vStartPeriod||' vEndPeriod='||vEndPeriod ||'vCntMonthsPeriod='||vCntMonthsPeriod||
      ' vStartPeriod_Fam='||vStartPeriod_Fam||' vEndPeriod_Fam='||vEndPeriod_Fam||' vMinStartAlloc='||vMinStartAlloc||
      ' vStartPeriod_Rec='||vStartPeriod_Rec||' vEndPeriod_Rec='||vEndPeriod_Rec);
 end if;*/

END B_F_CountMONTHS_PERIOD_751;
/
