CREATE FUNCTION       B_F_GetDateDecision (vPid IN NUMBER) RETURN date AS
/*******************************************************************************
Функция           : B_F_GetDateDecision
Наименование      : Функция определяет дату решения о назначении семейного капитала
				  : по PID получателя
Автор             : Речицкая А. В.
Состояние на дату : 18.05.2017
Возвращает        : дату решения о назначении семейного капитала по PID получателя
******************************************************************************/
 dDecision         date;
BEGIN
  BEGIN
      SELECT nvl(date_decision,to_date(sysdate,'dd-mm-yyyy'))
        INTO dDecision
        from assistance_family_capital
       WHERE cid=XLPL.CID
        and stage is null
		and close_date is null
		and alloc_code=701
        and PID_RECIPIENT=vPid;

  EXCEPTION
     WHEN others THEN
        dDecision:=XLPL.WorkDate;
  END;
 --RAISE_APPLICATION_ERROR(-20801,'B_F_GetDateDecision    22222    vPid='||vPid||'  dDecision='||dDecision );
  RETURN dDecision;
END B_F_GetDateDecision;
/
