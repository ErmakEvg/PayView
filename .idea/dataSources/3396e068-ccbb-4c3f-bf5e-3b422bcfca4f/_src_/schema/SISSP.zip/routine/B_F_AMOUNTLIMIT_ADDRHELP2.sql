CREATE FUNCTION       B_F_AmountLimit_AddrHelp2 return BOOLEAN is
/***************************************************************************************
// Функция: B_F_AmountLimit_AdrHelp
// Наименование: Функция, определяющая контроль на предельную сумму, при которой
//               допускается получение адресной социальной помощи 752
// Автор: Абрамович М.В.
// Состояние на дату 29.12.2011,14.07.2016(Denom),10.11.2017
// Код возврата: True - ССД меньше  установленной суммы, False - ССД больше
//               установленной суммы или ССД не вводилось вообще
//**************************************************************************************/
BPM_Now number; --БПМ на дату назначения  29.12.2011
BPM_Old number; --БПМ за прошлый квартал
Crit_Need number; --Критерий нуждаемости
Start_SDD   Date;
cFactorRound NUMBER; -- коэффициент округления --19.11.2017
begin
  BPM_Now:=S_CONST(18, XLPL.WorkDate);
  Crit_Need:= BPM_Now;
 --14.07.2016 BPM_Old:=S_CONST(18, ADD_MONTHS(XLPL.WorkDate,-3));
  --14.07.2016 if BPM_Now < BPM_Old then Crit_Need:=BPM_Old; end if;
  -- Если СДД не превышает % установленной суммы критерия нуждаемости, то
 --14.07.2016  if (B_F_Denom(B_F_RelProtAmountSSD()) <= (Crit_Need*S_CONST(47, XLPL.WorkDate)/100)) then
   Start_SDD:=NULL;
   begin
     select RECORD_START into Start_SDD
     from W$CASE_SUMMARY_INCOME
     where CID = XLPL.CID
     and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
     and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
     and NVL(STAGE,0) not IN (2,3);
   exception  --12.01.2016
        when NO_DATA_FOUND then
          Start_SDD:=XLPL.WorkDate;
   end;
--*10.11.2017
  BEGIN
        SELECT VALUE INTO cFactorRound  -- читаем коэффициент округления
        FROM LEGAL_CONSTANTS
        WHERE CODE = 17
        AND START_DATE = (SELECT MAX(START_DATE)
                          FROM LEGAL_CONSTANTS
                          WHERE CODE = 17
                          AND START_DATE <= XLPL.WorkDate);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN cFactorRound := 1;
      END;
--*
  --10.11.2017if (B_F_ModernSum (B_F_RelProtAmountSSD(),Start_SDD,XLPL.WorkDate) <= (Crit_Need*S_CONST(47, XLPL.WorkDate)/100)) then
  --10.11.2017 1. 5критерия нуждаемости нужно округлить
  if (B_F_ModernSum (B_F_RelProtAmountSSD(),Start_SDD,XLPL.WorkDate) <= S_VRound_Sum((Crit_Need*S_CONST(47, XLPL.WorkDate)/100),cFactorRound)) then
     --raise_application_error(-20004,'Отладка B_F_AmountLimit_AddrHelp2  1.5 КрНуж='||S_VRound_Sum((Crit_Need*S_CONST(47, XLPL.WorkDate)/100),cFactorRound));
    Return True;  -- возвратить "СДД меньше или равно установленной суммы"
  else
    Return False;  -- иначе - "СДД больше установленной суммы"
  end if;
end B_F_AmountLimit_AddrHelp2;
/
