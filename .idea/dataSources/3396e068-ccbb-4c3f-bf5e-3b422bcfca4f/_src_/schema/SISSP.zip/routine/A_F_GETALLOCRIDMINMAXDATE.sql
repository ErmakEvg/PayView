CREATE FUNCTION       A_F_GetAllocRIDMinMaxDate(aHighAllocCode NUMBER,
      aLowAllocCode VARCHAR2, aRecipient NUMBER) RETURN DBMS_SQL.Number_Table IS
--==============================================================================
-- Назначение: возвращает массив RID-ов записей в ALLOCATION,
--             у которых ALLOC_CODE является кодом нижнего уровня в ALLOCATIONS
--             для кода высокого уровня (пенсия, пособие) AHighAllocCode
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Входные праметры:
---------------------
-- aHighAllocCode - код высокого уровня (пенсия, пособие)
-- aLowAllocCode  - строка кодов нижнего уровня, если требуется
-- aRecipient     - значение получателя ( -1 - не важно,
--                                         0 - не получатель,
--                                         1 - получатель)
--------------------------------------------------------------------------------
-- Возвращаемое значение: массив RID-ов
--==============================================================================

xResume DBMS_SQL.Number_Table;
xLowAllocCode DBMS_SQL.Number_Table;
currLowAllocCode NUMBER;
xMinDate DATE;
xPID NUMBER;
i NUMBER;
k NUMBER;

BEGIN
xResume.Delete;
xLowAllocCode.Delete;
xPID := XLPL.GETPID;
xLowAllocCode := S_ParseFloatArray(aLowAllocCode);
xMinDate := A_F_CMinDate;
if xLowAllocCode.Count = 0 then
  FOR cRec1 IN (select a.RID, MIN(a.ALLOCATION_START) as ALLOC_START
                from ALLOCATION a, ALLOCATION_PERSON b, RECIPIENT c
                where a.RID = b.ALLOCATION_RID
				and ((a.CLOSE_DATE is NULL and a.ALLOC_STATUS = 1)
				     or (a.STEP_START = a.STEP_END and a.ALLOC_STATUS = 3))
				and ((aRecipient in (-1, 0))
				     or (aRecipient = 1 and c.PID = b.PID))
				and c.STAGE is NULL
				and c.CLOSE_DATE is NULL
				and c.CID = a.CID
				and b.PID = xPID
				and aHighAllocCode in (select CODE
				                       from ALLOCATIONS
									   where PARENT_CODE is NULL
									   start with CODE = a.ALLOC_CODE
									   connect by prior PARENT_CODE = CODE)
                group by a.RID)
  LOOP
    xResume(xResume.Count + 1) := cRec1.RID;
  END LOOP;
  FOR cRec2 IN (select a.RID, NVL(MIN(a.ALLOCATION_END), xMinDate) as ALLOC_END
               from ALLOCATION a, ALLOCATION_PERSON b, RECIPIENT c
               where a.RID = b.ALLOCATION_RID
			   and ((a.CLOSE_DATE is NULL and a.ALLOC_STATUS = 1)
			        or (a.STEP_START = a.STEP_END and a.ALLOC_STATUS = 3))
			   and ((aRecipient in (-1, 0))
			        or (aRecipient = 1 and c.PID = b.PID))
			   and c.STAGE is NULL
			   and c.CLOSE_DATE is NULL
			   and c.CID = a.CID
			   and b.PID = xPID
			   and aHighAllocCode in (select CODE
			                          from ALLOCATIONS
									  where PARENT_CODE is NULL
				                      start with CODE = a.ALLOC_CODE
				                      connect by prior PARENT_CODE = CODE)
               group by a.RID)
  LOOP
    if cRec2.ALLOC_END = xMinDate then
      xResume(xResume.Count + 1) := cRec2.RID;
    end if;
  END LOOP;
else
  k := xLowAllocCode.Count;
  FOR i IN 1..k LOOP
    currLowAllocCode := xLowAllocCode(i);
	FOR cRec3 IN (select a.RID, MIN(a.ALLOCATION_START) as ALLOC_START
                  from ALLOCATION a, ALLOCATION_PERSON b, RECIPIENT c
                  where a.RID = b.ALLOCATION_RID
				  and ((a.CLOSE_DATE is NULL and a.ALLOC_STATUS = 1)
				       or (a.STEP_START = a.STEP_END and a.ALLOC_STATUS = 3))
				  and ((aRecipient in (-1, 0))
				       or(aRecipient = 1 and c.PID = b.PID))
				  and c.STAGE is NULL
				  and c.CLOSE_DATE is NULL
				  and c.CID = a.CID
				  and b.PID = xPID
				  and aHighAllocCode in (select CODE
				                         from ALLOCATIONS
										 where PARENT_CODE is NULL
				                         start with CODE = a.ALLOC_CODE
				                         connect by prior PARENT_CODE = CODE)
			      and currLowAllocCode in (select CODE
				                           from ALLOCATIONS
				                           start with CODE = a.ALLOC_CODE
				                           connect by prior PARENT_CODE = CODE)
		          group by a.RID)
    LOOP
      xResume(xResume.Count + 1) := cRec3.RID;
    END LOOP;
  END LOOP;
  FOR i IN 1..k LOOP
    currLowAllocCode := xLowAllocCode(i);
	FOR cRec4 IN (select a.RID,
	                     NVL(MIN(a.ALLOCATION_END), xMinDate) as ALLOC_END
                  from ALLOCATION a, ALLOCATION_PERSON b, RECIPIENT c
                  where a.RID = b.ALLOCATION_RID
				  and ((a.CLOSE_DATE is NULL and a.ALLOC_STATUS = 1)
				       or (a.STEP_START = a.STEP_END and a.ALLOC_STATUS = 3))
				  and ((aRecipient in (-1, 0))
				       or(aRecipient = 1 and c.PID = b.PID))
			      and c.STAGE is NULL
				  and c.CLOSE_DATE is NULL
				  and c.CID = a.CID
				  and b.PID = xPID
				  and aHighAllocCode in (select CODE
				                         from ALLOCATIONS
										 where PARENT_CODE is null
				                         start with CODE = a.ALLOC_CODE
				                         connect by prior PARENT_CODE = CODE)
			      and currLowAllocCode in (select CODE from ALLOCATIONS
				                           start with CODE = a.ALLOC_CODE
				                           connect by prior PARENT_CODE = CODE)
		          group by a.RID)
	LOOP
      if cRec4.ALLOC_END = xMinDate then
        xResume(xResume.Count + 1) := cRec4.RID;
      end if;
	END LOOP;
  END LOOP;
end if;
RETURN xResume;
END A_F_GetAllocRIDMinMaxDate;
/
