CREATE FUNCTION       B_F_CHILDBIRTH RETURN DBMS_SQL.Number_Table AS
/***************************************************************************************
 Функция          : B_F_CHILDBIRTH
 Наименование     : Функция определяет дату рождения ребенка, появившегося в деле
 Автор            : Ворошилин В.                Комментарии и коректировка: ОЛВ
 Состояние на дату: 20.01.2000                         20.07.2012
 Возвращает       : массив
***************************************************************************************/

  A DBMS_SQL.Number_Table;
  BDay DATE;
  EDay DATE;
BEGIN
  A.Delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CHECKROLE(56) then
	return A;
  end if;
  XLPL.REPLACEROLE('Child');
  BDay := S_Birthdate(XLPL.BASE_ID, XLPL.GetPid, XLPL.WorkDate);
  XLPL.RESTOREROLE;
  EDay := S_AddYears(BDay, TRUNC(S_Const(401, XLPL.WorkDate)));
  for ACTSTART in (Select nvl(a.BIRTH_DATE, NULL) as bufBIRTH_DATE From W$PERSON a, W$CASE_PERSON c
                   Where c.CID = XLPL.CID
				     and c.PID <> XLPL.GetPid
					 and c.ROLE in (56, 68)
					 and a.PID = c.PID
					 and a.ENTERED_BY = XLPL.User_ID
					 and c.ENTERED_BY = XLPL.User_ID
					 and a.STAGE=4 -- 20.07.2012  OLV -- только при первом появлении ребенка в деле
					 and a.BIRTH_DATE > BDay)
  LOOP
    if (ACTSTART.bufBIRTH_DATE is not NULL) and (ACTSTART.bufBIRTH_DATE < EDay) or (ACTSTART.bufBIRTH_DATE < Last_Day(S_CURRDATE)) then
	  A(A.count+1) := S_Julian(ACTSTART.bufBIRTH_DATE);
	end if;
  end LOOP;
  RETURN A;
END B_F_CHILDBIRTH;
/
