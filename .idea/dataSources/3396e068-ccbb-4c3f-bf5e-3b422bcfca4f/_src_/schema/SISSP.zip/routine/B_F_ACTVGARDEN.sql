CREATE FUNCTION       B_F_ActvGarden RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_ActvGarden
// Наименование: Функция определения посещения ребенком детского сада
// Автор: Гуз Е.
// Состояние на дату 28.01.1999
// Возвращает: True - если лицо активно, False - если лицо не активно
//***************************************************************************************/

  CN_ACTIVITY NUMBER;
BEGIN
  Select COUNT(*) INTO CN_ACTIVITY From W$ACTIVITY
    Where PID = XLPL.GetPid
	  and ACTIVITY = 2
	  and LABOR = 221
	  and ENTERED_BY = XLPL.User_ID
	  and STAGE NOT IN(2,3) ;
  if CN_ACTIVITY = 0 then
    Select COUNT(*) INTO CN_ACTIVITY From  ACTIVITY
	  Where PID = XLPL.GetPid
	    and ACTIVITY = 2
		and LABOR = 221
		and STAGE NOT IN(2,3) ;
  end if;
  if CN_ACTIVITY = 0 then
    return False;
  else
    return true;
  end if;
END B_F_ActvGarden;
/
