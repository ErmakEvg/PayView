CREATE FUNCTION       A_F_ViplPeriod_EndCorr RETURN DATE IS
/**********************************************************************************************
 Функция                 : P_ViplPeriod_End
 Наименование        : Функция получения даты  конца выплатного периода
 Автор                     : ОЛВ
 Состояние на дату  : 26.06.2013
 Код возврата          : Возвращает дату конца выплатного периода
***********************************************************************************************/
  Metric_End DATE;
BEGIN
    SELECT NVL(RECORD_END, NULL)
	     INTO Metric_End
       FROM W$PERSON_METRIC pm, ACCOUNTING_PERIOD ap
        WHERE pm.PID = Xlpl.GetPid
              AND pm.code=740     -- 740 - Требуется ручная корректировка суммы назначения за текущий выплатной период
              AND pm.STAGE IN (1, 4)
              AND pm.ENTERED_BY = Xlpl.User_ID
              AND (pm.RECORD_START IS NOT NULL)
              AND (pm.RECORD_START =ap.period)
              AND (pm.RECORD_END IS NOT NULL)
             -- AND ((NVL(RECORD_START, LAST_DAY(SYSDATE)) < LAST_DAY( LAST_DAY(SYSDATE)+1)) AND (NVL(RECORD_END, LAST_DAY(SYSDATE)) < LAST_DAY( LAST_DAY(SYSDATE)+1)))
              AND ap.sign_close_period IS NULL;
  RETURN Metric_End;
				--   RAISE_APPLICATION_ERROR(-20801,'A_F_ViplPeriod_End 11111'||'   Metric_End='|| Metric_End||'   XLPL.WorkDate='||  Xlpl.WorkDate);
END A_F_ViplPeriod_EndCorr;
/
