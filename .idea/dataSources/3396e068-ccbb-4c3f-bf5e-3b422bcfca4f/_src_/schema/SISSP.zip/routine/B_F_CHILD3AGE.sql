CREATE FUNCTION       B_F_CHILD3AGE RETURN DBMS_SQL.NUMBER_TABLE IS
/***************************************************************************************
// Функция: F_CHILDBIRTH
// Наименование: Функция определяет дату исполнения 3 лет ребенку, появившемуся в деле
// Автор: Трухтанов
// Состояние на дату 20.01.2000
// Возвращает: массив
//***************************************************************************************/

A DBMS_SQL.NUMBER_TABLE;
BDay date;
StartDateBD date;
Dt date;
DateTalk date;
ACTSTART date;

BEGIN
  A.delete;
  if (not XLPL.CheckRole(56))
    then Return A;
    else XLPL.ReplaceRole('Child');
  end if;

  BDay := S_BIRTHDATE(1, XLPL.GETPID, XLPL.WORKDATE);
  StartDateBD := S_AddYears(BDay,S_Const(401, XLPL.WORKDATE))+1;
  Dt := S_DateConst(478, XLPL.WORKDATE);
  Dt := S_EncodeDate(S_YearOfDate(XLPL.WORKDATE), S_MonthOfDate(Dt), S_DayOfDate(Dt));
  if (StartDateBD >= Dt) AND (StartDateBD <= XLPL.WORKDATE) then
   	Dt := StartDateBD;
  end if;
  DateTalk := Last_Day(S_CurrDate);

  for C1 in (	Select a.BIRTH_DATE as BIRTH_DATE
                From   W$PERSON a,
				       W$CASE_PERSON c
                Where  c.CID = XLPL.CID and
				       c.PID <> XLPL.GETPID and
				       c.ROLE in (56, 68) and
				       a.PID = c.PID and
                       a.ENTERED_BY = XLPL.USER_ID and
				       c.ENTERED_BY = XLPL.USER_ID
			   )
  LOOP
    ACTSTART := C1.BIRTH_DATE;
	ACTSTART := S_AddYears(ACTSTART,S_Const(401, XLPL.WORKDATE))+1;
	  if (ACTSTART >= Dt) AND (ACTSTART <= DateTalk) then
      	A(A.COUNT+1) := s_julian(ACTSTART);
	  end if;
  end loop;

  XLPL.RestoreRole;
  Return A;

END B_F_CHILD3AGE;
/
