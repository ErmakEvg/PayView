CREATE FUNCTION       A_F_GETPIDWALLOC_PERSON(aCID in NUMBER, aAlloc_Code in NUMBER, aAID in NUMBER,
                                                   aROLE in NUMBER, Date_talk IN DATE) RETURN NUMBER AS
/**************************************************************************************
 NAME           : A_F_GETPIDWALLOC_PERSON
 Назначение     : Получить PID из W$ALLOCATION_PERSON
 Автор          : ОЛВ
 Дата           : 18.03.2011
 Код возврата   : PID
***************************************************************************************/
 pPID               NUMBER;
BEGIN
 BEGIN
    SELECT PID
	  into pPID
      from W$ALLOCATION_PERSON
	 where Allocation_RID = (
                   SELECT RID
                     from W$ALLOCATION
	                where cid = aCID
	                  and aid = aAID
	                  and alloc_code = aAlloc_Code
	                  and parent_rid is null
	                  and alloc_status in (2, 3)
	                  and step_start <= Date_talk
	                  and ((step_end >= Date_talk) or (step_end is null) )  )
	   and ROLE=aROLE
	   and stage in (1,4)
	   and ENTERED_BY = XLPL.USER_ID;
 exception
    when No_Data_Found then
	    	 pPID := NULL;
 end;
 RETURN pPID;

END A_F_GETPIDWALLOC_PERSON;
/
