CREATE FUNCTION       A_F_Relprot_RESIDING RETURN NUMBER IS
/***********************************************************************************************
 NAME                   : A_F_Relprot_RESIDING
 Назначение           : Возращает PRICE из PERSON_RESIDING_FEATURE
                                согласно W$RELATION_PROTOCOL
 Автор                    : ОЛВ
 Состояние на дату : 25.03.2013
 Код возврата         : Стоимость содержания в ИТУ
************************************************************************************************/
 vPrice         NUMBER;
BEGIN
 IF (Xlpl.INDIV <>2) then -- не массовый расчет -- 21.03.2012
   -- Выбрать в РБД из W$_RESIDING_FEATURE
    vPrice:=A_F_RelprotGetRESIDING(0);
 else
   -- Выбрать в ОБД из PERSON_RESIDING_FEATURE
     vPrice:=A_F_RelprotGetRESIDING(1);
 end if;
 if vPrice=-1 then
      vPrice:=null;--0;
 end if;
 return vPrice;
/* *
 vPrice                      NUMBER;
 vRID                        NUMBER;
 xWorkDate               DATE;
BEGIN
   xWorkDate := ADD_MONTHS(Xlpl.WorkDate, -1);

 vPrice := NULL;
  vRID:=A_F_Relprotgetrid_RESIDING;
  IF  vRID <> -1 THEN
 --RAISE_APPLICATION_ERROR(-20801,' A_F_Relprot_RESIDING 00  XLPL.WORKDATE='||Xlpl.WORKDATE||', xWorkDate='||xWorkDate||', XLPL.CID='||Xlpl.CID||', vPrice='||vPrice);
   SELECT NVL(Price, NULL)
    INTO vPrice
    FROM PERSON_RESIDING_FEATURE
    WHERE RID =  vRID
      AND PERIOD_START <= xWorkDate
      AND (PERIOD_END >= xWorkDate OR PERIOD_END IS NULL);
  ELSE
       vRID:=A_F_Relprotgetridw_RESIDING;
--RAISE_APPLICATION_ERROR(-20801,' A_F_Relprot_RESIDING 11  XLPL.WORKDATE='||Xlpl.WORKDATE||', xWorkDate='||xWorkDate||', XLPL.CID='||Xlpl.CID||', vPrice='||vPrice);
    IF vRID <> -1 THEN
      SELECT NVL(Price, NULL)
      INTO vPrice
      FROM W$PERSON_RESIDING_FEATURE
      WHERE RID =  vRID
        AND PERIOD_START <= xWorkDate
        AND (PERIOD_END >= xWorkDate OR PERIOD_END IS NULL);
    END IF;
  END IF;

  IF vPrice IS NOT NULL THEN
       RETURN vPrice;
  ELSE
       RETURN 0;
  END IF;
  /* */
END A_F_Relprot_RESIDING;
/
