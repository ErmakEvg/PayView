CREATE FUNCTION       A_F_RelProtSp_Pov RETURN NUMBER IS
/***************************************************************************************
 Функция            : A_F_RelProtSp_Pov
 Наименование       : функция расчета превышения специального стажа
                       для увеличения размера пенсии
 Автор              : Вахромин О.Ю.                Корректировка: ОЛВ
 Состояние на дату  :                                               30.09.2010
 Код возврата       : Специальный стаж для увеличения размера пенсии
***************************************************************************************/
 st             number;
 vGender        number;
 vAF            number;
 StSpProf       NUMBER;        -- специальный проф.стаж -- 30.09.2010
 StSp           NUMBER;        -- специальный стаж
BEGIN
   if A_F_RelProtGender=1 then
      St:=S_CONST(113,XLPL.WorkDate);   -- Стаж работы по списку №1 (мужчины)
   else    --end if;    if vGender=2 then
      St:=S_CONST(114,XLPL.WorkDate);
   end if;

  -- vAF:=A_F_RelProtRecord(3)+A_F_RelProtRecord(4)+A_F_RelProtRecord(6)+
  --    A_F_RelProtRecord(7)-St;

    StSp  :=A_F_RelProtRecord(3)+ A_F_RelProtRecord(4)+
            A_F_RelProtRecord(6)+ A_F_RelProtRecord(7);
    -- специальный проф.стаж учитывать при расчете превышения спец. стажа
    StSpProf  :=A_F_RelProtRecord_Prof(3)+ A_F_RelProtRecord_Prof(4)+
            A_F_RelProtRecord_Prof(6)+ A_F_RelProtRecord_Prof(7);
  vAF:=StSp + StSpProf - St;
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtSp_Pov 111 StSp='||StSp||'    StSpProf ='||StSpProf );

   if vAF>0 then
      return trunc(vAF/360);
   else
      return 0;
   end if;
	/*
	-- ОЛВ 01.10.2010 заплатка пока не разделили профстаж СП1 на СП1 и СП1 подз. !!!!!!! С.А.
   if xlpl.ALLOC_CODE=81 then
      StSpProf  :=A_F_RelProtRecord_Prof(3)+
            A_F_RelProtRecord_Prof(6)+ A_F_RelProtRecord_Prof(7);
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtSp_Pov 111 StSpProf ='||StSpProf );
	elsif
	  xlpl.ALLOC_CODE=82 then
        StSpProf  :=A_F_RelProtRecord_Prof(4)+
            A_F_RelProtRecord_Prof(6)+ A_F_RelProtRecord_Prof(7);

--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtSp_Pov 111 StSpProf ='||StSpProf );
	else
      StSpProf  :=A_F_RelProtRecord_Prof(3)+ A_F_RelProtRecord_Prof(4)+
            A_F_RelProtRecord_Prof(6)+ A_F_RelProtRecord_Prof(7);
-- RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtSp_Pov 222 xlpl.ALLOC_CODE ='||xlpl.ALLOC_CODE );
   end if;
   /* */
END A_F_RelProtSp_Pov;
/
