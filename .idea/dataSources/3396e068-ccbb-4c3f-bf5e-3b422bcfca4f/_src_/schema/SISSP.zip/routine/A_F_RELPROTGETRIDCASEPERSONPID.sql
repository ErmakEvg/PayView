CREATE FUNCTION       A_F_RELPROTGETRIDCASEPERSONPID RETURN DBMS_SQL.NUMBER_TABLE AS

/* -------------------------------------------------------------
// Автор: Басинюк Я.В.
// состояние на 10.05.1999
// Код возврата: RID из W$CASE_PERSON согласно коду по W$RELATION_PROTOCOL
// -------------------------------------------------------------*/

  xDRIDS DBMS_SQL.NUMBER_TABLE;
  vsRELATION_TABLE BINARY_INTEGER;
  vsDRID NUMBER;
BEGIN
  xDRIDS.delete;
  vsRELATION_TABLE := S_CodeTableSISSP('CASE_PERSON');
  if XLPL.AID = 0 then
    for vsDRID in (select DATA_RID from W$RELATION_PROTOCOL b, CASE_PERSON a
                   where b.CID = XLPL.CID
				     and GROUP_NO = XLPL.GROUP_NO
					 and ALLOC_CODE = XLPL.ALLOC_CODE
					 and RELATION_TABLE = vsRELATION_TABLE
					 and RELATION_DATE = XLPL.WorkDate
					 and b.ENTERED_BY = XLPL.USER_ID
					 and DATA_RID = a.RID
					 and NVL(a.RECORD_START, XLPL.WORKDATE) <= XLPL.WORKDATE
					 and NVL(a.RECORD_END, XLPL.WORKDATE) >= XLPL.WORKDATE)

	loop
	  xDRIDS(xDRIDS.count+1) := vsDRID.DATA_RID;
	end loop;
  else
    for vsDRID in (select DATA_RID from W$RELATION_PROTOCOL b, CASE_PERSON a
                   where b.CID = XLPL.CID
					 and AID = XLPL.AID
					 and ((GROUP_NO = XLPL.GROUP_NO) or (XLPL.GROUP_NO = 0))
					 and ALLOC_CODE = XLPL.ALLOC_CODE
					 and b.ENTERED_BY = XLPL.USER_ID
					 and RELATION_TABLE = vsRELATION_TABLE
					 and RELATION_DATE = XLPL.WorkDate
					 and DATA_RID = a.RID
					 and NVL(a.RECORD_START, XLPL.WORKDATE) <= XLPL.WORKDATE
					 and NVL(a.RECORD_END, XLPL.WORKDATE) >= XLPL.WORKDATE)
	loop
	  xDRIDS(xDRIDS.count+1) := vsDRID.DATA_RID;
    end loop;
  end if;
  return xDRIDS;
END A_F_RELPROTGETRIDCASEPERSONPID;
/
