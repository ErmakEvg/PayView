CREATE FUNCTION       A_F_ArrayDateConstant(pPeriod_Start in Date,
   pPeriod_End in Date,code_const in VarChar2) RETURN DBMS_SQL.Number_Table IS
/*Возвращает массив дат по изменениям законодательных констант
Вахромин О.Ю.*/
pCode_Const DBMS_SQL.Number_Table;
result_array DBMS_SQL.Number_Table;
prev_start date;
prev_end date;
BEGIN
   result_array.delete;
   pCode_Const:=S_ParseFloatArray(code_const);
   if pCode_Const.Count<>0 then
      for i in 1..pCode_Const.count loop
         prev_start:=NULL;
         prev_end:=NULL;
         for c1 in (SELECT start_date,close_date from legal_constants WHERE
            code=pCode_Const(i) and start_date>=pPeriod_Start and
            close_date<=pPeriod_End order by Start_Date) loop
			if ((prev_start is NULL)and(prev_end is NULL))or(c1.Start_Date=c1.Close_Date) then
               if (c1.Start_Date>pPeriod_Start)and(S_DayOfDate(c1.Start_Date)<>1) then
                  result_array(result_array.count+1):=s_julian(c1.Start_Date);
               end if;
			else
               if ((prev_end+1)<>c1.Start_Date)and(prev_end<pPeriod_End) then
                  result_array(result_array.count+1):=s_julian(prev_end+1);
               end if;
               if (c1.Start_Date>pPeriod_Start)and(S_DayOfDate(c1.Start_Date)<>1) then
                  result_array(result_array.count+1):=s_julian(c1.Start_Date);
               end if;
			end if;
			prev_start:=c1.Start_Date;
			prev_end:=c1.Close_Date;
         end loop;
      end loop;
   end if;
   ----- избавимся от повторений -----
   return A_F_ArrayDataChangeDelDup(result_array);
END A_F_ArrayDateConstant;
/
