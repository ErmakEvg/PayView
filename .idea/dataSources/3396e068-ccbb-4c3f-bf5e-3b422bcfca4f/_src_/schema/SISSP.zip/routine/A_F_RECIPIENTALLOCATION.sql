CREATE FUNCTION       A_F_RecipientAllocation(pAlloc_Code in NUMBER) RETURN Boolean IS
vCount number;
/*******************************************************************************
 Функция: A_F_RecipientAllocation
 Наименование: определение действующего шага назначения с заданным pAlloc_Code
 Автор: Холодова
 Состояние на дату 08.01.2002         04.10.2016 Исправлено ОЛВ
 Код возврата: TRUE есть действующий шаг назначения
               FALSE нет действующего шага назначения
*******************************************************************************/
BEGIN
 Select COUNT(*) into vCount
   From allocation_role_Group b,allocation c,allocation_person d,allocations a
   Where d.pid = XLPL.GetPid and
         d.role = b.code and
         a.code = pAlloc_Code and
             a.role_group = b.parent_code and
         b.feature = 1 and
             c.alloc_code = pAlloc_Code and
         c.parent_rid is null and
         c.cid <> XLPL.cid and
         c.alloc_status = 1 and
         c.rid = d.allocation_rid and
         c.step_start <= XLPL.WorkDate
         and c.stage is null ----04.10.2016 ОЛВ
         and c.step_end is null----04.10.2016 ОЛВ
         ;
  -- return vcount<>0;
   IF vcount<>0 THEN   ----04.10.2016 ОЛВ
     RETURN TRUE;
   ELSE
     RETURN FALSE;
   END IF;
exception
   when OTHERS then
      RAISE_APPLICATION_ERROR(-20801,'A_F_RecipientAllocation:'||SQLERRM);
END A_F_RecipientAllocation;
/
