CREATE FUNCTION       B_Child16_NadbavkaT RETURN DBMS_SQL.NUMBER_TABLE AS
/***************************************************************************************/
/* Функция: B_Child16_NadbavkaT
/* Наименование: переключатель по датам
/* Наименование: Проверка права и вычисление надбавок на пособие детям старше 3 лет
/* Автор: Ворошилин В.
/* Состояние на дату 26.09.2002
/***************************************************************************************/
BEGIN
   if XLPL.WorkDate < to_date('01-07-2002','DD-MM-YYYY') then
      return B_Child16_NadbavkaT_0;
   else
      return B_Child16_NadbavkaT_20020701;
   end if;
END B_Child16_NadbavkaT;
/
