CREATE FUNCTION       B_F_CHILDBD RETURN DBMS_SQL.NUMBER_TABLE IS
/***************************************************************************************
// Функция: F_CHILDBD
// Наименование: Функция определяет дату рождения ребенка, появившегося в деле
// Автор: Ворошилин В.
// Состояние на дату 20.01.2000
// Возвращает: массив с датой рождения появившегося в деле ребенка
//***************************************************************************************/

A DBMS_SQL.NUMBER_TABLE;
--ACTSTART date default null;
BDay date;
StartDateBD date;
Dt date;
DateTalk date;


BEGIN
  A.delete;
  if (not XLPL.CheckRole(56))
    then Return A;
    else XLPL.ReplaceRole('Child');
  end if;

  BDay := S_BIRTHDATE(1, XLPL.GETPID, XLPL.WORKDATE);

  StartDateBD := S_AddYears(BDay,S_Const(401, XLPL.WORKDATE))+1;
  Dt := S_DateConst(478, XLPL.WORKDATE);
  Dt := S_EncodeDate(S_YearOfDate(XLPL.WORKDATE), S_MonthOfDate(Dt), S_DayOfDate(Dt));
  if (StartDateBD >= Dt) AND (StartDateBD <= XLPL.WORKDATE) then
   	Dt := StartDateBD;
  end if;
  DateTalk := Last_Day(S_Currdate);

  for REC in (
		 		  select PID as wPID
				  from W$CASE_PERSON
				  where CID = XLPL.CID and
				  		 ROLE in (56, 68) and
				       STAGE NOT IN(2,3) and
				       ENTERED_BY = XLPL.USER_ID
		 		)
  LOOP
    for REC1
	 	 in (
		 		Select nvl(BIRTH_DATE, null) as ACTSTART
                From   W$PERSON
                Where  PID = rec.wPID and
				       STAGE not in (2,3) and
				       ENTERED_BY = XLPL.USER_ID
			   )
    LOOP
	  if (REC1.ACTSTART != null) AND (REC1.ACTSTART >= XLPL.WORKDATE) AND (REC1.ACTSTART < DateTalk) then
      	  A(A.Count+1) := s_julian(REC1.ACTSTART);
      end if;
	end loop;
  end loop;
  XLPL.RestoreRole;
  Return A;
END B_F_CHILDBD;
/
