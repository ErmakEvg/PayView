CREATE FUNCTION       B_F_ARRAYDATEESTOTHEREST RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_ARRAYDATEESTOTHEREST
+ Наименование: Получить массив дат предполагаемых завершений действия всех
+ 				назначений дела
+ Автор: Ворошилин В.
+ Состояние на дату 12.12.2000
==============================================================================*/

  a DBMS_SQL.NUMBER_TABLE;
  StopDtEnd DATE;
BEGIN
  a.Delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CheckRole(56) then
    return a;
  end if;
  XLPL.REPLACEROLE('Child');
  StopDtEnd := S_EncodeDate(S_YearOfDate(XLPL.WorkDate), S_MonthOfDate(S_Jtod(TRUNC(S_Const(479, XLPL.WorkDate)))), S_DayOfDate(S_Jtod(TRUNC(S_Const(479, XLPL.WorkDate)))));
  for OTHEREST in (select nvl(Estimation_Date, NULL) as Dt, STATUS_REASON, CHANGE_ALLOC_STATUS
                   from W$ALLOC_DATE_ESTIMATION
				   where CID = XLPL.CID
				     and AID <> XLPL.AID
					 and ALLOC_CODE in (select CODE from ALLOCATIONS where PARENT_CODE = 420)
					 and STAGE in (1, 4)
					 and ENTERED_BY = XLPL.User_ID)
  loop
	if (OTHEREST.Dt <= StopDtEnd) and (OTHEREST.Dt > LAST_DAY(S_CurrDate)) then
	  a(a.count+1) := S_Julian(OTHEREST.Dt);
	  a(a.count+1) := OTHEREST.STATUS_REASON;
	  a(a.count+1) := OTHEREST.CHANGE_ALLOC_STATUS;
	end if;
  end loop;
  XLPL.RESTOREROLE;
  return a;
END B_F_ARRAYDATEESTOTHEREST;
/
