CREATE FUNCTION       B_F_ARRAYDATEMINDEL(aData IN DBMS_SQL.NUMBER_TABLE) RETURN DBMS_SQL.NUMBER_TABLE AS
/***************************************************************************************
 Функция           : B_F_ARRAYDATEMINDEL
 Наименование      : Выбор минимальной тройки элементов
                      с удалением троек с технологическим кодом (код 998)
 Автор             :  Ворошилин В.           Корректировка и коментарии : ОЛВ
 Состояние на дату : 26.11.2000					   				      01.12.2010
 Код возврата      : Нумерация индексов результата - с нуля по возрастанию с шагом 3
***************************************************************************************/
 result    DBMS_SQL.NUMBER_TABLE;
 bufArray  DBMS_SQL.NUMBER_TABLE;
 i         BINARY_INTEGER;
 j         BINARY_INTEGER;
 k         BINARY_INTEGER;
BEGIN
  if aData.count = 0 then
    return aData;
  end if;

  result.Delete;
  bufArray.Delete;

    i := 1;
  while (i < aData.count) loop
    if aData(i+1) <> 998 then
	  bufArray(bufArray.count +1) := aData(i);
	  bufArray(bufArray.count +1) := aData(i+1);
	  bufArray(bufArray.count +1) := aData(i+2);
	end if;
	i := i+3;
  end loop;

 IF bufArray.count>0 then -- OLV 01.12.2010 00
   i := 1;
   j := bufArray(1);
   k := 1;
  while (i < bufArray.count) loop
    if bufArray(i) < j then
	  j := bufArray(i);
	  k := i;
	end if;
    i := i+3;
  end loop;
  result(result.count+1) := bufArray(k);
  result(result.count+1) := bufArray(k+1);
  result(result.count+1) := bufArray(k+2);
 END IF;

  return result;
END B_F_ARRAYDATEMINDEL;
/
