CREATE FUNCTION       B_F_CHECKPLAN_751(
                                                        pCID         IN NUMBER,
                                                        pDateHelp IN DATE,
                                                        pUser_ID   IN NUMBER)
RETURN NUMBER IS
/******************************************************************************
 Функция           :    B_F_CHECKPLAN_751
 Назначение     :   Функция, которая определяет проверку выполнения плана
                          :  по самостоятельному улучшению материального положения
 Основание       :   Положение о порядке предоставления государственной
                          : адресной социальной помощи по указу Президента
                          : Республики Беларусь № 41 от 19.01.2012г.(Изменения в ГАСП)
 Автор              : Ярошик А.К.
 Состояние на дату : 21.11.2018
                            :
 Возвращаемое  :
      значение       :  0 - не  имеет права, 1 - имеет право
 Изменения:

    Версия        Дата        Автор           Описание
    ---------  ----------  ---------------  ------------------------------------
    1.0        15.11.2018  Ярошик А.К.     Создание функции.

    Примечание:
      Таблица      : W$CASE_PERSON  - таблица персон
                         : W$FINANCE_PLAN - таблица плана персоны
      АРМ           : ГИССЗ
      Название программы : Case.pas ( пособие ГАСП )

*******************************************************************************/
  vRezult              Number;
  vCount               Number;
  vParAh              Number;
  vCID                 Number;
  vSignPlan          Number;
  vStartPlan          Date;
  vEndPlan           Date;
  vParAhEnd        Date;
  v_ErrorCode     Number;             -- переменная для хранения кода ошибки
  v_ErrorText       Varchar2(200);  -- переменная для хранения текста сообщения об ошибке

  Cursor Cursor_PID IS          -- данные по работе лица
    Select PID
    From W$CASE_PERSON
    Where CID= pCID
         and STAGE IN (1, 4)
         and ENTERED_BY = pUser_ID
    Order By PID;
BEGIN
  -- DateWork в F$CHECK751 - это 01 число месяца
  -- A_F_DATATALK          - дата обращения
  -- Select ADD_MONTHS(last_day(trunc(sysdate))+ 1, -1) From Dual
  --
  vCount:= 0;
  vRezult:= 1;
  --
  /****************************************************************************
      Анализ наличия данных в БД W$FINANCE_PLAN
  ****************************************************************************/
  --
  FOR rec1 IN Cursor_PID
  LOOP
    --
    Select count(*) INTO vCount
    From W$FINANCE_PLAN
    Where PID = rec1.PID
         and STAGE IN (1, 4)
         and ENTERED_BY = pUser_ID;
    --
    IF vCount> 0  THEN
      Select CID, RECORD_START, RECORD_END, SIGN_EXECUTE INTO vCID, vStartPlan, vEndPlan, vSignPlan
      From W$FINANCE_PLAN
      Where PID = rec1.PID
           and STAGE IN (1, 4)
           and ENTERED_BY = pUser_ID;
    END IF;
    --
    IF vSignPlan = 0 THEN
      IF vCID = pCID THEN
        vRezult:= 1;
      END IF;
      --
      IF vCID <> pCID THEN
        -- не истек срок выполнения плана
        IF pDateHelp <= vENDPlan  THEN
          vRezult:= 2;
          RETURN vRezult;
        END IF;
        -- истек срок периода назначения ГАСП ?
        Select count(*) INTO vParAh
        From PARAM_ADDR_HELP
        Where CID = vCID
             and STAGE IS Null;
        --
        IF vParAh  > 0 THEN
          Select TSSR_END INTO vParAhEnd
          From PARAM_ADDR_HELP
          Where CID = vCID
               and STAGE IS Null;
        END IF;
        --
        IF pDateHelp > vParAhEnd THEN
          vRezult:= 1;  -- истек срок периода назначения ГАСП
        ELSE
          vRezult:= 3;  -- не истек срок периода назначения ГАСП
        END IF;
        --
        /*IF pDateHelp >= ADD_MONTHS(vStartPlan, 12)  THEN
          vRezult:= 1;
        ELSE
          vRezult:= 0;
        END IF; */
      END IF;
    END IF;
    --
  END LOOP;
  --
  RETURN vRezult;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      vRezult:= 0;
    WHEN OTHERS THEN
      vRezult:= 0;
      v_ErrorCode := SQLCODE;
      v_ErrorText := substr(SQLERRM,1,200);
      --raise_application_error(-20001, SQLCODE || ': ' || SQLERRM);
      raise_application_error(-20001, v_ErrorText);
END B_F_CHECKPLAN_751;
/
