CREATE FUNCTION       A_F_RelProtRASCH RETURN NUMBER IS
/**********************************************************************************************
 Функция            : A_F_RelProtRASCH
 Наименование       : Метод расчета pr_RASCH из W$CASE для Межд.дог.с РФ
 Автор              : ОЛВ
 Состояние на дату  : 24.09.2010  20.12.2011  21.03.2012
 Код возврата       : Метод расчета - 1 - по пропорции
***********************************************************************************************/
 vsRASCH     NUMBER;
BEGIN
  vsRASCH:=0;
 IF (Xlpl.INDIV <>2) then -- не массовый расчет -- 21.03.2012
    -- Выбрать адрес в РБД pr_RASCH из W$CASE
    vsRASCH:=A_F_RelProtGetRASCH(0);
 else
    -- Выбрать адрес в ОБД pr_RASCH из CASE
    vsRASCH:=A_F_RelProtGetRASCH(1);
 end if;
 if vsRASCH=-1 then
    vsRASCH:=0;
 end if;
 return vsRASCH;
-- RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtGetRASCH  3 vsRASCH='||vsRASCH);
/* *
  vsRASCH:=0;
 -- Выбрать адрес в ОБД pr_RASCH из CASE
 vsRASCH:=A_F_RelProtGetRASCH(1); -- (1); сначала проверять в РБД, а то не видит при перерасчете, если изменили значение
	--vsRASCH:=A_F_RelProtGetRIDMETHOD(1);
 if vsRASCH=-1 then
    -- Выбрать адрес в РБД pr_RASCH из W$CASE
    vsRASCH:=A_F_RelProtGetRASCH(0); --(0);
	--vsRASCH:=A_F_RelProtGetRIDMETHOD(0);
    if vsRASCH=-1 then
      vsRASCH:=0;
    end if;
 end if;
 return vsRASCH;
/* */
END A_F_RelProtRASCH;
/
