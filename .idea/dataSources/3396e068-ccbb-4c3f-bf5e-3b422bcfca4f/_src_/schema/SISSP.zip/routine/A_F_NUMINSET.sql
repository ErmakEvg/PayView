CREATE FUNCTION       A_F_NumInSet(aNum in NUMBER, aSet in VARCHAR2)
                                                               RETURN BOOLEAN IS
--==============================================================================
-- Назначение: проверяет наличие числа в списке
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Возвращаемое значение: True - число в списке есть, в противном случае - False
--==============================================================================
xResume BOOLEAN;
xSet DBMS_SQL.Number_Table;
i NUMBER;
k NUMBER;

BEGIN
xResume := False;
xSet.Delete;
xSet := S_ParseFloatArray(aSet);
k := xSet.Count;
FOR i IN 1..k LOOP
  if aNum = xSet(i) then
    xResume := True;
	EXIT;
  end if;
END LOOP;
RETURN xResume;
END A_F_NumInSet;
/
