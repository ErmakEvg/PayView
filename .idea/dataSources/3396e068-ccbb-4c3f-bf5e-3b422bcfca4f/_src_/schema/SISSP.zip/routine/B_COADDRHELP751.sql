CREATE FUNCTION       B_COAddrHelp751 RETURN NUMBER AS

/**************************************************************************************
 Функция:      B_COAddrHelp751
 Наименование: Функция расчета суммы ежемесячного пособия (адресная социальная помощь)
 Автор:        Абрамович М.В.
 Состояние на дату 14.07 2014 ,20.08.2014, AMV 22.10.2014, AMV 03.03.2015,22.03.2016(DEN)
                   20.06.2016 (DEN), 18.10.2016(ок,)
                  ,26.07.2017 211 Ук ,22.08.2017 211 Ук,29.08.2017,01.09.2017

 Редактирование: Иванова Т.С. 20.08.2014
 Код возврата: число с суммой пособия
**************************************************************************************/

  Amount       NUMBER;
  Size_BPM     NUMBER;
  Size_BPM_OLD NUMBER;  --29.12.2011
  SDD          NUMBER;
  SDD_Factor   NUMBER;
  NMask        Varchar2(50);
  Factor       NUMBER;  --коэффициент
  wCID         NUMBER;  -- CID
  DateTalk     DATE;
  DateWork    Date;
  CNT_RBD     NUMBER;
  CNT_OBD     NUMBER;
  Fl_BZ_RBD   NUMBER;
  Start_SDD   Date;
  Start_GASP   Date;
BEGIN
/* Если среднедушевой доход семьи СДД на семью ниже наибольшей величины
   бюджета прожиточного минимума в среднем на душу населения за два последних квартала (критерий нуждаемости),
   то размер ежемесячного пособия  составляет положительную разность между критерием нуждаемости и СДД */
  XLPL.Payment:= 100;
  Factor:= 1;--26.07.2017
  Start_GASP:=XLPL.WorkDate;
 -- Получение коэф.Factor из T_PARAM_ADDRHELP
  if XLPL.INDIV= 2 then  --INDIV=2 - массовый расчет
    begin
      select VALUE_FACTOR INTO Factor
      from PARAM_ADDR_HELP a
      where a.CID = XLPL.CID
       and (a.STAGE not in (2,3) or a.STAGE is null);
      exception
        when NO_DATA_FOUND then
          Factor:= 1;
      end;

     --22.08.2017 -находим начало назначения
     begin
      --29.08.2017 select distinct ALLOCATION_START INTO Start_GASP
      select min(ALLOCATION_START) INTO Start_GASP
      from ALLOCATION
      where CID = XLPL.CID
       and NVL(STAGE,0) not in (2,3);
      exception
        when NO_DATA_FOUND then
          Start_GASP:=XLPL.WorkDate;
      end;

  else --индивидуальный расчет

    begin
      select VALUE_FACTOR INTO Factor
      from W$PARAM_ADDR_HELP a
      where a.CID = XLPL.CID
        and a.STAGE not in (2,3);
      exception
        when NO_DATA_FOUND then
          Factor:= 1;
      end;
          --22.08.2017 -находим начало назначения
    begin
     --29.08.2017 select distinct ALLOCATION_START INTO Start_GASP
     select min(ALLOCATION_START) INTO Start_GASP
     from W$ALLOCATION
     where CID = XLPL.CID
       and NVL(STAGE,0) not in (2,3) and ENTERED_BY = XLPL.User_ID;

     if   Start_GASP is NULL then  --01.09.2017
      Start_GASP:=A_F_DATATALK; --дата обращения
     end if; --01.09.2017

      exception
        when NO_DATA_FOUND then
          Start_GASP:=A_F_DATATALK; --дата обращения

      end;

  end if;
    --Size_BPM_OLD:=S_CONST(18, ADD_MONTHS(XLPL.WorkDate,-3));
/* До 01.04.2012 берем критерий нуждаемости на дату обращения и размер пособия не изменяется
   на весь срок, по указу № 41 при изменении критерия нуждаемости изменяется и размер пособмя,
   поэтому берем критерий нуждаемости по текущей дате для массового расчета */

    Size_BPM:= S_Const(18, XLPL.WorkDate); -- критерий нуждаемости на дату назначения (текущая дата при массовом расчете)
    -- устанавливаем критерий нуждаемости

 IF XLPL.INDIV= 2 then  --INDIV=2 - массовый расчет --its 20.08.2014
   --SDD :=B_F_AmountSSD751(XLPL.CID); -- сумма СДД для МР
   SDD :=0;
   Start_SDD:=NULL;
   begin
     select distinct NVL(SSD,0),RECORD_START into SDD,Start_SDD
     from CASE_SUMMARY_INCOME
     where CID = XLPL.CID
     and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
     and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
     and NVL(STAGE,0) not IN (2,3);
   exception  --12.01.2016
        when NO_DATA_FOUND then
          SDD:=0;
   end;


 ELSE
  -- SDD := ROUND(B_F_RelProtAmountSSD); -- сумма СДД --AMV 22.10.2014
  --**есть ли данные в РБД
     begin --22.03.2016
       select NVL(COUNT(SSD),0) INTO CNT_RBD --22.03.2016
       from w$CASE_SUMMARY_INCOME s
       where s.CID = XLPL.CID
              and NVL(s.RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
              and( (NVL(s.RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or( s.RECORD_END is null))
              and s.ENTERED_BY =XLPL.User_ID and NVL(s.STAGE,0) not IN (2,3);
      exception
        when NO_DATA_FOUND then
          CNT_RBD:= 0;
    end;
     if CNT_RBD = 0 then --находим по ОБД если нет в РБД
       begin
        select NVL(COUNT(SSD),0) INTO CNT_OBD --21.03.2016 NVL
                 from CASE_SUMMARY_INCOME
                 where CID = XLPL.CID
                      and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
                      and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
                      and NVL(STAGE,0) not IN (2,3);
       exception
        when NO_DATA_FOUND then
          CNT_OBD:= 0;
       end;
     end if;
  SDD:=0;
  Start_SDD:=null;
   if  ((CNT_RBD <> 0) OR (CNT_RBD <> 0)) then
      if CNT_RBD <> 0 then Fl_BZ_RBD:=1;
        else Fl_BZ_RBD:=0;
      end if; --есть SDD в РБД
     select distinct SSD,RECORD_START into SDD,Start_SDD
     from
        ( select  SSD,RECORD_START  --выборка по РБД --22.03.2016
         from w$CASE_SUMMARY_INCOME
         where CID = XLPL.CID
               and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
               and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
               and ENTERED_BY = XLPL.User_ID  and NVL(STAGE,0) not IN (2,3)
               and Fl_BZ_RBD=1
          union
         select  SSD,RECORD_START   --выборка по ОБД --22.03.2016
         from CASE_SUMMARY_INCOME
         where CID = XLPL.CID
               and NVL(RECORD_START, XLPL.WorkDate) <= XLPL.WorkDate
               and( (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate) or (RECORD_END is null))
               and NVL(STAGE,0) not IN (2,3)
               and Fl_BZ_RBD=0 );
  end if; --**

  END IF;

    --SDD_Factor:= ROUND(SDD/Factor); --15.03.16
  if SDD<>0 then
   -- B_F_ModernSum Функция для деноминирования (осовременивания) суммы
   -- Sum#    - сумма к деноминации (в т.ч. и сумма < 0)
   -- Date_Calc_Sum# - дата, на которую расчитана сумма
    -- Date_Paym_Sum# - дата, к которой должна быть приведена сумма


   if NVL(Start_GASP,XLPL.WorkDate)>=TO_DATE('01.07.2017','dd.mm.yyyy')  then --211 Указ --22.08.2017

      if (NVL(Factor,0) <> 0) then  --07082017 Balydka Dz.N.
       Factor:=1;
       SDD_Factor:= SDD/Factor;
      else
       SDD_Factor := SDD;
      end if;
   else -- до 211 Указ -- 22.08.2017
      SDD_Factor:= SDD/Factor;
   end if;

     SDD_Factor:=B_F_ModernSum (SDD_Factor,Start_SDD,XLPL.WorkDate);
     SDD_FACTOR:=ROUND(SDD_FACTOR,2);--18.10.2016 AMV
  else
    SDD_Factor:= 0;
  end if;
    /*         Расчет размера пособия */
  if SDD_Factor< Size_BPM  then
    --Amount := ROUND(Size_BPM - SDD_Factor);--15.03.16
    Amount := Size_BPM - SDD_Factor; --15.03.16
  else
    Amount :=0;
  end if;
  /*  if XLPL.CID=30214002707 then
   RAISE_APPLICATION_ERROR(-20851,'Отладка B_COAddrHelp751:  SDD = ' || SDD ||
                    ' SDD_Factor = ' || SDD_Factor ||' Size_BPM= '|| Size_BPM
                    ||' Amount= '|| Amount);
    end if;*/

    /*    Вывод в протокол  размера пособия */
  XLPL.S_protocol (' Критерий нуждаемости:                ' || TO_CHAR(Size_BPM) || CHR (10));
  XLPL.S_protocol (' Среднедушевой доход:                 ' || TO_CHAR(SDD) ||  CHR (10));
  NMask := LPAD('9', LENGTH(TO_CHAR(Factor)), '9') || '0.99';
  if Start_GASP<TO_DATE('01.07.2017','dd.mm.yyyy') then ---22.08.2017
    XLPL.S_protocol (' Корректирующий коэффициент:          ' || TO_CHAR(Factor,'0D000') || CHR (10));
    XLPL.S_protocol (' Скорректированный среднедушевой доход: ' || TO_CHAR(SDD_Factor) || CHR (10));
  end if;
  NMask := LPAD('9', LENGTH(TO_CHAR(Amount)), '9') || '0.99';
  XLPL.S_protocol (' Размер основного назначения:         '|| TO_CHAR(Amount, NMask) || CHR (10));
  XLPL.S_protocol (' Процент выплаты назначения:         ' || TO_CHAR(XLPL.Payment) || '%' || CHR (10));

  XLPL.AMOUNT := Amount;   -- вернуть 0
  Return Amount;            -- Возврат расчетной суммы
END B_COAddrHelp751;
/
