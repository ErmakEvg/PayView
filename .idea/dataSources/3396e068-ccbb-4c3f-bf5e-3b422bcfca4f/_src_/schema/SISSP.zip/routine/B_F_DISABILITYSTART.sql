CREATE FUNCTION       B_F_DisabilityStart RETURN DATE IS
/******************************************************************************
 NAME         : B_F_DisabilityStart
 Назначение   : Функция получения даты наступления инвалидности
 Автор        : ОЛВ
 Дата         :	10.11.2010
 Код возврата : Дата наступления инвалидности
******************************************************************************/
 Start_Dis	            DATE;
BEGIN
  -- Получить самую первую дату наступления инвалидности
  -------------------------------------------------
 SELECT min(Record_Start)
   INTO Start_Dis
   FROM W$MRAK_OPINION_ADVICE
  where PID=XLPL.GetPID
	and ADVICE_TYPE in (11,12,13)
	and OPINION_TYPE = 1
	and STAGE in (1,4)  --1 - Инф. действует (скопир. из ОБД, измен. не провод.) -- 4 - Новая инф. (инф. вв. с клав.)
    AND entered_by = XLPL.USER_ID;

  return Start_Dis;
END B_F_DisabilityStart;
/
