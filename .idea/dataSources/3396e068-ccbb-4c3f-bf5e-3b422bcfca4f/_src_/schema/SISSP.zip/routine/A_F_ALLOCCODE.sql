CREATE FUNCTION       A_F_AllocCode RETURN NUMBER AS
/*******************************************************************************
 Функция             :  A_F_AllocCode
 Наименование        :  Функция возвращает код назначения
 Автор               :  ОЛВ
 Состояние на дату   :  07.12.2016
 Код возврата        :  код назначения
********************************************************************************/
  pAlloc_Code         NUMBER;
BEGIN
  BEGIN
    SELECT NVL(alloc_code,0) INTO pAlloc_Code
    FROM ALLOCATION a, CASE_PERSON cp, ALLOCATION_PERSON ap
    WHERE a.cid = cp.CID
      AND cp.pid=ap.pid
      AND cp.pid=XLPL.GETPID
      AND a.rid= ap.allocation_rid
      AND cp.role=ap.role
      AND a.stage IS NULL
      AND cp.stage IS NULL
      AND ap.stage IS NULL
      AND cp.role in (51,53)
      AND a.comp_part IS NULL
      AND a.parent_rid IS NULL
      AND a.step_end IS NULL
      AND (XLPL.WorkDate between NVL(a.step_start,XLPL.WorkDate) and NVL(a.step_end,XLPL.WorkDate));
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
        pAlloc_Code := 0;
  END;
  RETURN pAlloc_Code;
END A_F_AllocCode;
/
