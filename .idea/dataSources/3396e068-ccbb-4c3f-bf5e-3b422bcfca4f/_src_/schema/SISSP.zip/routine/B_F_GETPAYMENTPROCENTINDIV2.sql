CREATE FUNCTION       B_F_GetPaymentProcentIndiv2 RETURN NUMBER IS
--==============================================================================
-- Назначение: читает процент выплаты для пособий при массовых расчетах
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Возвращаемое значение: - % выплаты (0, если сбой при выполнении запроса)
--==============================================================================
xCID NUMBER;
xAID NUMBER;
xWorkDate DATE;
xResume NUMBER;
BEGIN
xCID := XLPL.CID;
xAID := XLPL.AID;
xWorkDate := XLPL.WORKDATE;
begin
  select NVL(payment_percent, 0)
  into xResume
  from ALLOCATION
  where cid = xCID
  and aid = xAID
  and parent_rid is null
  and COMP_PART is null
  and alloc_status = 1
  and stage is null --(stage is null or stage <> 2) --08.08.2017 ITS
  and NVL(step_START, xWorkDate) <= xWorkDate
  and NVL(step_END, xWorkDate) >= xWorkDate;
exception
  when NO_DATA_FOUND then
    xResume := 0;
  when OTHERS then
    xResume := 0;
end;
RETURN xResume;
END B_F_GetPaymentProcentIndiv2;
/
