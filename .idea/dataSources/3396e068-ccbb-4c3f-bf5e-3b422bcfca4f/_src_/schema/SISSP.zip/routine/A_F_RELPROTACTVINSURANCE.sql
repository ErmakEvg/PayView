CREATE FUNCTION       A_F_RelProtActvInsurance(aActivity in VARCHAR2,
                                                aLabor in VARCHAR2,
                                                aDismiss_Reason in VARCHAR2)
												RETURN BOOLEAN IS
--==============================================================================
-- Назначение: возвращает True, если 'ПРИЗНАК УПЛАТЫ СТРАХОВЫХ ВЗНОСОВ' = 1
--          Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
--------------------------------------------------------------------------------
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Входные праметры:
---------------------
-- aActivity - код верхнего уровня  (Например 1 - работатет)
-- aLabor - код нижнего уровня ('' - игнорируются)
-- aDismiss_Reason - список кодов увольнений ('' - игнорируется, т.е. увольнялся)
--------------------------------------------------------------------------------
-- Предупреждение:
------------------
--  Если записи по W$ACTIVITY формировались через P_RelProtActivivtyD
-- (все записи на месяц), то результат будет некорректным
--==============================================================================

xResume BOOLEAN;
xActivity DBMS_SQL.Number_Table;
curr_Activity NUMBER;
xLabor DBMS_SQL.Number_Table;
curr_Labor NUMBER;
xRID DBMS_SQL.Number_Table;
curr_RID NUMBER;
i NUMBER;
k NUMBER;
m NUMBER;
n NUMBER;
o NUMBER;
p NUMBER;
xUser NUMBER;

BEGIN
xResume := False;
xUser := XLPL.USER_ID;
xActivity.Delete;
xActivity := S_ParseFloatArray(aActivity);
xLabor.Delete;
xLabor := S_ParseFloatArray(aLabor);
n := xActivity.Count;
p := xLabor.Count;
if aDismiss_Reason is NULL then
  xResume := True;
else
  xRID.Delete;
  xRID := A_F_RelProtGetRIDActivity(1);  --     1 - ОБД
  k := xRID.Count;
  if p = 0 then
    FOR i IN 1..k LOOP
	  if xResume = True then
		EXIT;
	  end if;
      curr_RID := xRID(i);
	  FOR m IN 1..n LOOP
 		if xResume = True then
		  EXIT;
		end if;
        curr_Activity := xActivity(m);
        FOR cRec1 IN (select NVL(PAYMENT_INSURANCE, -1) as PAYM_INS
	                  from ACTIVITY
                      where RID = curr_RID
		  	          and ACTIVITY.ACTIVITY = curr_Activity
					  and PAYMENT_INSURANCE = 1)
		LOOP
		  xResume := A_F_NumInSet(cRec1.PAYM_INS, aDismiss_Reason);
		  if xResume = True then
			EXIT;
		  end if;
        END LOOP;
      END LOOP;
    END LOOP;
  else  -- xLabor.Count <> 0
    FOR i IN 1..k LOOP
	  if xResume = True then
		EXIT;
	  end if;
      curr_RID := xRID(i);
	  FOR m IN 1..n LOOP
 		if xResume = True then
		  EXIT;
		end if;
        curr_Activity := xActivity(m);
  	    FOR o IN 1..p LOOP
 		  if xResume = True then
		    EXIT;
		  end if;
	      curr_Labor := xLabor(o);
		  FOR cRec2 IN (select NVL(PAYMENT_INSURANCE, -1) as PAYM_INS
		                from ACTIVITY
		                where RID = curr_RID
					    and ACTIVITY.ACTIVITY = curr_Activity
						and LABOR = curr_Labor
						and PAYMENT_INSURANCE = 1)
		  LOOP
 		    xResume := A_F_NumInSet(cRec2.PAYM_INS, aDismiss_Reason);
		    if xResume = True then
			  EXIT;
		    end if;
	      END LOOP;
		END LOOP;
	  END LOOP;
	END LOOP;
  end if;
  if xResume = False then
    xRID.Delete;
    xRID := A_F_RelProtGetRIDActivity(0);  --     РБД
    k := xRID.Count;
    if p = 0 then
      FOR i IN 1..k LOOP
	    if xResume = True then
		  EXIT;
	    end if;
        curr_RID := xRID(i);
	    FOR m IN 1..n LOOP
 		  if xResume = True then
		    EXIT;
		  end if;
          curr_Activity := xActivity(m);
          FOR cRec3 IN (select NVL(PAYMENT_INSURANCE, -1) as PAYM_INS
	                    from W$ACTIVITY
                        where RID = curr_RID
		  	            and W$ACTIVITY.ACTIVITY = curr_Activity
						and ENTERED_BY = xUser
					    and PAYMENT_INSURANCE = 1)
		  LOOP
		    xResume := A_F_NumInSet(cRec3.PAYM_INS, aDismiss_Reason);
		    if xResume = True then
			  EXIT;
		    end if;
          END LOOP;
        END LOOP;
      END LOOP;
    else  -- xLabor.Count <> 0
      FOR i IN 1..k LOOP
	    if xResume = True then
		  EXIT;
	    end if;
        curr_RID := xRID(i);
	    FOR m IN 1..n LOOP
 		  if xResume = True then
		    EXIT;
		  end if;
          curr_Activity := xActivity(m);
  	      FOR o IN 1..p LOOP
 		    if xResume = True then
		      EXIT;
		    end if;
	        curr_Labor := xLabor(o);
		    FOR cRec4 IN (select NVL(PAYMENT_INSURANCE, -1) as PAYM_INS
		                  from W$ACTIVITY
		                  where RID = curr_RID
				  	      and W$ACTIVITY.ACTIVITY = curr_Activity
						  and LABOR = curr_Labor
						  and ENTERED_BY = xUser
						  and PAYMENT_INSURANCE = 1)
		    LOOP
 		      xResume := A_F_NumInSet(cRec4.PAYM_INS, aDismiss_Reason);
		      if xResume = True then
			    EXIT;
		      end if;
	        END LOOP;
		  END LOOP;
	    END LOOP;
	  END LOOP;
    end if;
  end if;
end if;
RETURN xResume;
END A_F_RelProtActvInsurance;
/
