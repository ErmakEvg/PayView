CREATE FUNCTION       B_CBC01 RETURN NUMBER AS
/**********************************************************************************************
 Функция            : B_CBC01
 Наименование       : Функция расчета суммы пособия в связи с рождением ребенка
 Основание          : Согл. ЗРБ О ГОС.ПОС.СЕМЬЯМ, ВОСП.ДЕТЕЙ
                       (в ред. З. РБ от 28.12.2007 N 306-З)
 Автор              :  ОЛВ          комментарий и корректировка РАВ
 Состояние на дату  :  17.03.2010   23.09.2013		23.04.2018
***********************************************************************************************/

 Amount          NUMBER;
 Size_BPM        NUMBER;
 Percent         NUMBER;
 NMask           varchar2(50);

BEGIN

    XLPL.RoleDecl('Child','56');
    XLPL.REPLACEROLE('Child');
 /*                                Исходные данные
  /* -----------------------------------------------------------------------------------*/
 Size_BPM:=S_Const(18, XLPL.WorkDate);  -- Бюджет прожиточного минимума в среднем на душу населения

 -- 23.09.2013 Речицкая АВ --if A_F_RelProtMetric('359')  23.04.2018
 if  B_F_MetricWithOutDate('360') then          -- Ребенок - не первыйB_F_MetricWithOutDate('359') or
     Percent :=  S_Const(482, XLPL.WorkDate);  -- Размер пос. в св. с рожд. реб. - в % от БПМ в среднем на душу населения
--RAISE_APPLICATION_ERROR(-20801,'B_CBC01  1  Percent=' ||Percent||'  Size_BPM='||Size_BPM);
 ELSE                                      -- Ребенок - первый
     Percent :=  S_Const(481, XLPL.WorkDate) ; -- Размер пос. в св. с рожд. перв. реб. - в % от БПМ в среднем на душу населения
--RAISE_APPLICATION_ERROR(-20801,'B_CBC01   2 Percent=' ||Percent||'  Size_BPM='||Size_BPM);
 END IF;

   XLPL.RestoreRole;
  /* -----------------------------------------------------------------------------------*/
  /*                               Расчет размера пособия
  /* -----------------------------------------------------------------------------------*/
     Amount := S_VRound_Sum((Size_BPM * Percent/100), s_const(40,XLPL.WorkDate));
--RAISE_APPLICATION_ERROR(-20801,'B_CBC01   3 Percent=' ||Percent||'  Size_BPM='||Size_BPM||'  Amount='||Amount);

  /*                         Вывод в протокол  размера пособия
  /* -----------------------------------------------------------------------------------*/
  Xlpl.S_Protocol('-------------------------------------------------------------------------------- '|| CHR(10));
   NMask := LPAD('9', LENGTH(TO_CHAR(Amount)), '9') || '0.99';
  Xlpl.S_Protocol('Сумма назначения (' || TO_CHAR(Size_BPM, NMask) || ' * ' ||
    TO_CHAR(Percent*0.01, '90.99') || ' ): ' || CHR(9)  || TO_CHAR(Amount,  NMask) || CHR(10));

  XLPL.Payment := 100;
  XLPL.S_protocol ('Процент выплаты назначения:                ' || TO_CHAR(XLPL.Payment) || '%' || CHR (10));

  return Amount;

END B_CBC01;
/
