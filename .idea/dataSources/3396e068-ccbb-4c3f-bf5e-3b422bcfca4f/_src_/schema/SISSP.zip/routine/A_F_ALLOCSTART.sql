CREATE FUNCTION       A_F_Allocstart RETURN DATE IS
/***************************************************************************************
 Функция           :  A_F_AllocStart
 Наименование      :  Функция определения даты первоначального назначения
 Автор             :  ОЛВ
 Состояние на дату : 11.08.2011
 Код возврата      : Дата первоначального назначения
***************************************************************************************/
ALLOC_START_PN   DATE; -- дата первоначального назначения
BEGIN
  BEGIN
	   -- дата первоначального назначения
  SELECT MIN(allocation_start)
       INTO ALLOC_START_PN
       FROM W$ALLOCATION
      WHERE  CID=Xlpl.CID
	    AND STAGE IN (1,2, 4) ;
       ---select TO_DATE(b.ASVPD_ALLOCATION_START,'DD.MM.YYYY') into ASVPD_ALLOC_START from ASVPD_CASE b where b.CID=XLPL.CID;
  EXCEPTION
        WHEN NO_DATA_FOUND OR TOO_MANY_ROWS THEN
              ALLOC_START_PN:=Xlpl.WorkDate;
  END;
--RAISE_APPLICATION_ERROR(-20801,'A_F_AllocStartConvert ASVPD_ALLOC_START='||ALLOC_START_PN||'  Xlpl.WorkDate'|| Xlpl.WorkDate);
   RETURN ALLOC_START_PN;
END A_F_Allocstart;
/
