CREATE FUNCTION       B_AddMonths_D(Old_Date in DATE, Step in NUMBER) RETURN DATE AS
/*******************************************************************************
 Функция            : B_AddYearsMonths_D
 Наименование       : увеличивает дату на заданное количество месяцев
 Автор              : ОЛВ
 Состояние на дату  : 09.02.2011     07.06.2016
 Код возврата       : дата
********************************************************************************/
 Date_New         DATE;
 Dt_Day           Number;

BEGIN
   Date_New:=ADD_MONTHS(Old_Date, Step);
 -- исправить погрешность последнего дня месяца
 if Old_Date = Last_Day(Old_Date) then
     Dt_Day :=to_number(to_char(Old_Date,'DD'));
   if Dt_Day<to_number(to_char(Date_New,'DD')) then
      Date_New := S_EncodeDate(to_number(to_char(Date_New,'YYYY')), to_number(to_char(Date_New,'MM')), Dt_Day);
   end if;
 end if;

 RETURN Date_New;
END B_AddMonths_D;
/
