CREATE FUNCTION       B_F_BenefitPOG(aCode IN NUMBER) RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_BenefitPOG
// Наименование: Проверка на наличие у лица пособия на погребение
// Автор: Речицкая А. В..
// Состояние на дату 02.09.2016
// Код возврата: True - имеет право, False - не имеет право
//***************************************************************************************/

  aCount NUMBER;
BEGIN
  select count(*) into aCount
from ALLOCATION a, ALLOCATION_PERSON b
  where a.RID = b.ALLOCATION_RID
    and b.PID = XLPL.GetPid
    and b.role=60
 	and (a.STAGE <> 3 or a.STAGE is NULL)
	and (b.STAGE <> 3 or b.STAGE is NULL)
	and a.ALLOC_CODE in (select CODE from ALLOCATIONS start with CODE = aCode connect by prior CODE = PARENT_CODE)
	--and a.ALLOCATION_START <= :bufDate
	and a.ALLOCATION_END is null
	and (a.STEP_START=a.STEP_END and a.ALLOC_STATUS = 3);
    --RAISE_APPLICATION_ERROR(-20801,'Умершему уже назначено  пособие на погребение  '||'aCount=  '||aCount);
  RETURN aCount != 0;
END B_F_BenefitPOG;
/
