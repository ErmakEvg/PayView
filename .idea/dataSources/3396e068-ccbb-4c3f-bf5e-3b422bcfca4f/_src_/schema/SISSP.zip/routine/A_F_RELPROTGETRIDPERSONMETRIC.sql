CREATE FUNCTION       A_F_RelProtGetRidPersonMetric(Base_ID in number,
   pCode in NUMBER) RETURN DBMS_SQL.Number_Table IS
/***************************************************************************************
 Функция             :  A_F_RelProtGetRidPersonMetric
 Наименование        :  RID из PERSON_METRIC согласно W$RELATION_PROTOCOL
 Автор               :  Вахромин О.Ю.        Комментарии и корректировка: ОЛВ
 Состояние на дату   :                                     21.05.2014
 Код возврата        :  RID из W$RELATION_PROTOCOL для MRAK_OPINION_ADVICE
***************************************************************************************/
 vArray              DBMS_SQL.Number_Table;
 vsRELATION_TABLE    number;
BEGIN
   vArray.delete;
   if Base_ID=0 then
      vsRELATION_TABLE:=S_CODETABLESISSP('W$PERSON_METRIC');
      for c1 in (
             select DATA_RID
               from W$RELATION_PROTOCOL b,W$PERSON_METRIC a
              where CID=XLPL.CID
                and (Aid=XLPL.Aid or XLPL.Aid=0)
                and (GROUP_NO=XLPL.Group_No or (XLPL.AID<>0 and XLPL.Group_No=0))
                and ALLOC_CODE=XLPL.Alloc_Code
                and a.ENTERED_BY=XLPL.User_ID
                and b.ENTERED_BY=XLPL.User_ID
                and RELATION_TABLE=vsRELATION_TABLE
                and RELATION_DATE=XLPL.WorkDate
                and DATA_RID=a.RID
                and a.PID=XLPL.GetPid
                and (a.CODE=pCode or (XLPL.Aid=0 and pCode=-1))
                -- and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WorkDate) and NVL(a.RECORD_END,XLPL.WorkDate)) -- было закрыто у ТОДОС
      ) loop
         vArray(vArray.count+1):=c1.DATA_RID;
        end loop;
   else
      vsRELATION_TABLE:=S_CODETABLESISSP('PERSON_METRIC');
      for c1 in (
             select DATA_RID
               from W$RELATION_PROTOCOL b,PERSON_METRIC a
              where CID=XLPL.CID
                and (Aid=XLPL.Aid or XLPL.Aid=0)
                and (GROUP_NO=XLPL.Group_No or (XLPL.AID<>0 and XLPL.Group_No=0))
                and ALLOC_CODE=XLPL.Alloc_Code
                and b.ENTERED_BY=XLPL.User_ID
                and RELATION_TABLE=vsRELATION_TABLE
                and RELATION_DATE=XLPL.WorkDate
                and DATA_RID=a.RID
                and a.PID=XLPL.GetPid
                and (a.CODE=pCode or (XLPL.Aid=0 and pCode=-1))
                -- 21.05.2014 ОЛВ -- не видит 659 при МР--and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WorkDate) and NVL(a.RECORD_END,XLPL.WorkDate))
      ) loop
        vArray(vArray.count+1):=c1.DATA_RID;
      end loop;
   end if;
  return vArray;
END A_F_RelProtGetRidPersonMetric;
/
