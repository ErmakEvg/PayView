CREATE FUNCTION       A_F_RelProtGetRIDCasePNotPID RETURN DBMS_SQL.NUMBER_TABLE IS
/* -------------------------------------------------------------
// Автор: Боровнева
// состояние на
// Код возврата: RID из CASE_PERSON согласно коду по W$RELATION_PROTOCOL
// -------------------------------------------------------------*/

xDRIDS DBMS_SQL.Number_Table;
i integer;
vsRELATION_TABLE integer;
vsDRID number;
vsAID number;
vsCID number;
vsGROUP_NO number;
vsALLOC_CODE number;
BEGIN


 vsDRID := -1;
 xDRIDS.delete;
 vsCID := XLPL.CID;
 vsAID := XLPL.AID;
 vsGROUP_NO := XLPL.GROUP_NO;
 vsALLOC_CODE := XLPL.ALLOC_CODE;

 vsRELATION_TABLE := S_CodeTableSISSP ('CASE_PERSON');

  if vsAID = 0 then
      for c1 in ( select DATA_RID as vsDRID
                     from W$RELATION_PROTOCOL b, CASE_PERSON a
                     where  b.CID = vsCID
                     and GROUP_NO = vsGROUP_NO
                     and  ALLOC_CODE = vsALLOC_CODE
                     and  RELATION_TABLE = vsRELATION_TABLE
                     and RELATION_DATE = XLPL.WorkDate
                     and b.ENTERED_BY = XLPL.USER_ID
                     and DATA_RID = a.RID
                     --	 "a.CLOSE_DATE is NULL and "
                     --		  "a.STAGE is NULL and "
								     and NVL(a.RECORD_START, XLPL.WORKDATE) <= XLPL.WORKDATE
                     and NVL(a.RECORD_END, XLPL.WORKDATE) >= XLPL.WORKDATE
                     and a.PID <> XLPL.GETPID) loop
            xDRIDS(xDRIDS.Count+1) := c1.vsDRID;
      end loop;
  else
      for c1 in (select DATA_RID as vsDRID
                    from W$RELATION_PROTOCOL b, CASE_PERSON a
                    where b.CID = vsCID
                    and AID = vsAID
                    and ((GROUP_NO = vsGROUP_NO) or (vsGROUP_NO = 0))
                    and ALLOC_CODE = vsALLOC_CODE
                    and b.ENTERED_BY = XLPL.USER_ID
                    and RELATION_TABLE = vsRELATION_TABLE
                    and RELATION_DATE = XLPL.WorkDate
                    and DATA_RID = a.RID
					          --			 "a.CLOSE_DATE is NULL and "
                    --								 "a.STAGE is NULL and "
								    and NVL(a.RECORD_START, XLPL.WORKDATE) <= XLPL.WORKDATE
								    and NVL(a.RECORD_END, XLPL.WORKDATE) >= XLPL.WORKDATE
								    and a.PID <> XLPL.GETPID)  loop
		       xDRIDS(xDRIDS.Count+1) := c1.vsDRID;
      end loop;
  end if;
  return xDRIDS;

END A_F_RelProtGetRIDCasePNotPID;
/
