CREATE FUNCTION       B_F_GETPIDFROMCASEPERSON RETURN DBMS_SQL.NUMBER_TABLE AS
-- Получить массив PID из Case_Person, исключая свой собственный
aCID NUMBER;
A DBMS_SQL.NUMBER_TABLE;
i NUMBER;
aPID NUMBER;

BEGIN
aCID := XLPL.CID;
aPID := XLPL.GETPID;
A.delete;

for c in (Select PID
		  from  W$CASE_PERSON
		  where
		  CID = aCID and
		  ENTERED_BY = XLPL.USER_ID and
		  STAGE not in (2, 3) and
		  PID <> aPID) loop
	 A(A.count+1) := c.PID;
end loop;
return A;
END B_F_GETPIDFROMCASEPERSON;
/
