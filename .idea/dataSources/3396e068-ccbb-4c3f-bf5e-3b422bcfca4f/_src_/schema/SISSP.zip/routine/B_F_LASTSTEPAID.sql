CREATE FUNCTION       B_F_LASTSTEPAID(pAID in number, pCID in varchar2) RETURN DATE IS
BEGIN
return Last_day(S_CurrDate);
END B_F_LASTSTEPAID;
/
