CREATE FUNCTION       B_F_FormAllocationSteps03 RETURN DBMS_SQL.NUMBER_Table IS
/*==============================================================================
+ Функция: B_F_FormAllocationSteps03
+ Наименование: функция определяет шаги назначения по изменнениям для погибших
+ Автор: Ворошилин В.    			Корректировка Речицкая А. В.
+ Состояние на дату 18.10.2002		11.05.2015
==============================================================================*/

pAID NUMBER;			   						   -- идентификатор назначения
pCID NUMBER;		   							   -- идентификатор дела
Param6m NUMBER;					   				   -- признак превышения 6 месяцев
j NUMBER;						   			   	   -- счетчик
prnew NUMBER;
prold NUMBER;
prdate DATE;
PuskDate DATE;					   				   -- рабочая дата
d1 DATE;				   					  	   -- дата, используемая для работы
rDate DATE;				   				   		   -- дата, используемая для работы
LimitDate DATE;
result_step_start DBMS_SQL.NUMBER_Table;		   -- массив, накапливающий даты шагов
result_array DBMS_SQL.NUMBER_Table;				   -- массив, содержащий готовые для возврата даты шагов (без повторений)
result_function DBMS_SQL.NUMBER_Table;			   -- массив, в который функции возвращают даты шагов
result_rab DBMS_SQL.NUMBER_Table;
aP DBMS_SQL.NUMBER_Table;

BEGIN
j := 0;
aP.delete;
--==============================================================================
-- установка рабочих признаков:
-- если ParamPervNazn = 1, то это первичное назначение, иначе назначение есть
-- если Param6m = 1, то значит дата обращения превышает на 6 мес. дату начала
-- 				  	 действия назначения, иначе дата обращения не превышает
--					 дату начала действия на 6 мес.
--==============================================================================

d1 := XLPL.WorkDate;
Param6m := 0;									-- обнулить признак не превышения на 6 мес. даты возникновения права
PuskDate := d1;									-- Установить дату начала формирования переломных точек

----- для всей группы -----
if pAID <> 0 then
   aP := B_F_ManageAllocStatus;
   if aP.count > 0 then
 	  prnew := aP(1);
 	  prold := aP(2);
 	  prdate := S_JTod(aP(3));
	  if prdate is not NULL then
	  	 result_step_start(result_step_start.count+1) := S_julian(prdate);
	  end if;
   end if;

   aP.delete;
   aP := A_F_ArrayAllocationStep(XLPL.WorkDate);
   if aP.count > 0 then
	 for k in 1..aP.Count loop						   		  -- в оригинале - индекс с нуля
	  	 if S_jtod(aP(k)) > PuskDate then
		 	result_step_start(result_step_start.count+1) := aP(k);
		 end if;
	 end loop;
	 aP.delete;
   end if;
end if;

----- для получателя -----

result_function.delete;
result_function := B_F_ArrayDateChangePERSON(PuskDate, Param6m);
if result_function.count > 0 then
	 for j in 1..result_function.count loop
	 	 result_step_start(result_step_start.count+1) := result_function(j);
	 end loop;
end if;
-- добавлено 11.03.2015 Речицкая А. В.
result_function.delete;
result_function := B_F_ARRAYDATECHANGEBIRTHDEATH(PuskDate, Param6m);
if result_function.count > 0 then
	 for j in 1..result_function.count loop
	 	 result_step_start(result_step_start.count+1) := result_function(j);
	 end loop;
end if;-- добавлено 11.03.2015 Речицкая А. В.
--RAISE_APPLICATION_ERROR(-20801,'.B_F_FormAllocationSteps03  XLPL.GetPid='||XLPL.GetPid ||'result_function(1)= '||S_JToD(result_function(1)));

result_function.delete;
result_function := B_F_ArrayDateChangeADDRESS(PuskDate, Param6m);
if result_function.count > 0 then
	 for j in 1..result_function.count loop
	 	 result_step_start(result_step_start.count+1) := result_function(j);
	 end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateChangeMETRICMon(145, PuskDate, Param6m);
if result_function.count > 0 then
	 for j in 1..result_function.count loop
	 	 result_step_start(result_step_start.count+1) := result_function(j);
	 end loop;
end if;

----- для погибшего -----
if  XLPL.CheckRole(71) then
    XLPL.RoleDecl('Death','71');
    XLPL.REPLACEROLE('Death');

	result_function.delete;
    result_function := B_F_ArrayDateChangePERSON(PuskDate, Param6m);
	if result_function.count > 0 then
	   for j in 1..result_function.count loop
	 	   result_step_start(result_step_start.count+1) := result_function(j);
	   end loop;
	end if;

    XLPL.RestoreRole;
end if;
return A_F_ArrayDataChangeDelDup(result_step_start);
END B_F_FormAllocationSteps03;
/
