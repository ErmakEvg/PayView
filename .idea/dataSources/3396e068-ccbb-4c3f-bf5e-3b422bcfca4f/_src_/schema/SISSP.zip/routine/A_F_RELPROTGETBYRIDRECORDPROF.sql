CREATE FUNCTION       A_F_Relprotgetbyridrecordprof (Base_ID IN NUMBER,pRECORD_CODE IN NUMBER)
   RETURN NUMBER AS
/***************************************************************************************
 Функция             : A_F_RelProtGetByRidRecordProf
 Наименование        : Функция расчета стажа согласно W$RELATION_PROTOCOL и кода
 Автор               : ОЛВ            на основании A_F_RelProtGetByRidMRecord
 Состояние на дату   : 10.12.2009
 Код возврата        :
***************************************************************************************/
 vsRelation_Table NUMBER;
 vsRECORD_DAYS    NUMBER;
 --pst             varchar(100);
BEGIN
     -- в W$MANUAL_PROFST и MANUAL_PROFST м.б. несколько строк с одинаковыми кодами стажей - сказала К.Е.В.
	 -- здесь не согласно W$RELATION_PROTOCOL - заплатка
 IF Base_ID=0 THEN
         SELECT NVL(SUM(RECORD_DAYS),0)
		   INTO vsRECORD_DAYS
		   FROM W$MANUAL_PROFST a
		  WHERE a.PID=Xlpl.GetPID
			    AND a.STAGE IN (1,4,6)
			    AND Xlpl.WorkDate BETWEEN NVL(a.RECORD_START,Xlpl.WORKDATE)
			                          AND NVL(a.RECORD_END,Xlpl.WORKDATE)
		        AND a.ENTERED_BY=Xlpl.USER_ID
			    AND a.PROF_CODE IN
				             (SELECT Prof_Code
					            FROM STAGE_PROFST
						       WHERE  Stage_Code=pRECORD_CODE);

 ELSE
         SELECT NVL(SUM(RECORD_DAYS),0)
		   INTO vsRECORD_DAYS
		   FROM MANUAL_PROFST a
		  WHERE a.PID=Xlpl.GetPID
                AND a.STAGE IS NULL        -- and a.STAGE in (1,4,6)          --25.03.2013
			    AND Xlpl.WorkDate BETWEEN NVL(a.RECORD_START,Xlpl.WORKDATE)
			                          AND NVL(a.RECORD_END,Xlpl.WORKDATE)
			    AND a.PROF_CODE IN
				             (SELECT Prof_Code
					            FROM STAGE_PROFST
						       WHERE  Stage_Code=pRECORD_CODE);
 END IF;
	           --RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtGetByRidRecordProf    vsRECORD_DAYS='||vsRECORD_DAYS);
    RETURN vsRECORD_DAYS;

	/* согласно W$RELATION_PROTOCOL *
   if Base_Id=1 then
      vsRELATION_TABLE:=S_CodeTableSISSP('MANUAL_PROFST');
   else
      vsRELATION_TABLE:=S_CodeTableSISSP('W$MANUAL_PROFST');
   end if;
  pst :='';
  -- в W$MANUAL_PROFST и MANUAL_PROFST м.б. несколько строк с одинаковыми кодами стажей - сказала К.Е.В.
    begin
      if Base_ID=0 then
          pst :=pst ||' 1'||chr(10);
		 select NVL(Sum(RECORD_DAYS),0)
		   into vsRECORD_DAYS
		   from W$RELATION_PROTOCOL b,W$MANUAL_PROFST a
		  where     CID=XLPL.CID
			    and (AID=XLPL.AID or XLPL.AID=0)
			    and ( (GROUP_NO=XLPL.GROUP_NO) or (XLPL.AID<>0 and XLPL.GROUP_NO=0) )
			    and ALLOC_CODE=XLPL.ALLOC_CODE
			    and a.ENTERED_BY=XLPL.USER_ID
			    and RELATION_TABLE=vsRELATION_TABLE
			    and RELATION_DATE=XLPL.WorkDate
			    and DATA_RID=a.RID
			    and a.STAGE in (1,4,6)
			    and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE)
			                          and NVL(a.RECORD_END,XLPL.WORKDATE)
		        and a.PID=XLPL.GetPID
			    and a.RECORD_CODE in
				     (select Prof_Code
					    from Stage_ProfSt
						where  Stage_Code=pRECORD_CODE);

                pst :=pst ||to_Char(vsRECORD_DAYS)||chr(10);
               if pRECORD_CODE=52 then
                 RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtGetByRidRecordProf 222    pst='||pst);
               end if;
      else
		 select NVL(Sum(RECORD_DAYS),0)
		   into vsRECORD_DAYS
		   from W$RELATION_PROTOCOL b,MANUAL_PROFST a
		  where      CID=XLPL.CID
				and (AID=XLPL.AID or XLPL.AID=0)
				and ((GROUP_NO=XLPL.GROUP_NO) or (XLPL.AID<>0 and XLPL.GROUP_NO=0))
				and ALLOC_CODE=XLPL.ALLOC_CODE
				and b.ENTERED_BY=XLPL.USER_ID
				and RELATION_TABLE=vsRELATION_TABLE
				and RELATION_DATE=XLPL.WorkDate
				and DATA_RID=a.RID
				and XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE)
				                      and NVL(a.RECORD_END,XLPL.WORKDATE)
		        and a.PID=XLPL.GetPID
				and a.RECORD_CODEin
				     (select Prof_Code
					    from Stage_ProfSt
						where  Stage_Code=pRECORD_CODE);
      end if;

    exception
      when NO_DATA_FOUND then
         vsRECORD_DAYS := 0;
    end;
	 -- профессиональный стаж
	 pst :=pst ||to_Char(vsRECORD_DAYS)||chr(10);
	 -- sumRECORD_DAYS:=sumRECORD_DAYS+vsRECORD_DAYS;
 	-- pst :=pst ||'  sumRECORD_DAYS='||to_Char(sumRECORD_DAYS)||chr(10);
  RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtGetByRidRecordProf     pst='||pst);
	  /* */

END A_F_Relprotgetbyridrecordprof;
/
