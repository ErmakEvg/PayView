CREATE FUNCTION       A_F_ReasonClose_112 RETURN BOOLEAN IS
/******************************************************************************
 NAME         : A_F_ReasonClose_112
 Назначение   : Функция проверки кода причины закрытия назначения
 Автор        : ОЛВ
 Дата         :    11.02.2016
 Код возврата : Возвращает TRUE, если код причины закрытия назначения =112
******************************************************************************/
 vStatus_Reason  NUMBER;

BEGIN
   select count(*) into vStatus_Reason
     from w$change_alloc_status
    where cid=XLPL.Cid
      and aid=XLPL.Aid
      and alloc_status_new =3
      and Status_Reason=112; -- Выезд на постоянное место жительство за пределы РБ

 IF vStatus_Reason=0 THEN
    RETURN FALSE;
  ELSE
    RETURN TRUE; --  Есть выезд
  END IF;
END A_F_ReasonClose_112;
/
