CREATE FUNCTION       A_F_RelProtMetric(pCodes in VarChar2) RETURN BOOLEAN IS
/*Проверяет наличие метрики у человека согласно W$RELATION_PROTOCOL
Вахромин О.Ю.*/
xCode DBMS_SQL.NUMBER_TABLE;
xCodes DBMS_SQL.NUMBER_TABLE;
BEGIN

   xCode:=S_ParseFloatArray(pCODES);

--RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtMetric xCODE.count='||xCODE.count);


   for i in 1..xCODE.count loop

     if A_F_RelProtGetRIDPersonMetric(1,xCode(i)).count>0 then
        return true;
     else
        if A_F_RelProtGetRIDPersonMetric(0,xCode(i)).count>0 then
           return true;
        end if;
     end if;
   end loop;

   return false;
END A_F_RelProtMetric;
/
