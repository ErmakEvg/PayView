CREATE FUNCTION       A_F_HAVEMEDALSFOR1077(PPID  NUMBER) RETURN BOOLEAN IS
count_nagrad NUMBER;
count_rvalue NUMBER;
/******************************************************************************
   NAME:       A_F_HAVEMEDALSFOR1077
  Проверяет наличие орденов и медалей у человека на право поселения в РИВВиТ
  Так как медали и ордена не все введены в справочник REF_REWARD и нет признака
  отличия, медаль или орден
    Горбач Н.П
      Object Name:     A_F_HAVEMEDALSFOR1077
      Sysdate:         10.02.2016

******************************************************************************/
BEGIN
 --проверяем, есть ли у человека награды
   select count(r.reward_type)  into count_nagrad
   from SISSP.W$REWARD r, SISSP.REF_REWARD rr
    where
    r.pid= PPID
    AND rr.code(+) = r.reward_type
    and r.stage in (1,4)
    and rr.stage is null;
    if count_nagrad=0 then
        return false;
      else
      begin  --медали
       select count(r.reward_type)  into count_rvalue
         from SISSP.W$REWARD r, SISSP.REF_REWARD rr
         where
         r.pid= PPID
         and r.stage in (1,4)
         and rr.stage is null
         AND rr.code(+) = r.reward_type
         and  r.reward_type in (13,14,36,37);
       if count_rvalue <>0 then
          return TRUE;
       else
       begin --ордена
        select count(r.reward_type) into count_rvalue
        from SISSP.W$REWARD r, SISSP.REF_REWARD rr
        where
        r.pid = PPID
        and r.stage in (1,4)
        and rr.stage is null
        AND rr.code(+) = r.reward_type
        and  r.reward_type not in (25,33,34,35);
         if count_rvalue <>0 then
          return TRUE;
          else
          return false;
         end if;
       end;

     end if;
     end;
    end if;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END A_F_HAVEMEDALSFOR1077;
/
