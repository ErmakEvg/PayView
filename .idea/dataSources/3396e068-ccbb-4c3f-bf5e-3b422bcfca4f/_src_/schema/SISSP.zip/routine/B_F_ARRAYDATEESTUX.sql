CREATE FUNCTION       B_F_ARRAYDATEESTUX RETURN DBMS_SQL.NUMBER_TABLE AS
/*******************************************************************************
 Функция           : F_ARRAYDATEESTUX
 Наименование      : Построение массива с датой достижения ухаживающим пенсионного возраста
 				       для Estimation
 Автор             : Ворошилин В.                Корректировка ОЛВ
 Состояние на дату :                              12.12.2016   30.10.2017
 Код возврата      : Массив, состоящий из даты, кода причины, кода изменения состояния
******************************************************************************/
 result      DBMS_SQL.NUMBER_TABLE;
 DtBirth     DATE;    -- 12.12.2016 ОЛВ
 rabDate     DATE;
 RecipAge    NUMBER;-- BINARY_INTEGER;
BEGIN
   result.delete;
 DtBirth:=S_Birthdate(Xlpl.Base_ID,Xlpl.GetPid,Xlpl.WorkDate);

 -- Общеустановленный пенсионный возраст -- 12.12.2016 ОЛВ
 RecipAge:=P_AgePensionStep(106,108,DtBirth);
 rabDate :=ADD_MONTHS(DtBirth,TRUNC(RecipAge*12));
  if (rabDate >= LAST_DAY(Xlpl.WorkDate))  AND rabDate > LAST_DAY(S_CurrDate)  then
    result(result.count + 1) := S_Julian(LAST_DAY(rabDate));
 	result(result.count + 1) := 32;
 	result(result.count + 1) := 2;
  end if;

  -- Возраст наступления права на социальную пенсию -- 30.10.2017 ОЛВ
  IF S_Male(Xlpl.Base_ID,Xlpl.GetPid,Xlpl.WorkDate) THEN  -- мужчины
      RecipAge := S_Const(306, Xlpl.workdate);
  ELSE
      RecipAge := S_Const(308, Xlpl.workdate);
  END IF;
 rabDate :=ADD_MONTHS(DtBirth,TRUNC(RecipAge*12));
  if (rabDate >= LAST_DAY(Xlpl.WorkDate))  AND rabDate > LAST_DAY(S_CurrDate) then
    result(result.count + 1) := S_Julian(LAST_DAY(rabDate));
    result(result.count + 1) := 32;
    result(result.count + 1) := 2;
  end if;

  return result;
END B_F_ARRAYDATEESTUX;
/
