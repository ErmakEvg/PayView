CREATE FUNCTION       B_F_ARRAYDATEESTMRAKOPADVICEUX(AOPINION_TYPE IN BINARY_INTEGER, AADVICE_TYPE IN BINARY_INTEGER) RETURN DBMS_SQL.NUMBER_TABLE AS

/*****************************************************************
// Автор: Ворошилин В.				Корректировка
// Состояние на 17.11.2000			20.11.2014 Речицкая А.В.
// Код возврата: массив дат
// *****************************************************************/

  vsAOPINION_TYPE VARCHAR2(2000);
  vsAADVICE_TYPE VARCHAR2(2000);
  xDATES DBMS_SQL.NUMBER_TABLE;
  vsMin DATE;
  vsMax DATE;
  vsRECORD_START DATE;
  vsRECORD_END DATE;
  vsEXAMED_FROM DATE;
  vsDIS_TERM DATE;
BEGIN
  xDATES.Delete;
  if AOPINION_TYPE = - 1 then
    vsAOPINION_TYPE := '';
  else
    vsAOPINION_TYPE := TO_CHAR(AOPINION_TYPE);
  end if;
  if AADVICE_TYPE = - 1 then
    vsAADVICE_TYPE := '';
  else
    vsAADVICE_TYPE := TO_CHAR(AADVICE_TYPE);
  end if;
  for MRAKOPADVICE in (select NVL(a.RECORD_START, NULL) as vsRECORD_START,
                              NVL(a.RECORD_END, NULL) as vsRECORD_END,
							  NVL(b.EXAMED_FROM, NULL) as vsEXAMED_FROM,
							  NVL(a.DIS_TERM, NULL) as vsDIS_TERM
					   from W$MRAK_OPINION_ADVICE a, W$MRAK_OPINION b
					   where a.PID = XLPL.GetPid
					     and a.STAGE NOT IN (2,3)
						 and a.ENTERED_BY = XLPL.User_ID
						 and b.RID = a.MRAK_RID
						 and b.ENTERED_BY = MRAK_ENTERED_BY
                         AND b.RECORD_END IS NULL  --Добавлено 20.11.2014 Речицкая А.В.
						 and ((NVL(NVL(a.RECORD_START, b.EXAMED_FROM), LAST_DAY(S_CurrDate)) > LAST_DAY(S_CurrDate))
						     or (NVL(NVL(a.RECORD_END,a.DIS_TERM), LAST_DAY(S_CurrDate)) > LAST_DAY(S_CurrDate))))
--						 and a.OPINION_TYPE = AOPINION_TYPE
--						 and a.ADVICE_TYPE = AADVICE_TYPE)
  loop
    if MRAKOPADVICE.vsRECORD_START is NULL then
      vsMin := MRAKOPADVICE.vsEXAMED_FROM;
    else
      vsMin := MRAKOPADVICE.vsRECORD_START;
    end if;

    if MRAKOPADVICE.vsDIS_TERM is NULL and MRAKOPADVICE.vsRECORD_end is NULL then
       vsMax := NULL;
	end if;
    if MRAKOPADVICE.vsDIS_TERM is not NULL and MRAKOPADVICE.vsRECORD_end is NULL then
	   vsMax := MRAKOPADVICE.vsDIS_TERM;
	end if;
    if MRAKOPADVICE.vsDIS_TERM is NULL and MRAKOPADVICE.vsRECORD_end is not NULL then
	   vsMax := MRAKOPADVICE.vsRECORD_end;
	end if;
    if MRAKOPADVICE.vsDIS_TERM is not NULL and MRAKOPADVICE.vsRECORD_end is not NULL then
	   if MRAKOPADVICE.vsRECORD_end > MRAKOPADVICE.vsDIS_TERM then
	   	  vsMax := MRAKOPADVICE.vsDIS_TERM;
	   else
	      vsMax := MRAKOPADVICE.vsRECORD_end;
	   end if;
	end if;
    IF (vsMin is not NULL) THEN
      IF (vsMin > LAST_DAY(S_CurrDate)) THEN
        vsMin := LAST_DAY(vsMin);
          xDATES(xDATES.count + 1) := S_JULIAN (vsMin);
        IF AOPINION_TYPE = 1 THEN
          xDATES(xDATES.count + 1) := 314;
          xDATES(xDATES.count + 1) := 1;
        ELSE
          xDATES(xDATES.count + 1) := 315;
          xDATES(xDATES.count + 1) := 1;
        END IF;
      END IF;
    END IF;
    IF (vsMax is not NULL) THEN
      IF ((vsMax + 1) > (LAST_DAY(S_CurrDate))) THEN
        vsMax := LAST_DAY(vsMax);
          xDATES(xDATES.count + 1) := S_JULIAN (vsMax);
        IF AOPINION_TYPE = 1 THEN
          xDATES(xDATES.count + 1) := 33;
          xDATES(xDATES.count + 1) := 2;
        ELSE
          xDATES(xDATES.count + 1) := 58;
          xDATES(xDATES.count + 1) := 2;
        END IF;
      END IF;
    END IF;
  end loop;
  return xDATES;
END B_F_ARRAYDATEESTMRAKOPADVICEUX;
/
