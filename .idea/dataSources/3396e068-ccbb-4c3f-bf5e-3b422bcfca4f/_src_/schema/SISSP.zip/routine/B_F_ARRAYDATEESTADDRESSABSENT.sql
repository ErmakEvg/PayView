CREATE FUNCTION       B_F_ArrayDateEstADDRESSAbsent RETURN DBMS_SQL.NUMBER_TABLE AS
/**********************************************************************************************
 Функция            : B_F_ArrayDateEstADDRESSAbsent
 Наименование       : Функция возвращает массив дат изменения адреса проживания/прописки для Estimation
 Автор              : Ворошилин В.                    Корректировка: ОЛВ
 Состояние на дату  : 17.11.2000                                 16.03.2011   15.11.2011
 Код возврата       : массив дат изменения адреса проживания/прописки
***********************************************************************************************/
  chahge_date_aRecord   DBMS_SQL.NUMBER_TABLE;
  type_ADDR             NUMBER;
BEGIN
  chahge_date_aRecord.DELETE;
 /*  OLV 16.03.2011  */
 BEGIN
    SELECT MAX(ADDRESS_TYPE)
	  INTO type_ADDR
	  FROM W$ADDRESS
	 WHERE PID = XLPL.GetPid
	   AND STAGE IN (1, 4)
	   AND ENTERED_BY = XLPL.USER_ID;
 EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN chahge_date_aRecord;
 END;
/* */

    FOR AddressAbsent IN
	                 ( SELECT NVL(PERIOD_START, NULL) AS aRecord_start, NVL(PERIOD_END, NULL) AS aRecord_end
		 	             FROM W$ABSENCE_PERSON
             			WHERE PID = XLPL.GetPid
						  AND ADDRESS_RID =
						     (SELECT RID
						        FROM W$ADDRESS
						       WHERE PID = XLPL.GetPid
							     AND ADDRESS_TYPE = type_ADDR  -- OLV 16.03.2011  заплатка
						 		 AND STAGE IN (1, 4)           -- OLV 15.11.2011
							     AND ENTERED_BY = XLPL.USER_ID  )
						  AND (NVL(PERIOD_START, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate)
						      OR NVL(PERIOD_END, LAST_DAY(S_CurrDate)) >= LAST_DAY(S_CurrDate))
						  AND STAGE IN (1, 4)
						  AND ENTERED_BY = XLPL.USER_ID)
    LOOP
       IF (AddressAbsent.aRecord_start IS NOT NULL) AND (AddressAbsent.aRecord_start > LAST_DAY(S_CurrDate)) THEN
	       chahge_date_aRecord(chahge_date_aRecord.COUNT+1) := S_Julian(AddressAbsent.aRecord_start) - 1;
	       chahge_date_aRecord(chahge_date_aRecord.COUNT+1) := 65;
	       chahge_date_aRecord(chahge_date_aRecord.COUNT+1) := 1;
	   END IF;
	   IF (AddressAbsent.aRecord_end IS NOT NULL) AND ((AddressAbsent.aRecord_end + 1) > LAST_DAY(S_CurrDate)) THEN
	       chahge_date_aRecord(chahge_date_aRecord.COUNT+1) := S_Julian(AddressAbsent.aRecord_end);
	       chahge_date_aRecord(chahge_date_aRecord.COUNT+1) := 311;
	       chahge_date_aRecord(chahge_date_aRecord.COUNT+1) := 1;
	   END IF;
    END LOOP;
  RETURN chahge_date_aRecord;
END B_F_ArrayDateEstADDRESSAbsent;
/
