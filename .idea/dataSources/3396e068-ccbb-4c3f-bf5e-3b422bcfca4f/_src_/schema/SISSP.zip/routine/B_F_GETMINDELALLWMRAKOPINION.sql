CREATE FUNCTION       B_F_GetMinDelAllWMrakOpinion return DATE is
/* ---------------------------------------------------------------------------------------
// F_GetMinDelAllWMrakOpinion
// Автор Басинюк Я. В.
// состояние на 10.05.99
// Код возврата:  дата STEP_START из ALLOCATION для записей со STAGE = 3 из W$MRAK_OPINION
// по всем PID -ам из CASE_PERSON
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 15.07.2002
// --------------------------------------------------------------------------------------*/
  vsBNo number;
  vsDate date := null;
  vsMinDate date := null;
  alloc_date date;
begin
  vsBNo := S_CodeTableSISSP('MRAK_OPINION');

  for c1 in (select RID as vsRID from W$MRAK_OPINION
	         where ENTERED_BY = XLPL.User_ID
			   and STAGE = 3
			   and PID = XLPL.GetPID) loop

    vsDate := B_F_GetMinDateByRelRid(XLPL.CID, XLPL.AID, vsBNo, c1.vsRID);

    if (vsMinDate is null) then
      vsMinDate := vsDate;
	else
	  if (vsMinDate < vsDate) then
	    vsMinDate := vsDate;
	  end if;
	end if;
  end loop;

  alloc_date := B_F_StartDateAllocation();

  if (not (vsMinDate is null)) and (vsMinDate > alloc_date) then
    return vsMinDate;
  else
    return null;
  end if;
end;
/
