CREATE FUNCTION       A_F_GetRidsWActivity(ARELATION_DATE in Date,
   AACTIVITY in Number,ALABOR in Number,ASTAGE in Number,
   ADISMISSAL_REASON in DBMS_SQL.Number_Table) RETURN DBMS_SQL.Number_Table IS
/* Код возврата: возращает массив RID-ов по условию для W$ACTIVITY
 (если ALABOR = -1, то ALABOR не учитывается)
Вахромин О.Ю.*/
retRIDS DBMS_SQL.Number_Table;
i number;
BEGIN
   i:=1;
   if ALABOR=-1 then -- нет учета поля LABOR
      for c1 in (select RID,NVL(DISMISSAL_REASON,-1) D_REASON from W$ACTIVITY where
         PID=XLPL.GetPID and ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and
         ACTIVITY=AACTIVITY and
         (ARELATION_DATE between NVL(PERIOD_START,ARELATION_DATE) and
            NVL(PERIOD_END,ARELATION_DATE))) loop
		 if ADISMISSAL_REASON.count=0 then
            retRIDS(i):=c1.RID;
            i:=i+1;
         else
            for l in 1..ADISMISSAL_REASON.count loop
               if c1.D_REASON=ADISMISSAL_REASON(l) then
                  retRIDS(i):=c1.RID;
                  i:=i+1;
               end if;
            end loop;
         end if;
      end loop;
   else
      for c1 in (select RID,NVL(DISMISSAL_REASON,-1) D_REASON from W$ACTIVITY where
         PID=XLPL.GetPID and ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and
         ACTIVITY=AACTIVITY and LABOR=ALABOR and
         (ARELATION_DATE between NVL(PERIOD_START,ARELATION_DATE) and
            NVL(PERIOD_END,ARELATION_DATE))) loop
         if ADISMISSAL_REASON.count=0 then
            retRIDS(i):=c1.RID;
            i:=i+1;
         else
            for l in 1..ADISMISSAL_REASON.count loop
               if c1.D_REASON=ADISMISSAL_REASON(l) then
                  retRIDS(i):=c1.RID;
                  i:=i+1;
               end if;
            end loop;
         end if;
       end loop;
   end if;
   return retRIDS;
END A_F_GetRidsWActivity;
/
