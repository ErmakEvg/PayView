CREATE FUNCTION       B_F_ArrayDateEstChildOM RETURN DBMS_SQL.NUMBER_TABLE AS

/*==============================================================================
+ Функция: F_ArrayDateEstChildOM
+ Наименование: возвращает массив с датой наступления 1,5 года для Estimation
+ 				для ребенка одинокой матери
+ Автор: Ворошилин В.
+ Состояние на дату 30.11.2000
==============================================================================*/

  result_array DBMS_SQL.NUMBER_TABLE;
  StopDt DATE;
  StopDtEnd DATE;
BEGIN
  result_array.delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CHECKROLE(56) then
	return result_array;
  end if;
  XLPL.REPLACEROLE('Child');
  if B_AddYearsMonths(A_F_RelProtBirthDay, S_Const(409, XLPL.WorkDate)) > LAST_DAY(S_CurrDate) then
    result_array(1) := S_Julian(B_AddYearsMonths(A_F_RelProtBirthDay, S_Const(409, XLPL.WorkDate))) -1;
 	result_array(2) := 22;
 	result_array(3) := 2;
  end if;
  XLPL.RESTOREROLE;
  return result_array;
END B_F_ArrayDateEstChildOM;
/
