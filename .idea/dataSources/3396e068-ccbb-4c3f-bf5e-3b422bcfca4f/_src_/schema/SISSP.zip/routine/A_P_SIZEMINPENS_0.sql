CREATE FUNCTION       A_P_SIZEMINPENS_0 RETURN NUMBER AS
/*Исчисление размера пенсии в минимальном размере
(действует до 31.12.1999)
Вахромин О.Ю.*/
Min_Size NUMBER;
BEGIN
   Min_Size:=S_Const(16,XLPL.WorkDate);
   RETURN Min_Size;
END A_P_SIZEMINPENS_0;
/
