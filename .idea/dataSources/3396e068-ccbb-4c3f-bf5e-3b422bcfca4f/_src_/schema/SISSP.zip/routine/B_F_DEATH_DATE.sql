CREATE FUNCTION       B_F_Death_Date RETURN DATE AS

/***************************************************************************************
// Функция: B_F_Death_Date
// Наименование: Функция для определения даты смерти лица
// Автор: Боровнева
// Состояние на дату 16.02.1999
// Код возврата: дата смерти лица
//***************************************************************************************/

  aDeathDate DATE;
BEGIN
  begin
    SELECT DEATH_DATE INTO aDeathDate FROM W$PERSON
    WHERE PID = XLPL.GetPid
      and STAGE in (1, 4)
	  and DEATH_DATE <= XLPL.WorkDate
	  and Entered_By = XLPL.User_ID;
	exception
	  when NO_DATA_FOUND then
	    aDeathDate := NULL;
  end;
  return aDeathDate;
END B_F_Death_Date;
/
