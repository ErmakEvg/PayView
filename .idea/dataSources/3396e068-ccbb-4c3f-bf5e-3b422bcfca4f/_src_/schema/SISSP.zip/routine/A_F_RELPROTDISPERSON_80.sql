CREATE FUNCTION       A_F_RelProtDisPerson_80(ACODE_ROLE in NUMBER, pADVICE_TYPE1 IN NUMBER, pADVICE_TYPE2 IN NUMBER, pAge IN NUMBER, pWorkDate in DATE) RETURN  NUMBER AS
/*******************************************************************************
 Функция           : A_F_RelProtDisPerson_80
 Наименование      : Проверка наличия и подсчет в деле лиц, являющихся инв-ми
                       по pADVICE_TYPE с ролью ACODE_ROLE в возрасте до pAge
 Автор             : ОЛВ
 Состояние на дату : 02.06.2010 15.11.2011 19.01.2012  14.08.2015
 Код возврата      : возвращает true, если есть человек с ролью ACODE_ROLE
********************************************************************************/
  xDRIDS        DBMS_SQL.NUMBER_TABLE;
  vsDRID        NUMBER;
  pCount        NUMBER;
  vCount        NUMBER;
 -- st   varchar(4000);
BEGIN

 /* Входные параметры
  - ACODE_ROLE    - код роли в деле
  - pADVICE_TYPE1 - нуждается в уходе
  - pADVICE_TYPE2 - инвалидность
  - pAge          - возраст /* */

  xDRIDS.delete;
  pCount := 0;
  vCount:=0;
--st:=''; --'Начало:     '||chr(10);
 /* */
 -- ОБД : все RID из CASE_PERSON согласно коду по W$RELATION_PROTOCOL
 ----------------------------------------------------------------
    xDRIDS := A_F_RelProtGetRIDCasePersonPid;
	--xDRIDS.delete;
 if xDRIDS.count <> 0 then
   for i in 1..xDRIDS.count loop
	    vsDRID := xDRIDS(i);
				 --  st:=st||'1 i='||to_char(i)||'   vsDRID='||vsDRID;
	  --  Есть нуждающиеся 80-летние
	  --------------------------------
	  select count(*) into pCount
	  from CASE_PERSON a, PERSON b,
	       MRAK_OPINION_ADVICE c, MRAK_OPINION d
	  where a.RID = vsDRID
	    AND	a.PID = b.pid
	    AND	a.PID = c.pid
	    AND	a.PID = d.pid
		AND a.ROLE = ACODE_ROLE
		AND c.ADVICE_TYPE=pADVICE_TYPE1 -- Явл. утр. полн. и част.., нужд. в пост. уходе
		AND c.OPINION_TYPE=2            -- Нуждаемость в постоянном постороннем уходе 19.01.2012 OLV
		AND a.STAGE is null
		AND b.STAGE is null
		AND c.STAGE is null
		AND d.STAGE is null
   	    -- 14.08.2015 OLV --AND ((b.DEATH_DATE is NULL) OR (b.DEATH_DATE > pWorkDate)) -- 19.01.2012 OLV
        AND ((b.DEATH_DATE is NULL) OR (LAST_DAY(b.DEATH_DATE) > pWorkDate)) -- 14.08.2015 OLV
		AND S_AddYears (b.BIRTH_DATE,ROUND(pAge)) <= pWorkDate
		AND  NVL(NVL(c.RECORD_START,d.EXAMED_FROM),pWorkDate)<=pWorkDate
		AND  NVL(NVL(c.RECORD_END,c.DIS_TERM),pWorkDate)>=pWorkDate;
		                    -- st:=st||'  - 11 pCount='||to_char(pCount)||chr(10);
		IF (pCount is not null) and (pCount>0) THEN
           vCount:=vCount+1;
		                  --   st:=st||' сум1  vCount='||to_char(vCount)||'  pCount='||to_char(pCount)||chr(10);
		else
				          --   st:=st||' 2 i='||to_char(i)||'   vsDRID='||vsDRID;
	      --         Есть инв-ть
	      --------------------------------
		  select count(*) into pCount
	        from CASE_PERSON a, PERSON b,
		         MRAK_OPINION_ADVICE c, MRAK_OPINION d
	       where a.RID = vsDRID
	         AND a.PID = b.pid
	         AND a.PID = c.pid
	         AND a.PID = d.pid
		     AND a.ROLE = ACODE_ROLE
		     AND c.ADVICE_TYPE=pADVICE_TYPE2
			 AND c.OPINION_TYPE=1			 -- инв-ть
             AND d.RID=c.MRAK_RID
		     AND a.STAGE is null
		     AND b.STAGE is null
		     AND c.STAGE is null
		     AND d.STAGE is null
    	     -- 14.08.2015 OLV--AND ((b.DEATH_DATE is NULL) OR (b.DEATH_DATE > pWorkDate)) -- 19.01.2012 OLV
             AND ((b.DEATH_DATE is NULL) OR (LAST_DAY(b.DEATH_DATE) > pWorkDate)) -- 14.08.2015 OLV
		     AND  NVL(NVL(c.RECORD_START,d.EXAMED_FROM),pWorkDate)<=pWorkDate
		     AND  NVL(NVL(c.RECORD_END,c.DIS_TERM),pWorkDate)>=pWorkDate;
		                          --  st:=st||' -  22 pCount='||to_char(pCount)||chr(10);
	         IF (pCount is not null) and (pCount>0) THEN
                vCount:=vCount+1;
             END IF;
		                   --    st:=st||'сумм2   vCount='||to_char(vCount)||'  pCount='||to_char(pCount)||chr(10);--  ||vsDRID='||to_char(vsDRID)
                          --IF (pCount is not null) and (pCount>0) THEN
                           --   vCount:=vCount+pCount;
		                   --  st:=st||'сумма после select2    vsDRID='||to_char(vsDRID)||'   vCount='||to_char(vCount)||chr(10);
                           --  END IF;
        END IF;
   end loop;
 end if;
 /* */
 -- РБД : все RID из W$CASE_PERSON согласно коду по W$RELATION_PROTOCOL
 ----------------------------------------------------------------
    xDRIDS := A_F_RelProtGetRIDWCasePersPid;
 if xDRIDS.count <> 0 then
   for i in 1..xDRIDS.count loop
	    vsDRID := xDRIDS(i);

	  --  Есть нуждающиеся 80-летние
	  --------------------------------
	 select count(*) into pCount
	   from W$CASE_PERSON a, W$PERSON b,
	        W$MRAK_OPINION_ADVICE c, W$MRAK_OPINION d
	  where a.RID = vsDRID
	    AND	a.PID = b.pid
	    AND	a.PID = c.pid
	    AND	a.PID = d.pid
		AND a.ROLE = ACODE_ROLE
		AND a.ENTERED_BY = c.ENTERED_BY -- OLV 15.11.2011 - дело может находиться одновременно у неск-х польз-й
		AND a.ENTERED_BY = d.ENTERED_BY -- OLV 15.11.2011
		AND a.ENTERED_BY = b.ENTERED_BY -- OLV 15.11.2011
		AND c.ADVICE_TYPE=pADVICE_TYPE1 -- Явл. утр. полн. и част.., нужд. в пост. уходе
		AND c.OPINION_TYPE=2            -- Нуждаемость в постоянном постороннем уходе
		AND c.STAGE in (1,4)
		AND d.STAGE in (1,4)
    	-- 14.08.2015 OLV--AND ((b.DEATH_DATE is NULL) OR (b.DEATH_DATE > pWorkDate)) -- 19.01.2012 OLV
        AND ((b.DEATH_DATE is NULL) OR (LAST_DAY(b.DEATH_DATE) > pWorkDate)) -- 14.08.2015 OLV
		AND S_AddYears (b.BIRTH_DATE,ROUND(pAge)) <= pWorkDate
		AND NVL(NVL(c.RECORD_START,d.EXAMED_FROM),pWorkDate)<= pWorkDate
		AND NVL(NVL(c.RECORD_END,c.DIS_TERM),pWorkDate)>= pWorkDate;
		                 --  st:=st||'Вос0  1  vsDRID='||to_char(vsDRID)||' 1  pCount='||to_char(pCount)||chr(10);   --||'   Get_Pid='||to_char(XLPL.GetPid)||chr(10);
		IF (pCount is not null) and (pCount>0) THEN
           vCount:=vCount+1;
		                 --   st:=st||'Вос1  2  vsDRID='||to_char(vsDRID)||' 2  pCount='||to_char(vCount)||chr(10);--||'   Get_Pid='||to_char(XLPL.GetPid)||chr(10) ;
		else
	      --         Есть инв-ть
	      --------------------------------
	      select count(*) into pCount
	        from W$CASE_PERSON a, W$PERSON b,
			     W$MRAK_OPINION_ADVICE c, W$MRAK_OPINION d
	       where a.RID = vsDRID
	         AND a.PID = b.pid
	         AND a.PID = c.pid
	         AND a.PID = d.pid
		     AND a.ROLE = ACODE_ROLE
			 AND a.ENTERED_BY = c.ENTERED_BY -- OLV 15.11.2011 - дело может находиться одновременно у неск-х польз-й
			 AND a.ENTERED_BY = d.ENTERED_BY -- OLV 15.11.2011
		     AND a.ENTERED_BY = b.ENTERED_BY -- OLV 15.11.2011
		     AND c.ADVICE_TYPE=pADVICE_TYPE2 -- гр. инв-ти
			 AND c.OPINION_TYPE=1			 -- инв-ть
             AND d.RID=c.MRAK_RID
		     AND c.STAGE in (1,4)
		     AND d.STAGE in (1,4)
    	     -- 14.08.2015 OLV --AND ((b.DEATH_DATE is NULL) OR (b.DEATH_DATE > pWorkDate))
             AND ((b.DEATH_DATE is NULL) OR (LAST_DAY(b.DEATH_DATE) > pWorkDate)) -- 14.08.2015 OLV
		     AND  NVL(NVL(c.RECORD_START,d.EXAMED_FROM),pWorkDate)<=pWorkDate
		     AND  NVL(NVL(c.RECORD_END,c.DIS_TERM),pWorkDate)>=pWorkDate;
		                     --  st:=st||'Инв0  3  vsDRID='||to_char(vsDRID)||' 3  vCount='||to_char(vCount)||chr(10)||' 3  pCount='||to_char(pCount)||chr(10)||'   pADVICE_TYPE2='||to_char(pADVICE_TYPE2)||chr(10);--||'   Get_Pid='||to_char(XLPL.GetPid)||chr(10);
		     IF (pCount is not null) and (pCount>0) THEN
               vCount:=vCount+1;
		                     --   st:=st||'Инв1 4  vsDRID='||to_char(vsDRID)||' 4  vCount='||to_char(vCount)||chr(10);
                              -- RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtDisPerson 111   vCount='||vCount||'   pCount='||pCount||'   Get_Pid='||XLPL.GetPid );
             END IF;
        END IF;
				                 --  st:=st||'4    i='||to_char(i)||chr(10)||'   vCount='||to_char(vCount)||chr(10);
   end loop;
 end if;
                        --   RAISE_APPLICATION_ERROR(-20801,'A_F_RelProtDisPerson 444   pWorkDate='||pWorkDate||CHR(10)||ST||'   xDRIDS.count='||xDRIDS.count||chr(10));--||'   Get_Pid='||to_char(XLPL.GetPid)||chr(10));
  RETURN vCount;
/* *if xlpl.getpid=7060013971 and  XLPL.WorkDate = to_date('01-08-2015','DD-MM-YYYY')then--70602003069 then
--rDate := S_jtod(result_step_start(result_step_start.count));
RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtDisPerson_80  '
||chr(10)||'xDRIDS.count='||xDRIDS.count
||chr(10)||'vsDRID='||vsDRID
||chr(10)||'pCount='||pCount
);
end if; /**/

END A_F_RelProtDisPerson_80;
/
