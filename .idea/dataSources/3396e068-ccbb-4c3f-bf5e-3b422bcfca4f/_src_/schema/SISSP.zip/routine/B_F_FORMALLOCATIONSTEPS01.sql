CREATE FUNCTION       B_F_Formallocationsteps01 RETURN DBMS_SQL.NUMBER_Table IS
/**********************************************************************************************
 Функция                : B_F_FormAllocationSteps01
 Наименование       : функция определяет шаги назначения по изменениям
                                для пособий на детей до 3 лет
 Автор                     : Ворошилин В.           Комментарии и корректировка: ОЛВ
 Состояние на дату  : 18.07.2002   23.03.2010   09.02.2011  02.02.2012   22.05.2013  25.06.2013
 Код возврата           : массив даты шагов            Речицкая АВ  26.05.2014	10.05.2017
***********************************************************************************************/
 result_step_start DBMS_SQL.NUMBER_Table;           -- массив, накапливающий даты шагов
 result_array       DBMS_SQL.NUMBER_Table;           -- массив, содержащий готовые для возврата даты шагов (без повторений)
 result_function   DBMS_SQL.NUMBER_Table;           -- массив, в который функции возвращают даты шагов
 result_rab           DBMS_SQL.NUMBER_Table;
 aP                   DBMS_SQL.NUMBER_Table;
 A                   DBMS_SQL.NUMBER_Table;
 prdate            DATE;
 PuskDate            DATE;                               -- рабочая дата
 d1                DATE;                               -- дата, используемая для работы
 rDate                DATE;                               -- дата, используемая для работы
 BrDt1                DATE;
 DthDt                DATE;
 datetalk            DATE;
 d6m                DATE;
 StopDt            DATE;
 BrDt                DATE;
 WDt                DATE;
 LimitDate            DATE;
 LimitDate_Vipl     DATE;     -- OLV  25.06.2013
 pAlloc_Code        NUMBER;                             -- код назначения
 pAID               NUMBER;                               -- идентификатор назначения
 aPID               NUMBER;                            -- идентификатор лица
 pCID               NUMBER;                               -- идентификатор дела
 Param6m            NUMBER;                               -- признак превышения 6 месяцев
 i                  NUMBER;                                 -- счетчик
 j                    NUMBER;                               -- счетчик
 k                    NUMBER;                            -- счетчик
 M                    NUMBER;
 Y                    NUMBER;
 GrNo                NUMBER;
 prnew                NUMBER;
 prold                NUMBER;
 flg_insert_result BOOLEAN;                            -- признак повтора дат
 bl                BOOLEAN;
BEGIN

 Xlpl.SETGLOBALFLOAT('Bullit', 0);
 Xlpl.SETGLOBALFLOAT('WB', 1);

 pAlloc_Code := Xlpl.Alloc_Code;
 pAID := Xlpl.AID;
 pCID := Xlpl.CID;
 GrNo := Xlpl.Group_No;
 aP.DELETE;
 A.DELETE;
 i := 0;
 j := 0;
 k := 0;
 d1 := NULL;
 rDate := NULL;

--==============================================================================
-- установка рабочих признаков:
-- если Param6m = 1, то значит дата обращения превышает на 6 мес. дату начала
--                        действия назначения, иначе дата обращения не превышает
--                     дату начала действия на 6 мес.
--==============================================================================
   d1 := Xlpl.WorkDate;

 IF pAID = 0 THEN                                    -- Если это первичное назначение, то
     datetalk := A_F_Datatalk;                        -- Получить дату подачи заявления (или дату, указанную вручную)
     M := S_Const(432, Xlpl.WorkDate);                -- Взять срок срок обращения за пособием (в месяцах)
     d6m := ADD_MONTHS(d1, M);                            -- и добавить к дате начального шага.
   IF d6m < datetalk THEN                             -- Если полученная дата меньше даты подачи заявления, то
         Param6m := 1;                                    -- установить, что дата обращения превышает на 6 мес. дату начала действия назначения
   ELSE                                                -- иначе
      Param6m := 0;                                    -- дата обращения не превышает на 6 мес. даты возникновения права
   END IF;
 ELSE                                                   -- иначе
   Param6m := 0;                                    -- обнулить признак не превышения на 6 мес. даты возникновения права
 END IF;

 PuskDate := d1;                                        -- Установить дату начала формирования переломных точек

--==============================================================================
-- Ниже для всей группы и для каждого члена группы выполняются просмотр рабочих
-- таблиц и определяются даты всех происшедших в них изменений, начиная
-- с даты возникновения права (даты назначения пособий) по дату подачи заявления
-- и создается масив, состоящий из дат изменений информации (переломных точек),
-- общий по всем таблицам.
--==============================================================================
----- для всей группы -----
 IF pAID <> 0 THEN
   aP := B_F_Manageallocstatus;
   IF aP.COUNT > 0 THEN
       prnew := aP(1);
       prold := aP(2);
       prdate := S_Jtod(aP(3));
      IF prdate IS NOT NULL THEN
           result_step_start(result_step_start.COUNT+1) := S_Julian(prdate);
      END IF;
   END IF;
 END IF;

 aP.DELETE;

 -- Функция возвращает дату возобновления других назначений, находящихся в деле
   result_function.DELETE;
   result_function := A_P_Allocstartdateother(PuskDate, Param6m);
 IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
 END IF;

 -- Функция возвращает дату закрытия - приотановки других назначений, находящихся в деле
   result_function.DELETE;
   result_function := B_P_Allocclosedateother(PuskDate, Param6m);
 IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
 END IF;

 --ОЛВ -- 19.03.2012 Примечание: если т. перелома - 1.5, 2, 2.5 года уже были просчитаны, то при перерасчете будут здесь*
 -- Масcив шагов по старому назначению
    aP := A_F_Arrayallocationstep(Xlpl.WorkDate);
 IF aP.COUNT > 0 THEN
     FOR k IN 1..aP.COUNT LOOP                                     -- в оригинале - индекс с нуля
           IF S_Jtod(aP(k)) > PuskDate THEN
             result_step_start(result_step_start.COUNT+1) := aP(k);
         END IF;
     END LOOP;
     aP.DELETE;
 END IF;

 ---------------------------------------------------------------------
 --               Получатель в назначении            --
 ---------------------------------------------------------------------
         -- точки начала и конца текущего выплатного периода для ручной корректировки данных после массового расчета  -- ОЛВ   25.06.2013
        --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
             LimitDate_Vipl:=NULL;
            d1:=A_F_ViplPeriod_Start;
         IF d1 IS NOT NULL THEN
            result_step_start(result_step_start.COUNT+1):= S_Julian(d1);
            d1:=LAST_DAY(A_F_ViplPeriod_Start)+1;
            result_step_start(result_step_start.COUNT+1):= S_Julian(d1);
               LimitDate_Vipl:=d1;
        END IF;
-- Функция возвращает массив дат изменения общей информации о лице
   result_function.DELETE;
   result_function := B_F_Arraydatechangeperson(PuskDate, Param6m);
 IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
 END IF;

   result_function.DELETE;
   result_function := B_F_Arraydatechangeaddress(PuskDate, Param6m);
 IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
 END IF;

   result_function.DELETE;
   result_function := B_F_Arraydatechangeactivity(1, PuskDate, Param6m);
 IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
 END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangeactivity(2, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangeactivity(3, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangewmrak(PuskDate, -1, -1, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangeaddressab(PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(145, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(720, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(146, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

-- 154 - Проживает, ведет хозяйство и воспитывает ребенка совместно с отцом ребенка
result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(154, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(155, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(231, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(232, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(256, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(650, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(651, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(652, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(653, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(654, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(655, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(656, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(657, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(658, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(659, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;
--Речицкая А. В. 10.05.2017
result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(547, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;
-- 10.05.2017
result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(121, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(122, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(125, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(126, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(463, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(258, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(320, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(183, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Arraydatechangemetricmon(545, PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

result_function.DELETE;
result_function := B_F_Changepension(PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;


result_function.DELETE;
result_function := B_F_Changebenefit(PuskDate, Param6m);
IF result_function.COUNT > 0 THEN
     FOR j IN 1..result_function.COUNT LOOP
          result_step_start(result_step_start.COUNT+1) := result_function(j);
     END LOOP;
END IF;

 ---------------------------------------------------------------------
 --                       Ребенок в назначении                      --
 ---------------------------------------------------------------------
/* */
IF  Xlpl.CheckRole(56) THEN
    Xlpl.RoleDecl('Child','56');   -- Ребенок в назначении
    Xlpl.REPLACEROLE('Child');
/* */
    result_function.DELETE;
    result_function := B_F_Arraydatechangeperson(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeaddress(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
/* *--ОЛВ -- 15.03.2012  не показывать эти т. перелома - 1.5, 2, 2.5 *
    result_function.delete;
    result_function := B_F_ARRAYDATECHANGEACTIVITYGAR(PuskDate);
    if result_function.count > 0 then
       for j in 1..result_function.count loop
            result_step_start(result_step_start.count+1) := result_function(j);
       end loop;
    end if;
/* */
    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(2, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeaddressab(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(183, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(148, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(320, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(171, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
--22.05.2013 ОЛВ открыла -было закрыто --Речицкая АВ 17.04.2013
/* */ result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(359, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
   /* */
--Речицкая АВ 17.04.2013
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(354, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(257, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    --Речицкая АВ  добавлено 04.04.2013
 --188 - Находится на гос. обеспечении в ГУ, обеспечивающем получение образования по дневной форме обучения
 --679 - Проживает в детском доме семейного типа
 --680 - Проживает в детской деревне (городке)
 --681 - Проживает в приемной семье
 --193 - Находится на круглосуточном пребывании в ДУ
--682 право на пособие имеет 04.04.2013 Речицкая АВ
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(188, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(679, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(680, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(681, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(193, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
--04.04.2013 Речицкая АВ
    -- 259 - Ребенок посещает детское дошкольное учреждение - ОЛВ 02.02.2012
    result_function.DELETE;
    -- Нужно с первого числа месяца  следующего за месяцем оформления ОЛВ 19.03.2012
    result_function := B_F_Arraydatechangemetricmon(259, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(355, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(358, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(545, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    --10.07.2014  Речицкая АВ--result_function := B_F_Arraydatechangewmrak(PuskDate, -1, -1, Param6m);
    result_function := B_F_Arraydatechangewmrak_Pos(PuskDate, -1, -1, Param6m); --10.07.2014  Речицкая АВ  по новому положению пункт 12 Положения № 569 от 28.06.2013
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    Xlpl.RestoreRole;
END IF;
/* */
 ---------------------------------------------------------------------
 --                        Отец в назначении                        --
 ---------------------------------------------------------------------
IF (Xlpl.CheckRole(57) AND NOT B_F_Recipient(57)) OR
    Xlpl.CheckRole(69) THEN
    Xlpl.RoleDecl('Father','57, 69');
    Xlpl.REPLACEROLE('Father');

    result_function.DELETE;
    result_function := B_F_Arraydatechangeperson(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeaddress(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(1, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(2, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeactivity(3, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangeaddressab(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(183, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(650, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(651, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(652, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(653, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(654, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(655, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(656, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(657, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(658, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(659, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(463, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(256, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(258, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    --Речицкая АВ 26.05.2014 добавлена проверка 260 метрики
    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(260, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(320, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(545, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(121, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(122, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(125, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangemetricmon(126, PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Changepension(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Changebenefit(PuskDate, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;

    result_function.DELETE;
    result_function := B_F_Arraydatechangewmrak(PuskDate, -1, -1, Param6m);
    IF result_function.COUNT > 0 THEN
       FOR j IN 1..result_function.COUNT LOOP
            result_step_start(result_step_start.COUNT+1) := result_function(j);
       END LOOP;
    END IF;
    Xlpl.RestoreRole;
END IF;

 ---------------------------------------------------------------------
 --                     Ребенок в назначении                     --
 ---------------------------------------------------------------------
Xlpl.REPLACEROLE('Child');
BrDt := S_Birthdate(0, Xlpl.GETPID, Xlpl.WorkDate);            -- дата рождения ребенка
Xlpl.RestoreRole;

WDt := S_Currdate;
WDt := LAST_DAY(WDt);

Y := S_Const(401, Xlpl.WorkDate);
StopDt := S_Addyears(BrDt,Y);
IF StopDt > PuskDate AND StopDt <= WDt THEN
   result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt)+1;
END IF;

----- Наступление даты введения нового Закона -----
StopDt := S_Encodedate(2002, 04, 01);
IF StopDt > PuskDate AND StopDt <= WDt THEN
   result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
END IF;
----- Наступление даты введения нового Закона -----
StopDt := S_Encodedate(2013, 01, 01);
IF StopDt > PuskDate AND StopDt <= WDt THEN
   result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
END IF;
Xlpl.REPLACEROLE('Child');
-- Ребенок одинокой матери - <1.5 года -75%, >1.5 года -40% -- 17.05.2012
bl := B_F_Metric(354, Xlpl.WorkDate);
aPID := Xlpl.GETPID;
/* */
IF bl THEN
   BEGIN
   SELECT BIRTH_DATE, NVL(DEATH_DATE, NULL)
   INTO BrDt1, DthDt
   FROM W$PERSON
   WHERE PID = aPID AND
         ENTERED_BY = Xlpl.USER_ID AND
            NVL(RECORD_START, Xlpl.WorkDate) <= Xlpl.WorkDate AND
         (RECORD_END >= Xlpl.WorkDate OR RECORD_END IS NULL) AND
         STAGE  IN (1,4,6);
   EXCEPTION
   WHEN OTHERS THEN
        BrDt1 := NULL;
        DthDt := NULL;
   END;
   --                        1,5 года
   -------------------------------------------------------
   IF BrDt1 IS NOT NULL THEN
         Y := S_Const(409, Xlpl.WorkDate);                      -- 1,5 года
         --StopDt := B_AddYearsMonths(BrDt1, Y);
         StopDt := B_Addyearsmonths_D(BrDt1, Y); -- ОЛВ 09.02.2011 -- исправить погрешность последнего дня месяца
         IF StopDt > PuskDate AND StopDt <= WDt THEN
              result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt)+1;
      END IF;
      IF DthDt IS NOT NULL THEN
         StopDt := DthDt;
         IF StopDt > PuskDate AND StopDt <= WDt THEN
             result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
         END IF;
      END IF;

      -- ???? Это уже было -- ОЛВ 09.02.2011  ???
      Y := S_Const(409, Xlpl.WorkDate);                      -- 1,5 года
         --StopDt := B_AddYearsMonths(BrDt1, Y);
         StopDt := B_Addyearsmonths_D(BrDt1, Y);    -- ОЛВ 09.02.2011 -- исправить погрешность последнего дня месяца
         IF StopDt > PuskDate AND StopDt <= WDt THEN
              result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt)+1;
      END IF;

   END IF;
END IF;
/* */
--
-- 20/12/2012 Речицкая АВ if B_F_Disability(11, XLPL.WorkDate) then
IF B_F_Disability(14, Xlpl.WorkDate) THEN
   StopDt := NULL;
   BEGIN
   SELECT DIS_TERM
   INTO StopDt
   FROM W$MRAK_OPINION_ADVICE
   WHERE PID = Xlpl.GetPid  AND
            OPINION_TYPE = 1 AND
          --20/12/2012 Речицкая АВ ADVICE_TYPE = 11 and
         ADVICE_TYPE = 14 AND
         ENTERED_BY = Xlpl.USER_ID AND
         STAGE NOT IN(2,3) AND
         (RECORD_START <= Xlpl.WorkDate AND NVL(DIS_TERM, Xlpl.WorkDate) >= Xlpl.WorkDate) AND
         (RECORD_END >= Xlpl.WorkDate OR RECORD_END IS NULL);
   EXCEPTION
   WHEN OTHERS THEN
        StopDt := NULL;
   END;
   IF StopDt IS NOT NULL AND StopDt > PuskDate AND StopDt <= WDt THEN
      --20.12.20112 Речицкая Ав StopDt := Last_Day(StopDt);
      StopDt :=  (StopDt)+1;
      result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
   END IF;
END IF;

IF B_F_Disneed THEN
   StopDt := NULL;
   BEGIN
   SELECT RECORD_END
   INTO StopDt
   FROM W$MRAK_OPINION_ADVICE
   WHERE PID = aPID AND
            OPINION_TYPE = 2 AND
         ADVICE_TYPE = 21 AND
         ENTERED_BY = Xlpl.USER_ID AND
         STAGE NOT IN(2,3) AND
         (RECORD_START <= Xlpl.WorkDate AND NVL(RECORD_END, Xlpl.WorkDate) >= Xlpl.WorkDate) AND
         (RECORD_END >= Xlpl.WorkDate OR RECORD_END IS NULL);
   EXCEPTION
   WHEN OTHERS THEN
        StopDt := NULL;
   END;
   IF StopDt IS NOT NULL AND StopDt > PuskDate AND StopDt <= WDt THEN
      StopDt := LAST_DAY(StopDt);
      result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
   END IF;
END IF;
/* */
A := B_F_Childbirth;
IF A.COUNT > 0 THEN
   j := A.COUNT;
   FOR k IN 1..j LOOP
          StopDt := S_Jtod(A(k));
       IF StopDt IS NOT NULL AND StopDt > PuskDate AND StopDt <= WDt THEN
             result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
       END IF;
       IF B_F_Spisalloccode1 AND StopDt IS NOT NULL THEN
            StopDt := StopDt + S_Const(451, Xlpl.WorkDate) + 1;
          IF StopDt > PuskDate AND StopDt <= WDt THEN
               result_step_start(result_step_start.COUNT+1) := S_Julian(StopDt);
          END IF;
       END IF;
   END LOOP;
END IF;
/* */
Xlpl.RestoreRole;
/* */
 ---------------------------------------------------------------------
 --                   Получатель???? в назначении                   --
 ---------------------------------------------------------------------
result_rab.DELETE;
IF prnew = 3 OR prnew = 2 THEN
   LimitDate := prdate;
ELSE
   LimitDate := B_F_Laststepaid(pAID, pCID);
END IF;

  -- конец текущего выплатного периода для ручной корректировки данных после массового расчета  -- ОЛВ   25.06.2013
  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  IF  LimitDate_Vipl IS NOT NULL  THEN
       LimitDate:= LimitDate_Vipl;
  END IF;

  --RAISE_APPLICATION_ERROR(-20004,'A_F_Arraydatachangedeldup  '||CHR(10)||'  LimitDate='|| LimitDate||CHR(10));
FOR j IN 1..result_step_start.COUNT LOOP
    rDate := S_Jtod(result_step_start(j));
    --10.07.2014 Речицкая АВ --IF rDate IS NOT NULL AND rDate > Xlpl.WorkDate AND rDate <= LimitDate THEN
    IF rDate IS NOT NULL AND rDate > Xlpl.WorkDate AND rDate <= LimitDate+1 THEN --10.07.2014 Речицкая АВ
           result_rab(result_rab.COUNT+1) := result_step_start(j);
    END IF;
END LOOP;
result_step_start.DELETE;
FOR j IN 1..result_rab.COUNT LOOP
    result_step_start(result_step_start.COUNT+1) := result_rab(j);
END LOOP;
result_rab.DELETE;

IF result_step_start.COUNT > 0 THEN
   Xlpl.SETGLOBALFLOAT('Bullit', 1);
END IF;

RETURN A_F_Arraydatachangedeldup(result_step_start);

END B_F_Formallocationsteps01;
/
