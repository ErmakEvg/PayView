CREATE FUNCTION       B_F_GetContribution return NUMBER is
/*
безымянная функция
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 16.07.2002
*/
rez number;
begin
  for c1 in (select nvl(CONTRIBUTION_YEAR, null) as rez, a.YEAR as aYear
		   	 from W$CASE_SUMMARY_INCOME a
		   	 where CID = XLPL.CID
			   and STAGE <> 3
			   and ENTERED_BY = XLPL.User_ID) loop
    if (S_YearOfDate(XLPL.WorkDate) - 1 = S_YearOfDate(c1.aYear)) then
	   if c1.rez is not null then
       	  return c1.rez;
	   else
	      c1.rez := 0;
	      return c1.rez;
	   end if;
	end if;
  end loop;
rez := 0;
return rez;
end B_F_GetContribution;
/
