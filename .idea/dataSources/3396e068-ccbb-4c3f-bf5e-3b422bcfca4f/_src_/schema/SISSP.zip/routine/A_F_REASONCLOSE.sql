CREATE FUNCTION       A_F_ReasonClose RETURN NUMBER IS
/******************************************************************************
 NAME         : A_F_ReasonClose
 Назначение   : Функция получения кода причины закрытия(приостановки) назначения
 Автор        :  Вахромин О.Ю.                 Комментарии : ОЛВ
 Дата         :	 		  					   			   	 02.04.2010
 Код возврата : Возвращает код причины закрытия(приостановки) назначения
******************************************************************************/
 vStatus_Reason  NUMBER;

BEGIN
   select nvl(STATUS_REASON,0) into vStatus_Reason
     from w$change_alloc_status
	where cid=XLPL.Cid
	  and aid=XLPL.Aid
	  and alloc_status_new in (2,3)
	  and STATUS_DATE>=XLPL.WorkDate;

   return vStatus_Reason;

exception
   when NO_DATA_FOUND then
      return 0;

END A_F_ReasonClose;
/
