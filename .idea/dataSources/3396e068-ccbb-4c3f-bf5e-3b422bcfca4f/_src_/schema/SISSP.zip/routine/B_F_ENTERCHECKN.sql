CREATE FUNCTION       B_F_EnterCheckN RETURN BOOLEAN IS
/**********************************************************************************************
 Функция            : B_F_EnterCheckN
 Наименование       :  проверяет, имеет ли право лицо получать пособие на момент подачи заявления
 Автор              : ОЛВ                            Согл. Ворошилин В.Я.      (РМП)
 Состояние на дату  : 04.08.10  PAV 28.03.2018
 Код возврата       : True - имеет право, False - не имеет права
***********************************************************************************************/
xResume      BOOLEAN;
old_WorkDate DATE;
new_WorkDate DATE;
xPIDw        BOOLEAN;
xPIDb        BOOLEAN;
xPIDs        BOOLEAN;

BEGIN
new_WorkDate := A_F_DataTalk;
old_WorkDate := XLPL.WorkDate;
XLPL.SETWORKDATE(new_WorkDate);
-- работает
xPIDw := A_F_RelProtActv('1', '');
--xPIDb := A_F_RelProtActv('1', '200, 201, 202, 203, 204, 205, 206, 207,313,314'); скопировнная строка 02.03.2011 РАВ
xPIDb := A_F_RelProtActv('1', '200, 201, 202, 203, 204, 205, 206, 207,208,302,313,314,315'); --добавлена 208  02.03.2011 РАВ
-- учится
xPIDs := A_F_RelProtActv('2', '');
XLPL.SETWORKDATE(old_WorkDate);

if (xPIDw and not xPIDb) or    xPIDs then

 xResume := True;--имеет права получения в органах соцзащиты
else

  xResume := False; --Не имеет права получения в органах соцзащиты
  --RAISE_APPLICATION_ERROR(-20801,'B_F_EnterCheckN @@@  XLPL.GetPid=' ||XLPL.GetPid||'xPIDw='||' new_WorkDate='||new_WorkDate||' old_WorkDate='||old_WorkDate);

end if;
RETURN xResume;
END B_F_EnterCheckN;
/
