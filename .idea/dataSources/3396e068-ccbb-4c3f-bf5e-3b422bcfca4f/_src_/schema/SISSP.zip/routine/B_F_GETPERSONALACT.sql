CREATE FUNCTION       B_F_GetPersonalAct (vPid IN NUMBER) RETURN boolean AS
/*******************************************************************************
Функция           : B_F_GetPersonalAct
Наименование      : Функция определяет наличие лицевого счета
				  : при назначении семейного капитала по PID получателя
Автор             : Речицкая А. В.
Состояние на дату : 19.05.2017
Возвращает        : номер лицевого счета получателя семейного капитала по  его PID
******************************************************************************/
 dPersonalAcct         NUMBER;

  BEGIN
    Select COUNT(*)  INTO dPersonalAcct
   	from RECIPIENT
        Where PID =vPid--XLPL.GetPid
	         and stage is null
		     and close_date is null
			 and PERSONAL_ACCT is not null
    		 and cid=XLPL.CID;
     --RAISE_APPLICATION_ERROR(-20801,'GetPersonalAct    22222    vPid='||vPid||'   dPersonalAcct='|| dPersonalAcct );
     if     dPersonalAcct >0 then return true; else return false;end if;
    -- return dPersonalAcct >0;

   /* SELECT to_number(PERSONAL_ACCT)
        INTO dPersonalAcct
        from RECIPIENT
       WHERE cid=XLPL.CID
        and stage is null
		and close_date is null
		--and alloc_code=701
        and PID =vPid;
  EXCEPTION
     WHEN others THEN--NO_DATA_FOUND OR TOO_MANY_ROWS THEN
        dPersonalAcct:=0;*/
  END;
/
