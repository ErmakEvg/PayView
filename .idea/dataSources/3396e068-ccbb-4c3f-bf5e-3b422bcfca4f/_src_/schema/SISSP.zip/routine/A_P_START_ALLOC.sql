CREATE FUNCTION       A_P_Start_Alloc RETURN DATE AS
/*******************************************************************************
 Функция            : A_P_Start_Alloc
 Наименование       : Функция определения даты начала действия текущего назначения
 Автор              : ОЛВ
 Состояние на дату  : 16.11.2015
 Код возврата       : предположительная дата действия назначения
********************************************************************************/
 pStart_Alloc DATE;

BEGIN
   BEGIN
    SELECT min(step_start)
      INTO pStart_Alloc
      FROM ALLOCATION
     WHERE cid = Xlpl.CID
       AND aid = Xlpl.AID
       AND stage IS NULL
       AND alloc_status = 1
       AND parent_rid IS NULL
       AND comp_part IS NULL
       AND alloc_code = Xlpl.ALLOC_CODE;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
          pStart_Alloc := Xlpl.WorkDate;
     WHEN TOO_MANY_ROWS THEN
          RAISE_APPLICATION_ERROR(-20801,'A_P_Start_Alloc:  Cуществует некорректная запись в ALLOCATION');
   END;

  IF pStart_Alloc IS NULL THEN  -- 19.05.2015 OLV
     pStart_Alloc := Xlpl.WorkDate;
  END IF;
    RETURN   pStart_Alloc;
--  RAISE_APPLICATION_ERROR(-20801,'A_P_Start_Alloc:  pStart_Alloc='||pStart_Alloc);
END A_P_Start_Alloc;
/
