CREATE FUNCTION       A_F_Relprotabsence_Person_Mon(AORGANISATION_TYPE IN NUMBER)
   RETURN BOOLEAN IS
/***********************************************************************************************
 Функция                : A_F_Relprotabsence_Person_Mon
 Наименование       : Функция проверки выехал ли человек из ДИ, ИТУ
                                  на срок более 1 месяца
								  AORGANISATION_TYPE -  (9- дом-интернат, 14-ИТУ)
 Автор                     : Вахромин О.Ю.                       Комментарии: ОЛВ
 Состояние на дату  :                                                  18.07.2012
 Код возврата          : логический True - выехал , False - не выехал
***********************************************************************************************/
 vsDRID         NUMBER;
 vsMONTHS   NUMBER;
BEGIN
   vsMONTHS:=0;
   vsDRID:=A_F_Relprotgetridaddress(1,3);
  BEGIN
      IF vsDRID<>-1 THEN
         SELECT MONTHS_BETWEEN(p.PERIOD_END,p.PERIOD_START) INTO vsMONTHS
		    FROM ABSENCE_PERSON p
		 WHERE p.STAGE IS NULL
			   AND p.ADDRESS_RID=
                      (SELECT a.RID FROM ADDRESS a
					   WHERE a.RID=vsDRID
					        AND Xlpl.WorkDate BETWEEN NVL(a.RECORD_START,Xlpl.WORKDATE)
							                                       AND NVL(a.RECORD_END,Xlpl.WORKDATE)
				            AND a.CODE_ESTABLISHMENT IN
                                  (SELECT d.CODE FROM ORGANIZATIONS d
						           WHERE (AORGANISATION_TYPE=
                                                  (SELECT MIN(t.code) FROM ORG_TYPES t CONNECT BY PRIOR t.parent_code=t.code
                                                   START WITH t.code=d.org_type)
                                                 )
                                    )
                          )
			   AND Xlpl.Workdate BETWEEN NVL(p.PERIOD_START,Xlpl.WORKDATE)
			                                         AND NVL(p.PERIOD_END,Xlpl.WORKDATE);
      ELSE
         vsDRID:=A_F_Relprotgetridaddress(0,3);
         SELECT MONTHS_BETWEEN(p.PERIOD_END,p.PERIOD_START) INTO vsMONTHS FROM
            W$ABSENCE_PERSON p WHERE p.ENTERED_BY=Xlpl.USER_ID AND p.STAGE IN (1,4) AND
            p.ADDRESS_RID=
            (SELECT a.RID FROM W$ADDRESS a WHERE a.RID=vsDRID AND
               a.ENTERED_BY=Xlpl.USER_ID AND
               Xlpl.WorkDate BETWEEN NVL(a.RECORD_START,Xlpl.WORKDATE) AND
               NVL(a.RECORD_END,Xlpl.WORKDATE) AND a.CODE_ESTABLISHMENT IN
               (SELECT d.CODE FROM ORGANIZATIONS d WHERE (AORGANISATION_TYPE=
                  (SELECT MIN(t.code) FROM ORG_TYPES t CONNECT BY PRIOR t.parent_code=t.code
                     START WITH t.code=d.org_type)
                  )
               )
            ) AND Xlpl.WorkDate BETWEEN NVL(p.PERIOD_START,Xlpl.WORKDATE) AND
            NVL(p.PERIOD_END,Xlpl.WORKDATE);
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         RETURN FALSE;
   END;
   IF vsMONTHS>1 THEN
      RETURN TRUE;
   ELSE
      RETURN FALSE;
   END IF;
END A_F_Relprotabsence_Person_Mon;
/
