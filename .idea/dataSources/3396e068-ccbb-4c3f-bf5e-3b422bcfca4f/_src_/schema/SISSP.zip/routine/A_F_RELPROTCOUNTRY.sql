CREATE FUNCTION       A_F_RelProtCountry(pADDRESS_TYPE in NUMBER) RETURN NUMBER IS
/**********************************************************************************************
 Функция            : A_F_RelProtCountry
 Наименование       : Функция определения кода страны проживания   Country из W$ADDRESS
 Автор              : ОЛВ                                       согл. Вахромин О.Ю.
 Состояние на дату  : 24.09.2010  21.03.2012
 Код возврата       : код страны проживания  1 - РБ, 2 - РФ
***********************************************************************************************/
 vsCountry     NUMBER;
BEGIN
  vsCountry:=0;
 IF (Xlpl.INDIV <>2) then -- не массовый расчет -- 21.03.2012
    -- Выбрать адрес в РБД RID из W$ADDRESS
    vsCountry:=A_F_RelProtGetCountry(0,pADDRESS_TYPE);  -- 3
 else
    -- Выбрать адрес в ОБД Country из ADDRESS
    vsCountry:=A_F_RelProtGetCountry(1,pADDRESS_TYPE);  --3
 end if;
 if vsCountry=-1 then
    vsCountry:=0;   -- если нет записи - страна м.б. любая
 end if;
 return vsCOUNTRY;
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtCountry  1 vsCountry='||vsCountry);
/* *
  vsCountry:=0;
 -- Выбрать адрес в ОБД Country из ADDRESS
 vsCountry:=A_F_RelProtGetCountry(1,pADDRESS_TYPE);     --3
 if vsCountry=-1 then
    -- Выбрать адрес в РБД RID из W$ADDRESS
    vsCountry:=A_F_RelProtGetCountry(0,pADDRESS_TYPE);  -- 3
    if vsCountry=-1 then
      vsCountry:=0;   -- если нет записи - страна м.б. любая
    end if;
 end if;
 return vsCountry;
/* */
END A_F_RelProtCountry;
/
