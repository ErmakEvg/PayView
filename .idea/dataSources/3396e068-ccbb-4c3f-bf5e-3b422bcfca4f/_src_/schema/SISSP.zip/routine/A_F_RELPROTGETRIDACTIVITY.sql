CREATE FUNCTION       A_F_RelProtGetRIDActivity(Base_ID in NUMBER)
   RETURN DBMS_SQL.Number_Table IS
/******************************************************************************
 NAME              : A_F_RelProtGetRIDActivity
 Назначение        : Возращает из (W$)ACTIVITY  согласно W$RELATION_PROTOCOL
 Автор             :         Комментарии и корректировка: ОЛВ
 Состояние на дату :                                               09.06.2014
 Код возврата      : RID из (W$)ACTIVITY
*******************************************************************************/
vArray DBMS_SQL.Number_Table;
vsRELATION_TABLE NUMBER;
BEGIN
   vArray.delete;
 if Base_ID=0 then
      vsRELATION_TABLE:=S_CodeTableSISSP ('W$ACTIVITY');
   for c1 in (select DATA_RID from W$RELATION_PROTOCOL b,W$ACTIVITY a
               where CID=XLPL.Cid
                 and (Aid=XLPL.Aid or XLPL.Aid=0)
                 and ((GROUP_NO=XLPL.GROUP_NO) or (XLPL.Aid<>0 and XLPL.GROUP_NO=0))
                 and ALLOC_CODE=XLPL.ALLOC_CODE
                 and RELATION_TABLE=vsRELATION_TABLE
                 and RELATION_DATE=XLPL.WorkDate
                 and b.ENTERED_BY=XLPL.USER_ID
                 and a.ENTERED_BY=XLPL.User_ID -- 09.06.2014 ОЛВ
                 and DATA_RID=a.RID
                 and a.PID=XLPL.GetPID)
   loop
         vArray(vArray.count+1):=c1.data_rid;
   end loop;
 else
      vsRELATION_TABLE:=S_CodeTableSISSP ('ACTIVITY');
   for c1 in (select DATA_RID from W$RELATION_PROTOCOL b,ACTIVITY a
               where CID=XLPL.Cid
                 and (Aid=XLPL.Aid or XLPL.Aid=0)
                 and ((GROUP_NO=XLPL.GROUP_NO) or (XLPL.Aid<>0 and XLPL.GROUP_NO=0))
                 and ALLOC_CODE=XLPL.ALLOC_CODE
                 and RELATION_TABLE=vsRELATION_TABLE
                 and RELATION_DATE=XLPL.WorkDate
                 and b.ENTERED_BY=XLPL.USER_ID
                 and DATA_RID=a.RID
                 and a.PID=XLPL.GetPID)
    loop
         vArray(vArray.count+1):=c1.data_rid;
    end loop;
 end if;
   return vArray;
END A_F_RelProtGetRIDActivity;
/
