CREATE FUNCTION       B_F_Arraydateest18 RETURN DBMS_SQL.NUMBER_TABLE AS
/*------------------------------------------------------------------------------------------------------------------------------------------
 Функция                : B_F_Arraydateest18
 Наименование       : Переключатель по датам для пособий на детей до 3 лет
 Наименование       : возвращает массив с датой наступления 18 лет для Estimation
 Автор                    : ОЛВ
 Состояние на дату : 22.05.2013
--------------------------------------------------------------------------------------------------------------------------------------------*/
  result_array DBMS_SQL.NUMBER_TABLE;
BEGIN
  IF Xlpl.WorkDate < TO_DATE('01-01-2013','DD-MM-YYYY') THEN -- 22.05.2013 ОЛВ
            result_array.DELETE;
            RETURN result_array;
  ELSE
         RETURN B_F_Arraydateest18_20130101;
  END IF;
END B_F_Arraydateest18;
/
