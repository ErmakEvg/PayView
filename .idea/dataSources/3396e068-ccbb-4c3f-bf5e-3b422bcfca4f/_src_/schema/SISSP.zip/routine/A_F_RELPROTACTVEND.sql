CREATE FUNCTION       A_F_RelProtActvEnd(aActivity in NUMBER,
                                                                                    aLabor in VARCHAR2,
                                                                                    aDismiss_Reason in VARCHAR2)  RETURN DATE IS
/***************************************************************************************
 Функция                   : A_F_RelProtActvEnd
 Наименование          : Функция возвращает дату окончания ACTIVITY по W$RELATION_PROTOCOL
 Автор                      : Ворошилин В.Я.      (РМП)        Комментарии и корректировка: ОЛВ
 Состояние на дату  :                                                                                                   09.04.2010
 Код возврата           : дата окончания ACTIVITY
 Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL)
--------------------------------------------------------------------------------
Входные праметры:
         Activity                - код верхнего уровня  (Например 1 - работатет)
         aLabor                 - код нижнего уровня ('' - игнорируются)
         aDismiss_Reason - список кодов увольнений ('' - игнорируется)
****************************************************************************************/
 xLabor          DBMS_SQL.Number_Table;
 xRID             DBMS_SQL.Number_Table;
 xResume       DATE;
 curr_RID        NUMBER;
 xUser            NUMBER;
 i                    NUMBER;
 k                   NUMBER;
 xOut              BOOLEAN;
 xManyRecord BOOLEAN;

BEGIN

 xResume := NULL;
 xUser := XLPL.USER_ID;
 xOut := False;
 xManyRecord := False;
 xLabor.Delete;

 if aLabor is NOT NULL then
     xLabor := S_ParseFloatArray(aLabor);
    if xLabor.Count > 1 then
       raise_application_error(-20205,
	                     'A_F_RelProtActvEnd: параметры заданы неверно - ' ||
                         'число элементов в aLabor больше 1');
    end if;
 end if;

 --                 1 - ОБД
 -----------------------------------------------------
   xRID.Delete;
   xRID := A_F_RelProtGetRIDActivity(1);
   k := xRID.Count;
 FOR i IN 1..k LOOP
      curr_RID := xRID(i);
    begin
       select PERIOD_END into xResume
	     from ACTIVITY
        where RID = curr_RID
	       and ACTIVITY = aActivity
	       and ( (LABOR = TO_NUMBER(aLabor)) or (aLabor is NULL) )
	       and (      (DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason))
	                or  (  ( aDismiss_Reason is NULL) and (DISMISSAL_REASON is NULL) )     );

	   if xOut = True then
	      xManyRecord := True; -- ( > чем одному RIDу найдена запись с PERIOD_START)
	   end if;

           xOut := True;
    exception
           when NO_DATA_FOUND then
               NULL;
    end;
 END LOOP;

 -- Сообщение об ошибке
 if xManyRecord = True then
      raise_application_error(-20206,
	   'A_F_RelProtActvEnd: выбрано >0 одной строки из ACTIVITY' || CHR(10) ||
            '(aActivity = ' || TO_CHAR(aActivity) || ', aLabor = ' || aLabor ||
		    ', aDismiss_Reason = ' || aDismiss_Reason || ')');
 end if;

 --                 1 - РБД
 -----------------------------------------------------
 if xOut = False then
     xOut := False;
     xManyRecord := False;
     xRID.Delete;
     xRID := A_F_RelProtGetRIDActivity(0);  -- по РБД
     k := xRID.Count;
   FOR i IN 1..k LOOP
        curr_RID := xRID(i);
      begin
         select PERIOD_END into xResume
	       from W$ACTIVITY
         where RID = curr_RID
	        and ACTIVITY = aActivity
	        and ENTERED_BY = XLPL.USER_ID
	        and ((LABOR = TO_NUMBER(aLabor)) or (aLabor is NULL))
	        and (    (DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason))
	                or ( (aDismiss_Reason is NULL) and (DISMISSAL_REASON is NULL) )   );

		 if xOut = True then
	         xManyRecord := True; -- ( > чем одному RIDу найдена запись с PERIOD_START)
	     end if;
           xOut := True;

      exception
          when NO_DATA_FOUND then
        NULL;
      end;
  END LOOP;

  -- Сообщение об ошибке
  if xManyRecord = True then
      raise_application_error(-20207,
     'A_F_RelProtActvEnd: выбрано > одной строки из W$ACTIVITY' || CHR(10) ||
            '(aActivity = ' || TO_CHAR(aActivity) || ', aLabor = ' || aLabor ||
		    ', aDismiss_Reason = ' || aDismiss_Reason || ')');
  end if;

 end if;

RETURN xResume;

/* *
--==============================================================================
-- Назначение: возвращает дату окончания ACTIVITY по W$RELATION_PROTOCOL
--         Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL)
--------------------------------------------------------------------------------
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Входные праметры:
---------------------
-- aActivity - код верхнего уровня  (Например 1 - работатет)
-- aLabor - код нижнего уровня ('' - игнорируются)
-- aDismiss_Reason - список кодов увольнений ('' - игнорируется)
--==============================================================================

xResume DATE;
xLabor DBMS_SQL.Number_Table;
xRID DBMS_SQL.Number_Table;
i NUMBER;
k NUMBER;
curr_RID NUMBER;
xOut BOOLEAN;
xManyRecord BOOLEAN;
xUser NUMBER;

BEGIN
xResume := NULL;
xUser := XLPL.USER_ID;
xOut := False;
xManyRecord := False;
xLabor.Delete;
if aLabor is NOT NULL then
  xLabor := S_ParseFloatArray(aLabor);
  if xLabor.Count > 1 then
    raise_application_error(-20205,
	                     'A_F_RelProtActvEnd: параметры заданы неверно - ' ||
                         'число элементов в aLabor больше 1');
  end if;
end if;
xRID.Delete;
xRID := A_F_RelProtGetRIDActivity(1);  --     1 - ОБД
k := xRID.Count;
FOR i IN 1..k LOOP
  curr_RID := xRID(i);
  begin
    select PERIOD_END into xResume
	from ACTIVITY
    where RID = curr_RID
	and ACTIVITY.ACTIVITY = aActivity
	and ((ACTIVITY.LABOR = TO_NUMBER(aLabor)) or (aLabor is NULL))
	and ((DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason))
	             or ((aDismiss_Reason is NULL) and (DISMISSAL_REASON is NULL)));
	if xOut = True then
	  xManyRecord := True; -- ( > чем одному RIDу найдена запись с PERIOD_START)
	end if;
    xOut := True;
  exception
    when NO_DATA_FOUND then
      NULL;
  end;
END LOOP;
if xManyRecord = True then
      raise_application_error(-20206,
	   'A_F_RelProtActvEnd: выбрано > одной строки из ACTIVITY' || CHR(10) ||
            '(aActivity = ' || TO_CHAR(aActivity) || ', aLabor = ' || aLabor ||
		    ', aDismiss_Reason = ' || aDismiss_Reason || ')');
end if;
if xOut = False then
  xOut := False;
  xManyRecord := False;
  xRID.Delete;
  xRID := A_F_RelProtGetRIDActivity(0);  -- по РБД
  k := xRID.Count;
  FOR i IN 1..k LOOP
    curr_RID := xRID(i);
    begin
      select PERIOD_END into xResume
	  from W$ACTIVITY
      where RID = curr_RID
	  and W$ACTIVITY.ACTIVITY = aActivity
	  and ENTERED_BY = XLPL.USER_ID
	  and ((W$ACTIVITY.LABOR = TO_NUMBER(aLabor)) or (aLabor is NULL))
	  and ((DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason))
	             or ((aDismiss_Reason is NULL) and (DISMISSAL_REASON is NULL)));
	  if xOut = True then
	    xManyRecord := True; -- ( > чем одному RIDу найдена запись с PERIOD_START)
	  end if;
      xOut := True;
    exception
      when NO_DATA_FOUND then
        NULL;
    end;
  END LOOP;
  if xManyRecord = True then
      raise_application_error(-20207,
     'A_F_RelProtActvEnd: выбрано > одной строки из W$ACTIVITY' || CHR(10) ||
            '(aActivity = ' || TO_CHAR(aActivity) || ', aLabor = ' || aLabor ||
		    ', aDismiss_Reason = ' || aDismiss_Reason || ')');
  end if;
end if;
RETURN xResume;
/* */
END A_F_RelProtActvEnd;
/
