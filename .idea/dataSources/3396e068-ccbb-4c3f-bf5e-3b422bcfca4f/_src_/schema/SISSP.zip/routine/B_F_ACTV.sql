CREATE FUNCTION       B_F_Actv (bufACTIVITY IN NUMBER, bufDate IN DATE) RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_Actv
// Наименование: Функция определения рабочей активности лица
// Автор: Гуз Е.
// Состояние на дату 28.01.1999
// Возвращает: True - если лицо активно, False - если лицо не активно
//***************************************************************************************/

  CN_ACTIVITY NUMBER;
BEGIN
--RAISE_APPLICATION_ERROR(-20801,'B_F_Actv 0     CN_ACTIVITY =' ||CN_ACTIVITY );
  Select COUNT(*) INTO CN_ACTIVITY From W$ACTIVITY
  Where PID = XLPL.GETPID
    and ACTIVITY = bufACTIVITY
	and ENTERED_BY = XLPL.User_ID
	and STAGE NOT IN(2,3)
	and (NVL(PERIOD_START, bufDate) <= bufDate
	and NVL(PERIOD_END, bufDate) >= bufDate);
  RETURN CN_ACTIVITY != 0;
END B_F_Actv;
/
