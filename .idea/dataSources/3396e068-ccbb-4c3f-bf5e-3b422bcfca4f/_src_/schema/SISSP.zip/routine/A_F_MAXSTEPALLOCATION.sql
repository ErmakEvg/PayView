CREATE FUNCTION       A_F_MaxStepAllocation RETURN Date IS
/*Возвращает дату максимального шага назначения
Вахромин О.Ю.*/
Step_Start_M date;
BEGIN
   begin
      select max(step_start) into Step_Start_M from W$allocation where
         cid=XLPL.CID and aid=XLPL.AID and stage=1 and alloc_status in (1,2,3,4) and
         parent_rid is null and comp_part is null;
   exception
      when no_data_found then
         null;
   end;
   return Step_Start_M;
END A_F_MaxStepAllocation;
/
