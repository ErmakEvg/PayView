CREATE FUNCTION       B_F_DEFACT_751 (pActivity in Number, pLabor in VarChar2)
RETURN BOOLEAN AS

/******************************************************************************
 Функция           : B_F_DEFACT_751
 Назначение        : Функция определения активности (работа, учеба и т.д.)
                     лица в прошлом по коду pActivity (1,2,3)
 Основание         :
 Автор             : Ярошик А.К.
 Состояние на дату : 13.06.2012,25.06.2013
 Код возврата      : True - если лицо активно, False - если лицо не активно

 Изменения:

    Версия        Дата        Автор           Описание
    ---------  ----------  ---------------  ------------------------------------
    1.0        13.06.2012   Ярошик А.К.     Создание функции.

    Примечание:

      АРМ:                   ГИССЗ
      Название программы:    Case.pas ( пособие ГАСП )

********************************************************************************/

  vPid       Number;
  vUid       Number;
  vCount_Act Number;
  WorkDate   Date;
  vLabor     DBMS_SQL.Number_Table;
BEGIN
/*  Select COUNT(*) INTO COUNT_ACTIVITY From W$ACTIVITY
  Where PID = XLPL.GETPID
    and ACTIVITY IN (1, 2)
    and ENTERED_BY = XLPL.User_ID
    and STAGE NOT IN (2,3)
    and PERIOD_END IS NOT NULL
    and PERIOD_END < XLPL.WorkDate;

--        WorkDate Between NVL(Period_Start,WorkDate) and
--        NVL(Period_End,WorkDate))

*/

  vPid    := XLPL.GETPID;
  vUid    := XLPL.User_ID;
  WorkDate:= XLPL.WorkDate;
  vLabor  := S_ParseFloatArray(pLabor);

/* Определение активности лица в ОБД */

  IF (vLabor.Count= 0) THEN -- нет кодов нижнего уровня
    FOR a1 IN (Select Count(*) vCount_Act FROM ACTIVITY
               Where Pid = vPid and
                     Activity = pActivity and
                     Stage IS Null and
                     Period_End IS NOT NULL and
                     Period_End < WorkDate and
                     Entered_By = vUid)
    LOOP
      IF a1.vCount_Act > 0 THEN
        RETURN TRUE;
      END IF;
    END LOOP;

  ELSE
    FOR I IN 1..vLabor.Count
    LOOP
      Select Count(*) INTO vCount_Act FROM ACTIVITY
      Where Pid = vPid and
            Activity = pActivity and
            Labor = vLabor(I) and
            Stage IS Null and
            Period_End IS NOT NULL and
            Period_End < WorkDate and
			TRUNC(WorkDate,'YYYY')=TRUNC(Period_End,'YYYY') and --25.06.2013
            Entered_By = vUid;

      IF vCount_Act > 0 THEN
        RETURN TRUE;
      END IF;
    END LOOP;
  END IF;

/* Определение активности лица в РБД */

  IF (vLabor.Count= 0) THEN -- нет кодов нижнего уровня
    FOR a1 IN (Select Count(*) vCount_Act FROM W$ACTIVITY
               Where Pid = vPid and
                     Activity = pActivity and
                     Stage NOT IN (2,3) and
                     Period_End IS NOT NULL and
                     Period_End < WorkDate and
                     Entered_By = vUid)
    LOOP
      IF a1.vCount_Act > 0 THEN
        RETURN TRUE;
      END IF;
    END LOOP;

  ELSE
    FOR I IN 1..vLabor.Count
    LOOP
      Select Count(*) INTO vCount_Act FROM W$ACTIVITY
      Where Pid = vPid and
            Activity = pActivity and
            Labor = vLabor(I) and
            Stage NOT IN (2,3) and
            Period_End IS NOT NULL and
            Period_End < WorkDate and
			TRUNC(WorkDate,'YYYY')=TRUNC(Period_End,'YYYY') and --25.06.2013
            Entered_By = vUid;

      IF vCount_Act > 0 THEN
        RETURN TRUE;
      END IF;
    END LOOP;
  END IF;

  RETURN FALSE;

END B_F_DEFACT_751;
/
