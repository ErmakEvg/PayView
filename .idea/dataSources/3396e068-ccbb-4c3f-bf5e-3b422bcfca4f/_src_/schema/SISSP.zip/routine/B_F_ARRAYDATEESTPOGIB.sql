CREATE FUNCTION       B_F_ARRAYDATEESTPOGIB RETURN DBMS_SQL.NUMBER_TABLE IS
/*==============================================================================
+ Функция: B_F_ARRAYDATEESTPOGIB
+ Наименование: Формирование дат Estimation для ребенка до 3 лет
+ Автор: Ворошилин В.
+ Состояние на дату 20/10/2002
==============================================================================*/

result_step_start DBMS_SQL.NUMBER_TABLE;
result_function DBMS_SQL.NUMBER_TABLE;
j NUMBER;

BEGIN

result_step_start.delete;

result_function.delete;
result_function := B_F_ArrayDateEstAge3;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstMETRICPog;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstAddress;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

result_function.delete;
result_function := B_F_ArrayDateEstBirthDeath;
if result_function.count > 0 then
     for j in 1 .. result_function.count loop
     	 result_step_start(result_step_start.count + 1) := result_function(j);
     end loop;
end if;

return result_step_start;

END B_F_ARRAYDATEESTPOGIB;
/
