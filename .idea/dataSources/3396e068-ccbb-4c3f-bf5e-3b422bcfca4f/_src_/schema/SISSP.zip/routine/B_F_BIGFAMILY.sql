CREATE FUNCTION       B_F_BIGFAMILY RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_BIGFAMILY
// Наименование: Функция проверки, является ли семья многодетной (3 и более детей)
// Автор: Ворошилин В..
// Состояние на дату 06.12.1999
// Код возврата: True - семья многодетная, False - семья не многодетная
//***************************************************************************************/

  C_Role NUMBER;
BEGIN
  Select COUNT(*) INTO C_Role From W$CASE_PERSON
  Where CID = XLPL.CID
    and ROLE in (56, 68)
	and ENTERED_BY = XLPL.User_ID
	and STAGE NOT IN(2,3);
  if C_Role = 0 then
    Select COUNT(*) INTO C_Role From CASE_PERSON
	Where CID = XLPL.CID
	  and ROLE in (56, 68)
	  and STAGE NOT IN(2,3);
  end if;
  if C_Role >= 3 then
    return True;
  else
    return False;
  end if;
END B_F_BIGFAMILY;
/
