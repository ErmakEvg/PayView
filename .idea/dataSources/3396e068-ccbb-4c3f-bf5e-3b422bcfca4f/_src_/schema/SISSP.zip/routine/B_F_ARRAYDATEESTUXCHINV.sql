CREATE FUNCTION       B_F_Arraydateestuxchinv RETURN DBMS_SQL.NUMBER_TABLE AS
/*******************************************************************************
 Функция           : B_F_Arraydateestuxchinv
 Наименование      : Построение массива с датой достижения ухаживающим пенсионного
                     возраста при уходе за ребенком-инвалидом для Estimation
 Автор             : Ворошилин В.                Корректировка ОЛВ
 Состояние на дату : 17.11.2000                        12.12.2016
 Код возврата      : Массив, состоящий из даты, кода причины, кода изменения состояния
*******************************************************************************/
 Result   DBMS_SQL.NUMBER_TABLE;
 DtBirth  DATE;
 rabDate  DATE;
 RecipAge NUMBER;
 Pr       BOOLEAN;
--WDt DATE;

BEGIN
Result.DELETE;
rabDate := NULL;
RecipAge := 0;
Pr := FALSE;

 IF Xlpl.CheckRole(56) THEN
   Xlpl.RoleDecl('Child','56');
   Xlpl.REPLACEROLE('Child');
   Pr := A_F_Relprotdisability(1, '14') AND A_F_Relprotrelation('3, 4');
   Xlpl.RestoreRole;
 ELSE
    RETURN Result;
 END IF;
 IF NOT Xlpl.CheckRole(94) THEN
   -- Общеустановленный пенсионный возраст -- 12.12.2016 ОЛВ
   DtBirth:=S_Birthdate(Xlpl.Base_ID,Xlpl.GetPid,Xlpl.WorkDate);
     IF (A_F_Relprotrelation('1') OR A_F_Relprotrelation('2')) AND Pr THEN -- отец или мать -- 12.12.2016 ОЛВ
      RecipAge:=P_AgePensionStep(142,141,DtBirth);
    ELSE
      RecipAge:=P_AgePensionStep(106,108,DtBirth);
    END IF;
   rabDate :=ADD_MONTHS(DtBirth,TRUNC(RecipAge*12));

   /*-- 12.12.2016 ОЛВ--*
    IF A_F_Relprotmale AND A_F_Relprotrelation('1') AND Pr THEN RecipAge := S_Const(142, Xlpl.WorkDate); END IF;
    IF A_F_Relprotfemale AND A_F_Relprotrelation('2') AND Pr THEN RecipAge := S_Const(141, Xlpl.WorkDate); END IF;
    IF A_F_Relprotmale AND NOT A_F_Relprotrelation('1') THEN RecipAge := S_Const(106, Xlpl.WorkDate); END IF;
    IF A_F_Relprotfemale AND NOT A_F_Relprotrelation('2') THEN RecipAge := S_Const(108, Xlpl.WorkDate); END IF;
    DtBirth := A_F_Relprotbirthday;
    rabDate := S_Addyears(DtBirth, RecipAge);
   WDt := LAST_DAY(S_Currdate);/**/
    IF (rabDate IS NOT NULL AND rabDate > LAST_DAY(S_Currdate)) THEN
      Result(1) := S_Julian(LAST_DAY(rabDate));
      Result(2) := 32;
      Result(3) := 2;
    END IF;
 END IF;
    RETURN Result;
--if XLPL.GetPid= 5080013195 then RAISE_APPLICATION_ERROR(-20801,'B_F_ARRAYDATEESTUXCHINV   XLPL.GetPid=' ||XLPL.GetPid); end if;
  --if A_F_GETROLE=55 or A_F_GETROLE=57 or A_F_GETROLE=52 or A_F_GETROLE=69 or A_F_GETROLE=96 then
END B_F_Arraydateestuxchinv;
/
