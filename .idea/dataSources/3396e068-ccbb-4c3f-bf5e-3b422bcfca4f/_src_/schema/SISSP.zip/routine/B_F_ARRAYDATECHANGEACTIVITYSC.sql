CREATE FUNCTION       B_F_ArrayDateChangeACTIVITYSc RETURN DBMS_SQL.NUMBER_TABLE IS

/*==============================================================================
+ Функция: F_ArrayDateChangeACTIVITYSchool
+ Наименование: возвращает массив дат изменения "работ лица"
+ Автор: Трухтанов
+ Состояние на дату 03.05.1999
==============================================================================*/

result_array DBMS_SQL.NUMBER_TABLE;
RAge number;
DtBeg14 date;
DtBeg16 date;
DtBirth date;
WDt1 date;
WDt date;
Dt date;
StopDtEnd date;
StopDtSept date;
StopDtJuly date;
CN_ACTIVITY number;

BEGIN
  result_array.delete;

  if (not XLPL.CheckRole(56)) then return result_array;				   -- Если ребенок не указан, то возвратить "возраст не удовлетворяет"
     else XLPL.REPLACEROLE('Child');  	   								   -- иначе - ребенок в назначении
  end if;

  WDt := Last_Day(S_CurrDate);

  DtBirth := S_BirthDate(0,XLPL.GETPID, xlpl.WorkDate);
  RAge := S_Const(406,xlpl.WorkDate);    						-- 14 лет
  DtBeg14 := S_AddYears(DtBirth,RAge);
  RAge := S_Const(403, xlpl.WorkDate);    						-- 16 лет
  DtBeg16 := S_AddYears(DtBirth,RAge);
  WDt1 := A_F_DataTalk();

  if (S_YearOfDate(WDt1) < S_YearOfDate(WDt)) then
    Dt := S_Jtod(S_Const(479, xlpl.WorkDate));
    StopDtEnd := S_EncodeDate(S_YearOfDate(WDt1), S_MonthOfDate(Dt), S_DayOfDate(Dt));
    Dt := S_Jtod(S_Const(480, xlpl.WorkDate));
    StopDtSept := S_EncodeDate(S_YearOfDate(WDt1), S_MonthOfDate(Dt), S_DayOfDate(Dt));
    Dt := S_Jtod(S_Const(492, xlpl.WorkDate));
    StopDtJuly := S_EncodeDate(S_YearOfDate(WDt1), S_MonthOfDate(Dt), S_DayOfDate(Dt));

    if (DtBeg14 > StopDtSept) then return result_array; -- WDt
	end if;

--//if (DtBeg16 <= StopDtJuly)
--//{
--Child {CN_ACTIVITY = SQL(
    Select COUNT(*) into CN_ACTIVITY
                  From W$ACTIVITY
                  Where PID = XLPL.GETPID and
                        ACTIVITY = 2 and
				        LABOR = 237 and
                        ENTERED_BY = XLPL.USER_ID and
                        STAGE NOT IN(2,3) and
                        (PERIOD_START <= XLPL.WorkDate or PERIOD_START is null) and
                        (PERIOD_END >= XLPL.WorkDate or PERIOD_END is null);

    if (CN_ACTIVITY > 0) OR (DtBeg16 <= StopDtJuly)
      then
        result_array(1) := S_Julian(StopDtJuly + 1);
		XLPL.RestoreRole;
	    return result_array;
      else
        result_array(1) := S_Julian(StopDtSept + 1);
		XLPL.RestoreRole;
	    return result_array;
    end if;
--//}
    XLPL.RestoreRole;
    return result_array;
  else
    Dt := S_Jtod(S_Const(479, XLPL.WorkDate));
    StopDtEnd := S_EncodeDate(S_YearOfDate(WDt), S_MonthOfDate(Dt), S_DayOfDate(Dt));
    Dt := S_Jtod(S_Const(480, XLPL.WorkDate));
    StopDtSept := S_EncodeDate(S_YearOfDate(WDt), S_MonthOfDate(Dt), S_DayOfDate(Dt));
    Dt := S_Jtod(S_Const(492, XLPL.WorkDate));
    StopDtJuly := S_EncodeDate(S_YearOfDate(WDt), S_MonthOfDate(Dt), S_DayOfDate(Dt));

    if (DtBeg14 > StopDtSept) then
	  XLPL.RestoreRole;
	  return result_array; -- WDt
	end if;

--//if (DtBeg16 <= StopDtJuly)	   				 // WDt
--//{
    Select COUNT(*) into CN_ACTIVITY
                  From W$ACTIVITY
                  Where PID = XLPL.GETPID and
                        ACTIVITY = 2 and
				        LABOR = 237 and
                        ENTERED_BY = XLPL.USER_ID and
                        STAGE NOT IN(2,3) and
                        (PERIOD_START <=  XLPL.WorkDate or PERIOD_START is null) and
                        (PERIOD_END >= XLPL.WorkDate or PERIOD_END is null);

    if ((CN_ACTIVITY > 0) OR (DtBeg16 <= StopDtJuly)) AND (WDt > StopDtJuly) AND (WDt <= StopDtEnd)
	then
      result_array(1) := S_Julian(StopDtJuly + 1);
	  XLPL.RestoreRole;
	  return result_array;
    else
	  if (WDt > StopDtSept) AND (WDt <= StopDtEnd) then
        result_array(1) := S_Julian(StopDtsept + 1);
		XLPL.RestoreRole;
		return result_array;
	  end if;
	end if;
	XLPL.RestoreRole;
    return result_array;
  end if;

END B_F_ArrayDateChangeACTIVITYSc;
/
