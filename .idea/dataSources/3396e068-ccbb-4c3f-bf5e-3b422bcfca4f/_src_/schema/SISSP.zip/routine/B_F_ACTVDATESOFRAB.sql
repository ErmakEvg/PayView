CREATE FUNCTION       B_F_ActvDatesOfRab RETURN DBMS_SQL.Number_Table AS
/**********************************************************************************************
 Функция            : B_F_ActvDatesOfRab
 Наименование       : Функция определяет даты начала работы, дающей право на пособия в ОСЗ
 Автор              : Ворошилин В.         Комментарии и корректировка: ОЛВ
 Состояние на дату  : 11.11.1999                                       29.08.2011
 Код возврата       : массив
***********************************************************************************************/
 A           DBMS_SQL.Number_Table;
 BDay        DATE;
 StartDateBD DATE;
 Dt          DATE;
BEGIN
  A.Delete;
 if not XLPL.CHECKROLE(56) then
	return A;
 end if;

 XLPL.RoleDecl('Child', '56');
 XLPL.REPLACEROLE('Child');
  BDay := S_Birthdate(XLPL.BASE_ID, XLPL.GetPid, XLPL.WorkDate);
 XLPL.RESTOREROLE;

 -- 401 - Ограничение возраста ребенка для пособия по уходу за ребенком в возрасте до 3 лет - в годах
 -- 478 - Дата начала действия пособий на детей старше 3 лет (01.01)  - в числовом виде дата 01.01.1997
 -- день и месяц выбираем из справочника, а год - год расчета XLPL.WorkDate -1
  StartDateBD := S_AddYears(BDay, TRUNC(S_Const(401, XLPL.WorkDate))) + 1;
  Dt := S_DateConst(478, XLPL.WorkDate);
  Dt := S_EncodeDate(S_YearOfDate(XLPL.WorkDate), S_MonthOfDate(Dt), S_DayOfDate(Dt));
  if (StartDateBD >= Dt) and (StartDateBD <= XLPL.WorkDate) then
   	Dt := StartDateBD;
  end if;

  for ACTSTART in (Select PERIOD_START From W$ACTIVITY
                   Where PID = XLPL.GetPid
				     and ENTERED_BY = XLPL.User_ID
					 and ACTIVITY = 1
					-- and LABOR in (200, 201, 202, 203, 204, 205, 206, 207)
                     and LABOR in (200, 201, 202, 203, 204, 205, 206, 207,208,313,314,315) -- 208,315 - OLV 29.08.2011
					 and STAGE NOT IN (2, 3)
					 and PERIOD_START >= Dt
				   ORDER BY PERIOD_START)
  LOOP
    if ACTSTART.PERIOD_START is not NULL then
	  A(A.count+1) := S_Julian(ACTSTART.PERIOD_START);
	end if;
  end LOOP;
  RETURN A;
END B_F_ActvDatesOfRab;
/
