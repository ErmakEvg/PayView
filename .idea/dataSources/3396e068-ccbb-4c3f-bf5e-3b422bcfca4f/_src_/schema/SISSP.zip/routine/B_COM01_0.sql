CREATE FUNCTION       B_COM01_0 RETURN NUMBER AS

/***************************************************************************************
// Функция:  B_COM01_0
// Наименование: Функция расчета пособия одинокой матери (женщине, родившей ребенка вне
//               брака), воспитывающей ребенка в возрасте до 1,5 лет (новая версия)
// Автор: Ворошилин В.
// Состояние на дату 30.11.1999
// Код возврата: число с плавающей точкой с суммой пособия
//***************************************************************************************/

  d NUMBER;
  RelProtMetricBen BOOLEAN;
  RelProtIsPayOnAllocCodeNew BOOLEAN;
BEGIN
  if XLPL.INDIV = 2 then
    XLPL.Payment :=  B_F_GETPAYMENTPROCENTINDIV2;
	XLPL.Amount := S_CONST(15, XLPL.WorkDate) * S_CONST(420, XLPL.WorkDate) / 100;
	return XLPL.Amount;
  else
    XLPL.RoleDecl('Child', '56');
	if XLPL.CHECKROLE(56) then
	  d := 1;
	else
	  d := 0;
	end if;
	XLPL.REPLACEROLE('Child');
	RelProtMetricBen := B_F_RelProtMetricBen('354');
	RelProtIsPayOnAllocCodeNew := B_F_RelProtIsPayOnAllocCodeNew(496);
	if (RelProtIsPayOnAllocCodeNew) or ((d = 1) and (not RelProtMetricBen)) then
	  XLPL.Payment := 0;
	  XLPL.Amount := S_CONST(15, XLPL.WorkDate) * S_CONST(420, XLPL.WorkDate) / 100;
	  XLPL.RESTOREROLE;
	  return XLPL.Amount;
	end if;
    XLPL.Payment := 100;
	XLPL.Amount := S_CONST(15, XLPL.WorkDate) * S_CONST(420, XLPL.WorkDate) / 100;
	XLPL.RESTOREROLE;
	return XLPL.Amount;
  end if;
END B_COM01_0;
/
