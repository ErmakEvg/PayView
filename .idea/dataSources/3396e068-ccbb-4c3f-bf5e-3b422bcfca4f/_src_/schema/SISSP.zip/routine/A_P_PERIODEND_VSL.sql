CREATE FUNCTION       A_P_PERIODEND_VSL RETURN DATE AS

-- Функция определения окончания периода прохождения военной службы  для текущего человека

  vsEnd_vsl DATE;
BEGIN
  vsEnd_vsl := NULL;
  if A_F_RELPROTMETRIC('121 ,122 ,125 ,126') then
    if A_F_RELPROTMETRIC('121') then
      vsEnd_vsl := A_F_RELPROTMETRICEND(121);
    else
      if A_F_RELPROTMETRIC('122') then
        vsEnd_vsl := A_F_RELPROTMETRICEND(122);
      else
        if A_F_RELPROTMETRIC('125') then
          vsEnd_vsl := A_F_RELPROTMETRICEND(125);
        else
          if A_F_RELPROTMETRIC('126') then
            vsEnd_vsl := A_F_RELPROTMETRICEND(126);
          end if;
        end if;
      end if;
    end if;
  end if;
  return vsend_vsl;
end A_P_PERIODend_VSL;
/
