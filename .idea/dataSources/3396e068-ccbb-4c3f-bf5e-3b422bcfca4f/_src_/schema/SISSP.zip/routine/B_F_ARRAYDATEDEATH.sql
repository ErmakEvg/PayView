CREATE FUNCTION       B_F_ARRAYDATEDEATH(puskdate in date, Param6m in number) RETURN DBMS_SQL.NUMBER_TABLE IS
/*******************************************************************************
 Функция           : B_F_ARRAYDATEDEATH
 Наименование      : Функция возвращает массив дат изменения общей информации о лице
 Автор             : рухтанов        Комментарии и корректировка: ОЛВ
 Состояние на дату : 25.08.1999                     14.08.2015
 Код возврата      : возвращает массив дат
*********************************************************************************/
chahge_date_aRecord DBMS_SQL.NUMBER_TABLE;
DateTalk date;
DateTalk1 date;
flg_insert_result boolean;

BEGIN
  DateTalk := A_F_DataTalk();
  DateTalk1 := Last_Day(sysdate);

  for REC in (
    select nvl(BIRTH_DATE, null) as aRecord_start,
	       nvl(DEATH_DATE, null) as aRecord_end
      from W$PERSON
     where PID = XLPL.GETPID
       and RECORD_END is NULL
       and STAGE in (1, 4)
       and ENTERED_BY = XLPL.USER_ID)
  LOOP
    IF (REC.aRecord_start is not null) -- 14.08.2015 OLV--if (REC.aRecord_start != null)
      AND (REC.aRecord_start > PuskDate) AND (REC.aRecord_start <= DateTalk1) then

	  IF  (Param6m = 1) AND (XLPL.AID = 0)  then -- Если прпевышено 6 месяцев со для возникновения права
        chahge_date_aRecord(chahge_date_aRecord.count+1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), s_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
	  ELSE
        chahge_date_aRecord(chahge_date_aRecord.count+1) := s_julian(REC.aRecord_start);
	  END IF;
    END IF; -- 14.08.2015 OLV
    IF (REC.aRecord_end IS NOT NULL) -- 14.08.2015 OLV--(REC.aRecord_end != null)
     AND (REC.aRecord_end > PuskDate) AND (REC.aRecord_End <= DateTalk1) then
	     IF  (Param6m = 1) AND (XLPL.AID = 0)  then 	  				 -- Если прпевышено 6 месяцев со для возникновения права
            chahge_date_aRecord(chahge_date_aRecord.count+1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), s_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
         ELSE
            chahge_date_aRecord(chahge_date_aRecord.count+1) := s_julian(REC.aRecord_end) + 1;
	     END IF;
    END IF;
    -- 14.08.2015 OLV --END IF;
  end loop;

return chahge_date_aRecord;
/**if xlpl.getpid=7060000023 then--xlpl.cid=70602003069 then
--rDate := S_jtod(result_step_start(result_step_start.count));
RAISE_APPLICATION_ERROR(-20004,'B_F_ARRAYDATEDEATH 22222 chahge_date_aRecord.count= '||chahge_date_aRecord.count
||CHR(10)||'PuskDate='||PuskDate
||chr(10)||'DateTalk1='||DateTalk1
||chr(10)||'Param6m='||Param6m
||chr(10)||'REC.aRecord_start='||REC.aRecord_start
||chr(10)||'REC.aRecord_end='||REC.aRecord_end
);
end if; /**/

END B_F_ARRAYDATEDEATH;
/
