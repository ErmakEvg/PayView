CREATE FUNCTION       A_INTERCHANGEALLOC_CODE(pALLOC_CODE in NUMBER) RETURN NUMBER is
/***************************************************************************************
 Функция             :  A_INTERCHANGEALLOC_CODE
 Наименование        :  определяет ALLOC_CODE, который может заменить старый
                        если на него нет права или если нечем заменить то 0
 Автор               :  Боровнева                           Комментарии :  OLV
 Состояние на дату   :  28.05.1999                                        05.03.2011
 Код возврата        :  pALLOC_CODE - ALLOC_CODE который нужно заменить
***************************************************************************************/
 Result                 NUMBER;
 sl_ALLOC_CODE          Number;
 rez                    Number;
 check_result           Boolean;
 old_default_protocol   VarChar2(2000);

begin
  check_result := false;
  old_default_protocol := XLPL.S_GETPROTOCOL;

 for c1 in (select b.CODE sl_ALLOC_CODE
			  from   ( select distinct nvl(GROUP_NUM, 0) as GROUP_NUM
      			         from ALLOCATIONS
	  				    where CODE = pALLOC_CODE) a, ALLOCATIONS b
			 where b.GROUP_NUM = a.GROUP_NUM
			   and b.CODE <> pALLOC_CODE  order by b.CODE )
   LOOP

     XLPL.S_CLEARPROTOCOL;
	 -- определить ALLOC_CODE, который может заменить старый
     XLPL.ALLOC_CODE := c1.sl_ALLOC_CODE;

     -- формируем таблицу связок
     F$RELATION(c1.sl_ALLOC_CODE);

     -- проверяем право
     check_result := false;
     check_result := F$CHECK(c1.sl_ALLOC_CODE);

     if check_result  Then
       return c1.sl_ALLOC_CODE;
     End if;
 end loop;

  XLPL.S_CLEARPROTOCOL;
  XLPL.S_Protocol(old_default_protocol);
  return 0;
                              -- INSERT INTO ASVPD_PROV_NSI(FLD, ERROR) VALUES ('222', 'A_InterchangeALLOC_CODE    нет права');
							 -- commit;

  /*==============================================================================
+ Функция: FI_InterchangeALLOC_CODE
+ Наименование: определяет ALLOC_CODE, который может заменить старый если на
+               него нет права если нечем заменить то 0
+ Автор: Боровнева
+ Состояние на дату 28.05.1999
+ Параметры:pALLOC_CODE - ALLOC_CODE который нужно заменить
==============================================================================*
sl_ALLOC_CODE Number;
check_result Boolean;
old_default_protocol VarChar2(2000);
rez Number;
begin
  check_result := false;
  old_default_protocol := XLPL.S_GETPROTOCOL;

   for c1 in (select b.CODE sl_ALLOC_CODE
				   from (select distinct nvl(GROUP_NUM, 0) as GROUP_NUM
      			from ALLOCATIONS
	  				  where CODE = pALLOC_CODE) a, ALLOCATIONS b
						  where b.GROUP_NUM = a.GROUP_NUM and
						        b.CODE <> pALLOC_CODE  order by b.CODE )  LOOP

   ----- -----
   XLPL.S_CLEARPROTOCOL;
   XLPL.ALLOC_CODE := c1.sl_ALLOC_CODE;
   ----- формируем таблицу связок -----
   --try {
   F$RELATION(c1.sl_ALLOC_CODE);
    --  }
    --  catch(MethodNotFound) {
    --  }
    ----- проверяем право -----
    --try {
    check_result := false;
    check_result := F$CHECK(c1.sl_ALLOC_CODE);
     --}
     --catch(MethodNotFound) {
     --  check_result = false;
     --}

     if check_result  Then
       --@ClearDefaultProtocol();
       return c1.sl_ALLOC_CODE;
     End if;
	end loop;
  ----- -----
  XLPL.S_CLEARPROTOCOL;
  XLPL.S_Protocol(old_default_protocol);
  return 0;

  /* */
  end A_INTERCHANGEALLOC_CODE;
/
