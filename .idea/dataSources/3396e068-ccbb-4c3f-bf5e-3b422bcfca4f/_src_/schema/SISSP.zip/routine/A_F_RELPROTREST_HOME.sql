CREATE FUNCTION       A_F_RelProtRest_Home(AORGANISATION_TYPE in number)
   RETURN BOOLEAN IS
/*******************************************************************************
 NAME              : A_F_RelProtRest_Home
 Наименование      : Функция определяет проживает ли человек в ДИ, ИТУ согласно $RELATION_PROTOCOL
                     AORGANISATION_TYPE - тип организации (9-дом-интернат, 14-ИТУ)
 Автор             : Вахромин О.Ю.    Комментарии и корректировка : ОЛВ
 Состояние на дату :                       10.05.2011   19.05.2014  14.08.2018
 Код возврата      : RID из W$ADDRESS
********************************************************************************/
vsDRID number;
vsCOUNT number;
BEGIN
     vsDRID:=A_F_RelProtGetRIDAddress(1,2); -- 2014-05-19 ОЛВ --(1,3);
   begin
      if vsDRID<>-1 then
         SELECT CODE into vsCOUNT from org_types where code in
            (SELECT min(t.code) FROM ORG_TYPES t CONNECT BY PRIOR t.parent_code=t.code
               START WITH code=
               (select org_type from organizations where code=
                  (select a.code_establishment from address a  where a.rid=vsDRID and
                     a.STAGE Is Null and
                     XLPL.WORKDATE between NVL(a.RECORD_START,XLPL.WORKDATE) and
                     NVL(a.RECORD_END,XLPL.WORKDATE)
                  )
               )
            );
      else
         vsDRID:=A_F_RelProtGetRIDAddress(0,2); -- 2014-05-19 ОЛВ --(0,3);
         SELECT CODE  into vsCOUNT from org_types where code in
            (SELECT min(t.code) FROM ORG_TYPES t CONNECT BY PRIOR t.parent_code=t.code
               START WITH code=
               (select org_type from organizations where code=
                  (select a.code_establishment
                     from W$address a
                    where a.rid=vsDRID
                      and a.STAGE In (1,4)
                      and a.ENTERED_BY=XLPL.USER_ID
                      and XLPL.WORKDATE between NVL(a.RECORD_START,XLPL.WORKDATE)
                                            and NVL(a.RECORD_END,XLPL.WORKDATE)
                      /** -- 14.08.2018 OLV -- выплата с 1 числа следующего за помещением в ИТУ - требуется согласование
                      (( AORGANISATION_TYPE =14 AND XLPL.WorkDate between NVL(LAST_DAY(a.RECORD_START)+1,XLPL.WORKDATE) and NVL(a.RECORD_END,XLPL.WORKDATE))
                          OR
                       ( AORGANISATION_TYPE <>14 AND XLPL.WorkDate between NVL(a.RECORD_START,XLPL.WORKDATE) and NVL(a.RECORD_END,XLPL.WORKDATE)) )/**/
                  )
               )
            );
      end if;
   exception
      when No_Data_Found then
         return FALSE;
   end;
   if vsCOUNT=AORGANISATION_TYPE then
      return TRUE;
   else
      return FALSE;
   end if;
END A_F_RelProtRest_Home;
/
