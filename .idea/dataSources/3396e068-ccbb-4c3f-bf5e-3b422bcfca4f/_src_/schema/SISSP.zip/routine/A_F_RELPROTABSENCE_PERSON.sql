CREATE FUNCTION       A_F_Relprotabsence_Person(AORGANISATION_TYPE IN NUMBER) RETURN BOOLEAN IS
/*******************************************************************************
 Функция            : A_F_RelProtAbsence_Person
 Наименование       : Функция проверки выехал ли человек из ДИ, ИТУ
 Автор              : Вахромин О.Ю.     Комментарии  и корректировка: ОЛВ
 Состояние на дату  :                   18.07.2012   29.08.2018
 Код возврата       : логический True - выехал , False - не выехал
********************************************************************************/
 vsDRID   NUMBER;
 vsCOUNT  NUMBER;
BEGIN
   -- ОБД
   vsDRID:=A_F_RelProtGetRIDAddress(1,2); -- 29.08.2018 ОЛВ --(1,3);
 BEGIN
      IF vsDRID<>-1 THEN
         SELECT COUNT(*) INTO vsCOUNT
           FROM ABSENCE_PERSON p
          WHERE p.ADDRESS_RID=
               (SELECT a.RID FROM ADDRESS a
                 WHERE a.RID=vsDRID
                   AND Xlpl.WorkDate BETWEEN NVL(a.RECORD_START,Xlpl.WORKDATE)
                                      AND NVL(a.RECORD_END,Xlpl.WORKDATE)
                   AND a.CODE_ESTABLISHMENT IN
                    (SELECT d.CODE FROM ORGANIZATIONS d WHERE (AORGANISATION_TYPE=
                       (SELECT MIN(t.code) FROM ORG_TYPES t CONNECT BY PRIOR t.parent_code=t.code
                          START WITH t.code=d.org_type)  )
                    )  )
            AND p.STAGE IS NULL
            AND Xlpl.WorkDate BETWEEN NVL(p.PERIOD_START,Xlpl.WORKDATE)
                                  AND NVL(p.PERIOD_END,Xlpl.WORKDATE);
      ELSE
         -- РБД
           vsDRID:=A_F_RelProtGetRIDAddress(0,2); -- 29.08.2018 ОЛВ --(0,3);
         SELECT COUNT(*) INTO vsCOUNT
           FROM W$ABSENCE_PERSON p
          WHERE p.ADDRESS_RID=
                            (SELECT a.RID FROM W$ADDRESS a
                              WHERE a.RID=vsDRID
                                AND a.ENTERED_BY=Xlpl.USER_ID
                                AND Xlpl.WorkDate BETWEEN NVL(a.RECORD_START,Xlpl.WORKDATE)
                                                   AND NVL(a.RECORD_END,Xlpl.WORKDATE)
                                AND a.CODE_ESTABLISHMENT IN (SELECT d.CODE FROM ORGANIZATIONS d
                                                              WHERE (AORGANISATION_TYPE=
                                                                                      (SELECT MIN(t.code)
                                                                                       FROM ORG_TYPES t
                                                                           CONNECT BY PRIOR t.parent_code=t.code
                                                                                   START WITH t.code=d.org_type)  )  ) )
            AND p.STAGE IN (1,4)
            AND p.ENTERED_BY=Xlpl.USER_ID
            AND Xlpl.WorkDate BETWEEN NVL(p.PERIOD_START,Xlpl.WORKDATE) AND NVL(p.PERIOD_END,Xlpl.WORKDATE);
      END IF;
 EXCEPTION
      WHEN NO_DATA_FOUND THEN
         RETURN FALSE;
 END;
   IF vsCOUNT>0 THEN
      RETURN TRUE;
   ELSE
      RETURN FALSE;
   END IF;
END A_F_Relprotabsence_Person;
/
