CREATE FUNCTION       B_F_Actv_LearnSobes RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_Actv_LearnSobes
// Наименование: Функция определения учебы, дающей право на получение пособия в Собесе
// Автор: Ворошилин В.
// Состояние на дату 10.10.2001
// Возвращает: True - если лицо активно, False - если лицо не активно
//***************************************************************************************/

  CN_ACTIVITY NUMBER;
BEGIN
  Select COUNT(*) INTO CN_ACTIVITY From W$ACTIVITY
  Where PID = XLPL.GETPID
    and ACTIVITY = 2
	and LABOR in (226, 227, 229, 230, 232)
	and ENTERED_BY = XLPL.User_ID
	and STAGE NOT IN(2,3)
	and (NVL(PERIOD_START, XLPL.WorkDate) <= XLPL.WorkDate
	and NVL(PERIOD_END, XLPL.WorkDate) >= XLPL.WorkDate);
  RETURN CN_ACTIVITY != 0;
END B_F_Actv_LearnSobes;
/
