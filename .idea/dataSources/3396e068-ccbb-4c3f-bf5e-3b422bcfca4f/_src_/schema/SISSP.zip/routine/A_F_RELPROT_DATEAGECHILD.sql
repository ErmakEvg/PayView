CREATE FUNCTION       A_F_RELPROT_DATEAGECHILD(AROLE_CODE IN NUMBER,N_AGE IN NUMBER)
RETURN DATE IS
/***************************************************************************************
 Функция           : A_F_RELPROT_DATEAGECHILD
 Наименование      : Функция построения прогнозируемых дат для пенсий по СПК
 Автор             : Басинюк Я.В.           Комментарии : ОЛВ
 Состояние на дату : 13.05.1999                            18.01.2010
 Код возврата      : True если хотя бы один PID не равный PID-у по умолчанию
                     с ролью AROLE имеет возраст меньше N_AGE лет
                     Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL)
****************************************************************************************/

xDRIDS       DBMS_SQL.NUMBER_TABLE;
vsBIRTH_DATE DATE;
MaxDate      DATE DEFAULT NULL;
vsDRID       NUMBER;
vsPID        NUMBER;
vsDRID1      NUMBER;
Current_Pid  NUMBER;
BEGIN

  MaxDate := NULL;
  Current_Pid := XLPL.GETPID;

    /* --------------------------------------------------------------------
               RID из CASE_PERSON согласно коду по W$RELATION_PROTOCOL
    /* ---------------------------------------------------------------------*/
  xDRIDS := A_F_RELPROTGETRIDCASEPNOTPID();

 IF xDRIDS.COUNT > 0 THEN
  FOR l IN xDRIDS.first .. xDRIDS.last
  LOOP
	IF xDRIDS.EXISTS(l) THEN
	   vsDRID := xDRIDS(l);
      BEGIN
	    SELECT TO_CHAR(PID) INTO vsPID
		FROM CASE_PERSON
  	    WHERE RID = vsDRID AND ROLE = AROLE_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
           vsPID:=-1;
      END;

    IF vsPID <> -1 THEN
	  XLPL.SETPID(vsPID);
	  vsDRID1 := A_F_RelProtGetRIDPerson (1);
	  IF (vsDRID1 <> -1) THEN
  		SELECT BIRTH_DATE INTO vsBIRTH_DATE
		  FROM PERSON
		 WHERE RID = vsDRID1;

		IF (S_AddYears ( vsBIRTH_DATE,ROUND(N_Age)) > XLPL.WorkDate AND
		    S_AddYears ( vsBIRTH_DATE,ROUND(N_Age))> MaxDate)
		THEN
		  MaxDate :=  S_AddYears(vsBIRTH_DATE,ROUND(N_Age));
		END IF;
--	 	  } catch (NullValue) {
--		    raise Exception ("F_RELPROT_CARECHILD: Дело %s PID=%s(ОДБ) не задан день рождения",
--			                 $CID.string, vsPID);
--		  }
	  END IF;
--      } catch(NoDataFound) {}
	  IF MaxDate IS NOT NULL THEN
	    XLPL.SETPID(Current_Pid);
		RETURN MaxDate;
	  END IF;

    END IF;   -- if vsPID <> -1

    END IF;   -- if xDRIDS.exists(l)

   END LOOP;
  END IF;


    /* --------------------------------------------------------------------
               RID из W$CASE_PERSON согласно коду по W$RELATION_PROTOCOL
    /* ---------------------------------------------------------------------*/
    xDRIDS := A_F_RELPROTGETRIDWCASEPNOTPID ();

 IF xDRIDS.COUNT > 0 THEN
  FOR l IN xDRIDS.first .. xDRIDS.last
  LOOP
	IF xDRIDS.EXISTS(l) THEN
      vsDRID := xDRIDS(l);
      BEGIN
    	  SELECT TO_CHAR(PID) INTO vsPID
	        FROM W$CASE_PERSON
  	        WHERE RID = vsDRID AND ENTERED_BY = XLPL.USER_ID AND ROLE = AROLE_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
         vsPID:=-1;
      END;

      IF vsPID <> -1 THEN
	      XLPL.SETPID(vsPID);
        vsDRID1 := A_F_RelProtGetRIDPerson (0);

 	    IF (vsDRID1 <> -1) THEN
		  SELECT BIRTH_DATE INTO vsBIRTH_DATE
		    FROM W$PERSON
		   WHERE RID = vsDRID1 AND ENTERED_BY = XLPL.USER_ID;

		  IF ( (S_AddYears ( vsBIRTH_DATE,ROUND(N_Age)) > XLPL.WorkDate )
		     AND (MaxDate IS NULL OR (S_AddYears(vsBIRTH_DATE,ROUND(N_Age)) > MaxDate)) ) -- К.Е.В. 18.01.2010
		    -- AND (S_AddYears(vsBIRTH_DATE,round(N_Age)) > MaxDate) )  -- так было 18.01.2010
		  THEN
		     MaxDate :=  S_AddYears(vsBIRTH_DATE,ROUND(N_Age));
--RAISE_APPLICATION_ERROR(-20801,' A_F_RELPROT_DATEAGECHILD 00000  vsPID='||vsPID||'   vsBIRTH_DATE='||vsBIRTH_DATE||'  vsDRID1='||vsDRID1|| '    MaxDate='||MaxDate);
		  END IF;
	    END IF;

      END IF;
	END IF;  -- if xDRIDS.exists(l)
  END LOOP;

 END IF;     -- if xDRIDS.count > 0


  XLPL.SETPID(Current_Pid);

  RETURN MaxDate;


END A_F_RELPROT_DATEAGECHILD;
/
