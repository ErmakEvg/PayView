CREATE FUNCTION       B_F_ARRAYDATEESTCHILDUXOD RETURN DBMS_SQL.NUMBER_TABLE AS

/***************************************************************************************
// Функция: F_ARRAYDATEESTCHILDUXOD
// Наименование: Ограничение возраста для детей, нуждающихся в постоянном уходе
// 				 для Estimation
// Автор: Ворошилин В.
// Состояние на дату 29.11.2000
// Код возврата: Массив, состоящий из даты, кода причины, кода изменения состояния
//***************************************************************************************/

  result DBMS_SQL.NUMBER_TABLE;
  StopDt DATE;
  StopDtEnd DATE;
BEGIN
  result.delete;
  XLPL.RoleDecl('Child', '56');
  if not XLPL.CHECKROLE(56) then
	return result;
  end if;
  XLPL.REPLACEROLE('Child');
  StopDt := S_AddYears(A_F_RelProtBIRTHDAY, TRUNC(S_Const(405, XLPL.WorkDate)));
  StopDtEnd := S_EncodeDate(S_YearOfDate(XLPL.WorkDate), S_MonthOfDate(S_Jtod(S_Const(479, XLPL.WorkDate))), S_DayOfDate(S_Jtod(S_Const(479, XLPL.WorkDate))));
  if A_F_RelProtDisability(2, '21') then
    if (StopDt <= StopDtEnd) and (StopDt > LAST_DAY(S_CurrDate)) then
 	  result(1) := S_Julian(StopDt);
 	  result(2) := 24;
 	  result(3) := 2;
	end if;
  end if;
  XLPL.RESTOREROLE;
  return result;
END B_F_ARRAYDATEESTCHILDUXOD;
/
