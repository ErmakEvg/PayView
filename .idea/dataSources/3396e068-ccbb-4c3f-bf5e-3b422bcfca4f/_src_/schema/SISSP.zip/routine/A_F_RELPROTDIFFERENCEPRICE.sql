CREATE FUNCTION       A_F_RelProtDifferencePrice(APERCENT_MIN_SIZE in number,
   APERCENT_MIN_PENS in number) RETURN NUMBER IS
/*******************************************************************************
 Функция            : PA_F_RelProtDifferencePrice
 Наименование       : Функция определяет процент выплаты пенсии в ДИ
                      с учетом стоимости содержания
 Автор              : Вахромин О.Ю.    Комментарии и корректировка     : ОЛВ
 Состояние на дату  :                             08.08.2015
 Код возврата       : возвращает процент выплаты в ДИ
********************************************************************************/
 WorkDate          date;
 vPERCENT_MIN_SIZE number;
 vPERCENT_MIN_PENS number;
 vsDRID            number;    -- RID адреса
 vsPRICE           number:=0; -- Стоимость проживания в ДИ
 vsDIFFERENCE      number;    -- Разница между назначенной пенсией и стоимостью проживания в ДИ
 PERCENT           number:=0; -- Процент выплаты пенсии
 vSum              number;
BEGIN
  -- RETURN 10;
-- APERCENT_MIN_SIZE - процент назначенной пенсии
 --APERCENT_MIN_PENS - процент минимальной пенсии по возрасту
   -- Проживание в доме-интернате оплачивается родственниками в полном размере
  IF B_F_MetricCode('167') THEN --08.08.2015 OLV --IF A_F_RelProtMetric('167') THEN
      PERCENT:=100;
      RETURN PERCENT;
   END IF;
   WorkDate:=XLPL.WorkDate;
   XLPL.IS_ESTABLISHMENT:=1;                  -- 1 - находится в ДИ, 0 - не находится в ДИ
   -- Для выплаты возмещения вреда в ДИ
   if XLPL.ALLOC_CODE=40 then
      vPERCENT_MIN_SIZE:=25;
      vPERCENT_MIN_PENS:=20;
   else
      vPERCENT_MIN_SIZE:=aPERCENT_MIN_SIZE;
      vPERCENT_MIN_PENS:=aPERCENT_MIN_PENS;
   end if;

   -- $INDIV = 3 необходимо для вычисления минимального процента выплаты пенсии
   -- по статье 84 (проживающим в ДИ)
   -- при определении выплаты пенсии детям по пункту "а" статьи 35 (реализовано в виде удержаний)
   --if ($INDIV.int<>3) {
     -- 08.08.2015 OLV-- vsDRID:=A_F_RelProtGetRIDAddress(1,3);
     vsDRID:=A_F_RelProtGetRIDAddress(1,2); -- 08.08.2015 OLV -- обязательно проживание
   BEGIN
      IF vsDRID<>-1 then
         SELECT b.PRICE into vsPrice
           FROM ORG_RESIDING_FEATURES b
          WHERE b.CODE=
                (SELECT a.CODE_ESTABLISHMENT
                   FROM ADDRESS a
                  WHERE a.RID=vsDRID
                    AND NVL((TRUNC(a.RECORD_START)),WORKDATE)<=WORKDATE
                    AND NVL((TRUNC(a.RECORD_END)),WORKDATE)>=WORKDATE)
            AND NVL((TRUNC(b.START_DATE)),WORKDATE)<=WORKDATE
            AND NVL((TRUNC(b.END_DATE)),WORKDATE)>=WORKDATE
            AND b.PRICE IS NOT NULL;
      ELSE
           -- 08.08.2015 OLV-- vsDRID:=A_F_RelProtGetRIDAddress(0,3);
           vsDRID:=A_F_RelProtGetRIDAddress(0,2); -- 08.08.2015 OLV -- обязательно проживание
         SELECT b.PRICE
           INTO vsPrice
           FROM ORG_RESIDING_FEATURES b
          Where b.CODE=
                (SELECT a.CODE_ESTABLISHMENT
                   FROM W$ADDRESS a
                  WHERE a.RID=vsDRID
                    AND NVL((TRUNC(a.RECORD_START)),WORKDATE)<=WORKDATE
                    AND NVL((TRUNC(a.RECORD_END)),WORKDATE)>=WORKDATE
                    AND a.Entered_By=XLPL.User_Id)
                AND NVL((TRUNC(b.START_DATE)),WORKDATE)<=WORKDATE
                AND NVL((TRUNC(b.END_DATE)),WORKDATE)>=WORKDATE
                AND b.PRICE IS NOT NULL;
      END IF;
   EXCEPTION
      WHEN No_Data_Found OR Too_Many_Rows THEN -- выбирает Too_Many_Rows
         vsPRICE:=XLPL.Amount+100;
   END;
        --
       vsPRICE:=XLPL.Amount+100;    -- 08.08.2015 OLV -- разница пойдет в доплату

   -- Определяем разницу между назначенной пенсией и стоимостью проживания в ДИ
   vsDIFFERENCE:=XLPL.Amount-vsPRICE;
   vsum:=A_P_SIZEMINPENS()*APERCENT_MIN_PENS;

   if vsDIFFERENCE<=0 then
      if (XLPL.Amount*APERCENT_MIN_SIZE)/100< vsum/100  then
         PERCENT:=S_iround((vsum/XLPL.Amount)*100)/100;
      else
         PERCENT:=APERCENT_MIN_SIZE;
      end if;
   else
      if (vsDIFFERENCE<XLPL.Amount*APERCENT_MIN_SIZE/100)
        and (XLPL.Amount*APERCENT_MIN_SIZE/100<vsum/100) then
            PERCENT:=S_iround((vsum/XLPL.Amount)*100)/100;
      else
         if (vsDIFFERENCE<XLPL.Amount*APERCENT_MIN_SIZE/100)
           and (XLPL.Amount*APERCENT_MIN_SIZE/100>vsum/100) then
            PERCENT:=APERCENT_MIN_SIZE;
         else
            PERCENT:=S_iround((vsDIFFERENCE*100/XLPL.Amount)*100)/100;
         end if;
      end if;
   end if;

   RETURN PERCENT;
END A_F_RelProtDifferencePrice;
/
