CREATE FUNCTION       B_F_Absent RETURN DBMS_SQL.NUMBER_TABLE AS
/***********************************************************************************************
 Функция: B_F_Absent
Наименование: Функция определяет периоды нахождения ребенка в доме-интернате
				         (без привязки к дате)
Автор: Ворошилин В.
Состояние на дату 24.07.2000
Возвращает: массив, где первый член - дата начала отсутствия, второй - дата конца  отсутствия
************************************************************************************************/
  a DBMS_SQL.NUMBER_TABLE;
BEGIN
  a.DELETE;
  FOR curActvf IN (SELECT NVL(c.RECORD_START, NULL) AS bufPERIOD_START,
  	  		   	  		  NVL(c.RECORD_END, NULL) AS bufPERIOD_END
                   FROM W$ADDRESS c
				   WHERE  PID = Xlpl.GetPid
					   AND c.Code_Establishment IN
					                               (SELECT a.CODE FROM ORGANIZATIONS a, ORG_TYPES b
					                                WHERE a.ORG_TYPE = b.CODE
													      AND b.PARENT_CODE IN (9, 14))
					   AND c.STAGE IN (1, 4)
					   AND c.ENTERED_BY = Xlpl.User_ID
					   ORDER BY c.RECORD_START)
 LOOP
	a(a.COUNT+1) := S_Julian(curActvf.bufPERIOD_START);
	a(a.COUNT+1) := S_Julian(curActvf.bufPERIOD_END) + 1;
 END LOOP;
--RAISE_APPLICATION_ERROR(-20801,'B_F_Absent     XLPL.GetPid=' ||XLPL.GetPid);
  RETURN a;
END B_F_Absent;
/
