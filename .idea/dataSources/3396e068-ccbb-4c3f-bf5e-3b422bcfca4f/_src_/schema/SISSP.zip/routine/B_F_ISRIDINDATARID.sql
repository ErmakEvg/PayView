CREATE FUNCTION       B_F_ISRIDINDATARID(ARELATION_TABLE in number, AALLOCRID in number,
  ARID in number) return BOOLEAN is
/* ---------------------------------------------------------------------------------------
// F_ISRIDINDATARID
// набирайте текст функции здесь
// Автор Басинюк Я.В.
// состояние на 3.05.99
// есть ли такой RID для заданного назначения и заданной таблице
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 15.07.2002
// --------------------------------------------------------------------------------------*/
  xRIDS dbms_sql.Number_Table;
  i number;
begin
  for c1 in (select DATA_RID as vsRIDS
             from RELATION_ALLOC_DATA
		     where RELATION_TABLE = ARELATION_TABLE
		       and ALLOCATION_RID = AALLOCRID) loop

   xRIDS := S_ParseFloatArray(c1.vsRIDS);

   for i in 1..xRIDS.count loop
     if (ARID = xRIDS(i)) then
	   return true;
	 end if;
	end loop;
  end loop;

  return false;
end;
/
