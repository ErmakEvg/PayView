CREATE FUNCTION       A_F_Getrecord_Litva(CID#  IN NUMBER, div VARCHAR2) RETURN VARCHAR2 IS
/***********************************************************************************************
 Функция                : A_F_GETRECORD_Litva
 Наименование       : Возращает строку, представляющую стаж как количество
                                лет, месяцев и дней для выплатных документов по МД с Литвой
 Автор                     : ОЛВ
 Состояние на дату  : 16.04.2013
 Код возврата          : строка - количество лет, месяцев и днейс разделителем div
************************************************************************************************/
 vsVsego_Days      NUMBER;
 vsPID                   NUMBER;
 Result                  VARCHAR2(10);
BEGIN
  BEGIN
  -- выбрать PID
  SELECT pid  INTO  vsPID
     FROM  CASE_PERSON
    WHERE cid = CID#
        AND stage IS NULL
        AND ROLE IN (51, 54); -- 51 - Пенсионер, 54 - Кормилец1,  61 -Кормилец2

    -- Выбрать весь общий саж, включая Литовский
	--------------------------------------------------------------------------
     vsVsego_Days:=0;
    SELECT SUM(record_days) INTO vsVsego_Days
      FROM
         (
            SELECT record_days
               FROM MANUAL_RECORD
            WHERE pid=vsPID AND record_code IN (1,82) AND stage IS NULL
          UNION
            SELECT record_days FROM RECORD
             WHERE    pid=vsPID AND record_code=1 AND stage IS NULL
           ) ;
     Result := TO_CHAR(TRUNC((vsVsego_Days / 360))) || div ||
         TO_CHAR(TRUNC(((vsVsego_Days - (TRUNC((vsVsego_Days / 360)) * 360)) / 30))) || div ||
         TO_CHAR((vsVsego_Days - (TRUNC((vsVsego_Days / 30)) * 30))) ;

  EXCEPTION
       WHEN NO_DATA_FOUND THEN
	         Result := '00'||div||'00'||div||'00';
		WHEN OTHERS THEN
	         Result := '00'||div||'00'||div||'00';
  END;
	--RAISE_APPLICATION_ERROR(-20801,' A_F_GETRECORD_Litva           Result :  '|| Result);
    RETURN  Result;
END A_F_Getrecord_Litva;
/
