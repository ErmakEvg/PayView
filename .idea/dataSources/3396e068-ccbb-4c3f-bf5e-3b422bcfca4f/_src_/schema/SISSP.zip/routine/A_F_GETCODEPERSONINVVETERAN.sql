CREATE FUNCTION       A_F_GetCodePersonInvVeteran RETURN BOOLEAN AS
/***************************************************************************************
 Функция           : A_F_GetCodePerson
 Наименование      : Проверка наличия у персоны кодов инвалидов ВОВ или участников ВОВ

 Автор             : Горбач Н П.
 Состояние на дату : 01.12.2012
 Код возврата      : возвращает true, если есть у человека  код инвалида или участника ВОВ
****************************************************************************************/


  pCount        NUMBER;

BEGIN

 pCount:=0;

select count(*) into pCount
from
(
select gg.code
 from w$PERSON_METRIC gg,  W$person g
where
 g.PID=XLPL.GetPID
 and gg.stage in (1,4)
 and g.DEATH_DATE is null
 and g.STAGE in (1,4)
 and g.PID=gg.PID
 and gg.CODE in (select code from  metrics hh where hh.parent_code in (19,20,21))
 union
select gg.code
 from PERSON_METRIC gg,  person g
where
 g.PID=XLPL.GetPID
 and nvl(gg.stage,0) not in (2,3)
 and g.DEATH_DATE is null
 and nvl(g.STAGE ,0) not in (2,3)
 and g.PID=gg.PID
 and gg.CODE in (select code from  metrics hh where hh.parent_code in (19,20,21))
 );


        IF (pCount>0) THEN
           RETURN TRUE;
        END IF;


   RETURN FALSE;

END A_F_GetCodePersonInvVeteran;
/
