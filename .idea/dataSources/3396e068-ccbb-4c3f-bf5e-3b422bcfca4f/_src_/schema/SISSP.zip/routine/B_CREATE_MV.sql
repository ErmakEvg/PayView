CREATE FUNCTION       B_Create_MV(CALC_DATE1 DATE) return integer is
Result  integer;
 CD DATE;
begin
UPDATE M$CALC_DATE_MR SET CALC_DATE = CALC_DATE1, entry_date = SYSDATE;
  COMMIT;
 execute immediate 'DROP MATERIALIZED VIEW SISSP.MV_MASS_CALC_RESULT';
 execute immediate 'CREATE MATERIALIZED VIEW SISSP.MV_MASS_CALC_RESULT
TABLESPACE SISSP_DATA
PCTUSED    0
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH
COMPLETE
ON DEMAND
AS
SELECT   b.rid,
         b.payroll_no,
         b.prev_period_rid,
         b.cid,
         B.AID
  FROM   result_payment b
 WHERE   b.rid IN (SELECT  result_payment_rid FROM  calc_amount C,
  (SELECT  CALC_DATE, LAST_DAY(CALC_DATE) LCALC_DATE  FROM  M$CALC_DATE_MR)T
  WHERE  C.stage IS NULL AND NVL (C.history_flag, 0) = 0 AND C.period_start>=T.CALC_DATE
   AND C.period_start<=T.LCALC_DATE) AND b.base_aid IS NULL AND b.stage IS NULL';
execute immediate   'DROP MATERIALIZED VIEW SISSP.MV_MASS_CALC_RESULT2';
execute immediate
 ' CREATE MATERIALIZED VIEW MV_MASS_CALC_RESULT2
 TABLESPACE SISSP_DATA
PCTUSED    0
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH
COMPLETE
ON DEMAND
AS
SELECT a.rid, a.aid, a.cid, a.index_flag, a.history_flag,
       TRUNC (a.period_start, ''MON'') AS period_start, b.payroll_no,
       b.prev_period_rid
  FROM calc_amount a, result_payment b,
   (SELECT  CALC_DATE, LAST_DAY(CALC_DATE) LCALC_DATE  FROM   M$CALC_DATE_MR )T
 WHERE A.period_start BETWEEN T.CALC_DATE AND T.LCALC_DATE
   AND b.stage IS NULL AND b.rid = a.result_payment_rid
   AND NVL (a.history_flag, 0) = 0 AND a.parent_rid IS NULL AND a.stage IS NULL';
execute immediate 'create index MV_INDEX_MASS01 on MV_MASS_CALC_RESULT (CID)';
execute immediate 'create index MV_INDEX_MASS02 on MV_MASS_CALC_RESULT2 (CID)';
commit;
 return 0;
exception
 when OTHERS then
    RAISE_APPLICATION_ERROR(-20801,'no MV'||CHR(10)||SQLERRM);
 return (-1);
end B_Create_MV;
/
