CREATE FUNCTION       A_F_RelProtActvStart_AddrHELP(aActivity in NUMBER)
RETURN DATE IS
/*******************************************************************************
 Функция            : F$Check751
 Назначение         : возвращает дату начала ACTIVITY по W$RELATION_PROTOCOL
         Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL)
 Автор              : Абрамович М.В.      (РМП)
 Состояние на дату  : 02.10.2012
 Входные праметры   : aActivity - код верхнего уровня  (Например 1 - работатет)
 Код возврата       : дата начала ACTIVITY
*******************************************************************************/
  xResume DATE;
  --xLabor DBMS_SQL.Number_Table;
  xRID DBMS_SQL.Number_Table;
  i NUMBER;
  k NUMBER;
  curr_RID NUMBER;
  xOut BOOLEAN;
  xManyRecord BOOLEAN;
  xUser NUMBER;
BEGIN
  xResume := NULL;
  xUser := XLPL.USER_ID;
  xOut := False;
  xManyRecord := False;
  -- xLabor.Delete;
  -- if aLabor is NOT NULL then
  -- xLabor := S_ParseFloatArray(aLabor);
  -- if xLabor.Count > 1 then
  -- raise_application_error(-20202,
  --    'A_F_RelProtActvStart: параметры заданы неверно - ' ||
  --    'число элементов в aLabor больше 1');
  -- end if;
  -- end if;
  xRID.Delete;
  xRID := A_F_RelProtGetRIDActivity(1);  --     1 - ОБД, другое - РБД
  k := xRID.Count;
  FOR i IN 1..k LOOP
    curr_RID := xRID(i);
    begin
      Select PERIOD_START into xResume
	  From ACTIVITY
      Where RID = curr_RID
	    and ACTIVITY.ACTIVITY = aActivity
        and PERIOD_END is Null;

	 -- and ((ACTIVITY.LABOR = TO_NUMBER(aLabor))
	 -- or ((aLabor is NULL) and (ACTIVITY.LABOR is NULL)))
	 -- and ((DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason))
	 -- or ((aDismiss_Reason is NULL) and (DISMISSAL_REASON is NULL)));

	  if xOut = True then
	    xManyRecord := True; -- ( > чем одному RIDу найдена запись с PERIOD_START)
	  end if;
      xOut := True;
      exception
        when NO_DATA_FOUND then
          NULL;
      end;
  END LOOP;

  if xManyRecord = True then
    raise_application_error(-20203,
	  'A_F_RelProtActvStart_ADRHELP: выбрано > одной строки из ACTIVITY' || CHR(10) ||
      '(aActivity = ' || TO_CHAR(aActivity) ||  ')');
  end if;

  if xOut = False then
    xOut := False;
    xManyRecord := False;
    xRID.Delete;
    xRID := A_F_RelProtGetRIDActivity(0);  -- по РБД
    k := xRID.Count;
    FOR i IN 1..k LOOP
      curr_RID := xRID(i);
      begin
        Select PERIOD_START into xResume
	    From W$ACTIVITY
        Where RID = curr_RID
	      and W$ACTIVITY.ACTIVITY = aActivity
          and PERIOD_END is Null
	      and ENTERED_BY = xUser;

	   -- and ((W$ACTIVITY.LABOR = TO_NUMBER(aLabor))
	   -- or ((aLabor is NULL) and (W$ACTIVITY.LABOR is NULL)))
	   -- and ((DISMISSAL_REASON = TO_NUMBER(aDismiss_Reason))
	   -- or ((aDismiss_Reason is NULL) and (DISMISSAL_REASON is NULL)));

	    if xOut = True then
	      xManyRecord := True; -- ( > чем одному RIDу найдена запись с PERIOD_START)
	    end if;
        xOut := True;
        exception
          when NO_DATA_FOUND then
            NULL;
        end;
    END LOOP;

    if xManyRecord = True then
      raise_application_error(-20204,
     'A_F_RelProtActvStart_ADRHELP: выбрано > одной строки из W$ACTIVITY' || CHR(10) ||
     '(aActivity = ' || TO_CHAR(aActivity) ||  ')');
    end if;
  end if;

  RETURN xResume;

END A_F_RelProtActvStart_AddrHELP;
/
