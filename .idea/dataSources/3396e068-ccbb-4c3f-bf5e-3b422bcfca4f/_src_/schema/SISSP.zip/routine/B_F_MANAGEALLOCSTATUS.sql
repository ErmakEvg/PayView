CREATE FUNCTION       B_F_ManageAllocStatus RETURN DBMS_SQL.Number_Table IS
--==============================================================================
-- Назначение: производит анализ состояния назначения
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Возвращаемое значение: - массив, каждая тройка элементов которого содержит:
--                                                             ALLOC_STATUS_NEW
--                                                             ALLOC_STATUS_OLD
--                                                             STATUS_DATE
--==============================================================================
xResume DBMS_SQL.Number_Table;
xCID NUMBER;
xAID NUMBER;
xCount NUMBER;
BEGIN
xCID := XLPL.CID;
xAID := XLPL.AID;
xResume.Delete;
FOR cRec IN (select NVL(ALLOC_STATUS_NEW, 0) as STATUS_NEW,
                    NVL(ALLOC_STATUS_OLD, 0) as STATUS_OLD,
					STATUS_DATE
			 from w$change_alloc_status
			 where  CID = xCID
			 and AID = xAID)
LOOP
  xCount := xResume.Count;
  xResume(xCount + 1) := cRec.STATUS_NEW;
  xResume(xCount + 2) := cRec.STATUS_OLD;
  if cRec.STATUS_DATE is NULL then
    xResume(xCount + 3) := NULL;
  else
    xResume(xCount + 3) := S_Julian(cRec.STATUS_DATE);
  end if;
END LOOP;
RETURN xResume;
END B_F_ManageAllocStatus;
/
