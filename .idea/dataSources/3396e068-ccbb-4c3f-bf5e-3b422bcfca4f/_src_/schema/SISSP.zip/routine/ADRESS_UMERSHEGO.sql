CREATE FUNCTION       adress_umershego(cid# NUMBER, entered_by# NUMBER) RETURN VARCHAR2 IS
text VARCHAR2(2000);
/***************************************************************************************
 Функция           :  adress_umershego
 Наименование  :  Функция формирования адреса умершего лица в пособии на погребение при выдаче платежного поручения
 Автор               :  Речицкая А.В.
 Состояние на дату: 25.10.20010
 Код возврата    : Адрес умершего лица в пособии на погребение
***************************************************************************************/
BEGIN
SELECT DISTINCT
oblast.value||' '||oblastr.value||' '||raion.value||' '||raionr.value||' '||derevnia.value ||' '||site.value  ||' '|| street.value||house.value ||house_x.value ||appt.value /*подзапросы возвращают символ пробела, если в базе пустая запись */
INTO text
FROM
(SELECT NVL(( SELECT sd.value
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid =cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = (SELECT sd.parent_code
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid = cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =  (SELECT sd.parent_code
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid = cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =ad.site))),' ') value FROM dual) oblast,
(SELECT NVL(( SELECT rsd.catshortname
FROM
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
WHERE
cp.cid = cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  rsd.code = sd.level_code
AND  sd.code =  (SELECT sd.parent_code
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid = cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = (SELECT sd.parent_code
FROM
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
WHERE
cp.cid =cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =ad.site
AND  rsd.code = sd.level_code))),' ') value FROM dual) oblastr,
(SELECT NVL(( SELECT sd.value
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid =cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =  (SELECT sd.parent_code
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid = cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =ad.site)),' ') value FROM dual) raion,
(SELECT NVL(( SELECT rsd.catshortname
FROM
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
WHERE
cp.cid =cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  rsd.code = sd.level_code
AND  sd.code =  (SELECT sd.parent_code
FROM
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
WHERE
cp.cid = cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code =ad.site
AND  rsd.code = sd.level_code)),' ') value FROM dual) raionr,
(SELECT NVL(( SELECT rsd.catshortname
FROM
address ad,
case_person cp,
state_division sd,
ref_st_division_levels rsd
WHERE
cp.cid =cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site
AND  rsd.code = sd.level_code),' ') value FROM dual) derevnia,
(SELECT NVL(( SELECT sd.value
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid = cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site),' ') value FROM dual) site,
(SELECT NVL(( SELECT ' ул. '||sd.value
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid = cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by =  cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.street),' ') value FROM dual) street,
(SELECT NVL(( SELECT ' д. '||ad.house
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid =cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--ND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site),' ') value FROM dual) house,
(SELECT NVL(( SELECT ' корп. '||ad.house_x
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid = cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site),' ') value FROM dual) house_x,
(SELECT NVL(( SELECT ' кв. '||ad.appt
FROM
address ad,
case_person cp,
state_division sd
WHERE
cp.cid =cid#
--AND  cp.entered_by =  entered_by#
AND  cp.ROLE IN(60)
AND  ad.pid = cp.pid
--AND  ad.entered_by = cp.entered_by
--and  ad.stage in(1,4)
AND  ad.ADDRESS_TYPE IN (2,3)
AND  sd.code = ad.site),' ') value FROM dual) appt;
  RETURN TEXT;
END;
/
