CREATE FUNCTION       B_F_GetMinDelAllWPension return DATE is
/*==============================================================================
+ Функция: F_GetMinDelAllWPension
+ Наименование: Определяет min дату окончания действия пенсии для лица
+ Автор: Ворошилин В.
+ Состояние на дату 07.05.1999
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 15.07.2002
==============================================================================*/

  result_date date := null;
  alloc_date date;
begin
  alloc_date := B_F_StartDateAllocation();

  begin
    Select min(ALLOCATION_END) into result_date
  	from ALLOCATION a, ALLOCATION_PERSON b, CASE_PERSON c, ALLOCATION_ROLE_GROUP d
	where a.RID = b.ALLOCATION_RID
	  and b.PID = XLPL.GetPID
	  and c.PID = b.PID
	  and d.CODE = c.ROLE
	  and d.FEATURE = 1
	  and (c.STAGE <> 3 or c.STAGE is NULL)
	  and (a.STAGE <> 3 or a.STAGE is NULL)
	  and (b.STAGE <> 3 or b.STAGE is NULL)
	  and a.ALLOC_CODE in
	    (select CODE
		 from ALLOCATIONS
		 start with CODE = 1
		 connect by prior CODE = PARENT_CODE);
  exception
    when NO_DATA_FOUND then
      return result_date;
  end;

  if (not (result_date is null)) and (result_date > alloc_date) then
    return result_date;
  else
    return null;
  end if;
end;
/
