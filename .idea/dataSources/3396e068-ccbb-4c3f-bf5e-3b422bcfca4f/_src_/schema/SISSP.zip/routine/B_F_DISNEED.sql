CREATE FUNCTION       B_F_DisNeed RETURN BOOLEAN AS
/***************************************************************************************/
/* Функция: B_F_DisNeed
/* Наименование: функция возвращает True если человеку требуется уход
/* Автор: Ворошилин В.
/* Состояние на дату 05.02.1999
/***************************************************************************************/

  CN_DISABILITY NUMBER;
BEGIN
  select count(*) INTO CN_DISABILITY from W$MRAK_OPINION_ADVICE
  where PID = XLPL.GetPid
    and ENTERED_BY = XLPL.User_ID
	and STAGE not in (2,3)
	and RECORD_START <= XLPL.WorkDate
	and (NVL(RECORD_END, XLPL.WorkDate) >= XLPL.WorkDate)
	and OPINION_TYPE = 2
	and ADVICE_TYPE = 21 ;
  return CN_DISABILITY != 0;
END B_F_DisNeed;
/
