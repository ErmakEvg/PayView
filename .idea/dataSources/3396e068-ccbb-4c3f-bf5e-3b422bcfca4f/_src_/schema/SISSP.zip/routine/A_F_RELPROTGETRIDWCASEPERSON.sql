CREATE FUNCTION       A_F_RelProtGetRIDWCasePerson RETURN DBMS_SQL.NUMBER_TABLE IS
/*
// -------------------------------------------------------------
// Автор: Трухтанов.
// состояние
// Код возврата: RID из W$CASE_PERSON согласно коду по W$RELATION_PROTOCOL
// -------------------------------------------------------------

*/

xDRIDS DBMS_SQL.Number_Table;
i integer;
vsRELATION_TABLE integer;
vsDRID number;

BEGIN

  vsRELATION_TABLE := S_CodeTableSISSP ('W$CASE_PERSON');

  if XLPL.AID = 0 then
      for RID in (select DATA_RID as RID from W$RELATION_PROTOCOL b, W$CASE_PERSON a
                             where
							     b.CID = XLPL.CID and
								 GROUP_NO = XLPL.GROUP_NO and
								 ALLOC_CODE = XLPL.ALLOC_CODE and
								 RELATION_TABLE = vsRELATION_TABLE and
								 RELATION_DATE = XLPL.WorkDate and
								 b.ENTERED_BY = XLPL.USER_ID and
								 a.ENTERED_BY = XLPL.USER_ID and
								 DATA_RID = a.RID and
								 NVL(a.RECORD_START, XLPL.WORKDATE) <= XLPL.WORKDATE and
								 NVL(a.RECORD_END, XLPL.WORKDATE) >= XLPL.WORKDATE and
								 a.PID = XLPL.GETPID) LOOP
		 xDRIDS(xDRIDS.Count+1) := RID.RID;
		 end loop;
   else

      for RID in (select DATA_RID as RID from W$RELATION_PROTOCOL b, W$CASE_PERSON a
                             where
							     b.CID = XLPL.CID and
								 AID = XLPL.AID and
								 ((GROUP_NO = XLPL.GROUP_NO) or (XLPL.GROUP_NO = 0)) and
								 ALLOC_CODE = XLPL.ALLOC_CODE and
								 b.ENTERED_BY = XLPL.USER_ID and
								 a.ENTERED_BY = XLPL.USER_ID and
								 RELATION_TABLE = vsRELATION_TABLE and
								 RELATION_DATE = XLPL.WorkDate and
								 DATA_RID = a.RID and
								 a.PID = XLPL.GETPID) LOOP
		 xDRIDS(xDRIDS.Count +1) := RID.RID;
		 end loop;
		 end if;
return xDRIDS;

END A_F_RelProtGetRIDWCasePerson;
/
