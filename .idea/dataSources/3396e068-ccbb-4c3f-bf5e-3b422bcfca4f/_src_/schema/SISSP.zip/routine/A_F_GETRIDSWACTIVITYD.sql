CREATE FUNCTION       A_F_GetRidsWActivityD(ASTOP_DATE in Date,
   ARELATION_DATE in Date,ASTAGE in Number,AACTIVITY in Number,ALABOR in VarChar2)
   RETURN DBMS_SQL.Number_Table IS
/* Код возврата: возращает массив RID-ов по условию для W$ACTIVITY
             для даты (MM:YYYY) из диапозона RECORD_START .. RECORD_END
Вахромин О.Ю.*/
retRIDS DBMS_SQL.NUMBER_TABLE;
xLABOR DBMS_SQL.NUMBER_TABLE;
i number;
vsLeftDate date;
vsRightDate date;
vsDate date;
BEGIN
   i:=1;
   vsDate:=ARELATION_DATE;
   vsRightDate:=ASTOP_DATE;
   vsLeftDate:=S_FirstDayOfMonth(ARELATION_DATE);
   --debug ("F_GetRidsWActivityD: Взят интервал [%s:%s] из даты %s\n",
   --       DateToStr (vsLeftDate),DateToStr(vsRightDate),DateToStr(ARELATION_DATE));
   xLABOR:=S_ParseFloatArray(ALABOR);
   if (xLABOR.count=0) then
      for c1 in (select RID from W$ACTIVITY where PID=XLPL.GetPID and
         ACTIVITY=AACTIVITY and ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and
         ((ARELATION_DATE between NVL(PERIOD_START,ARELATION_DATE) and
            NVL(PERIOD_END,ARELATION_DATE)) or
         (vsLeftDate between NVL(PERIOD_START,vsLeftDate) and
            NVL(PERIOD_END,vsLeftDate)) or
         (vsRightDate between NVL(PERIOD_START,vsRightDate) and
            NVL(PERIOD_END,vsRightDate)) or
         ((NVL(PERIOD_START,vsLeftDate)>=vsLeftDate)and  -- проверка внутри интервала LeftData RightData
         (NVL(PERIOD_END,vsRightDate)<=vsRightDate)and
         (NVL(PERIOD_START,vsRightDate)<=vsRightDate)))) loop
         retRIDS(i):=c1.RID;
         i:=i+1;
      end loop;
   else
      for l in 1..xLABOR.count loop
         for c1 in (select RID from W$ACTIVITY where PID=XLPL.GetPID and
            ACTIVITY=AACTIVITY and LABOR=xLABOR(l) and ENTERED_BY=XLPL.USER_ID and
            STAGE=ASTAGE and
            ((ARELATION_DATE between NVL(PERIOD_START,ARELATION_DATE) and
               NVL(PERIOD_END,ARELATION_DATE)) or
            (vsLeftDate between NVL(PERIOD_START,vsLeftDate) and
               NVL(PERIOD_END,vsLeftDate)) or
            (vsRightDate between NVL(PERIOD_START,vsRightDate) and
               NVL(PERIOD_END,vsRightDate)) or
            ((NVL(PERIOD_START,vsLeftDate)>=vsLeftDate)and  -- проверка внутри интервала LeftData RightData
            (NVL(PERIOD_END,vsRightDate)<=vsRightDate)and
            (NVL(PERIOD_START,vsRightDate)<=vsRightDate)))) loop
            retRIDS(i):=c1.RID;
            i:=i+1;
         end loop;
      end loop;
   end if;
   return retRIDS;
END A_F_GetRidsWActivityD;
/
