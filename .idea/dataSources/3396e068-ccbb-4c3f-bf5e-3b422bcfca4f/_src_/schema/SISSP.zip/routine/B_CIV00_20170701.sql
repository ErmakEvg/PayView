CREATE FUNCTION       B_CIV00_20170701 RETURN NUMBER AS

/***************************************************************************************
// Функция:             B_CIV00_20170701
// Наименование:         Функция расчета суммы пособия лицу, осуществляющему уход
//                       за ребенком - инвалидом в возрасте до 18 лет в зависимости от группы здоровья
// Автор:                 Речицкая А. В.
// Состояние на дату     29.06.2017  26.2017  OLV
// Код возврата:         число с плавающей точкой с суммой пособия
//***************************************************************************************

/* Вычисление суммы для пособия по уходу за ребенком-инвалидом до 18 лет:
I или II степень утраты здоровья, - 100 процентов наибольшей величины БПМ;
III или IV степень утраты здоровья, - 120 процентов наибольшей величины БПМ; */

health  number;

BEGIN
  -- степень утраты здоровья
   IF  Xlpl.CheckRole(56) THEN
   Xlpl.RoleDecl('Child','56');       -- Ребенок в назначении -- 11.03.2013
   Xlpl.REPLACEROLE('Child');
      health:= A_F_Relprotdisabiltylosshealth();

     -- Исчисление размера пособия в зависимости от степени утраты здоровья
     if FLOOR(MONTHS_BETWEEN(XLPL.WorkDate,S_Birthdate(Xlpl.Base_ID,Xlpl.GetPid,Xlpl.WorkDate)) / 12) <=3 --26.2017  OLV -- B_F_Agecheck
        --B_ADDYEARSMONTHS_D(S_Birthdate(Xlpl.Base_ID,Xlpl.GetPid,Xlpl.WorkDate),3)<= Xlpl.WorkDate
        then
        XLPL.AMOUNT := S_CONST(18, XLPL.WorkDate) * S_CONST(497, XLPL.WorkDate) / 100;-- 100%
     else
         CASE
           WHEN (health=1 or health=2) THEN
        XLPL.AMOUNT := S_CONST(18, XLPL.WorkDate) * S_CONST(486, XLPL.WorkDate) / 100; -- 100%
           WHEN (health=3 or health=4)  THEN
        XLPL.AMOUNT := S_CONST(18, XLPL.WorkDate) * S_CONST(487, XLPL.WorkDate) / 100;  -- 120%
        ELSE
          XLPL.AMOUNT :=0;
         END CASE;
     end if;
       Xlpl.RestoreRole;
   END IF;
       --RAISE_APPLICATION_ERROR(-20801,'B_CIV00_20170701 +++       XLPL.AMOUNT ='||  XLPL.AMOUNT || '  health= '||health);

     --     Xlpl.S_PROTOCOL('F$amount206_20110801    health= ' ||health || CHR(10) || '   Xlpl.WorkDate=' ||Xlpl.WorkDate || CHR(10));

  RETURN XLPL.AMOUNT;
END B_CIV00_20170701;
/
