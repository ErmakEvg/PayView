CREATE FUNCTION       A_F_RelProtActvSEDate(AActivity in number, ALabor in varchar2,
  ADismiss_Reason in varchar2) return dbms_sql.Number_Table is
/* --------------------------------------------------------------------
// F_RelProtActvSEDate
// Автор: Ворошилин В.
// состояние на 02.05.2000
// Код возврата: возвращает даты начала и даты конца ACTIVITY по W$RELATION_PROTOCOL
// 	   а также дату ввода в ОДБ, если она есть.
//     Work_date - точка перелома (поле RELATION_DATE в W$RELATION_PROTOCOL
// Параметры:
//     AACTIVITY - код верхнего уровня  (На пример 1 - работатет)
//     ALABOR - код нижнего уровня ("" - игнорируются)
//     ADISMISS_REASON - список кодов увольнений ("" - игнорируется)
===========================================
= Перевод на PLS/QL Сманцер Ю.А. 17.07.2002
// --------------------------------------------------------------------*/

  DRIDS dbms_sql.Number_Table;
  Result dbms_sql.Number_Table;
  vsDRID number;
  i number := 0;
  j number := 0;
  xTmp dbms_sql.Number_Table;
begin
  Result.delete;

  if ALabor is not null then
    xTmp := S_ParseFloatArray(ALAbor);
    if xTmp.Count > 1 then
      Raise_Application_Error(-20801, 'F_RELPROTACTVSTART: параметр ALABOR содержит больше одного значения');
	end if;
  end if;

  DRIDS := A_F_RelProtGetRIDActivity(1);

  for i in 1..DRIDS.Count loop
    vsDRID := DRIDS(i);
    for c1 in (select PERIOD_START as retStart_Date, PERIOD_END as retEnd_Date, ENTRY_DATE as retEntry_Date
  	  		   from ACTIVITY
               where RID = vsDRID
			     and ACTIVITY = AACTIVITY
				 and ((LABOR = ALABOR) or ((ALABOR is NULL) and (LABOR is NULL)))
				 and ((DISMISSAL_REASON = ADISMISS_REASON) or ((ADISMISS_REASON is NULL) and (DISMISSAL_REASON is NULL)))) loop

      j := j + 1;
      if not (c1.retStart_Date is null) then
        Result(j) := S_julian(c1.retStart_Date);
	  else
        Result(j) := S_julian(null);
	  end if;

      j := j + 1;
	  if not (c1.retEnd_Date is null) then
        Result(j) := S_julian(c1.retEnd_Date);
	  else
	    Result(j) := S_julian(null);
	  end if;

      j := j + 1;
	  if not (c1.retEntry_Date is null) then
        Result(j) := S_julian(c1.retEntry_Date);
	  else
	    Result(j) := S_julian(null);
	  end if;
    end loop;
  end loop;

  DRIDS := A_F_RelProtGetRIDActivity(0);

  for i in 1..DRIDS.Count loop
    vsDRID := DRIDS(i);
    for c1 in (select PERIOD_START as retStart_Date, PERIOD_END as retEnd_Date, ENTRY_DATE as retEntry_Date
  	  		   from W$ACTIVITY
               where RID = vsDRID
			     and ACTIVITY = AACTIVITY
				 and ENTERED_BY = XLPL.USER_ID
				 and ((LABOR = ALABOR) or ((ALABOR is NULL) and (LABOR is NULL)))
				 and ((DISMISSAL_REASON = ADISMISS_REASON) or ((ADISMISS_REASON is NULL) and (DISMISSAL_REASON is NULL)))) loop

      j := j + 1;
	  if not (c1.retStart_Date is null) then
        Result(j) := S_julian(c1.retStart_Date);
	  else
	    Result(j) := S_julian(null);
	  end if;

      j := j + 1;
	  if not (c1.retEnd_Date is null) then
        Result(j) := S_julian(c1.retEnd_Date);
	  else
	    Result(j) := S_julian(null);
	  end if;

      j := j + 1;
      if not (c1.retEntry_Date is null) then
        Result(j) := S_julian(c1.retEntry_Date);
	  else
	    Result(j) := S_julian(null);
	  end if;
    end loop;
  end loop;

  return Result;
end;
/
