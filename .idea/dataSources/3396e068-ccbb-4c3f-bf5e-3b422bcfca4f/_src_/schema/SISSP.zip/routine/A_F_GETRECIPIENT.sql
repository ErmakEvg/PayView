CREATE FUNCTION       A_F_GETRECIPIENT(AALLOC_CODE IN DBMS_SQL.NUMBER_TABLE) RETURN NUMBER AS
-- Возвращает получателя из РБД
/*****************************************************************************
// Автор: Ворошилин
// Состояние на 16.05.2001
// Код возврата: PID получателя в деле или 0, т.е. получатель - организация
// *****************************************************************************/

vsPID NUMBER;
BEGIN
    BEGIN
      select PID INTO vsPID from W$RECIPIENT
	  where CID = XLPL.CID
	    and AID is NULL
		and STAGE in (1,4)
		and ENTERED_BY = XLPL.User_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vsPID := 0; --raise_application_error(-20801, 'FI_PROCESSINGALLOCATION: В деле '|| to_char(XLPL.CID) ||' нет получателя');
      WHEN TOO_MANY_ROWS THEN
        raise_application_error(-20801, 'FI_PROCESSINGALLOCATION: В деле '|| to_char(XLPL.CID) ||' больше одного получателя');
      WHEN OTHERS THEN
        vsPID := 0;
    END;
RETURN vsPID;


/*
  vsVALUE VARCHAR2(2000);
  vsVALUE1 VARCHAR2(2000);
  vsVALUE2 VARCHAR2(2000);
  vsPID NUMBER;
  vsCATEGORY BINARY_INTEGER;
  vsCALLOC_CODE BINARY_INTEGER;
  vsALLOC_CODE BINARY_INTEGER;
  vsCONTROL_ALLOC_CODE BINARY_INTEGER;
  vsPIDBen BINARY_INTEGER;
  i BINARY_INTEGER;
  vsROLE BINARY_INTEGER;
  vsROLE1 BINARY_INTEGER;
  vsROLE2 BINARY_INTEGER;
  bufI BINARY_INTEGER;
  rab DATE;
BEGIN
  rab :=XLPL.WorkDate;
  vsVALUE := NULL;
  vsVALUE1 := NULL;
  vsVALUE2 := NULL;
  vsPID := 0;
  vsPIDBen := 0;
  select ACCESS_DATA INTO vsCATEGORY from ID_CASE where CID = XLPL.CID;
  IF vsCATEGORY < 3 THEN
    BEGIN
      select PID INTO vsPID from W$RECIPIENT
	  where CID = XLPL.CID
	    and AID is NULL
		and STAGE in (1,4)
		and ENTERED_BY = XLPL.User_ID;
--    RETURN TO_CHAR(vsPID);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        raise_application_error(-20801, 'FI_PROCESSINGALLOCATION: В деле '|| to_char(XLPL.CID) ||' нет получателя');
      WHEN TOO_MANY_ROWS THEN
        raise_application_error(-20801, 'FI_PROCESSINGALLOCATION: В деле '|| to_char(XLPL.CID) ||' больше одного получателя');
      WHEN OTHERS THEN
        vsPID := 0;
    END;
	RETURN TO_CHAR(vsPID);

    IF vsCATEGORY = 2 THEN
      for i in 1..AALLOC_CODE.Count
      LOOP
        vsALLOC_CODE := AALLOC_CODE(i);

--**********************
-- Пособие на погребение
--**********************

        vsCONTROL_ALLOC_CODE := 550;
        vsROLE := 60;
        BEGIN
          select VALUE INTO vsVALUE from REF_ALLOCATION_ROLE
		  where code = vsRole
		    and Start_Date <= XLPL.WorkDate
			and (End_Date >= XLPL.WorkDate or End_Date is null);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            raise_application_error(-20801, 'Отсутствует информация в REF_ALLOCATION_ROLE');
        END;
        select count(*) INTO bufI from ALLOCATIONS
		where CODE = vsCONTROL_ALLOC_CODE start with CODE = vsALLOC_CODE connect by prior PARENT_CODE = CODE;
        IF (bufI <> 0) THEN
          BEGIN
            select PID INTO vsPID from W$CASE_PERSON
			where CID = XLPL.CID
			  and W$CASE_PERSON.ROLE = vsROLE
			  and rownum = 1
			  and STAGE in (1,4);
            RETURN TO_CHAR(vsPID);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              raise_application_error(-20801, 'Отсутствует лицо с ролью '''||vsVALUE||'''');
          END;
        END IF;

--*****************************************************************
-- Пособие на погибшего при исполнении служебного долга за рубежом
--****************************************************************

        vsCONTROL_ALLOC_CODE := 540;
        vsROLE := 70;
        BEGIN
          select VALUE INTO vsVALUE from REF_ALLOCATION_ROLE
		  where code = vsROLE
		    and Start_Date <= XLPL.WorkDate
			and (End_Date >= XLPL.WorkDate or End_Date is null);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            raise_application_error(-20801, 'Отсутствует информация в REF_ALLOCATION_ROLE');
        END;
        select count(*) INTO bufI from ALLOCATIONS
		where CODE = vsCONTROL_ALLOC_CODE start with CODE = vsALLOC_CODE connect by prior PARENT_CODE = CODE;
        IF (bufI <> 0) THEN
          BEGIN
            select PID INTO vsPID from W$CASE_PERSON
			where CID = XLPL.CId
			  and W$CASE_PERSON.ROLE = vsROLE
			  and rownum = 1
			  and STAGE in (1,4);
            RETURN TO_CHAR(vsPID);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              raise_application_error(-20801, 'Отсутствует лицо с ролью '''||vsVALUE||'''');
          END;
        END IF;

--*****************
-- Пособие по уходу
--*****************

        vsCONTROL_ALLOC_CODE := 530;
        vsROLE := 59;
        BEGIN
          select VALUE INTO vsVALUE from REF_ALLOCATION_ROLE
		  where code = vsROLE
		    and Start_Date <= XLPL.WorkDate
			and (End_Date >= XLPL.WorkDate or End_Date is null);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            raise_application_error(-20801, 'Отсутствует информация в REF_ALLOCATION_ROLE');
        END;
        select count(*) INTO bufI from ALLOCATIONS
		where CODE = vsCONTROL_ALLOC_CODE start with CODE = vsALLOC_CODE connect by prior PARENT_CODE = CODE;
        IF (bufI <>L 0) THEN
          BEGIN
            select PID INTO vsPID from W$CASE_PERSON
			where CID = XLPL.CID
			  and W$CASE_PERSON.ROLE = vsROLE
			  and rownum = 1
			  and STAGE in (1,4);
            RETURN TO_CHAR(vsPID);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              raise_application_error(-20801, 'Отсутствует лицо с ролью '''||vsVALUE||'''');
          END;
        END IF;

--****************
-- Детские пособия
--*****************

        select count(*) INTO bufI from W$CASE_PERSON
		where CID = XLPL.CID
		  and PID = vsPID
		  and STAGE in (1,4);
        IF (bufI <> 0) THEN
          RETURN TO_CHAR(vsPID);
        ELSE
          		 vsCONTROL_ALLOC_CODE := 400;
          		 vsROLE := 55;
          		 BEGIN
            	 	  select VALUE INTO vsVALUE from REF_ALLOCATION_ROLE
					  where code = vsROLE
			  		  and Start_Date <= XLPL.WorkDate
			  		  and (End_Date >= XLPL.WorkDate or End_Date is null);
          		 EXCEPTION
            	 WHEN NO_DATA_FOUND THEN
              	 	  raise_application_error(-20801, 'Отсутствует информация в REF_ALLOCATION_ROLE');
          		 END;

          		 vsROLE1 := 57;
          		 BEGIN
            	 select VALUE INTO vsVALUE1 from REF_ALLOCATION_ROLE
				 where code = vsROLE
			  	 	   and Start_Date <= XLPL.WorkDate
			  		   and (End_Date >= XLPL.WorkDate or End_Date is null);
          		 EXCEPTION
            	 WHEN NO_DATA_FOUND THEN
              	 	  raise_application_error(-20801, 'Отсутствует информация в REF_ALLOCATION_ROLE');
          		 END;

          		 vsROLE2 := 52;
          		 BEGIN
            	 select VALUE INTO vsVALUE2 from REF_ALLOCATION_ROLE
				 where code = vsROLE1
			  	 	   and Start_Date <= XLPL.WorkDate
			  		   and (End_Date >= XLPL.WorkDate or End_Date is null);
          		 EXCEPTION
            	 WHEN NO_DATA_FOUND THEN
              	 	  raise_application_error(-20801, 'Отсутствует информация в REF_ALLOCATION_ROLE');
          		 END;

          		 select count(*) INTO bufI from ALLOCATIONS
		  		 where CODE = vsCONTROL_ALLOC_CODE start with CODE = vsALLOC_CODE connect by prior PARENT_CODE = CODE;
          		 	   IF (bufI <> 0) THEN
            	 	   BEGIN
              	 	   select PID INTO vsPID from W$CASE_PERSON
			  		   where CID = XLPL.CID
			    	   and (W$CASE_PERSON.ROLE = vsROLE or W$CASE_PERSON.ROLE = vsROLE1 or W$CASE_PERSON.ROLE = vsROLE2)
					   and rownum = 1
					   and STAGE in (1,4);
              		   RETURN TO_CHAR(vsPID);
            		   EXCEPTION
              		   WHEN NO_DATA_FOUND THEN
                	   		raise_application_error(-20801, 'Отсутствует лицо с ролью '''||vsVALUE||''' или '''||vsVALUE1||''' или '''||vsVALUE2||'''');
            		   END;
          			   END IF;
        END IF;
      END LOOP;
    END IF;
  ELSE
    BEGIN
      select PID INTO vsPID from W$CASE_PERSON
	  where CID = XLPL.CID
	    and rownum =1
		and STAGE in (1,4);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        raise_application_error(-20801, 'Ошибка при работе с W$CASE_PERSON');
    END;
  END IF;
  RETURN TO_CHAR(vsPID); */

END A_F_GETRECIPIENT;
/
