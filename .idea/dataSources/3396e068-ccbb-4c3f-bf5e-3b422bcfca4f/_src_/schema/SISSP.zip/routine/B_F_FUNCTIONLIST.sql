CREATE FUNCTION       B_F_FunctionList (bufDate IN DATE) RETURN BOOLEAN AS

/***************************************************************************************
// Функция: B_F_FunctionList
// Наименование: Проверка, занимается ли лицо деятельностью, учитываемой при назначении пособий в Собесе
// Автор: Ворошилин В.
// Состояние на дату 12.07.2002
// Код возврата: True - если да, False - если ее нет
//***************************************************************************************/


BEGIN
 if    	   	   	 			   	 	  	              -- Если получатель НЕ
      B_F_Actv_RabSobes		           or 			  -- является работающим или
	  B_F_Actv_LearnSobes              or			  -- является учащимся или
	  B_F_Actv(3, bufDate) 	   		   or 			  -- является безработным
	  B_F_Pension 			   		   or 			  -- получает пенсию
	  B_F_BENEFITUNTIL3(420, bufDate)  or			  -- получает пособие по уходу за ребенком до 3 лет
	  B_F_BENEFITUNTIL3(490, bufDate)  or			  -- получает пособие по уходу за ребенком-инвалидом
	  B_F_BENEFITUNTIL3(530, bufDate)  or			  -- получает пособие по уходу за инвалидом 1 группы или престарелым
	  B_F_Metric(258, bufDate) 		   or			  -- получает пособие по уходу за инвалидом 1 группы или престарелым или ребенком-инвалидом
      B_F_Metric(650, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(651, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(652, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(653, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(654, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(655, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(656, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(657, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(658, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(659, bufDate) 		   or			  -- получает пенсию вне собеса
	  B_F_Metric(121, bufDate) 		   or			  -- является военнослужащим срочной службы
	  B_F_Metric(122, bufDate) 		   or			  -- является военнослужащим срочной службы
	  B_F_Metric(123, bufDate) 		   or			  -- является военнослужащим срочной службы
	  B_F_Metric(124, bufDate) 		   or			  -- является военнослужащим срочной службы
	  B_F_Metric(125, bufDate) 		   or			  -- является военнослужащим срочной службы
	  B_F_Metric(126, bufDate) 		   or	  		  -- является военнослужащим срочной службы
	  B_F_Disability(11, bufDate)  	   or		  	  -- является инвалидом 1 группы
	  B_F_Disability(12, bufDate)  	   or		  	  -- является инвалидом 2 группы
	  B_F_Disability(13, bufDate)
  then
    return True;
  else
    return false;
  end if;
END B_F_FunctionList;
/
