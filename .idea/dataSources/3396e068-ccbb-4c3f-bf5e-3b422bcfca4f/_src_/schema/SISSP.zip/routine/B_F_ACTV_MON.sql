CREATE FUNCTION       B_F_ACTV_MON(A_LABOR IN NUMBER) RETURN boolean IS

/******************************************************************************

   Наименование: Функция определения факта работы, учебы, безработицы лица по одному коду
   Возвращает: True - если лицо активно, False - если лицо не активно
   NAME:       Трухтанов
   10.07.2002
******************************************************************************/
CN_ACTIVITY number;
BEGIN
  Select COUNT(*) into CN_ACTIVITY
  From W$ACTIVITY
  Where PID   = XLPL.GETPID and
        LABOR = A_LABOR and
		ENTERED_BY = XLPL.USER_ID and
		STAGE NOT IN(2,3) and
        (PERIOD_START <= XLPL.workdate and NVL(PERIOD_END, XLPL.workdate) >= XLPL.workdate);

  if (CN_ACTIVITY <> 0)
    then return true;
    else return false;
  end if;

END B_F_ACTV_MON;
/
