CREATE FUNCTION       B_F_ARRAYDATECHANGEACTIVITY(pactivity in number,PuskDate in date, Param6m in number ) RETURN DBMS_SQL.NUMBER_TABLE IS
/*------------------------------------------------------------------------------
Функция          : B_F_ARRAYDATECHANGEACTIVITY
Наименование     : Функция возвращает массив дат изменения общей информации о лице
Автор            : Трухтанов            Корректировка: РАВ
Состояние на дату: 25.08.1999	        01,07.2014	28.07.2014	20.11.2014
--------------------------------------------------------------------------------*/
chahge_date_aRecord DBMS_SQL.NUMBER_TABLE;
DateTalk date;
DateTalk1 date;
lab       NUMBER;	--RAV 01,07.2014


BEGIN
  DateTalk := A_F_DataTalk();
  --DateTalk1 := Last_Day(S_CurrDate);  RAV 01,07.2014
  DateTalk1 := Last_Day(S_CurrDate)+1;
--  select Last_Day(sysdate) into DateTalk1 from dual;

    --РАВ 01,07.2014-- for Rec in (select nvl(PERIOD_START, null) as dat_start, nvl(PERIOD_END, null) as dat_end
   for Rec in (
       SELECT nvl(PERIOD_START, null) as dat_start, nvl(PERIOD_END, null) as dat_end, nvl(labor, 0)  as lab --РАВ 01,07.2014
  	     from W$ACTIVITY
   	    where PID = XLPL.GETPID
          AND ACTIVITY = pactivity
          AND (PERIOD_START > PuskDate OR PERIOD_END > PuskDate OR (PERIOD_START > PuskDate and PERIOD_END is NULL))
          AND STAGE in (1, 4)
          and ENTERED_BY =  XLPL.USER_ID)
    LOOP
       -- Param6m = 1 - только для нового назначения- дата обращения превышает на 6 мес. дату начала действия назначения
       -- Param6m = 0 - для нового назначения и перерасчета - дата обращения не превышает на 6 мес. даты возникновения права
	   if     (REC.dat_start is not null)
          AND (REC.dat_start > PuskDate)
          AND (REC.dat_start <= DateTalk1) then


           /* -РАВ 01,07.2014
             if (Param6m = 1) AND (XLPL.AID = 0) then
	  	        chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), s_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
	         else
	            chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(Rec.Dat_start);
	       end if;   /* */
         -- РАВ 01,07.2014

	      if (Param6m = 1) AND (XLPL.AID = 0) then --новое назначение

     	     chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), s_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
          else  -- новое и перерасчет
            if Rec.lab in (200,206,207,208,214,215,308,217)    -- 01,07.2014 РАВ  20.11.2014(308 добавлена) РАВ
               and (XLPL.AID<>0)                           -- 28.07.2014 OLV  -- не проверила
              then
      	         chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(Last_day(Rec.dat_start)+1);--РАВ 01,07.2014
              else
              --RAISE_APPLICATION_ERROR(-20004,'B_F_ARRAYDATECHANGEACTIVITY    chahge_date_aRecord(2)= ' );
              --chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(Rec.Dat_start + 1);
                 chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(Rec.Dat_start); --РАВ  07.04.2015 c даты начала работы
	          end if;
	      end if;
	   end if;

	  if     (REC.dat_end is not null)
         AND (REC.dat_end > PuskDate)
         AND (REC.dat_end <= DateTalk1) then
         if (Param6m = 1) AND (XLPL.AID = 0) then
	  	     chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(s_EncodeDate(s_YearOfDate(DateTalk), s_MonthOfDate(DateTalk), 1)); -- то выбрать начало месяца подачи заявления
	     else -- новое и перерасчет
            if Rec.lab in (200,206,207,208,214,215,308,217)    -- 01,07.2014 РАВ 20.11.2014(308 добавлена) РАВ
               and (XLPL.AID<>0)                           -- 28.07.2014 OLV  -- проверила
              then
      	        chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(Last_day(Rec.dat_end)+1); --РАВ 01,07.2014
            else
                chahge_date_aRecord(chahge_date_aRecord.Count + 1) := s_julian(Rec.dat_end + 1);
	        end if;
         end if;
      end if;
  end loop;
 return A_F_ArrayDataChangeDelDup(chahge_date_aRecord);
         --RAISE_APPLICATION_ERROR(-20004,'B_F_ARRAYDATECHANGEACTIVITY    chahge_date_aRecord(2)= '||s_Jtod(chahge_date_aRecord(1))||CHR(10)||' Rec.lab='||Rec.lab||CHR(10));
END B_F_ARRAYDATECHANGEACTIVITY;
/
