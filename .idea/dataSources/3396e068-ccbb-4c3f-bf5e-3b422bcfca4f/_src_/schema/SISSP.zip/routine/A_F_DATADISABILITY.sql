CREATE FUNCTION       A_F_DataDisability(aPID in NUMBER, aDate_talk IN DATE, aDate_Alloc_Restore IN DATE) RETURN Date IS
/***************************************************************************************
 Функция             : A_F_DataDisability
 Наименование        : Функция получения даты наступления инвалидности с детсва у иждивенца
 Автор               : ОЛВ
 Состояние на дату   : 18.03.2011
 Код возврата        : Дата наступления инвалидности
***************************************************************************************/
 Start_Disability   date;
BEGIN
  Start_Disability := NULL;
 BEGIN
		  FOR c1 IN
            (  SELECT a.EXAMED_from AS pStart_Date ,b.Record_Start AS pEnd_Date
		       FROM    W$MRAK_OPINION a,W$MRAK_OPINION_ADVICE b
               WHERE a.PID = aPID
			        AND b.MRAK_RID = a.rid
                    AND a.ENTERED_BY = Xlpl.USER_ID
                    AND b.advice_type IN (11,12,13,14)
					AND  b.dis_reason IN (4,5,6,15)
			        AND	b.opinion_type=1
			        AND	b.stage IN (1,4)
					/* *
			        AND	a.EXAMED_FROM =
                           (  SELECT MIN(c.EXAMED_FROM)
                           --(  SELECT c.EXAMED_FROM
			                  FROM W$MRAK_OPINION c,W$MRAK_OPINION_ADVICE d
                              WHERE c.PID = aPID
                                   AND d.MRAK_RID = c.rid
                                   AND c.ENTERED_BY = Xlpl.USER_ID
                                   AND c.EXAMED_FROM <= aDate_talk
                                   AND d.advice_type IN (11,12,13,14)
                                   AND d.dis_reason IN (4,5,6,15)
						         --  and d.RECORD_END is null
                                   AND d.opinion_type=1 )/* */
              )
              LOOP
                   IF c1.pStart_Date > aDate_Alloc_Restore THEN
                       Start_Disability := c1.pStart_Date;
		           END IF;
              END LOOP;

 EXCEPTION
      WHEN NO_DATA_FOUND THEN
            Start_Disability := NULL;
 END;
   /* *
 raise_application_error(-20004,'A_F_DataDisability    '||CHR(10)||'  Date_talk='||aDate_talk||'   pPID='||aPID
 ||'   Start_Disability ='||Start_Disability
 ||'   Date_Alloc_Restor='||aDate_Alloc_Restore); /* */


   return Start_Disability;
END A_F_DataDisability;
/
