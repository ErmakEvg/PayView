CREATE FUNCTION       B_F_CountAIDDate(aAllocCode in NUMBER,
                                            aTestDate in DATE) RETURN NUMBER IS
--==============================================================================
-- Назначение: считает количество указанных назначений
--             у выбранного лица на требуемую дату
--------------------------------------------------------------------------------
-- Автор: Ворошилин В.Я.      (РМП)
--------------------------------------------------------------------------------
-- Входные праметры:
---------------------
-- aAllocCode
-- aTestDate
--------------------------------------------------------------------------------
-- Возвращаемое значение: количество назначений
--==============================================================================

xResume NUMBER;
xPID NUMBER;

BEGIN
xPID := XLPL.GETPID;
select distinct count (*) into xResume
from ALLOCATION a,
     ALLOCATION_PERSON b,
	 CASE_PERSON c,
	 RECIPIENT d
where a.RID = b.ALLOCATION_RID
and a.ALLOC_STATUS = 1
and b.PID = xPID
and c.PID = b.PID
and d.CID = c.CID
and d.PID = b.PID
and (c.STAGE <> 3 or c.STAGE is NULL)
and (a.STAGE <> 3 or a.STAGE is NULL)
and (b.STAGE <> 3 or b.STAGE is NULL)
and (d.STAGE <> 3 or d.STAGE is NULL)
and a.ALLOC_CODE in (select CODE
                     from ALLOCATIONS
					 start with CODE = aAllocCode
					 connect by prior CODE = PARENT_CODE)
and NVL(STEP_START, aTestDate) <= aTestDate
and NVL(STEP_END, aTestDate) >= aTestDate;
RETURN xResume;
END B_F_CountAIDDate;
/
