CREATE FUNCTION       ad_Um(cid# VARCHAR2, entered_by# VARCHAR2) RETURN VARCHAR2 IS text VARCHAR2(2000);
BEGIN
select distinct
oblast.value||' '||oblastr.value||' '||raion.value||' '||raionr.value||' '||derevnia.value ||' '||site.value  ||' '|| street.value||house.value ||house_x.value ||appt.value /*подзапросы возвращают символ пробела, если в базе пустая запись */
into text
from
(select nvl(( select sd.value
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid =cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code = (select sd.parent_code
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid = cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code =  (select sd.parent_code
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid = cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code =wad.site))),' ') value from dual) oblast,
(select nvl(( select rsd.catshortname
from
w$address wad,
w$case_person wcp,
state_division sd,
ref_st_division_levels rsd
where
wcp.cid = cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  rsd.code = sd.level_code
and  sd.code =  (select sd.parent_code
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid = cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code = (select sd.parent_code
from
w$address wad,
w$case_person wcp,
state_division sd,
ref_st_division_levels rsd
where
wcp.cid =cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code =wad.site
and  rsd.code = sd.level_code))),' ') value from dual) oblastr,
(select nvl(( select sd.value
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid =cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code =  (select sd.parent_code
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid = cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code =wad.site)),' ') value from dual) raion,
(select nvl(( select rsd.catshortname
from
w$address wad,
w$case_person wcp,
state_division sd,
ref_st_division_levels rsd
where
wcp.cid =cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  rsd.code = sd.level_code
and  sd.code =  (select sd.parent_code
from
w$address wad,
w$case_person wcp,
state_division sd,
ref_st_division_levels rsd
where
wcp.cid = cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code =wad.site
and  rsd.code = sd.level_code)),' ') value from dual) raionr,
(select nvl(( select rsd.catshortname
from
w$address wad,
w$case_person wcp,
state_division sd,
ref_st_division_levels rsd
where
wcp.cid =cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code = wad.site
and  rsd.code = sd.level_code),' ') value from dual) derevnia,
(select nvl(( select sd.value
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid = cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code = wad.site),' ') value from dual) site,
(select nvl(( select ' ул. '||sd.value
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid = cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by =  wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code = wad.street),' ') value from dual) street,
(select nvl(( select ' д. '||wad.house
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid =cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code = wad.site),' ') value from dual) house,
(select nvl(( select ' корп. '||wad.house_x
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid = cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code = wad.site),' ') value from dual) house_x,
(select nvl(( select ' кв. '||wad.appt
from
w$address wad,
w$case_person wcp,
state_division sd
where
wcp.cid =cid#
and  wcp.entered_by =  entered_by#
and  wcp.role in(60)
and  wad.pid = wcp.pid
and  wad.entered_by = wcp.entered_by
and  wad.stage in(1,4)
and  wad.ADDRESS_TYPE in (2,3)
and  sd.code = wad.site),' ') value from dual) appt;
  RETURN TEXT;
END;
/
