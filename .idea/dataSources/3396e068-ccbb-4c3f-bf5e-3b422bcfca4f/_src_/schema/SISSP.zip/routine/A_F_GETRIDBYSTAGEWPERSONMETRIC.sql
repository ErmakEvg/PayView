CREATE FUNCTION       A_F_GetRIDbyStageWPersonMetric(ACODE in number,
   ASTAGE in number,ADataNorm in number) RETURN NUMBER IS
/***************************************************************************************
 Функция             : A_F_GetRIDbyStageWPersonMetric
 Наименование        : Функция формирования связки в W$RELATION_PROTOCOL по PERSON_METRIC
                       для заданного PID
 Автор               : Вахромин О.Ю.                     Комментарии: ОЛВ
 Состояние на дату   : 						 			              24.05.2012
 Код возврата        : Возвращает получателя из ОДБ
***************************************************************************************/
/*
 ACODES список кодов  через запятую без пробела
     если ACODES пустой, то НИЧЕГО не выбирается
Вахромин О.Ю.*/
vsDRID number;
vsSWorkDate date;
vsEWorkDate date;
WorkDate date;
vsPid number;
vsData_Rid varchar2(200);
rez boolean;
xACODES DBMS_SQL.NUMBER_TABLE;
BEGIN
   vsDRID:=-1;
   WorkDate:=XLPL.WorkDate;
   vsPid:=XLPL.GetPid;
   if ADataNorm=0 then
      vsSWorkDate:=WorkDate;
      vsEWorkDate:=WorkDate;
   elsif ADataNorm=1 then -- Нормируется Record_start
      vsSWorkDate:=S_FirstDayOfMonth(WorkDate);
      vsEWorkDate:=WorkDate;
   elsif ADataNorm=2 then -- Нормируется Record_end
      vsSWorkDate:=WorkDate;
      vsEWorkDate:=S_FirstDayOfMonth(WorkDate);
   elsif ADataNorm=3 then -- Нормируется Record_start  Record_end
      vsSWorkDate:=S_FirstDayOfMonth(WorkDate);
      vsEWorkDate:=S_FirstDayOfMonth(WorkDate);
   else
      null;
   end if;
   if (ADataNorm=1)or(ADataNorm=3) then
      begin
         select RID into vsDRID from W$PERSON_METRIC where PID=vsPID and
            ENTERED_BY=XLPL.USER_ID and
            ((NVL(RECORD_START,vsSWorkDate)<vsSWorkDate) or (RECORD_START is NULL)) and
            (NVL(RECORD_END,vsEWorkDate)>=vsEWorkDate) and STAGE=ASTAGE and CODE=ACODE;
      exception
         when No_Data_Found then
            vsDRID:=-1;
      end;
      if vsDRid is NULL then
         vsDRID:=-1;
      end if;
   end if;
   if (ADataNorm=0)or(ADataNorm=2) then
      begin
         select RID into vsDRID from W$PERSON_METRIC where PID=vsPID and
            ENTERED_BY=XLPL.USER_ID and
            ((NVL(RECORD_START,vsSWorkDate)<=vsSWorkDate) or (RECORD_START is NULL)) and
            (NVL(RECORD_END,vsEWorkDate)>=vsEWorkDate) and STAGE=ASTAGE and CODE=ACODE;
      exception
         when No_Data_Found then
            vsDRID:=-1;
      end;
      if vsDRid is NULL then
         vsDRID:=-1;
      end if;
   end if;
   if ADataNorm=4 then
      begin
         select RID into vsDRID from W$PERSON_METRIC where PID=vsPID and
            ENTERED_BY=XLPL.USER_ID and STAGE=ASTAGE and CODE=ACODE;
      exception
         when No_Data_Found then
            vsDRID:=-1;
      end;
      if vsDRid is NULL then
         vsDRID:=-1;
      end if;
   end if;
   --Боровнева - проверка был ли старый шаг назначения расссчитан на характеристике из ОБД
   -- если да - то vsDRID добавляется в связку ; если нет - то vsDRID  не добавляется  15.05.2000
   if (ASTAGE=1)and(XLPL.AID>0) then
     begin
         SELECT DATA_RID into vsData_Rid FROM RELATION_ALLOC_DATA WHERE
            ALLOCATION_RID=
            (SELECT RID FROM ALLOCATION WHERE CID=XLPL.CID AND AID=XLPL.AID AND
               PARENT_RID IS NULL AND COMP_PART IS NULL AND
               XLPL.WorkDate between STEP_START AND NVL(step_end,XLPL.WorkDAte) AND
               Close_Date IS NULL) AND
            RELATION_TABLE=
               (SELECT CODE FROM SISSP_TABLES WHERE NAME_TABLE ='PERSON_METRIC');
      exception
         when No_Data_Found then
            vsDRID:=-1;
     -- end;
      if vsDRid is NULL then
         vsDRID:=-1;
      end if;
   --end if;
      if vsDRID <> -1 then
         begin
           rez:=false;
           xACODES:=S_ParseFloatArray(vsData_Rid);
           for i in 1..xACODES.count loop
             rez:=(xACODES(i)=vsDRID);
           exit when rez;
           end loop;
          if not rez then
              vsDRID:=-1;
          end if;
         end;
      end if;
     end;
    end if;
    return vsDRID;
END A_F_GetRIDbyStageWPersonMetric;
/
