CREATE FUNCTION       B_F_FactToPayContribution return BOOLEAN is
/***************************************************************************************
// Функция: B_F_FactToPayContribution
// Наименование: Функция, определяющая, платили ли родители взносы в ФСЗ
// Автор: Гуз Е.
// Состояние на дату 04.02.1999
// Код возврата: True - лицо платит взносы, False - лицо не платит взносы
/***************************************************************************************/
SumContribution NUMBER;

BEGIN

SumContribution := B_F_AmountToPayContribution();
if SumContribution <> 0 then return True; else return False; end if;

END B_F_FactToPayContribution;
/
