CREATE FUNCTION       B_F_Arraydateestactivitygarden RETURN DBMS_SQL.NUMBER_TABLE AS
/*------------------------------------------------------------------------------------------------------------------------------------------
 Функция                : F_ArrayDateEstACTIVITYGarden
 Наименование       : Переключатель по датам
 Наименование       : возвращает массив с датой наступления 1,5 года для Estimation
 Автор                    : Ворошилин В.                 Корректировка:   ОЛВ
 Состояние на дату 03.05.2000                           22.05.2013
--------------------------------------------------------------------------------------------------------------------------------------------*/
  result_array DBMS_SQL.NUMBER_TABLE;
BEGIN
  IF Xlpl.WorkDate < TO_DATE('01-01-2013','DD-MM-YYYY') THEN -- 22.05.2013 ОЛВ
      IF Xlpl.WorkDate < TO_DATE('01-04-2002','DD-MM-YYYY') THEN
         RETURN B_F_Arraydateestgard_0;
      ELSE
         RETURN B_F_Arraydateestgard_20020401;
      END IF;
  ELSE
            result_array.DELETE;
            RETURN result_array;
  END IF;
END B_F_Arraydateestactivitygarden;
/
