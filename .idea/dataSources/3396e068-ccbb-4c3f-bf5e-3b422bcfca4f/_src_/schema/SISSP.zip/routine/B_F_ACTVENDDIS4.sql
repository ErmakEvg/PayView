CREATE FUNCTION       B_F_ActvEndDis4 RETURN Date as
/* Определение даты увольнения лица по причине ликвидации предприятия */
d date;
BEGIN
  begin
  select max(PERIOD_END) into d
	  from W$ACTIVITY
      where PID = XLPL.GetPID
	  and ACTIVITY in (1, 2)
	  and ENTERED_BY = XLPL.USER_ID
	  and LABOR is NULL
	  and DISMISSAL_REASON = 4;
  exception
      when NO_DATA_FOUND then
      d := NULL;
  end;
return d;
END B_F_ActvEndDis4;
/
