CREATE FUNCTION       A_F_Address_Text(pADDRESS_TYPE in NUMBER,ppVALUE in VARCHAR) RETURN BOOLEAN IS
/***************************************************************************************
 NAME              : A_F_RelProtAddress_Text
 Наименование      : Функция возвращает TRUE, если пенсионер проживает по указанному адресу в РБ
 Автор             : ОЛВ
 Состояние на дату : 16.05.2011
 Код возврата      : TRUE или FALSE
***************************************************************************************/
 vsDRID          NUMBER;
 vsTEXT_ADDRESS  varchar(255);
 pVALUE          varchar(10);  -- ???? сколько ????
BEGIN
 -- pADDRESS_TYPE - ТИП АДРЕСА; АДРЕС ПРОПИСКИ И/ИЛИ АДР. ПРОЖИВ. (1 - РЕГИСТР., 2 - ПРОЖИВ., 3 - ТО И  ДР.)
 -- ppVALUE
 -- TEXT_ADDRESS  - НАСЕЛЁННЫЙ ПУНКТ введенный вручную
 pVALUE:=upper('%'||ppVALUE||' %');

 -- Выбрать адрес в РБД RID из W$ADDRESS
   begin
	     SELECT TEXT_ADDRESS
		   INTO vsTEXT_ADDRESS
		   FROM W$ADDRESS
		  where PID=XLPL.GetPID
		    AND STAGE IN (1,4)
			AND (XLPL.WorkDate between NVL(RECORD_START,XLPL.WORKDATE) and
                                      NVL(RECORD_END,XLPL.WORKDATE) )
			and ((ADDRESS_TYPE= pADDRESS_TYPE) OR (ADDRESS_TYPE= 3)) --ADDRESS_TYPE= pADDRESS_TYPE
		    AND upper(TEXT_ADDRESS) LIKE pVALUE
			AND ((COUNTRY is NULL) OR (COUNTRY =1)) ;
   exception
        when NO_DATA_FOUND then
            vsTEXT_ADDRESS:=NULL;
   end;

 if  vsTEXT_ADDRESS IS NULL then
      RETURN FALSE;
 else
      RETURN TRUE;
 end if;
--RAISE_APPLICATION_ERROR(-20004,'A_F_RelProtAddress 1 xlpl.GetPid=' || xlpl.GetPid ||'  vsTEXT_ADDRESS='||vsTEXT_ADDRESS );
END A_F_Address_Text;
/
