CREATE FUNCTION       A_F_Relprotrecord(pCODE IN NUMBER) RETURN NUMBER IS
/*Возвращает стаж человека согласно W$RELATION_PROTOCOL и кода
Вахромин О.Ю.*/
BEGIN




   RETURN A_F_Relprotgetbyridrecord(0,pCODE)+A_F_Relprotgetbyridrecord(1,pCODE)+
      A_F_Relprotgetbyridmrecord(0,pCODE)+A_F_Relprotgetbyridmrecord(1,pCODE);
END A_F_Relprotrecord;
/
